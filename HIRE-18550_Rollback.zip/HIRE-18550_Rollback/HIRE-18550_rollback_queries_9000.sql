
--Total 3000

   --row number: 6001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3041448 , [Content] ='EXEMPT'
 WHERE id=186662545


   --row number: 6002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3041448 , [Content] ='NO'
 WHERE id=186662546


   --row number: 6003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3041448 , [Content] ='1.1 - Executive/Senior Level Officials and Managers'
 WHERE id=186662547


   --row number: 6004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3041448 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186662548


   --row number: 6005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3041448 , [Content] ='Technical'
 WHERE id=186662549


   --row number: 6006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3041448 , [Content] ='06/08/18'
 WHERE id=186662550


   --row number: 6007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3042700 , [Content] ='4923 IND'
 WHERE id=186745089


   --row number: 6008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3042700 , [Content] ='IND'
 WHERE id=186745090


   --row number: 6009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3042700 , [Content] ='APAC'
 WHERE id=186745091


   --row number: 6010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3042700 , [Content] ='INDIA'
 WHERE id=186745092


   --row number: 6011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3042700 , [Content] ='Info Systems/Technology'
 WHERE id=186745093


   --row number: 6012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3042700 , [Content] ='4923 - Incident Response Analyst IC3'
 WHERE id=186745094


   --row number: 6013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3042700 , [Content] ='Incident Response'
 WHERE id=186745095


   --row number: 6014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3042700 , [Content] ='IC3'
 WHERE id=186745096


   --row number: 6015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3042700 , [Content] ='INR'
 WHERE id=186745098


   --row number: 6016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3042700 , [Content] ='1,027,600 / 1,258,800 / 1,490,000 / 1,721,200 / 1,952,400'
 WHERE id=186745099


   --row number: 6017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3042700 , [Content] ='15%'
 WHERE id=186745101


   --row number: 6018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3042700 , [Content] ='Yes'
 WHERE id=186745102


   --row number: 6019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3042700 , [Content] ='2 - Professionals'
 WHERE id=186745103


   --row number: 6020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3042700 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186745104


   --row number: 6021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3042700 , [Content] ='Technical'
 WHERE id=186745105


   --row number: 6022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3042700 , [Content] ='09/05/18'
 WHERE id=186745106


   --row number: 6023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3043437 , [Content] ='2 - Professionals'
 WHERE id=186801536


   --row number: 6024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3043437 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186801537


   --row number: 6025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3043437 , [Content] ='Technical'
 WHERE id=186801538


   --row number: 6026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3043437 , [Content] ='6/27/2018'
 WHERE id=186801539


   --row number: 6027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3043437 , [Content] ='6534 US - MRKT 1'
 WHERE id=186801520


   --row number: 6028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3043437 , [Content] ='US - MRKT 1'
 WHERE id=186801521


   --row number: 6029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3043437 , [Content] ='AMS'
 WHERE id=186801522


   --row number: 6030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3043437 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186801523


   --row number: 6031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3043437 , [Content] ='Info Systems/Technology'
 WHERE id=186801524


   --row number: 6032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3043437 , [Content] ='6534 - Web Developer IC4'
 WHERE id=186801525


   --row number: 6033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3043437 , [Content] ='Web Development'
 WHERE id=186801526


   --row number: 6034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3043437 , [Content] ='IC4'
 WHERE id=186801527


   --row number: 6035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3043437 , [Content] ='USD'
 WHERE id=186801529


   --row number: 6036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3043437 , [Content] ='100,300 / 121,300 / 142,300 / 163,350 / 184,400'
 WHERE id=186801530


   --row number: 6037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3043437 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=186801531


   --row number: 6038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3043437 , [Content] ='20%'
 WHERE id=186801532


   --row number: 6039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3043437 , [Content] ='Yes'
 WHERE id=186801533


   --row number: 6040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3043437 , [Content] ='EXEMPT'
 WHERE id=186801534


   --row number: 6041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3043437 , [Content] ='NO'
 WHERE id=186801535


   --row number: 6042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3044383 , [Content] ='20%'
 WHERE id=186851311


   --row number: 6043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3044383 , [Content] ='Yes'
 WHERE id=186851312


   --row number: 6044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3044383 , [Content] ='EXEMPT'
 WHERE id=186851313


   --row number: 6045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3044383 , [Content] ='NO'
 WHERE id=186851314


   --row number: 6046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3044383 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=186851315


   --row number: 6047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3044383 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186851316


   --row number: 6048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3044383 , [Content] ='Non Technical'
 WHERE id=186851317


   --row number: 6049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3044383 , [Content] ='6/27/2018'
 WHERE id=186851318


   --row number: 6050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3044383 , [Content] ='3573 US - MRKT 2'
 WHERE id=186851299


   --row number: 6051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3044383 , [Content] ='US - MRKT 2'
 WHERE id=186851300


   --row number: 6052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3044383 , [Content] ='AMS'
 WHERE id=186851301


   --row number: 6053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3044383 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186851302


   --row number: 6054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3044383 , [Content] ='Marketing'
 WHERE id=186851303


   --row number: 6055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3044383 , [Content] ='3573 - Mgr, Content Development Mgmt M3'
 WHERE id=186851304


   --row number: 6056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3044383 , [Content] ='Content Development'
 WHERE id=186851305


   --row number: 6057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3044383 , [Content] ='M3'
 WHERE id=186851306


   --row number: 6058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3044383 , [Content] ='USD'
 WHERE id=186851308


   --row number: 6059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3044383 , [Content] ='87,400 / 105,700 / 124,000 / 142,300 / 160,600'
 WHERE id=186851309


   --row number: 6060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3044383 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=186851310


   --row number: 6061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3044476 , [Content] ='NO'
 WHERE id=186858945


   --row number: 6062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3044476 , [Content] ='4 - Sales Workers'
 WHERE id=186858946


   --row number: 6063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3044476 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186858947


   --row number: 6064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3044476 , [Content] ='Technical'
 WHERE id=186858948


   --row number: 6065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3044476 , [Content] ='6/27/2018'
 WHERE id=186858949


   --row number: 6066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3044476 , [Content] ='S1414A US - MRKT 1'
 WHERE id=186858929


   --row number: 6067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3044476 , [Content] ='US - MRKT 1'
 WHERE id=186858930


   --row number: 6068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3044476 , [Content] ='AMS'
 WHERE id=186858931


   --row number: 6069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3044476 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186858932


   --row number: 6070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3044476 , [Content] ='Solution Consulting'
 WHERE id=186858933


   --row number: 6071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3044476 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=186858934


   --row number: 6072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3044476 , [Content] ='Solution Consultant Architect'
 WHERE id=186858935


   --row number: 6073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3044476 , [Content] ='IC4'
 WHERE id=186858936


   --row number: 6074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3044476 , [Content] ='USD'
 WHERE id=186858938


   --row number: 6075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3044476 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=186858939


   --row number: 6076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3044476 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=186858940


   --row number: 6077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3044476 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=186858941


   --row number: 6078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3044476 , [Content] ='75/25'
 WHERE id=186858942


   --row number: 6079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3044476 , [Content] ='Yes'
 WHERE id=186858943


   --row number: 6080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3044476 , [Content] ='EXEMPT'
 WHERE id=186858944


   --row number: 6081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3044477 , [Content] ='NO'
 WHERE id=186859147


   --row number: 6082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3044477 , [Content] ='4 - Sales Workers'
 WHERE id=186859148


   --row number: 6083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3044477 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186859149


   --row number: 6084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3044477 , [Content] ='Technical'
 WHERE id=186859150


   --row number: 6085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3044477 , [Content] ='6/27/2018'
 WHERE id=186859151


   --row number: 6086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3044477 , [Content] ='S1414A US - MRKT 1'
 WHERE id=186859131


   --row number: 6087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3044477 , [Content] ='US - MRKT 1'
 WHERE id=186859132


   --row number: 6088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3044477 , [Content] ='AMS'
 WHERE id=186859133


   --row number: 6089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3044477 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186859134


   --row number: 6090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3044477 , [Content] ='Solution Consulting'
 WHERE id=186859135


   --row number: 6091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3044477 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=186859136


   --row number: 6092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3044477 , [Content] ='Solution Consultant Architect'
 WHERE id=186859137


   --row number: 6093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3044477 , [Content] ='IC4'
 WHERE id=186859138


   --row number: 6094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3044477 , [Content] ='USD'
 WHERE id=186859140


   --row number: 6095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3044477 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=186859141


   --row number: 6096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3044477 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=186859142


   --row number: 6097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3044477 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=186859143


   --row number: 6098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3044477 , [Content] ='75/25'
 WHERE id=186859144


   --row number: 6099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3044477 , [Content] ='Yes'
 WHERE id=186859145


   --row number: 6100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3044477 , [Content] ='EXEMPT'
 WHERE id=186859146


   --row number: 6101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3050862 , [Content] ='NO'
 WHERE id=186950973


   --row number: 6102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3050862 , [Content] ='5 - Administrative Support Workers'
 WHERE id=186950974


   --row number: 6103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3050862 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186950975


   --row number: 6104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3050862 , [Content] ='Non Technical'
 WHERE id=186950976


   --row number: 6105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3050862 , [Content] ='6/27/2018'
 WHERE id=186950977


   --row number: 6106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3050862 , [Content] ='S1202 US - MRKT 2'
 WHERE id=186950957


   --row number: 6107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3050862 , [Content] ='US - MRKT 2'
 WHERE id=186950958


   --row number: 6108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3050862 , [Content] ='AMS'
 WHERE id=186950959


   --row number: 6109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3050862 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186950960


   --row number: 6110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3050862 , [Content] ='Sales'
 WHERE id=186950961


   --row number: 6111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3050862 , [Content] ='S1202 - Sup, Inside Sales M2'
 WHERE id=186950962


   --row number: 6112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3050862 , [Content] ='Inside Sales'
 WHERE id=186950963


   --row number: 6113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3050862 , [Content] ='M2'
 WHERE id=186950964


   --row number: 6114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3050862 , [Content] ='USD'
 WHERE id=186950966


   --row number: 6115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3050862 , [Content] ='77,350 / 84,175 / 91,000 / 97,825 / 104,650'
 WHERE id=186950967


   --row number: 6116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3050862 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=186950968


   --row number: 6117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3050862 , [Content] ='110,500 / 120,250 / 130,000 / 139,750 / 149,500'
 WHERE id=186950969


   --row number: 6118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3050862 , [Content] ='70/30'
 WHERE id=186950970


   --row number: 6119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3050862 , [Content] ='Yes'
 WHERE id=186950971


   --row number: 6120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3050862 , [Content] ='EXEMPT'
 WHERE id=186950972


   --row number: 6121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3051764 , [Content] ='2 - Professionals'
 WHERE id=187013065


   --row number: 6122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3051764 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187013066


   --row number: 6123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3051764 , [Content] ='Technical'
 WHERE id=187013067


   --row number: 6124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3051764 , [Content] ='6/27/2018'
 WHERE id=187013068


   --row number: 6125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3051764 , [Content] ='5893 US - MRKT 1'
 WHERE id=187013049


   --row number: 6126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3051764 , [Content] ='US - MRKT 1'
 WHERE id=187013050


   --row number: 6127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3051764 , [Content] ='AMS'
 WHERE id=187013051


   --row number: 6128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3051764 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=187013052


   --row number: 6129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3051764 , [Content] ='Professional Services'
 WHERE id=187013053


   --row number: 6130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3051764 , [Content] ='5893 - Technical Curriculum Developer IC3'
 WHERE id=187013054


   --row number: 6131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3051764 , [Content] ='Technical Curriculum'
 WHERE id=187013055


   --row number: 6132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3051764 , [Content] ='IC3'
 WHERE id=187013056


   --row number: 6133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3051764 , [Content] ='USD'
 WHERE id=187013058


   --row number: 6134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3051764 , [Content] ='80,800 / 94,150 / 107,500 / 120,800 / 134,100'
 WHERE id=187013059


   --row number: 6135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3051764 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=187013060


   --row number: 6136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3051764 , [Content] ='10%'
 WHERE id=187013061


   --row number: 6137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3051764 , [Content] ='Yes'
 WHERE id=187013062


   --row number: 6138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3051764 , [Content] ='EXEMPT'
 WHERE id=187013063


   --row number: 6139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3051764 , [Content] ='NO'
 WHERE id=187013064


   --row number: 6140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3052576 , [Content] ='6/27/2018'
 WHERE id=187186740


   --row number: 6141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3052576 , [Content] ='5704 JPN'
 WHERE id=187186723


   --row number: 6142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3052576 , [Content] ='JPN'
 WHERE id=187186724


   --row number: 6143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3052576 , [Content] ='APAC'
 WHERE id=187186725


   --row number: 6144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3052576 , [Content] ='JAPAN'
 WHERE id=187186726


   --row number: 6145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3052576 , [Content] ='Professional Services'
 WHERE id=187186727


   --row number: 6146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3052576 , [Content] ='5704 - Client Relationship Manager IC4'
 WHERE id=187186728


   --row number: 6147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3052576 , [Content] ='Partner Support'
 WHERE id=187186729


   --row number: 6148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3052576 , [Content] ='IC4'
 WHERE id=187186730


   --row number: 6149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3052576 , [Content] ='JPY'
 WHERE id=187186732


   --row number: 6150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3052576 , [Content] ='8,509,200 / 10,292,100 / 12,075,000 / 13,857,850 / 15,640,700'
 WHERE id=187186733


   --row number: 6151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3052576 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=187186734


   --row number: 6152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3052576 , [Content] ='20%'
 WHERE id=187186735


   --row number: 6153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3052576 , [Content] ='Yes'
 WHERE id=187186736


   --row number: 6154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3052576 , [Content] ='2 - Professionals'
 WHERE id=187186737


   --row number: 6155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3052576 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187186738


   --row number: 6156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3052576 , [Content] ='Technical'
 WHERE id=187186739


   --row number: 6157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3052724 , [Content] ='6/27/2018'
 WHERE id=187206488


   --row number: 6158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3052724 , [Content] ='5674 NLD'
 WHERE id=187206472


   --row number: 6159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3052724 , [Content] ='NLD'
 WHERE id=187206473


   --row number: 6160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3052724 , [Content] ='EMEA'
 WHERE id=187206474


   --row number: 6161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3052724 , [Content] ='NETHERLANDS'
 WHERE id=187206475


   --row number: 6162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3052724 , [Content] ='Business Strategy'
 WHERE id=187206476


   --row number: 6163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3052724 , [Content] ='5674 - Business Strategy Mgr IC4'
 WHERE id=187206477


   --row number: 6164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3052724 , [Content] ='Business Strategy'
 WHERE id=187206478


   --row number: 6165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3052724 , [Content] ='IC4'
 WHERE id=187206479


   --row number: 6166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3052724 , [Content] ='EUR'
 WHERE id=187206481


   --row number: 6167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3052724 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=187206482


   --row number: 6168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3052724 , [Content] ='20%'
 WHERE id=187206483


   --row number: 6169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3052724 , [Content] ='Yes'
 WHERE id=187206484


   --row number: 6170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3052724 , [Content] ='2 - Professionals'
 WHERE id=187206485


   --row number: 6171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3052724 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187206486


   --row number: 6172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3052724 , [Content] ='Non Technical'
 WHERE id=187206487


   --row number: 6173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3052768 , [Content] ='Technical'
 WHERE id=187208567


   --row number: 6174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3052768 , [Content] ='6/27/2018'
 WHERE id=187208568


   --row number: 6175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3052768 , [Content] ='5874 ITA'
 WHERE id=187208551


   --row number: 6176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3052768 , [Content] ='ITA'
 WHERE id=187208552


   --row number: 6177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3052768 , [Content] ='EMEA'
 WHERE id=187208553


   --row number: 6178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3052768 , [Content] ='ITALY'
 WHERE id=187208554


   --row number: 6179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3052768 , [Content] ='Professional Services'
 WHERE id=187208555


   --row number: 6180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3052768 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=187208556


   --row number: 6181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3052768 , [Content] ='Engagement Mgrs'
 WHERE id=187208557


   --row number: 6182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3052768 , [Content] ='IC4'
 WHERE id=187208558


   --row number: 6183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3052768 , [Content] ='EUR'
 WHERE id=187208560


   --row number: 6184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3052768 , [Content] ='50,000 / 60,500 / 71,000 / 81,450 / 91,900'
 WHERE id=187208561


   --row number: 6185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3052768 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=187208562


   --row number: 6186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3052768 , [Content] ='20%'
 WHERE id=187208563


   --row number: 6187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3052768 , [Content] ='Yes'
 WHERE id=187208564


   --row number: 6188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3052768 , [Content] ='2 - Professionals'
 WHERE id=187208565


   --row number: 6189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3052768 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187208566


   --row number: 6190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3053485 , [Content] ='2 - Professionals'
 WHERE id=187271124


   --row number: 6191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3053485 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187271125


   --row number: 6192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3053485 , [Content] ='7/20/2018'
 WHERE id=187271127


   --row number: 6193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3053485 , [Content] ='5225 US - MRKT 1'
 WHERE id=187271108


   --row number: 6194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3053485 , [Content] ='US - MRKT 1'
 WHERE id=187271109


   --row number: 6195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3053485 , [Content] ='AMS'
 WHERE id=187271110


   --row number: 6196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3053485 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=187271111


   --row number: 6197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3053485 , [Content] ='Engineering'
 WHERE id=187271112


   --row number: 6198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3053485 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=187271113


   --row number: 6199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3053485 , [Content] ='Product Mgmt Mgr'
 WHERE id=187271114


   --row number: 6200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3053485 , [Content] ='IC5'
 WHERE id=187271115


   --row number: 6201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3053485 , [Content] ='USD'
 WHERE id=187271117


   --row number: 6202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3053485 , [Content] ='123,800 / 151,650 / 179,500 / 207,350 / 235,200'
 WHERE id=187271118


   --row number: 6203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3053485 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=187271119


   --row number: 6204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3053485 , [Content] ='25%'
 WHERE id=187271120


   --row number: 6205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3053485 , [Content] ='Yes'
 WHERE id=187271121


   --row number: 6206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3053485 , [Content] ='EXEMPT'
 WHERE id=187271122


   --row number: 6207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3053485 , [Content] ='NO'
 WHERE id=187271123


   --row number: 6208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054380 , [Content] ='6/27/2018'
 WHERE id=187375205


   --row number: 6209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054380 , [Content] ='5182 IND'
 WHERE id=187375189


   --row number: 6210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054380 , [Content] ='IND'
 WHERE id=187375190


   --row number: 6211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054380 , [Content] ='APAC'
 WHERE id=187375191


   --row number: 6212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054380 , [Content] ='INDIA'
 WHERE id=187375192


   --row number: 6213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054380 , [Content] ='Engineering'
 WHERE id=187375193


   --row number: 6214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054380 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=187375194


   --row number: 6215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054380 , [Content] ='Quality'
 WHERE id=187375195


   --row number: 6216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054380 , [Content] ='IC2'
 WHERE id=187375196


   --row number: 6217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054380 , [Content] ='INR'
 WHERE id=187375198


   --row number: 6218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054380 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=187375199


   --row number: 6219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054380 , [Content] ='10%'
 WHERE id=187375200


   --row number: 6220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054380 , [Content] ='No'
 WHERE id=187375201


   --row number: 6221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054380 , [Content] ='2 - Professionals'
 WHERE id=187375202


   --row number: 6222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054380 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187375203


   --row number: 6223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054380 , [Content] ='Technical'
 WHERE id=187375204


   --row number: 6224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054388 , [Content] ='10/05/18'
 WHERE id=187375911


   --row number: 6225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054388 , [Content] ='5182 IND'
 WHERE id=187375894


   --row number: 6226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054388 , [Content] ='IND'
 WHERE id=187375895


   --row number: 6227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054388 , [Content] ='APAC'
 WHERE id=187375896


   --row number: 6228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054388 , [Content] ='INDIA'
 WHERE id=187375897


   --row number: 6229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054388 , [Content] ='Engineering'
 WHERE id=187375898


   --row number: 6230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054388 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=187375899


   --row number: 6231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054388 , [Content] ='Quality'
 WHERE id=187375900


   --row number: 6232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054388 , [Content] ='IC2'
 WHERE id=187375901


   --row number: 6233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054388 , [Content] ='INR'
 WHERE id=187375903


   --row number: 6234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054388 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=187375904


   --row number: 6235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054388 , [Content] ='10%'
 WHERE id=187375906


   --row number: 6236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054388 , [Content] ='No'
 WHERE id=187375907


   --row number: 6237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054388 , [Content] ='2 - Professionals'
 WHERE id=187375908


   --row number: 6238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054388 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187375909


   --row number: 6239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054388 , [Content] ='Technical'
 WHERE id=187375910


   --row number: 6240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054391 , [Content] ='5183 IND'
 WHERE id=187376181


   --row number: 6241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054391 , [Content] ='IND'
 WHERE id=187376182


   --row number: 6242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054391 , [Content] ='APAC'
 WHERE id=187376183


   --row number: 6243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054391 , [Content] ='INDIA'
 WHERE id=187376184


   --row number: 6244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054391 , [Content] ='Engineering'
 WHERE id=187376185


   --row number: 6245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054391 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=187376186


   --row number: 6246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054391 , [Content] ='Quality'
 WHERE id=187376187


   --row number: 6247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054391 , [Content] ='IC3'
 WHERE id=187376188


   --row number: 6248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054391 , [Content] ='INR'
 WHERE id=187376190


   --row number: 6249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054391 , [Content] ='1,344,800 / 1,647,400 / 1,950,000 / 2,252,550 / 2,555,100'
 WHERE id=187376191


   --row number: 6250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3054391 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=187376192


   --row number: 6251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054391 , [Content] ='15%'
 WHERE id=187376193


   --row number: 6252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054391 , [Content] ='Yes'
 WHERE id=187376194


   --row number: 6253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054391 , [Content] ='2 - Professionals'
 WHERE id=187376195


   --row number: 6254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054391 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187376196


   --row number: 6255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054391 , [Content] ='Technical'
 WHERE id=187376197


   --row number: 6256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054391 , [Content] ='6/27/2018'
 WHERE id=187376198


   --row number: 6257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054507 , [Content] ='6804 NLD'
 WHERE id=187384514


   --row number: 6258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054507 , [Content] ='NLD'
 WHERE id=187384515


   --row number: 6259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054507 , [Content] ='EMEA'
 WHERE id=187384516


   --row number: 6260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054507 , [Content] ='NETHERLANDS'
 WHERE id=187384517


   --row number: 6261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054507 , [Content] ='Info Systems/Technology'
 WHERE id=187384518


   --row number: 6262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054507 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=187384519


   --row number: 6263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054507 , [Content] ='UI/UX Designer'
 WHERE id=187384520


   --row number: 6264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054507 , [Content] ='IC4'
 WHERE id=187384521


   --row number: 6265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054507 , [Content] ='EUR'
 WHERE id=187384523


   --row number: 6266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054507 , [Content] ='61,600 / 74,500 / 87,400 / 100,300 / 113,200'
 WHERE id=187384524


   --row number: 6267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3054507 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=187384525


   --row number: 6268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054507 , [Content] ='20%'
 WHERE id=187384526


   --row number: 6269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054507 , [Content] ='Yes'
 WHERE id=187384527


   --row number: 6270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054507 , [Content] ='2 - Professionals'
 WHERE id=187384528


   --row number: 6271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054507 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187384529


   --row number: 6272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054507 , [Content] ='Technical'
 WHERE id=187384530


   --row number: 6273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054507 , [Content] ='04/05/18'
 WHERE id=187384531


   --row number: 6274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054501 , [Content] ='9999 IND'
 WHERE id=187384150


   --row number: 6275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054501 , [Content] ='IND'
 WHERE id=187384151


   --row number: 6276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054501 , [Content] ='APAC'
 WHERE id=187384152


   --row number: 6277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054501 , [Content] ='India'
 WHERE id=187384153


   --row number: 6278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054501 , [Content] ='9999 - Intern'
 WHERE id=187384154


   --row number: 6279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054501 , [Content] ='INR'
 WHERE id=187384155


   --row number: 6280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054501 , [Content] ='No'
 WHERE id=187384156


   --row number: 6281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054501 , [Content] ='6/27/2018'
 WHERE id=187384157


   --row number: 6282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054527 , [Content] ='Technical'
 WHERE id=187386390


   --row number: 6283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054527 , [Content] ='06/08/18'
 WHERE id=187386391


   --row number: 6284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054527 , [Content] ='5764 ITA'
 WHERE id=187386374


   --row number: 6285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054527 , [Content] ='ITA'
 WHERE id=187386375


   --row number: 6286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054527 , [Content] ='EMEA'
 WHERE id=187386376


   --row number: 6287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054527 , [Content] ='ITALY'
 WHERE id=187386377


   --row number: 6288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054527 , [Content] ='Professional Services'
 WHERE id=187386378


   --row number: 6289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054527 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=187386379


   --row number: 6290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054527 , [Content] ='Technology Consultant'
 WHERE id=187386380


   --row number: 6291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054527 , [Content] ='IC4'
 WHERE id=187386381


   --row number: 6292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054527 , [Content] ='EUR'
 WHERE id=187386383


   --row number: 6293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054527 , [Content] ='43,700 / 52,850 / 62,000 / 71,150 / 80,300'
 WHERE id=187386384


   --row number: 6294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3054527 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=187386385


   --row number: 6295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054527 , [Content] ='20%'
 WHERE id=187386386


   --row number: 6296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054527 , [Content] ='Yes'
 WHERE id=187386387


   --row number: 6297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054527 , [Content] ='2 - Professionals'
 WHERE id=187386388


   --row number: 6298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054527 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187386389


   --row number: 6299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054528 , [Content] ='5763 ESP'
 WHERE id=187386633


   --row number: 6300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054528 , [Content] ='ESP'
 WHERE id=187386634


   --row number: 6301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054528 , [Content] ='EMEA'
 WHERE id=187386635


   --row number: 6302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054528 , [Content] ='SPAIN'
 WHERE id=187386636


   --row number: 6303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054528 , [Content] ='Professional Services'
 WHERE id=187386637


   --row number: 6304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054528 , [Content] ='5763 - Technology Consultant IC3'
 WHERE id=187386638


   --row number: 6305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054528 , [Content] ='Technology Consultant'
 WHERE id=187386639


   --row number: 6306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054528 , [Content] ='IC3'
 WHERE id=187386640


   --row number: 6307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054528 , [Content] ='EUR'
 WHERE id=187386642


   --row number: 6308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054528 , [Content] ='Technical'
 WHERE id=187386649


   --row number: 6309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054528 , [Content] ='6/27/2018'
 WHERE id=187386650


   --row number: 6310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054528 , [Content] ='33,000 / 38,950 / 44,900 / 50,850 / 56,800'
 WHERE id=187386643


   --row number: 6311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3054528 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=187386644


   --row number: 6312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054528 , [Content] ='15%'
 WHERE id=187386645


   --row number: 6313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054528 , [Content] ='Yes'
 WHERE id=187386646


   --row number: 6314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054528 , [Content] ='2 - Professionals'
 WHERE id=187386647


   --row number: 6315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054528 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187386648


   --row number: 6316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054566 , [Content] ='6/27/2018'
 WHERE id=187388555


   --row number: 6317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054578 , [Content] ='INR'
 WHERE id=187388839


   --row number: 6318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054578 , [Content] ='No'
 WHERE id=187388840


   --row number: 6319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054578 , [Content] ='6/27/2018'
 WHERE id=187388841


   --row number: 6320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054566 , [Content] ='9999 IND'
 WHERE id=187388548


   --row number: 6321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054566 , [Content] ='IND'
 WHERE id=187388549


   --row number: 6322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054566 , [Content] ='APAC'
 WHERE id=187388550


   --row number: 6323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054566 , [Content] ='India'
 WHERE id=187388551


   --row number: 6324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054566 , [Content] ='9999 - Intern'
 WHERE id=187388552


   --row number: 6325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054566 , [Content] ='INR'
 WHERE id=187388553


   --row number: 6326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054566 , [Content] ='No'
 WHERE id=187388554


   --row number: 6327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054578 , [Content] ='9999 IND'
 WHERE id=187388834


   --row number: 6328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054578 , [Content] ='IND'
 WHERE id=187388835


   --row number: 6329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054578 , [Content] ='APAC'
 WHERE id=187388836


   --row number: 6330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054578 , [Content] ='India'
 WHERE id=187388837


   --row number: 6331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054578 , [Content] ='9999 - Intern'
 WHERE id=187388838


   --row number: 6332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054948 , [Content] ='US - MRKT 1'
 WHERE id=187420866


   --row number: 6333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3054948 , [Content] ='NO'
 WHERE id=187420880


   --row number: 6334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3054948 , [Content] ='2 - Professionals'
 WHERE id=187420881


   --row number: 6335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3054948 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187420882


   --row number: 6336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3054948 , [Content] ='Technical'
 WHERE id=187420883


   --row number: 6337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054948 , [Content] ='10/05/18'
 WHERE id=187420884


   --row number: 6338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054948 , [Content] ='AMS'
 WHERE id=187420867


   --row number: 6339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054948 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=187420868


   --row number: 6340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3054948 , [Content] ='Engineering'
 WHERE id=187420869


   --row number: 6341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054948 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=187420870


   --row number: 6342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3054948 , [Content] ='Software'
 WHERE id=187420871


   --row number: 6343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3054948 , [Content] ='IC4'
 WHERE id=187420872


   --row number: 6344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054948 , [Content] ='5144 US - MRKT 1'
 WHERE id=187420865


   --row number: 6345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054948 , [Content] ='USD'
 WHERE id=187420874


   --row number: 6346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3054948 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=187420875


   --row number: 6347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3054948 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=187420876


   --row number: 6348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3054948 , [Content] ='20%'
 WHERE id=187420877


   --row number: 6349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054948 , [Content] ='Yes'
 WHERE id=187420878


   --row number: 6350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3054948 , [Content] ='EXEMPT'
 WHERE id=187420879


   --row number: 6351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3054975 , [Content] ='9999 IND'
 WHERE id=187424175


   --row number: 6352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3054975 , [Content] ='IND'
 WHERE id=187424176


   --row number: 6353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3054975 , [Content] ='APAC'
 WHERE id=187424177


   --row number: 6354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3054975 , [Content] ='India'
 WHERE id=187424178


   --row number: 6355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3054975 , [Content] ='9999 - Intern'
 WHERE id=187424179


   --row number: 6356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3054975 , [Content] ='INR'
 WHERE id=187424180


   --row number: 6357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3054975 , [Content] ='No'
 WHERE id=187424181


   --row number: 6358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3054975 , [Content] ='6/27/2018'
 WHERE id=187424182


   --row number: 6359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3055193 , [Content] ='NO'
 WHERE id=187442723


   --row number: 6360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3055193 , [Content] ='4 - Sales Workers'
 WHERE id=187442724


   --row number: 6361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3055193 , [Content] ='8742-Salespersons - Outside'
 WHERE id=187442725


   --row number: 6362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3055193 , [Content] ='Technical'
 WHERE id=187442726


   --row number: 6363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3055193 , [Content] ='6/27/2018'
 WHERE id=187442727


   --row number: 6364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3055193 , [Content] ='S1414 US - MRKT 2'
 WHERE id=187442707


   --row number: 6365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3055193 , [Content] ='US - MRKT 2'
 WHERE id=187442708


   --row number: 6366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3055193 , [Content] ='AMS'
 WHERE id=187442709


   --row number: 6367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3055193 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=187442710


   --row number: 6368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3055193 , [Content] ='Solution Consulting'
 WHERE id=187442711


   --row number: 6369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3055193 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=187442712


   --row number: 6370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3055193 , [Content] ='Solution Consultant Core'
 WHERE id=187442713


   --row number: 6371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3055193 , [Content] ='IC4'
 WHERE id=187442714


   --row number: 6372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3055193 , [Content] ='USD'
 WHERE id=187442716


   --row number: 6373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3055193 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=187442717


   --row number: 6374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3055193 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=187442718


   --row number: 6375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3055193 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=187442719


   --row number: 6376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3055193 , [Content] ='75/25'
 WHERE id=187442720


   --row number: 6377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3055193 , [Content] ='Yes'
 WHERE id=187442721


   --row number: 6378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3055193 , [Content] ='EXEMPT'
 WHERE id=187442722


   --row number: 6379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3055882 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=187500421


   --row number: 6380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3055882 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=187500422


   --row number: 6381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3055882 , [Content] ='75/25'
 WHERE id=187500423


   --row number: 6382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3055882 , [Content] ='Yes'
 WHERE id=187500424


   --row number: 6383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3055882 , [Content] ='EXEMPT'
 WHERE id=187500425


   --row number: 6384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3055882 , [Content] ='NO'
 WHERE id=187500426


   --row number: 6385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3055882 , [Content] ='4 - Sales Workers'
 WHERE id=187500427


   --row number: 6386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3055882 , [Content] ='8742-Salespersons - Outside'
 WHERE id=187500428


   --row number: 6387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3055882 , [Content] ='Technical'
 WHERE id=187500429


   --row number: 6388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3055882 , [Content] ='6/27/2018'
 WHERE id=187500430


   --row number: 6389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3055882 , [Content] ='S1414A US - MRKT 1'
 WHERE id=187500410


   --row number: 6390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3055882 , [Content] ='US - MRKT 1'
 WHERE id=187500411


   --row number: 6391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3055882 , [Content] ='AMS'
 WHERE id=187500412


   --row number: 6392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3055882 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=187500413


   --row number: 6393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3055882 , [Content] ='Solution Consulting'
 WHERE id=187500414


   --row number: 6394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3055882 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=187500415


   --row number: 6395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3055882 , [Content] ='Solution Consultant Architect'
 WHERE id=187500416


   --row number: 6396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3055882 , [Content] ='IC4'
 WHERE id=187500417


   --row number: 6397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3055882 , [Content] ='USD'
 WHERE id=187500419


   --row number: 6398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3055882 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=187500420


   --row number: 6399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3055971 , [Content] ='Technical'
 WHERE id=187514591


   --row number: 6400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3055971 , [Content] ='S1413 AUS'
 WHERE id=187514578


   --row number: 6401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3055971 , [Content] ='AUS'
 WHERE id=187514579


   --row number: 6402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3055971 , [Content] ='APAC'
 WHERE id=187514580


   --row number: 6403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3055971 , [Content] ='AUSTRALIA'
 WHERE id=187514581


   --row number: 6404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3055971 , [Content] ='Solution Consulting'
 WHERE id=187514582


   --row number: 6405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3055971 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=187514583


   --row number: 6406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3055971 , [Content] ='Solution Consultant Core'
 WHERE id=187514584


   --row number: 6407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3055971 , [Content] ='IC3'
 WHERE id=187514585


   --row number: 6408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3055971 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=187514587


   --row number: 6409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3055971 , [Content] ='75/25'
 WHERE id=187514588


   --row number: 6410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3055971 , [Content] ='4 - Sales Workers'
 WHERE id=187514589


   --row number: 6411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3055971 , [Content] ='8742-Salespersons - Outside'
 WHERE id=187514590


   --row number: 6412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3055971 , [Content] ='10/05/18'
 WHERE id=187514910


   --row number: 6413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3055971 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=187514911


   --row number: 6414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3055971 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=187514912


   --row number: 6415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3055971 , [Content] ='Yes'
 WHERE id=187514909


   --row number: 6416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3055971 , [Content] ='AUD'
 WHERE id=187514913


   --row number: 6417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056067 , [Content] ='Yes'
 WHERE id=187535415


   --row number: 6418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056067 , [Content] ='2 - Professionals'
 WHERE id=187535416


   --row number: 6419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056067 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187535417


   --row number: 6420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056067 , [Content] ='Technical'
 WHERE id=187535418


   --row number: 6421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056067 , [Content] ='7/20/2018'
 WHERE id=187535419


   --row number: 6422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056067 , [Content] ='6493 IND'
 WHERE id=187535403


   --row number: 6423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056067 , [Content] ='IND'
 WHERE id=187535404


   --row number: 6424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056067 , [Content] ='APAC'
 WHERE id=187535405


   --row number: 6425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056067 , [Content] ='INDIA'
 WHERE id=187535406


   --row number: 6426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056067 , [Content] ='Info Systems/Technology'
 WHERE id=187535407


   --row number: 6427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056067 , [Content] ='6493 - Data Informatics Analyst IC3'
 WHERE id=187535408


   --row number: 6428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056067 , [Content] ='Data Informatics'
 WHERE id=187535409


   --row number: 6429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056067 , [Content] ='IC3'
 WHERE id=187535410


   --row number: 6430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056067 , [Content] ='INR'
 WHERE id=187535412


   --row number: 6431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056067 , [Content] ='1,337,900 / 1,638,950 / 1,940,000 / 2,241,000 / 2,542,000'
 WHERE id=187535413


   --row number: 6432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3056067 , [Content] ='15%'
 WHERE id=187535414


   --row number: 6433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056069 , [Content] ='6/27/2018'
 WHERE id=187535928


   --row number: 6434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056069 , [Content] ='3593 IND'
 WHERE id=187535911


   --row number: 6435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056069 , [Content] ='IND'
 WHERE id=187535912


   --row number: 6436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056069 , [Content] ='APAC'
 WHERE id=187535913


   --row number: 6437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056069 , [Content] ='INDIA'
 WHERE id=187535914


   --row number: 6438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056069 , [Content] ='Info Systems/Technology'
 WHERE id=187535915


   --row number: 6439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056069 , [Content] ='3593 - Mgr, Data Informatics Mgmt M3'
 WHERE id=187535916


   --row number: 6440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056069 , [Content] ='Data Informatics'
 WHERE id=187535917


   --row number: 6441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056069 , [Content] ='M3'
 WHERE id=187535918


   --row number: 6442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056069 , [Content] ='INR'
 WHERE id=187535920


   --row number: 6443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056069 , [Content] ='1,724,100 / 2,112,050 / 2,500,000 / 2,887,900 / 3,275,800'
 WHERE id=187535921


   --row number: 6444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3056069 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=187535922


   --row number: 6445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3056069 , [Content] ='20%'
 WHERE id=187535923


   --row number: 6446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056069 , [Content] ='Yes'
 WHERE id=187535924


   --row number: 6447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056069 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=187535925


   --row number: 6448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056069 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187535926


   --row number: 6449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056069 , [Content] ='Technical'
 WHERE id=187535927


   --row number: 6450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056070 , [Content] ='7/20/2018'
 WHERE id=187536050


   --row number: 6451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056071 , [Content] ='3593 IND'
 WHERE id=187536071


   --row number: 6452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056071 , [Content] ='IND'
 WHERE id=187536072


   --row number: 6453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056071 , [Content] ='APAC'
 WHERE id=187536073


   --row number: 6454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056071 , [Content] ='INDIA'
 WHERE id=187536074


   --row number: 6455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056071 , [Content] ='Info Systems/Technology'
 WHERE id=187536075


   --row number: 6456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056070 , [Content] ='3594 IND'
 WHERE id=187536033


   --row number: 6457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056070 , [Content] ='IND'
 WHERE id=187536034


   --row number: 6458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056070 , [Content] ='APAC'
 WHERE id=187536035


   --row number: 6459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056070 , [Content] ='INDIA'
 WHERE id=187536036


   --row number: 6460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056070 , [Content] ='Info Systems/Technology'
 WHERE id=187536037


   --row number: 6461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056070 , [Content] ='3594 - Sr Mgr, Data Informatics Mgmt M4'
 WHERE id=187536038


   --row number: 6462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056070 , [Content] ='Data Informatics'
 WHERE id=187536039


   --row number: 6463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056070 , [Content] ='M4'
 WHERE id=187536040


   --row number: 6464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056070 , [Content] ='INR'
 WHERE id=187536042


   --row number: 6465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056070 , [Content] ='2,758,600 / 3,379,300 / 4,000,000 / 4,620,650 / 5,241,300'
 WHERE id=187536043


   --row number: 6466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3056070 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=187536044


   --row number: 6467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3056070 , [Content] ='25%'
 WHERE id=187536045


   --row number: 6468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056070 , [Content] ='Yes'
 WHERE id=187536046


   --row number: 6469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056070 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=187536047


   --row number: 6470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056070 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187536048


   --row number: 6471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056070 , [Content] ='Technical'
 WHERE id=187536049


   --row number: 6472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056071 , [Content] ='3593 - Mgr, Data Informatics Mgmt M3'
 WHERE id=187536076


   --row number: 6473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056071 , [Content] ='Data Informatics'
 WHERE id=187536077


   --row number: 6474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056071 , [Content] ='M3'
 WHERE id=187536078


   --row number: 6475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056071 , [Content] ='INR'
 WHERE id=187536080


   --row number: 6476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056071 , [Content] ='1,724,100 / 2,112,050 / 2,500,000 / 2,887,900 / 3,275,800'
 WHERE id=187536081


   --row number: 6477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3056071 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=187536082


   --row number: 6478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3056071 , [Content] ='20%'
 WHERE id=187536083


   --row number: 6479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056071 , [Content] ='Yes'
 WHERE id=187536084


   --row number: 6480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056071 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=187536085


   --row number: 6481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056071 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187536086


   --row number: 6482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056071 , [Content] ='Technical'
 WHERE id=187536087


   --row number: 6483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056071 , [Content] ='6/27/2018'
 WHERE id=187536088


   --row number: 6484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056359 , [Content] ='EMEA'
 WHERE id=187561020


   --row number: 6485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056359 , [Content] ='Non Technical'
 WHERE id=187561034


   --row number: 6486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056359 , [Content] ='6/27/2018'
 WHERE id=187561035


   --row number: 6487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056359 , [Content] ='SWEDEN'
 WHERE id=187561021


   --row number: 6488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056359 , [Content] ='Sales'
 WHERE id=187561022


   --row number: 6489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056359 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=187561023


   --row number: 6490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056359 , [Content] ='Inside Sales'
 WHERE id=187561024


   --row number: 6491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056359 , [Content] ='A2'
 WHERE id=187561025


   --row number: 6492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056359 , [Content] ='SEK'
 WHERE id=187561027


   --row number: 6493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056359 , [Content] ='204,000 / 222,000 / 240,000 / 258,000 / 276,000'
 WHERE id=187561028


   --row number: 6494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3056359 , [Content] ='340,000 / 370,000 / 400,000 / 430,000 / 460,000'
 WHERE id=187561029


   --row number: 6495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3056359 , [Content] ='60/40'
 WHERE id=187561030


   --row number: 6496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056359 , [Content] ='No'
 WHERE id=187561031


   --row number: 6497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056359 , [Content] ='4 - Sales Workers'
 WHERE id=187561032


   --row number: 6498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056359 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187561033


   --row number: 6499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056359 , [Content] ='S1332 SWE'
 WHERE id=187561018


   --row number: 6500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056359 , [Content] ='SWE'
 WHERE id=187561019


   --row number: 6501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056367 , [Content] ='6/27/2018'
 WHERE id=187561979


   --row number: 6502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056367 , [Content] ='S1333 SWE'
 WHERE id=187561962


   --row number: 6503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056367 , [Content] ='SWE'
 WHERE id=187561963


   --row number: 6504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056367 , [Content] ='EMEA'
 WHERE id=187561964


   --row number: 6505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056367 , [Content] ='SWEDEN'
 WHERE id=187561965


   --row number: 6506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056367 , [Content] ='Sales'
 WHERE id=187561966


   --row number: 6507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056367 , [Content] ='S1333 - Account Development Rep A3'
 WHERE id=187561967


   --row number: 6508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056367 , [Content] ='Inside Sales'
 WHERE id=187561968


   --row number: 6509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056367 , [Content] ='A3'
 WHERE id=187561969


   --row number: 6510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056367 , [Content] ='SEK'
 WHERE id=187561971


   --row number: 6511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056367 , [Content] ='252,450 / 274,725 / 297,000 / 319,275 / 341,550'
 WHERE id=187561972


   --row number: 6512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3056367 , [Content] ='420,750 / 457,875 / 495,000 / 532,125 / 569,250'
 WHERE id=187561973


   --row number: 6513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3056367 , [Content] ='60/40'
 WHERE id=187561974


   --row number: 6514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056367 , [Content] ='No'
 WHERE id=187561975


   --row number: 6515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056367 , [Content] ='4 - Sales Workers'
 WHERE id=187561976


   --row number: 6516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056367 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187561977


   --row number: 6517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056367 , [Content] ='Non Technical'
 WHERE id=187561978


   --row number: 6518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056690 , [Content] ='2994 IND'
 WHERE id=187637217


   --row number: 6519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056690 , [Content] ='IND'
 WHERE id=187637218


   --row number: 6520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056690 , [Content] ='APAC'
 WHERE id=187637219


   --row number: 6521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056690 , [Content] ='INDIA'
 WHERE id=187637220


   --row number: 6522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056690 , [Content] ='Finance'
 WHERE id=187637221


   --row number: 6523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056690 , [Content] ='2994 - Sr Mgr, Revenue Mgmt M4'
 WHERE id=187637222


   --row number: 6524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056690 , [Content] ='Revenue Accounting'
 WHERE id=187637223


   --row number: 6525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056690 , [Content] ='M4'
 WHERE id=187637224


   --row number: 6526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056690 , [Content] ='INR'
 WHERE id=187637226


   --row number: 6527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056690 , [Content] ='1,851,700 / 2,268,350 / 2,685,000 / 3,101,600 / 3,518,200'
 WHERE id=187637227


   --row number: 6528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3056690 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=187637228


   --row number: 6529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3056690 , [Content] ='25%'
 WHERE id=187637229


   --row number: 6530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056690 , [Content] ='Yes'
 WHERE id=187637230


   --row number: 6531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056690 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=187637231


   --row number: 6532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056690 , [Content] ='8810-Clerical Office Employees'
 WHERE id=187637232


   --row number: 6533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056690 , [Content] ='Non Technical'
 WHERE id=187637233


   --row number: 6534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056690 , [Content] ='6/27/2018'
 WHERE id=187637234


   --row number: 6535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3056763 , [Content] ='5183 IND'
 WHERE id=187648480


   --row number: 6536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3056763 , [Content] ='IND'
 WHERE id=187648481


   --row number: 6537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3056763 , [Content] ='APAC'
 WHERE id=187648482


   --row number: 6538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3056763 , [Content] ='INDIA'
 WHERE id=187648483


   --row number: 6539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3056763 , [Content] ='Engineering'
 WHERE id=187648484


   --row number: 6540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3056763 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=187648485


   --row number: 6541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3056763 , [Content] ='Quality'
 WHERE id=187648486


   --row number: 6542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3056763 , [Content] ='IC3'
 WHERE id=187648487


   --row number: 6543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3056763 , [Content] ='INR'
 WHERE id=187648489


   --row number: 6544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3056763 , [Content] ='1,344,800 / 1,647,400 / 1,950,000 / 2,252,550 / 2,555,100'
 WHERE id=187648490


   --row number: 6545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3056763 , [Content] ='09/05/18'
 WHERE id=187648496


   --row number: 6546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3056763 , [Content] ='15%'
 WHERE id=187648491


   --row number: 6547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3056763 , [Content] ='Yes'
 WHERE id=187648492


   --row number: 6548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3056763 , [Content] ='2 - Professionals'
 WHERE id=187648493


   --row number: 6549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3056763 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187648494


   --row number: 6550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3056763 , [Content] ='Technical'
 WHERE id=187648495


   --row number: 6551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3058133 , [Content] ='9999 AUS'
 WHERE id=187781769


   --row number: 6552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3058133 , [Content] ='AUS'
 WHERE id=187781770


   --row number: 6553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3058133 , [Content] ='APAC'
 WHERE id=187781771


   --row number: 6554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3058133 , [Content] ='Australia'
 WHERE id=187781772


   --row number: 6555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3058133 , [Content] ='9999 - Intern'
 WHERE id=187781773


   --row number: 6556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3058133 , [Content] ='AUD'
 WHERE id=187781774


   --row number: 6557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3058133 , [Content] ='No'
 WHERE id=187781775


   --row number: 6558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3058133 , [Content] ='6/27/2018'
 WHERE id=187781776


   --row number: 6559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3058334 , [Content] ='6/27/2018'
 WHERE id=187811390


   --row number: 6560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3058334 , [Content] ='5144 IND'
 WHERE id=187811373


   --row number: 6561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3058334 , [Content] ='IND'
 WHERE id=187811374


   --row number: 6562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3058334 , [Content] ='APAC'
 WHERE id=187811375


   --row number: 6563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3058334 , [Content] ='INDIA'
 WHERE id=187811376


   --row number: 6564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3058334 , [Content] ='Engineering'
 WHERE id=187811377


   --row number: 6565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3058334 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=187811378


   --row number: 6566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3058334 , [Content] ='Software'
 WHERE id=187811379


   --row number: 6567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3058334 , [Content] ='IC4'
 WHERE id=187811380


   --row number: 6568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3058334 , [Content] ='INR'
 WHERE id=187811382


   --row number: 6569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3058334 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=187811383


   --row number: 6570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3058334 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=187811384


   --row number: 6571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3058334 , [Content] ='20%'
 WHERE id=187811385


   --row number: 6572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3058334 , [Content] ='Yes'
 WHERE id=187811386


   --row number: 6573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3058334 , [Content] ='2 - Professionals'
 WHERE id=187811387


   --row number: 6574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3058334 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187811388


   --row number: 6575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3058334 , [Content] ='Technical'
 WHERE id=187811389


   --row number: 6576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3058342 , [Content] ='7/20/2018'
 WHERE id=187811819


   --row number: 6577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3058342 , [Content] ='5182 IND'
 WHERE id=187811802


   --row number: 6578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3058342 , [Content] ='IND'
 WHERE id=187811803


   --row number: 6579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3058342 , [Content] ='APAC'
 WHERE id=187811804


   --row number: 6580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3058342 , [Content] ='INDIA'
 WHERE id=187811805


   --row number: 6581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3058342 , [Content] ='Engineering'
 WHERE id=187811806


   --row number: 6582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3058342 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=187811807


   --row number: 6583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3058342 , [Content] ='Quality'
 WHERE id=187811808


   --row number: 6584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3058342 , [Content] ='IC2'
 WHERE id=187811809


   --row number: 6585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3058342 , [Content] ='INR'
 WHERE id=187811811


   --row number: 6586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3058342 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=187811812


   --row number: 6587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3058342 , [Content] ='10%'
 WHERE id=187811814


   --row number: 6588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3058342 , [Content] ='No'
 WHERE id=187811815


   --row number: 6589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3058342 , [Content] ='2 - Professionals'
 WHERE id=187811816


   --row number: 6590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3058342 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=187811817


   --row number: 6591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3058342 , [Content] ='Technical'
 WHERE id=187811818


   --row number: 6592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3060899 , [Content] ='2 - Professionals'
 WHERE id=188164263


   --row number: 6593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3060899 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=188164264


   --row number: 6594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3060899 , [Content] ='Technical'
 WHERE id=188164265


   --row number: 6595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3060899 , [Content] ='6/27/2018'
 WHERE id=188164266


   --row number: 6596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3060899 , [Content] ='5184 US - MRKT 1'
 WHERE id=188164247


   --row number: 6597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3060899 , [Content] ='US - MRKT 1'
 WHERE id=188164248


   --row number: 6598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3060899 , [Content] ='AMS'
 WHERE id=188164249


   --row number: 6599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3060899 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188164250


   --row number: 6600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3060899 , [Content] ='Engineering'
 WHERE id=188164251


   --row number: 6601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3060899 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=188164252


   --row number: 6602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3060899 , [Content] ='Quality'
 WHERE id=188164253


   --row number: 6603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3060899 , [Content] ='IC4'
 WHERE id=188164254


   --row number: 6604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3060899 , [Content] ='USD'
 WHERE id=188164256


   --row number: 6605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3060899 , [Content] ='103,300 / 124,950 / 146,600 / 168,250 / 189,900'
 WHERE id=188164257


   --row number: 6606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3060899 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=188164258


   --row number: 6607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3060899 , [Content] ='20%'
 WHERE id=188164259


   --row number: 6608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3060899 , [Content] ='Yes'
 WHERE id=188164260


   --row number: 6609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3060899 , [Content] ='EXEMPT'
 WHERE id=188164261


   --row number: 6610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3060899 , [Content] ='NO'
 WHERE id=188164262


   --row number: 6611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3061985 , [Content] ='Technical'
 WHERE id=188284878


   --row number: 6612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3061985 , [Content] ='6/27/2018'
 WHERE id=188284879


   --row number: 6613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3061985 , [Content] ='S1612 JPN'
 WHERE id=188284861


   --row number: 6614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3061985 , [Content] ='JPN'
 WHERE id=188284862


   --row number: 6615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3061985 , [Content] ='APAC'
 WHERE id=188284863


   --row number: 6616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3061985 , [Content] ='JAPAN'
 WHERE id=188284864


   --row number: 6617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3061985 , [Content] ='Sales'
 WHERE id=188284865


   --row number: 6618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3061985 , [Content] ='S1612 - Regional Partner Mgr IC2'
 WHERE id=188284866


   --row number: 6619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3061985 , [Content] ='Partner Sales'
 WHERE id=188284867


   --row number: 6620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3061985 , [Content] ='IC2'
 WHERE id=188284868


   --row number: 6621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3061985 , [Content] ='JPY'
 WHERE id=188284870


   --row number: 6622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3061985 , [Content] ='6,555,880 / 7,134,340 / 7,712,800 / 8,291,260 / 8,869,720'
 WHERE id=188284871


   --row number: 6623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3061985 , [Content] ='23,400 / 32,700 / 42,000 / 51,600 / 61,200'
 WHERE id=188284872


   --row number: 6624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3061985 , [Content] ='8,194,850 / 8,917,925 / 9,641,000 / 10,364,075 / 11,087,150'
 WHERE id=188284873


   --row number: 6625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3061985 , [Content] ='80/20'
 WHERE id=188284874


   --row number: 6626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3061985 , [Content] ='Yes'
 WHERE id=188284875


   --row number: 6627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3061985 , [Content] ='4 - Sales Workers'
 WHERE id=188284876


   --row number: 6628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3061985 , [Content] ='8742-Salespersons - Outside'
 WHERE id=188284877


   --row number: 6629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3062079 , [Content] ='09/05/18'
 WHERE id=188297246


   --row number: 6630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3062079 , [Content] ='S635 NLD'
 WHERE id=188297230


   --row number: 6631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3062079 , [Content] ='NLD'
 WHERE id=188297231


   --row number: 6632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3062079 , [Content] ='EMEA'
 WHERE id=188297232


   --row number: 6633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3062079 , [Content] ='NETHERLANDS'
 WHERE id=188297233


   --row number: 6634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3062079 , [Content] ='Sales'
 WHERE id=188297234


   --row number: 6635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3062079 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=188297235


   --row number: 6636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3062079 , [Content] ='Enterprise Accounts'
 WHERE id=188297236


   --row number: 6637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3062079 , [Content] ='IC5'
 WHERE id=188297237


   --row number: 6638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3062079 , [Content] ='EUR'
 WHERE id=188297239


   --row number: 6639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3062079 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=188297240


   --row number: 6640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3062079 , [Content] ='Yes'
 WHERE id=188297242


   --row number: 6641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3062079 , [Content] ='4 - Sales Workers'
 WHERE id=188297243


   --row number: 6642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3062079 , [Content] ='8742-Salespersons - Outside'
 WHERE id=188297244


   --row number: 6643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3062079 , [Content] ='Technical'
 WHERE id=188297245


   --row number: 6644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3063262 , [Content] ='8810-Clerical Office Employees'
 WHERE id=188438266


   --row number: 6645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3063262 , [Content] ='Non Technical'
 WHERE id=188438267


   --row number: 6646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3063262 , [Content] ='6/27/2018'
 WHERE id=188438268


   --row number: 6647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3063262 , [Content] ='6605 US - MRKT 1'
 WHERE id=188438242


   --row number: 6648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3063262 , [Content] ='US - MRKT 1'
 WHERE id=188438243


   --row number: 6649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3063262 , [Content] ='AMS'
 WHERE id=188438244


   --row number: 6650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3063262 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188438245


   --row number: 6651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3063262 , [Content] ='Marketing'
 WHERE id=188438246


   --row number: 6652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3063262 , [Content] ='6605 - Graphics Designer IC5'
 WHERE id=188438247


   --row number: 6653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3063262 , [Content] ='Graphic Arts Design'
 WHERE id=188438248


   --row number: 6654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3063262 , [Content] ='IC5'
 WHERE id=188438249


   --row number: 6655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3063262 , [Content] ='USD'
 WHERE id=188438251


   --row number: 6656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3063262 , [Content] ='110,800 / 134,000 / 157,200 / 180,450 / 203,700'
 WHERE id=188438252


   --row number: 6657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3063262 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=188438253


   --row number: 6658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3063262 , [Content] ='20%'
 WHERE id=188438256


   --row number: 6659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3063262 , [Content] ='Yes'
 WHERE id=188438257


   --row number: 6660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3063262 , [Content] ='EXEMPT'
 WHERE id=188438260


   --row number: 6661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3063262 , [Content] ='NO'
 WHERE id=188438261


   --row number: 6662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3063262 , [Content] ='2 - Professionals'
 WHERE id=188438265


   --row number: 6663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3063881 , [Content] ='EXEMPT'
 WHERE id=188491960


   --row number: 6664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3063881 , [Content] ='NO'
 WHERE id=188491961


   --row number: 6665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3063881 , [Content] ='4 - Sales Workers'
 WHERE id=188491962


   --row number: 6666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3063881 , [Content] ='8742-Salespersons - Outside'
 WHERE id=188491963


   --row number: 6667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3063881 , [Content] ='Technical'
 WHERE id=188491964


   --row number: 6668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3063881 , [Content] ='4/25/2018'
 WHERE id=188491965


   --row number: 6669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3063881 , [Content] ='S1414A US - MRKT 1'
 WHERE id=188491945


   --row number: 6670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3063881 , [Content] ='US - MRKT 1'
 WHERE id=188491946


   --row number: 6671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3063881 , [Content] ='AMS'
 WHERE id=188491947


   --row number: 6672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3063881 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188491948


   --row number: 6673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3063881 , [Content] ='Solution Consulting'
 WHERE id=188491949


   --row number: 6674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3063881 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=188491950


   --row number: 6675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3063881 , [Content] ='Solution Consultant Architect'
 WHERE id=188491951


   --row number: 6676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3063881 , [Content] ='IC4'
 WHERE id=188491952


   --row number: 6677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3063881 , [Content] ='USD'
 WHERE id=188491954


   --row number: 6678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3063881 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=188491955


   --row number: 6679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3063881 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=188491956


   --row number: 6680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3063881 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=188491957


   --row number: 6681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3063881 , [Content] ='75/25'
 WHERE id=188491958


   --row number: 6682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3063881 , [Content] ='Yes'
 WHERE id=188491959


   --row number: 6683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3064240 , [Content] ='9999 IND'
 WHERE id=188595618


   --row number: 6684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3064240 , [Content] ='IND'
 WHERE id=188595619


   --row number: 6685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3064240 , [Content] ='APAC'
 WHERE id=188595620


   --row number: 6686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3064240 , [Content] ='India'
 WHERE id=188595621


   --row number: 6687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3064240 , [Content] ='9999 - Intern'
 WHERE id=188595622


   --row number: 6688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3064240 , [Content] ='INR'
 WHERE id=188595623


   --row number: 6689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3064240 , [Content] ='No'
 WHERE id=188595624


   --row number: 6690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3064240 , [Content] ='6/27/2018'
 WHERE id=188595625


   --row number: 6691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3064239 , [Content] ='9999 IND'
 WHERE id=188595410


   --row number: 6692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3064239 , [Content] ='IND'
 WHERE id=188595411


   --row number: 6693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3064239 , [Content] ='APAC'
 WHERE id=188595412


   --row number: 6694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3064239 , [Content] ='India'
 WHERE id=188595413


   --row number: 6695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3064239 , [Content] ='9999 - Intern'
 WHERE id=188595414


   --row number: 6696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3064239 , [Content] ='INR'
 WHERE id=188595415


   --row number: 6697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3064239 , [Content] ='No'
 WHERE id=188595416


   --row number: 6698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3064239 , [Content] ='6/27/2018'
 WHERE id=188595417


   --row number: 6699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3064264 , [Content] ='9999 IND'
 WHERE id=188599708


   --row number: 6700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3064264 , [Content] ='IND'
 WHERE id=188599709


   --row number: 6701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3064264 , [Content] ='APAC'
 WHERE id=188599710


   --row number: 6702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3064264 , [Content] ='India'
 WHERE id=188599711


   --row number: 6703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3064264 , [Content] ='9999 - Intern'
 WHERE id=188599712


   --row number: 6704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3064264 , [Content] ='INR'
 WHERE id=188599713


   --row number: 6705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3064264 , [Content] ='No'
 WHERE id=188599714


   --row number: 6706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3064264 , [Content] ='6/27/2018'
 WHERE id=188599715


   --row number: 6707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3064260 , [Content] ='9999 IND'
 WHERE id=188599544


   --row number: 6708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3064260 , [Content] ='IND'
 WHERE id=188599545


   --row number: 6709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3064260 , [Content] ='APAC'
 WHERE id=188599546


   --row number: 6710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3064260 , [Content] ='India'
 WHERE id=188599547


   --row number: 6711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3064260 , [Content] ='9999 - Intern'
 WHERE id=188599548


   --row number: 6712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3064260 , [Content] ='INR'
 WHERE id=188599549


   --row number: 6713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3064260 , [Content] ='No'
 WHERE id=188599550


   --row number: 6714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3064260 , [Content] ='6/27/2018'
 WHERE id=188599551


   --row number: 6715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3064267 , [Content] ='9999 IND'
 WHERE id=188599776


   --row number: 6716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3064267 , [Content] ='IND'
 WHERE id=188599777


   --row number: 6717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3064267 , [Content] ='APAC'
 WHERE id=188599778


   --row number: 6718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3064267 , [Content] ='India'
 WHERE id=188599779


   --row number: 6719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3064267 , [Content] ='9999 - Intern'
 WHERE id=188599780


   --row number: 6720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3064267 , [Content] ='INR'
 WHERE id=188599781


   --row number: 6721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3064267 , [Content] ='No'
 WHERE id=188599782


   --row number: 6722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3064267 , [Content] ='6/27/2018'
 WHERE id=188599783


   --row number: 6723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3064774 , [Content] ='5142 IND'
 WHERE id=188639453


   --row number: 6724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3064774 , [Content] ='IND'
 WHERE id=188639454


   --row number: 6725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3064774 , [Content] ='APAC'
 WHERE id=188639455


   --row number: 6726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3064774 , [Content] ='INDIA'
 WHERE id=188639456


   --row number: 6727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3064774 , [Content] ='Engineering'
 WHERE id=188639457


   --row number: 6728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3064774 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=188639458


   --row number: 6729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3064774 , [Content] ='Software'
 WHERE id=188639459


   --row number: 6730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3064774 , [Content] ='IC2'
 WHERE id=188639460


   --row number: 6731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3064774 , [Content] ='INR'
 WHERE id=188639462


   --row number: 6732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3064774 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=188639463


   --row number: 6733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3064774 , [Content] ='10%'
 WHERE id=188639464


   --row number: 6734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3064774 , [Content] ='No'
 WHERE id=188639465


   --row number: 6735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3064774 , [Content] ='2 - Professionals'
 WHERE id=188639466


   --row number: 6736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3064774 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=188639467


   --row number: 6737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3064774 , [Content] ='Technical'
 WHERE id=188639468


   --row number: 6738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3064774 , [Content] ='10/05/18'
 WHERE id=188639469


   --row number: 6739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3065738 , [Content] ='8810-Clerical Office Employees'
 WHERE id=188723026


   --row number: 6740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3065738 , [Content] ='Non Technical'
 WHERE id=188723027


   --row number: 6741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3065738 , [Content] ='6/27/2018'
 WHERE id=188723028


   --row number: 6742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3065738 , [Content] ='6262 US - MRKT 1'
 WHERE id=188723009


   --row number: 6743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3065738 , [Content] ='US - MRKT 1'
 WHERE id=188723010


   --row number: 6744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3065738 , [Content] ='AMS'
 WHERE id=188723011


   --row number: 6745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3065738 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188723012


   --row number: 6746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3065738 , [Content] ='Legal'
 WHERE id=188723013


   --row number: 6747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3065738 , [Content] ='6262 - Stock Plan Administrator IC2'
 WHERE id=188723014


   --row number: 6748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3065738 , [Content] ='Stock Plan Administration'
 WHERE id=188723015


   --row number: 6749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3065738 , [Content] ='IC2'
 WHERE id=188723016


   --row number: 6750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3065738 , [Content] ='USD'
 WHERE id=188723018


   --row number: 6751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3065738 , [Content] ='70,400 / 80,400 / 90,400 / 100,450 / 110,500'
 WHERE id=188723019


   --row number: 6752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3065738 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=188723020


   --row number: 6753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3065738 , [Content] ='10%'
 WHERE id=188723021


   --row number: 6754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3065738 , [Content] ='Yes'
 WHERE id=188723022


   --row number: 6755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3065738 , [Content] ='EXEMPT'
 WHERE id=188723023


   --row number: 6756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3065738 , [Content] ='NO'
 WHERE id=188723024


   --row number: 6757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3065738 , [Content] ='2 - Professionals'
 WHERE id=188723025


   --row number: 6758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3066422 , [Content] ='S635 NLD'
 WHERE id=188820732


   --row number: 6759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3066422 , [Content] ='NLD'
 WHERE id=188820733


   --row number: 6760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3066422 , [Content] ='EMEA'
 WHERE id=188820734


   --row number: 6761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3066422 , [Content] ='NETHERLANDS'
 WHERE id=188820735


   --row number: 6762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3066422 , [Content] ='Sales'
 WHERE id=188820736


   --row number: 6763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3066422 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=188820737


   --row number: 6764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3066422 , [Content] ='Enterprise Accounts'
 WHERE id=188820738


   --row number: 6765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3066422 , [Content] ='IC5'
 WHERE id=188820739


   --row number: 6766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3066422 , [Content] ='EUR'
 WHERE id=188820746


   --row number: 6767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3066422 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=188820747


   --row number: 6768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3066422 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=188820748


   --row number: 6769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3066422 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=188820749


   --row number: 6770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3066422 , [Content] ='50/50'
 WHERE id=188820750


   --row number: 6771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3066422 , [Content] ='Yes'
 WHERE id=188820751


   --row number: 6772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3066422 , [Content] ='4 - Sales Workers'
 WHERE id=188820752


   --row number: 6773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3066422 , [Content] ='8742-Salespersons - Outside'
 WHERE id=188820754


   --row number: 6774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3066422 , [Content] ='Technical'
 WHERE id=188820755


   --row number: 6775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3066422 , [Content] ='6/27/2018'
 WHERE id=188820756


   --row number: 6776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3066117 , [Content] ='9999 IND'
 WHERE id=188793306


   --row number: 6777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3066117 , [Content] ='IND'
 WHERE id=188793307


   --row number: 6778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3066117 , [Content] ='APAC'
 WHERE id=188793308


   --row number: 6779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3066117 , [Content] ='India'
 WHERE id=188793309


   --row number: 6780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3066117 , [Content] ='9999 - Intern'
 WHERE id=188793310


   --row number: 6781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3066117 , [Content] ='INR'
 WHERE id=188793311


   --row number: 6782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3066117 , [Content] ='No'
 WHERE id=188793312


   --row number: 6783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3066117 , [Content] ='6/27/2018'
 WHERE id=188793313


   --row number: 6784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3066859 , [Content] ='Technical'
 WHERE id=188852216


   --row number: 6785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3066859 , [Content] ='6/27/2018'
 WHERE id=188852217


   --row number: 6786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3066859 , [Content] ='5835 US - MRKT 2'
 WHERE id=188852199


   --row number: 6787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3066859 , [Content] ='US - MRKT 2'
 WHERE id=188852200


   --row number: 6788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3066859 , [Content] ='AMS'
 WHERE id=188852201


   --row number: 6789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3066859 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188852202


   --row number: 6790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3066859 , [Content] ='Professional Services'
 WHERE id=188852203


   --row number: 6791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3066859 , [Content] ='5835 - Delivery Manager IC5'
 WHERE id=188852204


   --row number: 6792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3066859 , [Content] ='Delivery Mgrs'
 WHERE id=188852205


   --row number: 6793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3066859 , [Content] ='IC5'
 WHERE id=188852206


   --row number: 6794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3066859 , [Content] ='USD'
 WHERE id=188852208


   --row number: 6795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3066859 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=188852209


   --row number: 6796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3066859 , [Content] ='20%'
 WHERE id=188852210


   --row number: 6797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3066859 , [Content] ='Yes'
 WHERE id=188852211


   --row number: 6798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3066859 , [Content] ='EXEMPT'
 WHERE id=188852212


   --row number: 6799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3066859 , [Content] ='NO'
 WHERE id=188852213


   --row number: 6800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3066859 , [Content] ='2 - Professionals'
 WHERE id=188852214


   --row number: 6801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3066859 , [Content] ='8810-Clerical Office Employees'
 WHERE id=188852215


   --row number: 6802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3067064 , [Content] ='2 - Professionals'
 WHERE id=188869197


   --row number: 6803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3067064 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=188869198


   --row number: 6804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3067064 , [Content] ='Technical'
 WHERE id=188869199


   --row number: 6805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3067064 , [Content] ='6/27/2018'
 WHERE id=188869200


   --row number: 6806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3067064 , [Content] ='5143 US - MRKT 1'
 WHERE id=188869181


   --row number: 6807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3067064 , [Content] ='US - MRKT 1'
 WHERE id=188869182


   --row number: 6808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3067064 , [Content] ='AMS'
 WHERE id=188869183


   --row number: 6809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3067064 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188869184


   --row number: 6810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3067064 , [Content] ='Engineering'
 WHERE id=188869185


   --row number: 6811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3067064 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=188869186


   --row number: 6812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3067064 , [Content] ='Software'
 WHERE id=188869187


   --row number: 6813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3067064 , [Content] ='IC3'
 WHERE id=188869188


   --row number: 6814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3067064 , [Content] ='USD'
 WHERE id=188869190


   --row number: 6815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3067064 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=188869191


   --row number: 6816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3067064 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=188869192


   --row number: 6817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3067064 , [Content] ='15%'
 WHERE id=188869193


   --row number: 6818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3067064 , [Content] ='Yes'
 WHERE id=188869194


   --row number: 6819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3067064 , [Content] ='EXEMPT'
 WHERE id=188869195


   --row number: 6820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3067064 , [Content] ='NO'
 WHERE id=188869196


   --row number: 6821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3067166 , [Content] ='8810-Clerical Office Employees'
 WHERE id=188875494


   --row number: 6822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3067166 , [Content] ='Technical'
 WHERE id=188875495


   --row number: 6823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3067166 , [Content] ='6/27/2018'
 WHERE id=188875496


   --row number: 6824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3067166 , [Content] ='5224 US - MRKT 1'
 WHERE id=188875477


   --row number: 6825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3067166 , [Content] ='US - MRKT 1'
 WHERE id=188875478


   --row number: 6826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3067166 , [Content] ='AMS'
 WHERE id=188875479


   --row number: 6827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3067166 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188875480


   --row number: 6828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3067166 , [Content] ='Engineering'
 WHERE id=188875481


   --row number: 6829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3067166 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=188875482


   --row number: 6830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3067166 , [Content] ='Product Mgmt Mgr'
 WHERE id=188875483


   --row number: 6831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3067166 , [Content] ='IC4'
 WHERE id=188875484


   --row number: 6832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3067166 , [Content] ='USD'
 WHERE id=188875486


   --row number: 6833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3067166 , [Content] ='113,400 / 137,150 / 160,900 / 184,650 / 208,400'
 WHERE id=188875487


   --row number: 6834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3067166 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=188875488


   --row number: 6835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3067166 , [Content] ='20%'
 WHERE id=188875489


   --row number: 6836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3067166 , [Content] ='Yes'
 WHERE id=188875490


   --row number: 6837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3067166 , [Content] ='EXEMPT'
 WHERE id=188875491


   --row number: 6838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3067166 , [Content] ='NO'
 WHERE id=188875492


   --row number: 6839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3067166 , [Content] ='2 - Professionals'
 WHERE id=188875493


   --row number: 6840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3067330 , [Content] ='8810-Clerical Office Employees'
 WHERE id=188891514


   --row number: 6841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3067330 , [Content] ='Technical'
 WHERE id=188891515


   --row number: 6842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3067330 , [Content] ='10/05/18'
 WHERE id=188891516


   --row number: 6843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3067330 , [Content] ='5312 US - MRKT 1'
 WHERE id=188891497


   --row number: 6844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3067330 , [Content] ='US - MRKT 1'
 WHERE id=188891498


   --row number: 6845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3067330 , [Content] ='AMS'
 WHERE id=188891499


   --row number: 6846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3067330 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=188891500


   --row number: 6847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3067330 , [Content] ='Engineering Operations'
 WHERE id=188891501


   --row number: 6848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3067330 , [Content] ='5312 - Technical Writer IC2'
 WHERE id=188891502


   --row number: 6849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3067330 , [Content] ='Technical Writer'
 WHERE id=188891503


   --row number: 6850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3067330 , [Content] ='IC2'
 WHERE id=188891504


   --row number: 6851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3067330 , [Content] ='USD'
 WHERE id=188891506


   --row number: 6852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3067330 , [Content] ='74,300 / 84,900 / 95,500 / 106,100 / 116,700'
 WHERE id=188891507


   --row number: 6853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3067330 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=188891508


   --row number: 6854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3067330 , [Content] ='10%'
 WHERE id=188891509


   --row number: 6855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3067330 , [Content] ='Yes'
 WHERE id=188891510


   --row number: 6856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3067330 , [Content] ='EXEMPT'
 WHERE id=188891511


   --row number: 6857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3067330 , [Content] ='NO'
 WHERE id=188891512


   --row number: 6858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3067330 , [Content] ='2 - Professionals'
 WHERE id=188891513


   --row number: 6859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3069017 , [Content] ='EXEMPT'
 WHERE id=189084429


   --row number: 6860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3069017 , [Content] ='NO'
 WHERE id=189084430


   --row number: 6861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3069017 , [Content] ='4 - Sales Workers'
 WHERE id=189084431


   --row number: 6862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3069017 , [Content] ='8742-Salespersons - Outside'
 WHERE id=189084432


   --row number: 6863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3069017 , [Content] ='Technical'
 WHERE id=189084433


   --row number: 6864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3069017 , [Content] ='6/27/2018'
 WHERE id=189084434


   --row number: 6865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3069017 , [Content] ='S1413 US - MRKT 2'
 WHERE id=189084414


   --row number: 6866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3069017 , [Content] ='US - MRKT 2'
 WHERE id=189084415


   --row number: 6867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3069017 , [Content] ='AMS'
 WHERE id=189084416


   --row number: 6868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3069017 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189084417


   --row number: 6869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3069017 , [Content] ='Solution Consulting'
 WHERE id=189084418


   --row number: 6870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3069017 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=189084419


   --row number: 6871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3069017 , [Content] ='Solution Consultant Core'
 WHERE id=189084420


   --row number: 6872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3069017 , [Content] ='IC3'
 WHERE id=189084421


   --row number: 6873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3069017 , [Content] ='USD'
 WHERE id=189084423


   --row number: 6874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3069017 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=189084424


   --row number: 6875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3069017 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=189084425


   --row number: 6876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3069017 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=189084426


   --row number: 6877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3069017 , [Content] ='75/25'
 WHERE id=189084427


   --row number: 6878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3069017 , [Content] ='Yes'
 WHERE id=189084428


   --row number: 6879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3069058 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=189087212


   --row number: 6880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3069058 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=189087213


   --row number: 6881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3069058 , [Content] ='Technical'
 WHERE id=189087214


   --row number: 6882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3069058 , [Content] ='6/27/2018'
 WHERE id=189087215


   --row number: 6883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3069058 , [Content] ='2264 US - MRKT 1'
 WHERE id=189087196


   --row number: 6884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3069058 , [Content] ='US - MRKT 1'
 WHERE id=189087197


   --row number: 6885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3069058 , [Content] ='AMS'
 WHERE id=189087198


   --row number: 6886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3069058 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189087199


   --row number: 6887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3069058 , [Content] ='Engineering'
 WHERE id=189087200


   --row number: 6888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3069058 , [Content] ='2264 - Sr Mgr, Project/Program (Design) Mgmt M4'
 WHERE id=189087201


   --row number: 6889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3069058 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=189087202


   --row number: 6890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3069058 , [Content] ='M4'
 WHERE id=189087203


   --row number: 6891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3069058 , [Content] ='USD'
 WHERE id=189087205


   --row number: 6892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3069058 , [Content] ='136,900 / 167,700 / 198,500 / 229,300 / 260,100'
 WHERE id=189087206


   --row number: 6893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3069058 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=189087207


   --row number: 6894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3069058 , [Content] ='25%'
 WHERE id=189087208


   --row number: 6895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3069058 , [Content] ='Yes'
 WHERE id=189087209


   --row number: 6896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3069058 , [Content] ='EXEMPT'
 WHERE id=189087210


   --row number: 6897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3069058 , [Content] ='NO'
 WHERE id=189087211


   --row number: 6898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3070211 , [Content] ='6/27/2018'
 WHERE id=189307994


   --row number: 6899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3070211 , [Content] ='5233 NLD'
 WHERE id=189307977


   --row number: 6900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3070211 , [Content] ='NLD'
 WHERE id=189307978


   --row number: 6901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3070211 , [Content] ='EMEA'
 WHERE id=189307979


   --row number: 6902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3070211 , [Content] ='NETHERLANDS'
 WHERE id=189307980


   --row number: 6903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3070211 , [Content] ='Engineering'
 WHERE id=189307981


   --row number: 6904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3070211 , [Content] ='5233 - Sr UI Engineer IC3'
 WHERE id=189307982


   --row number: 6905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3070211 , [Content] ='UI'
 WHERE id=189307983


   --row number: 6906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3070211 , [Content] ='IC3'
 WHERE id=189307984


   --row number: 6907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3070211 , [Content] ='EUR'
 WHERE id=189307986


   --row number: 6908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3070211 , [Content] ='52,400 / 61,850 / 71,300 / 80,700 / 90,100'
 WHERE id=189307987


   --row number: 6909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3070211 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=189307988


   --row number: 6910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3070211 , [Content] ='15%'
 WHERE id=189307989


   --row number: 6911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3070211 , [Content] ='Yes'
 WHERE id=189307990


   --row number: 6912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3070211 , [Content] ='2 - Professionals'
 WHERE id=189307991


   --row number: 6913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3070211 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=189307992


   --row number: 6914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3070211 , [Content] ='Technical'
 WHERE id=189307993


   --row number: 6915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3070263 , [Content] ='4 - Sales Workers'
 WHERE id=189309135


   --row number: 6916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3070263 , [Content] ='8742-Salespersons - Outside'
 WHERE id=189309136


   --row number: 6917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3070263 , [Content] ='Technical'
 WHERE id=189309137


   --row number: 6918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3070263 , [Content] ='10/05/18'
 WHERE id=189309138


   --row number: 6919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3070263 , [Content] ='S1414 UK'
 WHERE id=189309120


   --row number: 6920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3070263 , [Content] ='UK'
 WHERE id=189309121


   --row number: 6921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3070263 , [Content] ='EMEA'
 WHERE id=189309122


   --row number: 6922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3070263 , [Content] ='UNITED KINGDOM'
 WHERE id=189309123


   --row number: 6923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3070263 , [Content] ='Solution Consulting'
 WHERE id=189309124


   --row number: 6924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3070263 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=189309125


   --row number: 6925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3070263 , [Content] ='Solution Consultant Core'
 WHERE id=189309126


   --row number: 6926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3070263 , [Content] ='IC4'
 WHERE id=189309127


   --row number: 6927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3070263 , [Content] ='GBP'
 WHERE id=189309129


   --row number: 6928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3070263 , [Content] ='66,938 / 72,844 / 78,750 / 84,656 / 90,563'
 WHERE id=189309130


   --row number: 6929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3070263 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=189309131


   --row number: 6930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3070263 , [Content] ='89,250 / 97,125 / 105,000 / 112,875 / 120,750'
 WHERE id=189309132


   --row number: 6931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3070263 , [Content] ='75/25'
 WHERE id=189309133


   --row number: 6932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3070263 , [Content] ='Yes'
 WHERE id=189309134


   --row number: 6933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3071620 , [Content] ='2 - Professionals'
 WHERE id=189454178


   --row number: 6934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3071620 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189454179


   --row number: 6935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3071620 , [Content] ='Technical'
 WHERE id=189454180


   --row number: 6936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3071620 , [Content] ='6/27/2018'
 WHERE id=189454181


   --row number: 6937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3071620 , [Content] ='6624 US - MRKT 1'
 WHERE id=189454162


   --row number: 6938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3071620 , [Content] ='US - MRKT 1'
 WHERE id=189454163


   --row number: 6939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3071620 , [Content] ='AMS'
 WHERE id=189454164


   --row number: 6940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3071620 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189454165


   --row number: 6941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3071620 , [Content] ='Info Systems/Technology'
 WHERE id=189454166


   --row number: 6942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3071620 , [Content] ='6624 - Project (Information Systems) Mgr IC4'
 WHERE id=189454167


   --row number: 6943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3071620 , [Content] ='IT Project/Program Mgrs'
 WHERE id=189454168


   --row number: 6944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3071620 , [Content] ='IC4'
 WHERE id=189454169


   --row number: 6945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3071620 , [Content] ='USD'
 WHERE id=189454171


   --row number: 6946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3071620 , [Content] ='103,200 / 124,800 / 146,400 / 168,050 / 189,700'
 WHERE id=189454172


   --row number: 6947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3071620 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=189454173


   --row number: 6948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3071620 , [Content] ='20%'
 WHERE id=189454174


   --row number: 6949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3071620 , [Content] ='Yes'
 WHERE id=189454175


   --row number: 6950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3071620 , [Content] ='EXEMPT'
 WHERE id=189454176


   --row number: 6951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3071620 , [Content] ='NO'
 WHERE id=189454177


   --row number: 6952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3071793 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=189476414


   --row number: 6953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3071793 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189476415


   --row number: 6954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3071793 , [Content] ='Technical'
 WHERE id=189476416


   --row number: 6955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3071793 , [Content] ='09/05/18'
 WHERE id=189476417


   --row number: 6956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3071793 , [Content] ='S1874 US - MRKT 1'
 WHERE id=189476398


   --row number: 6957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3071793 , [Content] ='US - MRKT 1'
 WHERE id=189476399


   --row number: 6958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3071793 , [Content] ='AMS'
 WHERE id=189476400


   --row number: 6959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3071793 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189476401


   --row number: 6960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3071793 , [Content] ='Sales Operations'
 WHERE id=189476402


   --row number: 6961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3071793 , [Content] ='S1874 - Sr Mgr, Sales Training and Enablement Mgmt M4'
 WHERE id=189476403


   --row number: 6962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3071793 , [Content] ='Sales Training/Enablement'
 WHERE id=189476404


   --row number: 6963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3071793 , [Content] ='M4'
 WHERE id=189476405


   --row number: 6964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3071793 , [Content] ='USD'
 WHERE id=189476407


   --row number: 6965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3071793 , [Content] ='109,900 / 134,600 / 159,300 / 184,050 / 208,800'
 WHERE id=189476408


   --row number: 6966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3071793 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=189476409


   --row number: 6967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3071793 , [Content] ='25%'
 WHERE id=189476410


   --row number: 6968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3071793 , [Content] ='Yes'
 WHERE id=189476411


   --row number: 6969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3071793 , [Content] ='EXEMPT'
 WHERE id=189476412


   --row number: 6970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3071793 , [Content] ='NO'
 WHERE id=189476413


   --row number: 6971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3072002 , [Content] ='6/27/2018'
 WHERE id=189501902


   --row number: 6972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3072002 , [Content] ='6583 IND'
 WHERE id=189501885


   --row number: 6973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3072002 , [Content] ='IND'
 WHERE id=189501886


   --row number: 6974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3072002 , [Content] ='APAC'
 WHERE id=189501887


   --row number: 6975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3072002 , [Content] ='INDIA'
 WHERE id=189501888


   --row number: 6976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3072002 , [Content] ='Info Systems/Technology'
 WHERE id=189501889


   --row number: 6977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3072002 , [Content] ='6583 - Sr Information Security Engineer IC3'
 WHERE id=189501890


   --row number: 6978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3072002 , [Content] ='Security'
 WHERE id=189501891


   --row number: 6979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3072002 , [Content] ='IC3'
 WHERE id=189501892


   --row number: 6980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3072002 , [Content] ='INR'
 WHERE id=189501894


   --row number: 6981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3072002 , [Content] ='1,027,600 / 1,258,800 / 1,490,000 / 1,721,200 / 1,952,400'
 WHERE id=189501895


   --row number: 6982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3072002 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=189501896


   --row number: 6983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3072002 , [Content] ='15%'
 WHERE id=189501897


   --row number: 6984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3072002 , [Content] ='Yes'
 WHERE id=189501898


   --row number: 6985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3072002 , [Content] ='2 - Professionals'
 WHERE id=189501899


   --row number: 6986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3072002 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189501900


   --row number: 6987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3072002 , [Content] ='Technical'
 WHERE id=189501901


   --row number: 6988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3072003 , [Content] ='6583 IND'
 WHERE id=189502170


   --row number: 6989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3072003 , [Content] ='IND'
 WHERE id=189502171


   --row number: 6990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3072003 , [Content] ='APAC'
 WHERE id=189502172


   --row number: 6991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3072003 , [Content] ='INDIA'
 WHERE id=189502173


   --row number: 6992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3072003 , [Content] ='Info Systems/Technology'
 WHERE id=189502174


   --row number: 6993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3072003 , [Content] ='6583 - Sr Information Security Engineer IC3'
 WHERE id=189502175


   --row number: 6994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3072003 , [Content] ='Security'
 WHERE id=189502176


   --row number: 6995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3072003 , [Content] ='IC3'
 WHERE id=189502177


   --row number: 6996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3072003 , [Content] ='INR'
 WHERE id=189502179


   --row number: 6997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3072003 , [Content] ='1,027,600 / 1,258,800 / 1,490,000 / 1,721,200 / 1,952,400'
 WHERE id=189502180


   --row number: 6998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3072003 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=189502181


   --row number: 6999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3072003 , [Content] ='15%'
 WHERE id=189502182


   --row number: 7000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3072003 , [Content] ='Yes'
 WHERE id=189502183


   --row number: 7001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3072003 , [Content] ='2 - Professionals'
 WHERE id=189502184


   --row number: 7002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3072003 , [Content] ='6/27/2018'
 WHERE id=189502187


   --row number: 7003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3072003 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189502185


   --row number: 7004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3072003 , [Content] ='Technical'
 WHERE id=189502186


   --row number: 7005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3072328 , [Content] ='15%'
 WHERE id=189580344


   --row number: 7006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3072328 , [Content] ='Technical'
 WHERE id=189580348


   --row number: 7007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3072328 , [Content] ='6/27/2018'
 WHERE id=189580349


   --row number: 7008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3072328 , [Content] ='Yes'
 WHERE id=189580345


   --row number: 7009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3072328 , [Content] ='5143 IND'
 WHERE id=189580332


   --row number: 7010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3072328 , [Content] ='IND'
 WHERE id=189580333


   --row number: 7011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3072328 , [Content] ='APAC'
 WHERE id=189580334


   --row number: 7012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3072328 , [Content] ='INDIA'
 WHERE id=189580335


   --row number: 7013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3072328 , [Content] ='Engineering'
 WHERE id=189580336


   --row number: 7014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3072328 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=189580337


   --row number: 7015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3072328 , [Content] ='Software'
 WHERE id=189580338


   --row number: 7016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3072328 , [Content] ='IC3'
 WHERE id=189580339


   --row number: 7017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3072328 , [Content] ='INR'
 WHERE id=189580341


   --row number: 7018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3072328 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=189580342


   --row number: 7019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3072328 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=189580343


   --row number: 7020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3072328 , [Content] ='2 - Professionals'
 WHERE id=189580346


   --row number: 7021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3072328 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=189580347


   --row number: 7022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3072355 , [Content] ='10/05/18'
 WHERE id=189581968


   --row number: 7023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3072355 , [Content] ='5704 SWE'
 WHERE id=189581951


   --row number: 7024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3072355 , [Content] ='SWE'
 WHERE id=189581952


   --row number: 7025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3072355 , [Content] ='EMEA'
 WHERE id=189581953


   --row number: 7026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3072355 , [Content] ='SWEDEN'
 WHERE id=189581954


   --row number: 7027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3072355 , [Content] ='Professional Services'
 WHERE id=189581955


   --row number: 7028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3072355 , [Content] ='5704 - Client Relationship Manager IC4'
 WHERE id=189581956


   --row number: 7029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3072355 , [Content] ='Partner Support'
 WHERE id=189581957


   --row number: 7030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3072355 , [Content] ='IC4'
 WHERE id=189581958


   --row number: 7031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3072355 , [Content] ='SEK'
 WHERE id=189581960


   --row number: 7032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3072355 , [Content] ='528,500 / 639,250 / 750,000 / 860,700 / 971,400'
 WHERE id=189581961


   --row number: 7033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3072355 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=189581962


   --row number: 7034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3072355 , [Content] ='20%'
 WHERE id=189581963


   --row number: 7035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3072355 , [Content] ='Yes'
 WHERE id=189581964


   --row number: 7036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3072355 , [Content] ='2 - Professionals'
 WHERE id=189581965


   --row number: 7037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3072355 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189581966


   --row number: 7038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3072355 , [Content] ='Technical'
 WHERE id=189581967


   --row number: 7039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3072403 , [Content] ='Technical'
 WHERE id=189584513


   --row number: 7040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3072403 , [Content] ='7/20/18'
 WHERE id=189584514


   --row number: 7041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3072403 , [Content] ='5223 IND'
 WHERE id=189584497


   --row number: 7042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3072403 , [Content] ='IND'
 WHERE id=189584498


   --row number: 7043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3072403 , [Content] ='APAC'
 WHERE id=189584499


   --row number: 7044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3072403 , [Content] ='INDIA'
 WHERE id=189584500


   --row number: 7045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3072403 , [Content] ='Engineering'
 WHERE id=189584501


   --row number: 7046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3072403 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=189584502


   --row number: 7047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3072403 , [Content] ='Product Mgmt Mgr'
 WHERE id=189584503


   --row number: 7048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3072403 , [Content] ='IC3'
 WHERE id=189584504


   --row number: 7049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3072403 , [Content] ='INR'
 WHERE id=189584506


   --row number: 7050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3072403 , [Content] ='1,396,600 / 1,710,800 / 2,025,000 / 2,339,250 / 2,653,500'
 WHERE id=189584507


   --row number: 7051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3072403 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=189584508


   --row number: 7052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3072403 , [Content] ='15%'
 WHERE id=189584509


   --row number: 7053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3072403 , [Content] ='Yes'
 WHERE id=189584510


   --row number: 7054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3072403 , [Content] ='2 - Professionals'
 WHERE id=189584511


   --row number: 7055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3072403 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189584512


   --row number: 7056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3072420 , [Content] ='S1615 NLD'
 WHERE id=189585499


   --row number: 7057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3072420 , [Content] ='NLD'
 WHERE id=189585500


   --row number: 7058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3072420 , [Content] ='EMEA'
 WHERE id=189585501


   --row number: 7059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3072420 , [Content] ='NETHERLANDS'
 WHERE id=189585502


   --row number: 7060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3072420 , [Content] ='Sales'
 WHERE id=189585503


   --row number: 7061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3072420 , [Content] ='S1615 - Regional Partner Mgr IC5'
 WHERE id=189585504


   --row number: 7062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3072420 , [Content] ='Partner Sales'
 WHERE id=189585505


   --row number: 7063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3072420 , [Content] ='IC5'
 WHERE id=189585506


   --row number: 7064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3072420 , [Content] ='725 / 1,300 / 1,880'
 WHERE id=189585508


   --row number: 7065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3072420 , [Content] ='60/40'
 WHERE id=189585509


   --row number: 7066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3072420 , [Content] ='Yes'
 WHERE id=189585510


   --row number: 7067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3072420 , [Content] ='4 - Sales Workers'
 WHERE id=189585511


   --row number: 7068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3072420 , [Content] ='8742-Salespersons - Outside'
 WHERE id=189585512


   --row number: 7069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3072420 , [Content] ='Technical'
 WHERE id=189585513


   --row number: 7070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3073013 , [Content] ='Technical'
 WHERE id=189626063


   --row number: 7071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3073013 , [Content] ='6/27/2018'
 WHERE id=189626064


   --row number: 7072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3073013 , [Content] ='5143 IND'
 WHERE id=189626047


   --row number: 7073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3073013 , [Content] ='IND'
 WHERE id=189626048


   --row number: 7074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3073013 , [Content] ='APAC'
 WHERE id=189626049


   --row number: 7075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3073013 , [Content] ='INDIA'
 WHERE id=189626050


   --row number: 7076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3073013 , [Content] ='Engineering'
 WHERE id=189626051


   --row number: 7077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3073013 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=189626052


   --row number: 7078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3073013 , [Content] ='Software'
 WHERE id=189626053


   --row number: 7079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3073013 , [Content] ='IC3'
 WHERE id=189626054


   --row number: 7080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3073013 , [Content] ='INR'
 WHERE id=189626056


   --row number: 7081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3073013 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=189626057


   --row number: 7082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3073013 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=189626058


   --row number: 7083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3073013 , [Content] ='15%'
 WHERE id=189626059


   --row number: 7084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3073013 , [Content] ='Yes'
 WHERE id=189626060


   --row number: 7085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3073013 , [Content] ='2 - Professionals'
 WHERE id=189626061


   --row number: 7086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3073013 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=189626062


   --row number: 7087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3073369 , [Content] ='2 - Professionals'
 WHERE id=189655531


   --row number: 7088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3073369 , [Content] ='6/27/2018'
 WHERE id=189655534


   --row number: 7089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3073369 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=189655532


   --row number: 7090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3073369 , [Content] ='Technical'
 WHERE id=189655533


   --row number: 7091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3073369 , [Content] ='5374 US - MRKT 2'
 WHERE id=189655515


   --row number: 7092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3073369 , [Content] ='US - MRKT 2'
 WHERE id=189655516


   --row number: 7093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3073369 , [Content] ='AMS'
 WHERE id=189655517


   --row number: 7094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3073369 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189655518


   --row number: 7095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3073369 , [Content] ='Engineering'
 WHERE id=189655519


   --row number: 7096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3073369 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=189655520


   --row number: 7097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3073369 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=189655521


   --row number: 7098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3073369 , [Content] ='IC4'
 WHERE id=189655522


   --row number: 7099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3073369 , [Content] ='USD'
 WHERE id=189655524


   --row number: 7100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3073369 , [Content] ='96,100 / 116,250 / 136,400 / 156,500 / 176,600'
 WHERE id=189655525


   --row number: 7101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3073369 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=189655526


   --row number: 7102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3073369 , [Content] ='20%'
 WHERE id=189655527


   --row number: 7103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3073369 , [Content] ='Yes'
 WHERE id=189655528


   --row number: 7104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3073369 , [Content] ='EXEMPT'
 WHERE id=189655529


   --row number: 7105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3073369 , [Content] ='NO'
 WHERE id=189655530


   --row number: 7106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3073805 , [Content] ='5764 SGP'
 WHERE id=189697142


   --row number: 7107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3073805 , [Content] ='SGP'
 WHERE id=189697143


   --row number: 7108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3073805 , [Content] ='APAC'
 WHERE id=189697144


   --row number: 7109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3073805 , [Content] ='SINGAPORE'
 WHERE id=189697145


   --row number: 7110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3073805 , [Content] ='Professional Services'
 WHERE id=189697146


   --row number: 7111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3073805 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=189697147


   --row number: 7112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3073805 , [Content] ='Technology Consultant'
 WHERE id=189697148


   --row number: 7113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3073805 , [Content] ='IC4'
 WHERE id=189697149


   --row number: 7114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3073805 , [Content] ='109,200 / 132,100 / 155,000 / 177,850 / 200,700'
 WHERE id=189697151


   --row number: 7115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3073805 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=189697152


   --row number: 7116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3073805 , [Content] ='20%'
 WHERE id=189697153


   --row number: 7117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3073805 , [Content] ='Yes'
 WHERE id=189697154


   --row number: 7118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3073805 , [Content] ='2 - Professionals'
 WHERE id=189697155


   --row number: 7119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3073805 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189697156


   --row number: 7120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3073805 , [Content] ='Technical'
 WHERE id=189697157


   --row number: 7121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3073809 , [Content] ='6/27/2018'
 WHERE id=189697461


   --row number: 7122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3073809 , [Content] ='5774 SGP'
 WHERE id=189697444


   --row number: 7123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3073809 , [Content] ='SGP'
 WHERE id=189697445


   --row number: 7124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3073809 , [Content] ='APAC'
 WHERE id=189697446


   --row number: 7125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3073809 , [Content] ='SINGAPORE'
 WHERE id=189697447


   --row number: 7126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3073809 , [Content] ='Professional Services'
 WHERE id=189697448


   --row number: 7127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3073809 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=189697449


   --row number: 7128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3073809 , [Content] ='Business Process Consulting'
 WHERE id=189697450


   --row number: 7129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3073809 , [Content] ='IC4'
 WHERE id=189697451


   --row number: 7130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3073809 , [Content] ='SGD'
 WHERE id=189697453


   --row number: 7131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3073809 , [Content] ='104,600 / 123,450 / 142,300 / 161,100 / 179,900'
 WHERE id=189697454


   --row number: 7132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3073809 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=189697455


   --row number: 7133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3073809 , [Content] ='15%'
 WHERE id=189697456


   --row number: 7134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3073809 , [Content] ='Yes'
 WHERE id=189697457


   --row number: 7135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3073809 , [Content] ='2 - Professionals'
 WHERE id=189697458


   --row number: 7136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3073809 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189697459


   --row number: 7137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3073809 , [Content] ='Technical'
 WHERE id=189697460


   --row number: 7138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3073815 , [Content] ='Technical'
 WHERE id=189697781


   --row number: 7139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3073815 , [Content] ='5764 AUS'
 WHERE id=189697766


   --row number: 7140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3073815 , [Content] ='AUS'
 WHERE id=189697767


   --row number: 7141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3073815 , [Content] ='APAC'
 WHERE id=189697768


   --row number: 7142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3073815 , [Content] ='AUSTRALIA'
 WHERE id=189697769


   --row number: 7143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3073815 , [Content] ='Professional Services'
 WHERE id=189697770


   --row number: 7144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3073815 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=189697771


   --row number: 7145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3073815 , [Content] ='Technology Consultant'
 WHERE id=189697772


   --row number: 7146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3073815 , [Content] ='IC4'
 WHERE id=189697773


   --row number: 7147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3073815 , [Content] ='109,900 / 156,000 / 202,000'
 WHERE id=189697775


   --row number: 7148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3073815 , [Content] ='400 / 700 / 1,000'
 WHERE id=189697776


   --row number: 7149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3073815 , [Content] ='20%'
 WHERE id=189697777


   --row number: 7150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3073815 , [Content] ='Yes'
 WHERE id=189697778


   --row number: 7151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3073815 , [Content] ='2 - Professionals'
 WHERE id=189697779


   --row number: 7152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3073815 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189697780


   --row number: 7153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3073818 , [Content] ='5773 AUS'
 WHERE id=189698207


   --row number: 7154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3073818 , [Content] ='AUS'
 WHERE id=189698208


   --row number: 7155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3073818 , [Content] ='APAC'
 WHERE id=189698209


   --row number: 7156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3073818 , [Content] ='AUSTRALIA'
 WHERE id=189698210


   --row number: 7157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3073818 , [Content] ='Professional Services'
 WHERE id=189698211


   --row number: 7158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3073818 , [Content] ='5773 - Business Process Consultant IC3'
 WHERE id=189698212


   --row number: 7159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3073818 , [Content] ='Business Process Consulting'
 WHERE id=189698213


   --row number: 7160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3073818 , [Content] ='IC3'
 WHERE id=189698214


   --row number: 7161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3073818 , [Content] ='AUD'
 WHERE id=189698216


   --row number: 7162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3073818 , [Content] ='102,900 / 119,900 / 136,900 / 153,850 / 170,800'
 WHERE id=189698217


   --row number: 7163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3073818 , [Content] ='27,000 / 37,500 / 48,000 / 58,800 / 69,600'
 WHERE id=189698218


   --row number: 7164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3073818 , [Content] ='10%'
 WHERE id=189698219


   --row number: 7165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3073818 , [Content] ='Yes'
 WHERE id=189698220


   --row number: 7166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3073818 , [Content] ='2 - Professionals'
 WHERE id=189698221


   --row number: 7167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3073818 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189698222


   --row number: 7168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3073818 , [Content] ='Technical'
 WHERE id=189698223


   --row number: 7169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3073818 , [Content] ='6/27/2018'
 WHERE id=189698224


   --row number: 7170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3075334 , [Content] ='EXEMPT'
 WHERE id=189852601


   --row number: 7171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3075334 , [Content] ='2 - Professionals'
 WHERE id=189852603


   --row number: 7172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3075334 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189852604


   --row number: 7173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3075334 , [Content] ='Non Technical'
 WHERE id=189852605


   --row number: 7174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3075334 , [Content] ='6/27/2018'
 WHERE id=189852606


   --row number: 7175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3075493 , [Content] ='6613 US - MRKT 1'
 WHERE id=189864993


   --row number: 7176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3075493 , [Content] ='US - MRKT 1'
 WHERE id=189864994


   --row number: 7177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3075493 , [Content] ='AMS'
 WHERE id=189864995


   --row number: 7178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3075493 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189864996


   --row number: 7179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3075493 , [Content] ='Info Systems/Technology'
 WHERE id=189864997


   --row number: 7180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3075493 , [Content] ='6613 - Sr Storage Engineer IC3'
 WHERE id=189864998


   --row number: 7181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3075493 , [Content] ='Storage'
 WHERE id=189864999


   --row number: 7182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3075493 , [Content] ='IC3'
 WHERE id=189865000


   --row number: 7183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3075493 , [Content] ='USD'
 WHERE id=189865002


   --row number: 7184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3075493 , [Content] ='90,400 / 106,700 / 123,000 / 139,250 / 155,500'
 WHERE id=189865003


   --row number: 7185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3075493 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=189865004


   --row number: 7186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3075493 , [Content] ='15%'
 WHERE id=189865005


   --row number: 7187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3075493 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=189865006


   --row number: 7188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3075493 , [Content] ='Yes'
 WHERE id=189865007


   --row number: 7189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3075493 , [Content] ='EXEMPT'
 WHERE id=189865008


   --row number: 7190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3075493 , [Content] ='YES'
 WHERE id=189865009


   --row number: 7191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3075334 , [Content] ='NO'
 WHERE id=189852602


   --row number: 7192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3075334 , [Content] ='US - MRKT 1'
 WHERE id=189852588


   --row number: 7193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3075334 , [Content] ='AMS'
 WHERE id=189852589


   --row number: 7194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3075334 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=189852590


   --row number: 7195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3075334 , [Content] ='Business Strategy'
 WHERE id=189852591


   --row number: 7196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3075334 , [Content] ='6014 - Business Analytics IC4'
 WHERE id=189852592


   --row number: 7197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3075334 , [Content] ='Business Analytics'
 WHERE id=189852593


   --row number: 7198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3075334 , [Content] ='IC4'
 WHERE id=189852594


   --row number: 7199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3075334 , [Content] ='USD'
 WHERE id=189852596


   --row number: 7200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3075334 , [Content] ='103,900 / 122,600 / 141,300 / 160,000 / 178,700'
 WHERE id=189852597


   --row number: 7201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3075334 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=189852598


   --row number: 7202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3075334 , [Content] ='15%'
 WHERE id=189852599


   --row number: 7203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3075334 , [Content] ='Yes'
 WHERE id=189852600


   --row number: 7204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3075334 , [Content] ='6014 US - MRKT 1'
 WHERE id=189852587


   --row number: 7205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3075493 , [Content] ='2 - Professionals'
 WHERE id=189865010


   --row number: 7206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3075493 , [Content] ='8810-Clerical Office Employees'
 WHERE id=189865011


   --row number: 7207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3075493 , [Content] ='Technical'
 WHERE id=189865012


   --row number: 7208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3075493 , [Content] ='6/27/2018'
 WHERE id=189865013


   --row number: 7209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3076707 , [Content] ='S1414 UK'
 WHERE id=189994067


   --row number: 7210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3076707 , [Content] ='UK'
 WHERE id=189994068


   --row number: 7211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3076707 , [Content] ='EMEA'
 WHERE id=189994069


   --row number: 7212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3076707 , [Content] ='UNITED KINGDOM'
 WHERE id=189994070


   --row number: 7213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3076707 , [Content] ='Solution Consulting'
 WHERE id=189994071


   --row number: 7214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3076707 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=189994072


   --row number: 7215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3076707 , [Content] ='Solution Consultant Core'
 WHERE id=189994073


   --row number: 7216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3076707 , [Content] ='IC4'
 WHERE id=189994074


   --row number: 7217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3076707 , [Content] ='GBP'
 WHERE id=189994076


   --row number: 7218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3076707 , [Content] ='66,938 / 72,844 / 78,750 / 84,656 / 90,563'
 WHERE id=189994077


   --row number: 7219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3076707 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=189994078


   --row number: 7220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3076707 , [Content] ='89,250 / 97,125 / 105,000 / 112,875 / 120,750'
 WHERE id=189994079


   --row number: 7221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3076707 , [Content] ='75/25'
 WHERE id=189994080


   --row number: 7222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3076707 , [Content] ='Yes'
 WHERE id=189994081


   --row number: 7223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3076707 , [Content] ='4 - Sales Workers'
 WHERE id=189994084


   --row number: 7224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3076707 , [Content] ='8742-Salespersons - Outside'
 WHERE id=189994085


   --row number: 7225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3076707 , [Content] ='Technical'
 WHERE id=189994086


   --row number: 7226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3076707 , [Content] ='6/27/2018'
 WHERE id=189994087


   --row number: 7227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3076723 , [Content] ='S1414 DEU'
 WHERE id=189999087


   --row number: 7228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3076723 , [Content] ='DEU'
 WHERE id=189999088


   --row number: 7229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3076723 , [Content] ='EMEA'
 WHERE id=189999089


   --row number: 7230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3076723 , [Content] ='GERMANY'
 WHERE id=189999090


   --row number: 7231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3076723 , [Content] ='Solution Consulting'
 WHERE id=189999091


   --row number: 7232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3076723 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=189999092


   --row number: 7233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3076723 , [Content] ='Solution Consultant Core'
 WHERE id=189999093


   --row number: 7234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3076723 , [Content] ='IC4'
 WHERE id=189999094


   --row number: 7235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3076723 , [Content] ='EUR'
 WHERE id=189999096


   --row number: 7236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3076723 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=189999097


   --row number: 7237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3076723 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=189999098


   --row number: 7238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3076723 , [Content] ='102,000 / 111,000 / 120,000 / 129,000 / 138,000'
 WHERE id=189999099


   --row number: 7239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3076723 , [Content] ='75/25'
 WHERE id=189999100


   --row number: 7240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3076723 , [Content] ='Yes'
 WHERE id=189999101


   --row number: 7241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3076723 , [Content] ='4 - Sales Workers'
 WHERE id=189999102


   --row number: 7242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3076723 , [Content] ='8742-Salespersons - Outside'
 WHERE id=189999103


   --row number: 7243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3076723 , [Content] ='Technical'
 WHERE id=189999104


   --row number: 7244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3076723 , [Content] ='6/27/2018'
 WHERE id=189999105


   --row number: 7245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3076756 , [Content] ='5182 UK'
 WHERE id=190008788


   --row number: 7246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3076756 , [Content] ='UK'
 WHERE id=190008789


   --row number: 7247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3076756 , [Content] ='EMEA'
 WHERE id=190008790


   --row number: 7248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3076756 , [Content] ='UNITED KINGDOM'
 WHERE id=190008791


   --row number: 7249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3076756 , [Content] ='Engineering'
 WHERE id=190008792


   --row number: 7250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3076756 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=190008793


   --row number: 7251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3076756 , [Content] ='Quality'
 WHERE id=190008794


   --row number: 7252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3076756 , [Content] ='IC2'
 WHERE id=190008795


   --row number: 7253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3076756 , [Content] ='GBP'
 WHERE id=190008797


   --row number: 7254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3076756 , [Content] ='29,400 / 34,250 / 39,100 / 43,950 / 48,800'
 WHERE id=190008798


   --row number: 7255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3076756 , [Content] ='10%'
 WHERE id=190008799


   --row number: 7256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3076756 , [Content] ='No'
 WHERE id=190008800


   --row number: 7257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3076756 , [Content] ='2 - Professionals'
 WHERE id=190008801


   --row number: 7258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3076756 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=190008802


   --row number: 7259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3076756 , [Content] ='Technical'
 WHERE id=190008803


   --row number: 7260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3076756 , [Content] ='6/27/2018'
 WHERE id=190008804


   --row number: 7261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3076768 , [Content] ='S1413 FRA'
 WHERE id=190010039


   --row number: 7262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3076768 , [Content] ='FRA'
 WHERE id=190010040


   --row number: 7263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3076768 , [Content] ='EMEA'
 WHERE id=190010041


   --row number: 7264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3076768 , [Content] ='FRANCE'
 WHERE id=190010042


   --row number: 7265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3076768 , [Content] ='Solution Consulting'
 WHERE id=190010043


   --row number: 7266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3076768 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=190010044


   --row number: 7267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3076768 , [Content] ='Solution Consultant Core'
 WHERE id=190010045


   --row number: 7268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3076768 , [Content] ='IC3'
 WHERE id=190010046


   --row number: 7269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3076768 , [Content] ='EUR'
 WHERE id=190010048


   --row number: 7270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3076768 , [Content] ='57,375 / 62,438 / 67,500 / 72,563 / 77,625'
 WHERE id=190010049


   --row number: 7271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3076768 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=190010050


   --row number: 7272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3076768 , [Content] ='75/25'
 WHERE id=190010051


   --row number: 7273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3076768 , [Content] ='No'
 WHERE id=190010052


   --row number: 7274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3076768 , [Content] ='4 - Sales Workers'
 WHERE id=190010053


   --row number: 7275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3076768 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190010054


   --row number: 7276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3076768 , [Content] ='Technical'
 WHERE id=190010055


   --row number: 7277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3076768 , [Content] ='10/26/2018'
 WHERE id=190010056


   --row number: 7278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3077248 , [Content] ='S1411 US - MRKT 2'
 WHERE id=190062489


   --row number: 7279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3077248 , [Content] ='US - MRKT 2'
 WHERE id=190062490


   --row number: 7280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3077248 , [Content] ='AMS'
 WHERE id=190062491


   --row number: 7281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3077248 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190062492


   --row number: 7282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3077248 , [Content] ='Solution Consulting'
 WHERE id=190062493


   --row number: 7283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3077248 , [Content] ='S1411 - Assoc Solution Consultant IC1'
 WHERE id=190062494


   --row number: 7284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3077248 , [Content] ='Solution Consultant Core'
 WHERE id=190062495


   --row number: 7285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3077248 , [Content] ='IC1'
 WHERE id=190062496


   --row number: 7286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3077248 , [Content] ='USD'
 WHERE id=190062498


   --row number: 7287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3077248 , [Content] ='63,750 / 69,375 / 75,000 / 80,625 / 86,250'
 WHERE id=190062499


   --row number: 7288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3077248 , [Content] ='24,600 / 29,100 / 33,600 / 38,400 / 43,200'
 WHERE id=190062500


   --row number: 7289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3077248 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=190062501


   --row number: 7290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3077248 , [Content] ='75/25'
 WHERE id=190062502


   --row number: 7291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3077248 , [Content] ='Yes'
 WHERE id=190062503


   --row number: 7292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3077248 , [Content] ='EXEMPT'
 WHERE id=190062504


   --row number: 7293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3077248 , [Content] ='NO'
 WHERE id=190062505


   --row number: 7294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3077248 , [Content] ='4 - Sales Workers'
 WHERE id=190062506


   --row number: 7295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3077248 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190062507


   --row number: 7296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3077248 , [Content] ='Technical'
 WHERE id=190062508


   --row number: 7297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3077248 , [Content] ='6/27/2018'
 WHERE id=190062509


   --row number: 7298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3077698 , [Content] ='2703 US - MRKT 1'
 WHERE id=190097703


   --row number: 7299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3077698 , [Content] ='US - MRKT 1'
 WHERE id=190097704


   --row number: 7300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3077698 , [Content] ='AMS'
 WHERE id=190097705


   --row number: 7301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3077698 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190097706


   --row number: 7302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3077698 , [Content] ='Marketing'
 WHERE id=190097707


   --row number: 7303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3077698 , [Content] ='2703 - Mgr, Product Portfolio Mgmt M3'
 WHERE id=190097708


   --row number: 7304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3077698 , [Content] ='Product Mgrs'
 WHERE id=190097709


   --row number: 7305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3077698 , [Content] ='M3'
 WHERE id=190097710


   --row number: 7306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3077698 , [Content] ='USD'
 WHERE id=190097712


   --row number: 7307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3077698 , [Content] ='109,500 / 132,450 / 155,400 / 178,350 / 201,300'
 WHERE id=190097713


   --row number: 7308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3077698 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=190097714


   --row number: 7309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3077698 , [Content] ='20%'
 WHERE id=190097715


   --row number: 7310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3077698 , [Content] ='Yes'
 WHERE id=190097716


   --row number: 7311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3077698 , [Content] ='EXEMPT'
 WHERE id=190097717


   --row number: 7312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3077698 , [Content] ='NO'
 WHERE id=190097718


   --row number: 7313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3077698 , [Content] ='6/27/2018'
 WHERE id=190097722


   --row number: 7314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3077698 , [Content] ='Technical'
 WHERE id=190097721


   --row number: 7315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3077698 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190097720


   --row number: 7316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3077698 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=190097719


   --row number: 7317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3077867 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=190120334


   --row number: 7318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3077867 , [Content] ='Non Technical'
 WHERE id=190120341


   --row number: 7319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3077867 , [Content] ='04/05/18'
 WHERE id=190120342


   --row number: 7320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3077867 , [Content] ='178,000 / 218,050 / 258,100 / 298,150 / 338,200'
 WHERE id=190120333


   --row number: 7321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3077867 , [Content] ='USD'
 WHERE id=190120332


   --row number: 7322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3077867 , [Content] ='M6'
 WHERE id=190120330


   --row number: 7323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3077867 , [Content] ='Strategic Planning/Analytics'
 WHERE id=190120329


   --row number: 7324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3077867 , [Content] ='2966 - Sr Dir, Strategic Planning/Analytics Mgmt M6'
 WHERE id=190120328


   --row number: 7325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3077867 , [Content] ='Business Strategy'
 WHERE id=190120327


   --row number: 7326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3077867 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190120326


   --row number: 7327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3077867 , [Content] ='AMS'
 WHERE id=190120325


   --row number: 7328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3077867 , [Content] ='US - MRKT 1'
 WHERE id=190120324


   --row number: 7329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3077867 , [Content] ='2966 US - MRKT 1'
 WHERE id=190120323


   --row number: 7330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3077867 , [Content] ='30%'
 WHERE id=190120335


   --row number: 7331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3077867 , [Content] ='Yes'
 WHERE id=190120336


   --row number: 7332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3077867 , [Content] ='EXEMPT'
 WHERE id=190120337


   --row number: 7333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3077867 , [Content] ='NO'
 WHERE id=190120338


   --row number: 7334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3077867 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=190120339


   --row number: 7335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3077867 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190120340


   --row number: 7336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3077914 , [Content] ='6/27/2018'
 WHERE id=190133187


   --row number: 7337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3077914 , [Content] ='5143 IND'
 WHERE id=190133170


   --row number: 7338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3077914 , [Content] ='IND'
 WHERE id=190133171


   --row number: 7339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3077914 , [Content] ='APAC'
 WHERE id=190133172


   --row number: 7340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3077914 , [Content] ='INDIA'
 WHERE id=190133173


   --row number: 7341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3077914 , [Content] ='Engineering'
 WHERE id=190133174


   --row number: 7342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3077914 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=190133175


   --row number: 7343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3077914 , [Content] ='Software'
 WHERE id=190133176


   --row number: 7344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3077914 , [Content] ='IC3'
 WHERE id=190133177


   --row number: 7345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3077914 , [Content] ='INR'
 WHERE id=190133179


   --row number: 7346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3077914 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=190133180


   --row number: 7347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3077914 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=190133181


   --row number: 7348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3077914 , [Content] ='15%'
 WHERE id=190133182


   --row number: 7349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3077914 , [Content] ='Yes'
 WHERE id=190133183


   --row number: 7350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3077914 , [Content] ='2 - Professionals'
 WHERE id=190133184


   --row number: 7351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3077914 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=190133185


   --row number: 7352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3077914 , [Content] ='Technical'
 WHERE id=190133186


   --row number: 7353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3077944 , [Content] ='5142 IND'
 WHERE id=190134293


   --row number: 7354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3077944 , [Content] ='IND'
 WHERE id=190134294


   --row number: 7355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3077944 , [Content] ='APAC'
 WHERE id=190134295


   --row number: 7356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3077944 , [Content] ='INDIA'
 WHERE id=190134296


   --row number: 7357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3077944 , [Content] ='Engineering'
 WHERE id=190134297


   --row number: 7358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3077944 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=190134298


   --row number: 7359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3077944 , [Content] ='Software'
 WHERE id=190134299


   --row number: 7360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3077944 , [Content] ='IC2'
 WHERE id=190134300


   --row number: 7361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3077944 , [Content] ='INR'
 WHERE id=190134302


   --row number: 7362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3077944 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=190134303


   --row number: 7363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3077944 , [Content] ='10%'
 WHERE id=190134304


   --row number: 7364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3077944 , [Content] ='No'
 WHERE id=190134305


   --row number: 7365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3077944 , [Content] ='2 - Professionals'
 WHERE id=190134306


   --row number: 7366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3077944 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=190134307


   --row number: 7367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3077944 , [Content] ='Technical'
 WHERE id=190134308


   --row number: 7368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3077944 , [Content] ='04/05/18'
 WHERE id=190134309


   --row number: 7369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3079001 , [Content] ='6592 US - MRKT 1'
 WHERE id=190253188


   --row number: 7370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3079001 , [Content] ='US - MRKT 1'
 WHERE id=190253189


   --row number: 7371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3079001 , [Content] ='AMS'
 WHERE id=190253190


   --row number: 7372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3079001 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190253191


   --row number: 7373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3079001 , [Content] ='Info Systems/Technology'
 WHERE id=190253192


   --row number: 7374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3079001 , [Content] ='6592 - Database Engineer IC2'
 WHERE id=190253193


   --row number: 7375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3079001 , [Content] ='Database Engineer'
 WHERE id=190253194


   --row number: 7376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3079001 , [Content] ='IC2'
 WHERE id=190253195


   --row number: 7377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3079001 , [Content] ='Technical'
 WHERE id=190253206


   --row number: 7378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3079001 , [Content] ='10/05/18'
 WHERE id=190253207


   --row number: 7379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3079001 , [Content] ='USD'
 WHERE id=190253197


   --row number: 7380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3079001 , [Content] ='82,200 / 95,750 / 109,300 / 122,900 / 136,500'
 WHERE id=190253198


   --row number: 7381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3079001 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=190253199


   --row number: 7382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3079001 , [Content] ='10%'
 WHERE id=190253200


   --row number: 7383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3079001 , [Content] ='Yes'
 WHERE id=190253201


   --row number: 7384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3079001 , [Content] ='EXEMPT'
 WHERE id=190253202


   --row number: 7385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3079001 , [Content] ='YES'
 WHERE id=190253203


   --row number: 7386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3079001 , [Content] ='2 - Professionals'
 WHERE id=190253204


   --row number: 7387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3079001 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190253205


   --row number: 7388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3079619 , [Content] ='INDIA'
 WHERE id=190296869


   --row number: 7389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3079619 , [Content] ='Technical'
 WHERE id=190296882


   --row number: 7390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3079619 , [Content] ='7/20/2018'
 WHERE id=190296883


   --row number: 7391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3079619 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=190296870


   --row number: 7392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3079619 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=190296871


   --row number: 7393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3079619 , [Content] ='6483 IND'
 WHERE id=190296866


   --row number: 7394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3079619 , [Content] ='IND'
 WHERE id=190296867


   --row number: 7395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3079619 , [Content] ='APAC'
 WHERE id=190296868


   --row number: 7396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3079619 , [Content] ='Production service'
 WHERE id=190296872


   --row number: 7397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3079619 , [Content] ='IC3'
 WHERE id=190296873


   --row number: 7398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3079619 , [Content] ='INR'
 WHERE id=190296875


   --row number: 7399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3079619 , [Content] ='1,206,900 / 1,478,450 / 1,750,000 / 2,021,550 / 2,293,100'
 WHERE id=190296876


   --row number: 7400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3079619 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=190296877


   --row number: 7401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3079619 , [Content] ='15%'
 WHERE id=190296878


   --row number: 7402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3079619 , [Content] ='Yes'
 WHERE id=190296879


   --row number: 7403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3079619 , [Content] ='2 - Professionals'
 WHERE id=190296880


   --row number: 7404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3079619 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190296881


   --row number: 7405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3056067 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=190311536


   --row number: 7406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3080000 , [Content] ='4 - Sales Workers'
 WHERE id=190431890


   --row number: 7407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3080000 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190431891


   --row number: 7408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3080000 , [Content] ='Technical'
 WHERE id=190431892


   --row number: 7409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080000 , [Content] ='7/20/2018'
 WHERE id=190431893


   --row number: 7410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080001 , [Content] ='S1415 AUS'
 WHERE id=190431979


   --row number: 7411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080000 , [Content] ='S1416 AUS'
 WHERE id=190431875


   --row number: 7412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080000 , [Content] ='AUS'
 WHERE id=190431876


   --row number: 7413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080000 , [Content] ='APAC'
 WHERE id=190431877


   --row number: 7414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080000 , [Content] ='AUSTRALIA'
 WHERE id=190431878


   --row number: 7415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3080000 , [Content] ='Solution Consulting'
 WHERE id=190431879


   --row number: 7416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080000 , [Content] ='S1416 - Principal Solution Consultant IC6'
 WHERE id=190431880


   --row number: 7417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3080000 , [Content] ='Solution Consultant Core'
 WHERE id=190431881


   --row number: 7418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3080000 , [Content] ='IC6'
 WHERE id=190431882


   --row number: 7419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080000 , [Content] ='AUD'
 WHERE id=190431884


   --row number: 7420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3080000 , [Content] ='191,250 / 208,125 / 225,000 / 241,875 / 258,750'
 WHERE id=190431885


   --row number: 7421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3080000 , [Content] ='93,000 / 139,500 / 186,000 / 232,500 / 279,000'
 WHERE id=190431886


   --row number: 7422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3080000 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=190431887


   --row number: 7423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3080000 , [Content] ='75/25'
 WHERE id=190431888


   --row number: 7424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080000 , [Content] ='Yes'
 WHERE id=190431889


   --row number: 7425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080001 , [Content] ='AUS'
 WHERE id=190431980


   --row number: 7426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080001 , [Content] ='APAC'
 WHERE id=190431981


   --row number: 7427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080001 , [Content] ='AUSTRALIA'
 WHERE id=190431982


   --row number: 7428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3080001 , [Content] ='Solution Consulting'
 WHERE id=190431983


   --row number: 7429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080001 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=190431984


   --row number: 7430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3080001 , [Content] ='Solution Consultant Core'
 WHERE id=190431985


   --row number: 7431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3080001 , [Content] ='IC5'
 WHERE id=190431986


   --row number: 7432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080001 , [Content] ='AUD'
 WHERE id=190431988


   --row number: 7433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3080001 , [Content] ='168,938 / 183,844 / 198,750 / 213,656 / 228,563'
 WHERE id=190431989


   --row number: 7434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3080001 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=190431990


   --row number: 7435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3080001 , [Content] ='225,250 / 245,125 / 265,000 / 284,875 / 304,750'
 WHERE id=190431991


   --row number: 7436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3080001 , [Content] ='75/25'
 WHERE id=190431992


   --row number: 7437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080001 , [Content] ='Yes'
 WHERE id=190431993


   --row number: 7438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3080001 , [Content] ='4 - Sales Workers'
 WHERE id=190431994


   --row number: 7439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3080001 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190431995


   --row number: 7440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3080001 , [Content] ='Technical'
 WHERE id=190431996


   --row number: 7441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080001 , [Content] ='7/20/2018'
 WHERE id=190431997


   --row number: 7442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080224 , [Content] ='04/05/18'
 WHERE id=190486889


   --row number: 7443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080224 , [Content] ='5694 DEU'
 WHERE id=190486872


   --row number: 7444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080224 , [Content] ='DEU'
 WHERE id=190486873


   --row number: 7445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080224 , [Content] ='EMEA'
 WHERE id=190486874


   --row number: 7446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080224 , [Content] ='GERMANY'
 WHERE id=190486875


   --row number: 7447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3080224 , [Content] ='Customer Support'
 WHERE id=190486876


   --row number: 7448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080224 , [Content] ='5694 - Support Account Services Mgr IC4'
 WHERE id=190486877


   --row number: 7449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3080224 , [Content] ='SAM Services'
 WHERE id=190486878


   --row number: 7450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3080224 , [Content] ='IC4'
 WHERE id=190486879


   --row number: 7451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080224 , [Content] ='EUR'
 WHERE id=190486881


   --row number: 7452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3080224 , [Content] ='64,900 / 76,550 / 88,200 / 99,900 / 111,600'
 WHERE id=190486882


   --row number: 7453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3080224 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=190486883


   --row number: 7454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3080224 , [Content] ='15%'
 WHERE id=190486884


   --row number: 7455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080224 , [Content] ='Yes'
 WHERE id=190486885


   --row number: 7456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3080224 , [Content] ='2 - Professionals'
 WHERE id=190486886


   --row number: 7457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3080224 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190486887


   --row number: 7458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3080224 , [Content] ='Technical'
 WHERE id=190486888


   --row number: 7459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3080229 , [Content] ='Technical'
 WHERE id=190488472


   --row number: 7460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080229 , [Content] ='7/20/2018'
 WHERE id=190488473


   --row number: 7461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080229 , [Content] ='5694 NLD'
 WHERE id=190488456


   --row number: 7462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080229 , [Content] ='NLD'
 WHERE id=190488457


   --row number: 7463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080229 , [Content] ='EMEA'
 WHERE id=190488458


   --row number: 7464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080229 , [Content] ='NETHERLANDS'
 WHERE id=190488459


   --row number: 7465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3080229 , [Content] ='Customer Support'
 WHERE id=190488460


   --row number: 7466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080229 , [Content] ='5694 - Support Account Services Mgr IC4'
 WHERE id=190488461


   --row number: 7467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3080229 , [Content] ='SAM Services'
 WHERE id=190488462


   --row number: 7468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3080229 , [Content] ='IC4'
 WHERE id=190488463


   --row number: 7469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080229 , [Content] ='EUR'
 WHERE id=190488465


   --row number: 7470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3080229 , [Content] ='60,400 / 71,250 / 82,100 / 93,000 / 103,900'
 WHERE id=190488466


   --row number: 7471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3080229 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=190488467


   --row number: 7472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3080229 , [Content] ='15%'
 WHERE id=190488468


   --row number: 7473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080229 , [Content] ='Yes'
 WHERE id=190488469


   --row number: 7474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3080229 , [Content] ='2 - Professionals'
 WHERE id=190488470


   --row number: 7475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3080229 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190488471


   --row number: 7476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080252 , [Content] ='7/20/2018'
 WHERE id=190497850


   --row number: 7477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080252 , [Content] ='6075 NLD'
 WHERE id=190497833


   --row number: 7478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080252 , [Content] ='NLD'
 WHERE id=190497834


   --row number: 7479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080252 , [Content] ='EMEA'
 WHERE id=190497835


   --row number: 7480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080252 , [Content] ='NETHERLANDS'
 WHERE id=190497836


   --row number: 7481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3080252 , [Content] ='Legal'
 WHERE id=190497837


   --row number: 7482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080252 , [Content] ='6075 - Contracts Manager IC5'
 WHERE id=190497838


   --row number: 7483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3080252 , [Content] ='Contracts Mgmt'
 WHERE id=190497839


   --row number: 7484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3080252 , [Content] ='IC5'
 WHERE id=190497840


   --row number: 7485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080252 , [Content] ='EUR'
 WHERE id=190497842


   --row number: 7486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3080252 , [Content] ='65,500 / 79,250 / 93,000 / 106,700 / 120,400'
 WHERE id=190497843


   --row number: 7487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3080252 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=190497844


   --row number: 7488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3080252 , [Content] ='20%'
 WHERE id=190497845


   --row number: 7489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080252 , [Content] ='Yes'
 WHERE id=190497846


   --row number: 7490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3080252 , [Content] ='2 - Professionals'
 WHERE id=190497847


   --row number: 7491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3080252 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190497848


   --row number: 7492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3080252 , [Content] ='Non Technical'
 WHERE id=190497849


   --row number: 7493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080307 , [Content] ='9999 IND'
 WHERE id=190516192


   --row number: 7494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080307 , [Content] ='IND'
 WHERE id=190516193


   --row number: 7495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080307 , [Content] ='APAC'
 WHERE id=190516194


   --row number: 7496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080307 , [Content] ='India'
 WHERE id=190516195


   --row number: 7497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080307 , [Content] ='9999 - Intern'
 WHERE id=190516196


   --row number: 7498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080307 , [Content] ='INR'
 WHERE id=190516197


   --row number: 7499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080307 , [Content] ='No'
 WHERE id=190516198


   --row number: 7500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080307 , [Content] ='7/20/2018'
 WHERE id=190516199


   --row number: 7501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3080344 , [Content] ='5874 ITA'
 WHERE id=190521289


   --row number: 7502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3080344 , [Content] ='ITA'
 WHERE id=190521290


   --row number: 7503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3080344 , [Content] ='EMEA'
 WHERE id=190521291


   --row number: 7504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3080344 , [Content] ='ITALY'
 WHERE id=190521292


   --row number: 7505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3080344 , [Content] ='Professional Services'
 WHERE id=190521293


   --row number: 7506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3080344 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190521304


   --row number: 7507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3080344 , [Content] ='Technical'
 WHERE id=190521305


   --row number: 7508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3080344 , [Content] ='6/27/2018'
 WHERE id=190521306


   --row number: 7509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3080344 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=190521294


   --row number: 7510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3080344 , [Content] ='Engagement Mgrs'
 WHERE id=190521295


   --row number: 7511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3080344 , [Content] ='IC4'
 WHERE id=190521296


   --row number: 7512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3080344 , [Content] ='EUR'
 WHERE id=190521298


   --row number: 7513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3080344 , [Content] ='50,000 / 60,500 / 71,000 / 81,450 / 91,900'
 WHERE id=190521299


   --row number: 7514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3080344 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=190521300


   --row number: 7515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3080344 , [Content] ='20%'
 WHERE id=190521301


   --row number: 7516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3080344 , [Content] ='Yes'
 WHERE id=190521302


   --row number: 7517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3080344 , [Content] ='2 - Professionals'
 WHERE id=190521303


   --row number: 7518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3081755 , [Content] ='AMS'
 WHERE id=190652300


   --row number: 7519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3081755 , [Content] ='NO'
 WHERE id=190652314


   --row number: 7520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3081755 , [Content] ='4 - Sales Workers'
 WHERE id=190652315


   --row number: 7521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3081755 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190652316


   --row number: 7522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3081755 , [Content] ='Technical'
 WHERE id=190652317


   --row number: 7523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3081755 , [Content] ='09/05/18'
 WHERE id=190652318


   --row number: 7524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3081755 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190652301


   --row number: 7525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3081755 , [Content] ='Solution Consulting'
 WHERE id=190652302


   --row number: 7526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3081755 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=190652303


   --row number: 7527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3081755 , [Content] ='Solution Consultant Core'
 WHERE id=190652304


   --row number: 7528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3081755 , [Content] ='IC5'
 WHERE id=190652305


   --row number: 7529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3081755 , [Content] ='USD'
 WHERE id=190652307


   --row number: 7530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3081755 , [Content] ='140,888 / 153,319 / 165,750 / 178,181 / 190,613'
 WHERE id=190652308


   --row number: 7531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3081755 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=190652309


   --row number: 7532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3081755 , [Content] ='187,850 / 204,425 / 221,000 / 237,575 / 254,150'
 WHERE id=190652310


   --row number: 7533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3081755 , [Content] ='75/25'
 WHERE id=190652311


   --row number: 7534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3081755 , [Content] ='Yes'
 WHERE id=190652312


   --row number: 7535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3081755 , [Content] ='EXEMPT'
 WHERE id=190652313


   --row number: 7536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3081755 , [Content] ='S1415 US - MRKT 1'
 WHERE id=190652298


   --row number: 7537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3081755 , [Content] ='US - MRKT 1'
 WHERE id=190652299


   --row number: 7538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3081843 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190665099


   --row number: 7539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3081843 , [Content] ='Technical'
 WHERE id=190665100


   --row number: 7540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3081843 , [Content] ='7/20/2018'
 WHERE id=190665101


   --row number: 7541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3081843 , [Content] ='S1805 US - MRKT 1'
 WHERE id=190665082


   --row number: 7542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3081843 , [Content] ='US - MRKT 1'
 WHERE id=190665083


   --row number: 7543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3081843 , [Content] ='AMS'
 WHERE id=190665084


   --row number: 7544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3081843 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190665085


   --row number: 7545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3081843 , [Content] ='Sales Operations'
 WHERE id=190665086


   --row number: 7546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3081843 , [Content] ='S1805 - Dir, Sales Operations Mgmt M5'
 WHERE id=190665087


   --row number: 7547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3081843 , [Content] ='Sales Operations'
 WHERE id=190665088


   --row number: 7548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3081843 , [Content] ='M5'
 WHERE id=190665089


   --row number: 7549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3081843 , [Content] ='USD'
 WHERE id=190665091


   --row number: 7550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3081843 , [Content] ='133,000 / 162,950 / 192,900 / 222,800 / 252,700'
 WHERE id=190665092


   --row number: 7551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3081843 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=190665093


   --row number: 7552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3081843 , [Content] ='25%'
 WHERE id=190665094


   --row number: 7553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3081843 , [Content] ='Yes'
 WHERE id=190665095


   --row number: 7554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3081843 , [Content] ='EXEMPT'
 WHERE id=190665096


   --row number: 7555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3081843 , [Content] ='NO'
 WHERE id=190665097


   --row number: 7556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3081843 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=190665098


   --row number: 7557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3081893 , [Content] ='S1414 HKG'
 WHERE id=190684995


   --row number: 7558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3081893 , [Content] ='HKG'
 WHERE id=190684996


   --row number: 7559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3081893 , [Content] ='APAC'
 WHERE id=190684997


   --row number: 7560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3081893 , [Content] ='HONG KONG'
 WHERE id=190684998


   --row number: 7561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3081893 , [Content] ='4 - Sales Workers'
 WHERE id=190685010


   --row number: 7562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3081893 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190685011


   --row number: 7563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3081893 , [Content] ='Technical'
 WHERE id=190685012


   --row number: 7564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3081893 , [Content] ='7/20/2018'
 WHERE id=190685013


   --row number: 7565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3081893 , [Content] ='Solution Consulting'
 WHERE id=190684999


   --row number: 7566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3081893 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=190685000


   --row number: 7567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3081893 , [Content] ='Solution Consultant Core'
 WHERE id=190685001


   --row number: 7568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3081893 , [Content] ='IC4'
 WHERE id=190685002


   --row number: 7569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3081893 , [Content] ='HKD'
 WHERE id=190685004


   --row number: 7570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3081893 , [Content] ='829,069 / 902,222 / 975,375 / 1,048,528 / 1,121,681'
 WHERE id=190685005


   --row number: 7571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3081893 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=190685006


   --row number: 7572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3081893 , [Content] ='1,105,425 / 1,202,963 / 1,300,500 / 1,398,038 / 1,495,575'
 WHERE id=190685007


   --row number: 7573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3081893 , [Content] ='75/25'
 WHERE id=190685008


   --row number: 7574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3081893 , [Content] ='Yes'
 WHERE id=190685009


   --row number: 7575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3081919 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=190686999


   --row number: 7576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3081919 , [Content] ='Software'
 WHERE id=190687000


   --row number: 7577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3081919 , [Content] ='IC4'
 WHERE id=190687001


   --row number: 7578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3081919 , [Content] ='INR'
 WHERE id=190687003


   --row number: 7579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3081919 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=190687004


   --row number: 7580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3081919 , [Content] ='5144 IND'
 WHERE id=190686994


   --row number: 7581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3081919 , [Content] ='IND'
 WHERE id=190686995


   --row number: 7582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3081919 , [Content] ='APAC'
 WHERE id=190686996


   --row number: 7583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3081919 , [Content] ='INDIA'
 WHERE id=190686997


   --row number: 7584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3081919 , [Content] ='Engineering'
 WHERE id=190686998


   --row number: 7585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3081919 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=190687005


   --row number: 7586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3081919 , [Content] ='20%'
 WHERE id=190687006


   --row number: 7587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3081919 , [Content] ='Yes'
 WHERE id=190687007


   --row number: 7588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3081919 , [Content] ='2 - Professionals'
 WHERE id=190687008


   --row number: 7589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3081919 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=190687009


   --row number: 7590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3081919 , [Content] ='Technical'
 WHERE id=190687010


   --row number: 7591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3081919 , [Content] ='4/25/2018'
 WHERE id=190687011


   --row number: 7592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3082606 , [Content] ='15%'
 WHERE id=190816330


   --row number: 7593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3082606 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190816335


   --row number: 7594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3082606 , [Content] ='Non Technical'
 WHERE id=190816336


   --row number: 7595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3082606 , [Content] ='7/20/2018'
 WHERE id=190816337


   --row number: 7596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3082606 , [Content] ='Yes'
 WHERE id=190816331


   --row number: 7597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3082606 , [Content] ='2 - Professionals'
 WHERE id=190816334


   --row number: 7598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3082606 , [Content] ='US - MRKT 1'
 WHERE id=190816319


   --row number: 7599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3082606 , [Content] ='AMS'
 WHERE id=190816320


   --row number: 7600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3082606 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190816321


   --row number: 7601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3082606 , [Content] ='Finance'
 WHERE id=190816322


   --row number: 7602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3082606 , [Content] ='6174 - Sr. Internal Auditor IC4'
 WHERE id=190816323


   --row number: 7603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3082606 , [Content] ='Internal Audit'
 WHERE id=190816324


   --row number: 7604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3082606 , [Content] ='IC4'
 WHERE id=190816325


   --row number: 7605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3082606 , [Content] ='USD'
 WHERE id=190816327


   --row number: 7606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3082606 , [Content] ='96,200 / 113,500 / 130,800 / 148,150 / 165,500'
 WHERE id=190816328


   --row number: 7607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3082606 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=190816329


   --row number: 7608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3082606 , [Content] ='EXEMPT'
 WHERE id=190816332


   --row number: 7609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3082606 , [Content] ='NO'
 WHERE id=190816333


   --row number: 7610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3082606 , [Content] ='6174 US - MRKT 1'
 WHERE id=190816318


   --row number: 7611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3082618 , [Content] ='5/22/18'
 WHERE id=190818054


   --row number: 7612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3082618 , [Content] ='GBP'
 WHERE id=190818046


   --row number: 7613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3082618 , [Content] ='35,100 / 41,400 / 47,700 / 54,050 / 60,400'
 WHERE id=190818047


   --row number: 7614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3082618 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=190818048


   --row number: 7615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3082618 , [Content] ='15%'
 WHERE id=190818049


   --row number: 7616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3082618 , [Content] ='Yes'
 WHERE id=190818050


   --row number: 7617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3082618 , [Content] ='2 - Professionals'
 WHERE id=190818051


   --row number: 7618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3082618 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190818052


   --row number: 7619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3082618 , [Content] ='Technical'
 WHERE id=190818053


   --row number: 7620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3082618 , [Content] ='5823 UK'
 WHERE id=190818037


   --row number: 7621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3082618 , [Content] ='UK'
 WHERE id=190818038


   --row number: 7622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3082618 , [Content] ='EMEA'
 WHERE id=190818039


   --row number: 7623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3082618 , [Content] ='UNITED KINGDOM'
 WHERE id=190818040


   --row number: 7624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3082618 , [Content] ='Customer Support'
 WHERE id=190818041


   --row number: 7625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3082618 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=190818042


   --row number: 7626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3082618 , [Content] ='Technical Support'
 WHERE id=190818043


   --row number: 7627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3082618 , [Content] ='IC3'
 WHERE id=190818044


   --row number: 7628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3082736 , [Content] ='Technical'
 WHERE id=190830625


   --row number: 7629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3082736 , [Content] ='7/20/2018'
 WHERE id=190830626


   --row number: 7630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3082736 , [Content] ='5822 NLD'
 WHERE id=190830610


   --row number: 7631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3082736 , [Content] ='NLD'
 WHERE id=190830611


   --row number: 7632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3082736 , [Content] ='EMEA'
 WHERE id=190830612


   --row number: 7633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3082736 , [Content] ='NETHERLANDS'
 WHERE id=190830613


   --row number: 7634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3082736 , [Content] ='Customer Support'
 WHERE id=190830614


   --row number: 7635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3082736 , [Content] ='5822 - Tech Support Engineer IC2'
 WHERE id=190830615


   --row number: 7636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3082736 , [Content] ='Technical Support'
 WHERE id=190830616


   --row number: 7637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3082736 , [Content] ='IC2'
 WHERE id=190830617


   --row number: 7638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3082736 , [Content] ='EUR'
 WHERE id=190830619


   --row number: 7639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3082736 , [Content] ='39,500 / 46,000 / 52,500 / 59,050 / 65,600'
 WHERE id=190830620


   --row number: 7640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3082736 , [Content] ='10%'
 WHERE id=190830621


   --row number: 7641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3082736 , [Content] ='No'
 WHERE id=190830622


   --row number: 7642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3082736 , [Content] ='2 - Professionals'
 WHERE id=190830623


   --row number: 7643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3082736 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190830624


   --row number: 7644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3082738 , [Content] ='Technical'
 WHERE id=190830834


   --row number: 7645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3082738 , [Content] ='7/20/2018'
 WHERE id=190830835


   --row number: 7646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3082738 , [Content] ='5822 UK'
 WHERE id=190830819


   --row number: 7647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3082738 , [Content] ='UK'
 WHERE id=190830820


   --row number: 7648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3082738 , [Content] ='EMEA'
 WHERE id=190830821


   --row number: 7649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3082738 , [Content] ='UNITED KINGDOM'
 WHERE id=190830822


   --row number: 7650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3082738 , [Content] ='Customer Support'
 WHERE id=190830823


   --row number: 7651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3082738 , [Content] ='5822 - Tech Support Engineer IC2'
 WHERE id=190830824


   --row number: 7652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3082738 , [Content] ='Technical Support'
 WHERE id=190830825


   --row number: 7653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3082738 , [Content] ='IC2'
 WHERE id=190830826


   --row number: 7654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3082738 , [Content] ='GBP'
 WHERE id=190830828


   --row number: 7655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3082738 , [Content] ='29,200 / 34,000 / 38,800 / 43,650 / 48,500'
 WHERE id=190830829


   --row number: 7656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3082738 , [Content] ='10%'
 WHERE id=190830830


   --row number: 7657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3082738 , [Content] ='No'
 WHERE id=190830831


   --row number: 7658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3082738 , [Content] ='2 - Professionals'
 WHERE id=190830832


   --row number: 7659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3082738 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190830833


   --row number: 7660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3083402 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=190883796


   --row number: 7661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3083402 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190883797


   --row number: 7662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3083402 , [Content] ='Non Technical'
 WHERE id=190883798


   --row number: 7663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3083402 , [Content] ='7/20/2018'
 WHERE id=190883799


   --row number: 7664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3083402 , [Content] ='3635 US - MRKT 1'
 WHERE id=190883780


   --row number: 7665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3083402 , [Content] ='US - MRKT 1'
 WHERE id=190883781


   --row number: 7666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3083402 , [Content] ='AMS'
 WHERE id=190883782


   --row number: 7667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3083402 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190883783


   --row number: 7668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3083402 , [Content] ='Administration'
 WHERE id=190883784


   --row number: 7669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3083402 , [Content] ='3635 - Dir, Project Mgmt M5'
 WHERE id=190883785


   --row number: 7670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3083402 , [Content] ='Project/Program Mgrs'
 WHERE id=190883786


   --row number: 7671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3083402 , [Content] ='M5'
 WHERE id=190883787


   --row number: 7672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3083402 , [Content] ='USD'
 WHERE id=190883789


   --row number: 7673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3083402 , [Content] ='139,000 / 170,250 / 201,500 / 232,800 / 264,100'
 WHERE id=190883790


   --row number: 7674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3083402 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=190883791


   --row number: 7675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3083402 , [Content] ='25%'
 WHERE id=190883792


   --row number: 7676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3083402 , [Content] ='Yes'
 WHERE id=190883793


   --row number: 7677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3083402 , [Content] ='EXEMPT'
 WHERE id=190883794


   --row number: 7678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3083402 , [Content] ='NO'
 WHERE id=190883795


   --row number: 7679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3083711 , [Content] ='7/20/18'
 WHERE id=190907908


   --row number: 7680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3083711 , [Content] ='S1365 US - MRKT 2'
 WHERE id=190907889


   --row number: 7681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3083711 , [Content] ='US - MRKT 2'
 WHERE id=190907890


   --row number: 7682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3083711 , [Content] ='AMS'
 WHERE id=190907891


   --row number: 7683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3083711 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190907892


   --row number: 7684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3083711 , [Content] ='Sales'
 WHERE id=190907893


   --row number: 7685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3083711 , [Content] ='S1365 - Dir, Inside/Contract Renewal Sales Mgmt M5'
 WHERE id=190907894


   --row number: 7686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3083711 , [Content] ='Inside/Contract Renewal'
 WHERE id=190907895


   --row number: 7687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3083711 , [Content] ='M5'
 WHERE id=190907896


   --row number: 7688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3083711 , [Content] ='USD'
 WHERE id=190907898


   --row number: 7689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3083711 , [Content] ='130,900 / 142,450 / 154,000 / 165,550 / 177,100'
 WHERE id=190907899


   --row number: 7690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3083711 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=190907900


   --row number: 7691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3083711 , [Content] ='Yes'
 WHERE id=190907902


   --row number: 7692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3083711 , [Content] ='EXEMPT'
 WHERE id=190907903


   --row number: 7693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3083711 , [Content] ='NO'
 WHERE id=190907904


   --row number: 7694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3083711 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=190907905


   --row number: 7695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3083711 , [Content] ='8742-Salespersons - Outside'
 WHERE id=190907906


   --row number: 7696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3083725 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=190909096


   --row number: 7697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3083725 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=190909097


   --row number: 7698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3083725 , [Content] ='Technical'
 WHERE id=190909098


   --row number: 7699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3083725 , [Content] ='7/20/2018'
 WHERE id=190909099


   --row number: 7700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3083725 , [Content] ='S1804 US - MRKT 2'
 WHERE id=190909080


   --row number: 7701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3083725 , [Content] ='US - MRKT 2'
 WHERE id=190909081


   --row number: 7702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3083725 , [Content] ='AMS'
 WHERE id=190909082


   --row number: 7703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3083725 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190909083


   --row number: 7704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3083725 , [Content] ='Sales Operations'
 WHERE id=190909084


   --row number: 7705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3083725 , [Content] ='S1804 - Sr Mgr, Sales Operations Mgmt M4'
 WHERE id=190909085


   --row number: 7706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3083725 , [Content] ='Sales Operations'
 WHERE id=190909086


   --row number: 7707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3083725 , [Content] ='M4'
 WHERE id=190909087


   --row number: 7708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3083725 , [Content] ='USD'
 WHERE id=190909089


   --row number: 7709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3083725 , [Content] ='100,600 / 123,250 / 145,900 / 168,500 / 191,100'
 WHERE id=190909090


   --row number: 7710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3083725 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=190909091


   --row number: 7711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3083725 , [Content] ='25%'
 WHERE id=190909092


   --row number: 7712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3083725 , [Content] ='Yes'
 WHERE id=190909093


   --row number: 7713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3083725 , [Content] ='EXEMPT'
 WHERE id=190909094


   --row number: 7714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3083725 , [Content] ='NO'
 WHERE id=190909095


   --row number: 7715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3083816 , [Content] ='2 - Professionals'
 WHERE id=190917390


   --row number: 7716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3083816 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190917391


   --row number: 7717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3083816 , [Content] ='Technical'
 WHERE id=190917392


   --row number: 7718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3083816 , [Content] ='7/20/2018'
 WHERE id=190917393


   --row number: 7719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3083816 , [Content] ='5765 US - MRKT 2'
 WHERE id=190917374


   --row number: 7720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3083816 , [Content] ='US - MRKT 2'
 WHERE id=190917375


   --row number: 7721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3083816 , [Content] ='AMS'
 WHERE id=190917376


   --row number: 7722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3083816 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190917377


   --row number: 7723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3083816 , [Content] ='Professional Services'
 WHERE id=190917378


   --row number: 7724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3083816 , [Content] ='5765 - Technology Consultant IC5'
 WHERE id=190917379


   --row number: 7725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3083816 , [Content] ='Technology Consultant'
 WHERE id=190917380


   --row number: 7726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3083816 , [Content] ='IC5'
 WHERE id=190917381


   --row number: 7727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3083816 , [Content] ='USD'
 WHERE id=190917383


   --row number: 7728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3083816 , [Content] ='106,200 / 130,100 / 154,000 / 177,900 / 201,800'
 WHERE id=190917384


   --row number: 7729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3083816 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=190917385


   --row number: 7730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3083816 , [Content] ='25%'
 WHERE id=190917386


   --row number: 7731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3083816 , [Content] ='Yes'
 WHERE id=190917387


   --row number: 7732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3083816 , [Content] ='EXEMPT'
 WHERE id=190917388


   --row number: 7733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3083816 , [Content] ='NO'
 WHERE id=190917389


   --row number: 7734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3083823 , [Content] ='2 - Professionals'
 WHERE id=190918289


   --row number: 7735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3083823 , [Content] ='Technical'
 WHERE id=190918291


   --row number: 7736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3083823 , [Content] ='7/20/2018'
 WHERE id=190918293


   --row number: 7737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3083823 , [Content] ='8810-Clerical Office Employees'
 WHERE id=190918290


   --row number: 7738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3083823 , [Content] ='5893 US - MRKT 1'
 WHERE id=190918267


   --row number: 7739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3083823 , [Content] ='US - MRKT 1'
 WHERE id=190918268


   --row number: 7740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3083823 , [Content] ='AMS'
 WHERE id=190918270


   --row number: 7741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3083823 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=190918271


   --row number: 7742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3083823 , [Content] ='Professional Services'
 WHERE id=190918272


   --row number: 7743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3083823 , [Content] ='5893 - Technical Curriculum Developer IC3'
 WHERE id=190918274


   --row number: 7744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3083823 , [Content] ='Technical Curriculum'
 WHERE id=190918275


   --row number: 7745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3083823 , [Content] ='IC3'
 WHERE id=190918276


   --row number: 7746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3083823 , [Content] ='USD'
 WHERE id=190918279


   --row number: 7747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3083823 , [Content] ='80,800 / 94,150 / 107,500 / 120,800 / 134,100'
 WHERE id=190918280


   --row number: 7748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3083823 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=190918282


   --row number: 7749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3083823 , [Content] ='10%'
 WHERE id=190918283


   --row number: 7750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3083823 , [Content] ='Yes'
 WHERE id=190918284


   --row number: 7751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3083823 , [Content] ='EXEMPT'
 WHERE id=190918286


   --row number: 7752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3083823 , [Content] ='NO'
 WHERE id=190918287


   --row number: 7753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3084287 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=191033196


   --row number: 7754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3084287 , [Content] ='8742-Salespersons - Outside'
 WHERE id=191033197


   --row number: 7755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3084287 , [Content] ='Technical'
 WHERE id=191033198


   --row number: 7756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3084287 , [Content] ='7/20/2018'
 WHERE id=191033199


   --row number: 7757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3084287 , [Content] ='S315 HKG'
 WHERE id=191033181


   --row number: 7758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3084287 , [Content] ='HKG'
 WHERE id=191033182


   --row number: 7759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3084287 , [Content] ='APAC'
 WHERE id=191033183


   --row number: 7760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3084287 , [Content] ='HONG KONG'
 WHERE id=191033184


   --row number: 7761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3084287 , [Content] ='Sales'
 WHERE id=191033185


   --row number: 7762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3084287 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=191033186


   --row number: 7763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3084287 , [Content] ='Sales Management'
 WHERE id=191033187


   --row number: 7764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3084287 , [Content] ='M5'
 WHERE id=191033188


   --row number: 7765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3084287 , [Content] ='HKD'
 WHERE id=191033190


   --row number: 7766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3084287 , [Content] ='1,127,738 / 1,227,244 / 1,326,750 / 1,426,256 / 1,525,763'
 WHERE id=191033191


   --row number: 7767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3084287 , [Content] ='93,000 / 139,500 / 186,000 / 232,500 / 279,000'
 WHERE id=191033192


   --row number: 7768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3084287 , [Content] ='2,255,475 / 2,454,488 / 2,653,500 / 2,852,513 / 3,051,525'
 WHERE id=191033193


   --row number: 7769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3084287 , [Content] ='50/50'
 WHERE id=191033194


   --row number: 7770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3084287 , [Content] ='Yes'
 WHERE id=191033195


   --row number: 7771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3084296 , [Content] ='09/05/18'
 WHERE id=191033718


   --row number: 7772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3084296 , [Content] ='5693 IND'
 WHERE id=191033702


   --row number: 7773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3084296 , [Content] ='IND'
 WHERE id=191033703


   --row number: 7774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3084296 , [Content] ='APAC'
 WHERE id=191033704


   --row number: 7775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3084296 , [Content] ='INDIA'
 WHERE id=191033705


   --row number: 7776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3084296 , [Content] ='Customer Support'
 WHERE id=191033706


   --row number: 7777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3084296 , [Content] ='5693 - Support Account Services Mgr IC3'
 WHERE id=191033707


   --row number: 7778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3084296 , [Content] ='SAM Services'
 WHERE id=191033708


   --row number: 7779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3084296 , [Content] ='IC3'
 WHERE id=191033709


   --row number: 7780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3084296 , [Content] ='INR'
 WHERE id=191033711


   --row number: 7781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3084296 , [Content] ='1,034,500 / 1,267,250 / 1,500,000 / 1,732,800 / 1,965,600'
 WHERE id=191033712


   --row number: 7782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3084296 , [Content] ='10%'
 WHERE id=191033713


   --row number: 7783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3084296 , [Content] ='No'
 WHERE id=191033714


   --row number: 7784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3084296 , [Content] ='2 - Professionals'
 WHERE id=191033715


   --row number: 7785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3084296 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191033716


   --row number: 7786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3084296 , [Content] ='Technical'
 WHERE id=191033717


   --row number: 7787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3084303 , [Content] ='Technical'
 WHERE id=191034287


   --row number: 7788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3084303 , [Content] ='7/20/2018'
 WHERE id=191034288


   --row number: 7789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3084303 , [Content] ='2793 IND'
 WHERE id=191034271


   --row number: 7790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3084303 , [Content] ='IND'
 WHERE id=191034272


   --row number: 7791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3084303 , [Content] ='APAC'
 WHERE id=191034273


   --row number: 7792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3084303 , [Content] ='INDIA'
 WHERE id=191034274


   --row number: 7793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3084303 , [Content] ='Customer Support'
 WHERE id=191034275


   --row number: 7794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3084303 , [Content] ='2793 - Mgr, Technical Support Mgmt M3'
 WHERE id=191034276


   --row number: 7795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3084303 , [Content] ='Technical Support'
 WHERE id=191034277


   --row number: 7796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3084303 , [Content] ='M3'
 WHERE id=191034278


   --row number: 7797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3084303 , [Content] ='INR'
 WHERE id=191034280


   --row number: 7798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3084303 , [Content] ='1,620,700 / 1,985,350 / 2,350,000 / 2,714,650 / 3,079,300'
 WHERE id=191034281


   --row number: 7799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3084303 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=191034282


   --row number: 7800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3084303 , [Content] ='20%'
 WHERE id=191034283


   --row number: 7801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3084303 , [Content] ='Yes'
 WHERE id=191034284


   --row number: 7802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3084303 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=191034285


   --row number: 7803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3084303 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191034286


   --row number: 7804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3084481 , [Content] ='8742-Salespersons - Outside'
 WHERE id=191083603


   --row number: 7805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3084481 , [Content] ='Technical'
 WHERE id=191083604


   --row number: 7806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3084481 , [Content] ='7/20/2018'
 WHERE id=191083605


   --row number: 7807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3084481 , [Content] ='S1415A NLD'
 WHERE id=191083587


   --row number: 7808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3084481 , [Content] ='NLD'
 WHERE id=191083588


   --row number: 7809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3084481 , [Content] ='EMEA'
 WHERE id=191083589


   --row number: 7810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3084481 , [Content] ='NETHERLANDS'
 WHERE id=191083590


   --row number: 7811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3084481 , [Content] ='Solution Consulting'
 WHERE id=191083591


   --row number: 7812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3084481 , [Content] ='S1415A - Sr Advisory Solution Architect IC5'
 WHERE id=191083592


   --row number: 7813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3084481 , [Content] ='Solution Consultant Architect'
 WHERE id=191083593


   --row number: 7814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3084481 , [Content] ='IC5'
 WHERE id=191083594


   --row number: 7815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3084481 , [Content] ='EUR'
 WHERE id=191083596


   --row number: 7816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3084481 , [Content] ='90,844 / 98,859 / 106,875 / 114,891 / 122,906'
 WHERE id=191083597


   --row number: 7817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3084481 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=191083598


   --row number: 7818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3084481 , [Content] ='121,125 / 131,813 / 142,500 / 153,188 / 163,875'
 WHERE id=191083599


   --row number: 7819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3084481 , [Content] ='75/25'
 WHERE id=191083600


   --row number: 7820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3084481 , [Content] ='Yes'
 WHERE id=191083601


   --row number: 7821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3084481 , [Content] ='4 - Sales Workers'
 WHERE id=191083602


   --row number: 7822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3083711 , [Content] ='187,000 / 203,500 / 220,000 / 236,500 / 253,000'
 WHERE id=191217467


   --row number: 7823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3086130 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=191259732


   --row number: 7824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3086130 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191259733


   --row number: 7825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3086130 , [Content] ='Non Technical'
 WHERE id=191259734


   --row number: 7826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3086130 , [Content] ='7/20/2018'
 WHERE id=191259735


   --row number: 7827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3083711 , [Content] ='70/30'
 WHERE id=191217468


   --row number: 7828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3086130 , [Content] ='Yes'
 WHERE id=191259731


   --row number: 7829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3086130 , [Content] ='3104 SGP'
 WHERE id=191259718


   --row number: 7830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3086130 , [Content] ='SGP'
 WHERE id=191259719


   --row number: 7831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3086130 , [Content] ='APAC'
 WHERE id=191259720


   --row number: 7832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3086130 , [Content] ='SINGAPORE'
 WHERE id=191259721


   --row number: 7833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3086130 , [Content] ='Finance'
 WHERE id=191259722


   --row number: 7834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3086130 , [Content] ='3104 - Sr Mgr, Accounting Mgmt M4'
 WHERE id=191259723


   --row number: 7835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3086130 , [Content] ='Accounting'
 WHERE id=191259724


   --row number: 7836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3086130 , [Content] ='M4'
 WHERE id=191259725


   --row number: 7837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3086130 , [Content] ='SGD'
 WHERE id=191259727


   --row number: 7838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3086130 , [Content] ='127,200 / 155,800 / 184,400 / 213,050 / 241,700'
 WHERE id=191259728


   --row number: 7839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3086130 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=191259729


   --row number: 7840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3086130 , [Content] ='25%'
 WHERE id=191259730


   --row number: 7841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3087480 , [Content] ='EXEMPT'
 WHERE id=191398915


   --row number: 7842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3087480 , [Content] ='NO'
 WHERE id=191398916


   --row number: 7843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3087480 , [Content] ='4 - Sales Workers'
 WHERE id=191398917


   --row number: 7844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3087480 , [Content] ='8742-Salespersons - Outside'
 WHERE id=191398918


   --row number: 7845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3087480 , [Content] ='Technical'
 WHERE id=191398919


   --row number: 7846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3087480 , [Content] ='09/05/18'
 WHERE id=191398920


   --row number: 7847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3087480 , [Content] ='R3614B US - MRKT 2'
 WHERE id=191398900


   --row number: 7848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3087480 , [Content] ='US - MRKT 2'
 WHERE id=191398901


   --row number: 7849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3087480 , [Content] ='AMS'
 WHERE id=191398902


   --row number: 7850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3087480 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191398903


   --row number: 7851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3087480 , [Content] ='Sales'
 WHERE id=191398904


   --row number: 7852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3087480 , [Content] ='R3614B - Commercial Account Exec IC4'
 WHERE id=191398905


   --row number: 7853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3087480 , [Content] ='Commercial Accounts'
 WHERE id=191398906


   --row number: 7854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3087480 , [Content] ='IC4'
 WHERE id=191398907


   --row number: 7855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3087480 , [Content] ='USD'
 WHERE id=191398909


   --row number: 7856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3087480 , [Content] ='114,750 / 124,875 / 135,000 / 145,125 / 155,250'
 WHERE id=191398910


   --row number: 7857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3087480 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=191398911


   --row number: 7858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3087480 , [Content] ='229,500 / 249,750 / 270,000 / 290,250 / 310,500'
 WHERE id=191398912


   --row number: 7859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3087480 , [Content] ='50/50'
 WHERE id=191398913


   --row number: 7860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3087480 , [Content] ='Yes'
 WHERE id=191398914


   --row number: 7861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3087544 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191404644


   --row number: 7862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3087544 , [Content] ='Technical'
 WHERE id=191404645


   --row number: 7863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3087544 , [Content] ='7/20/2018'
 WHERE id=191404646


   --row number: 7864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3087544 , [Content] ='6464 US - MRKT 1'
 WHERE id=191404627


   --row number: 7865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3087544 , [Content] ='US - MRKT 1'
 WHERE id=191404628


   --row number: 7866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3087544 , [Content] ='AMS'
 WHERE id=191404629


   --row number: 7867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3087544 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191404630


   --row number: 7868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3087544 , [Content] ='Info Systems/Technology'
 WHERE id=191404631


   --row number: 7869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3087544 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=191404632


   --row number: 7870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3087544 , [Content] ='Business Systems Analysis'
 WHERE id=191404633


   --row number: 7871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3087544 , [Content] ='IC4'
 WHERE id=191404634


   --row number: 7872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3087544 , [Content] ='USD'
 WHERE id=191404636


   --row number: 7873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3087544 , [Content] ='104,200 / 122,950 / 141,700 / 160,450 / 179,200'
 WHERE id=191404637


   --row number: 7874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3087544 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=191404638


   --row number: 7875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3087544 , [Content] ='15%'
 WHERE id=191404639


   --row number: 7876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3087544 , [Content] ='Yes'
 WHERE id=191404640


   --row number: 7877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3087544 , [Content] ='EXEMPT'
 WHERE id=191404641


   --row number: 7878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3087544 , [Content] ='NO'
 WHERE id=191404642


   --row number: 7879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3087544 , [Content] ='2 - Professionals'
 WHERE id=191404643


   --row number: 7880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3088995 , [Content] ='2 - Professionals'
 WHERE id=191562240


   --row number: 7881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3088995 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191562241


   --row number: 7882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3088995 , [Content] ='Non Technical'
 WHERE id=191562242


   --row number: 7883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3088995 , [Content] ='7/20/2018'
 WHERE id=191562243


   --row number: 7884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3088995 , [Content] ='6013 US - MRKT 1'
 WHERE id=191562224


   --row number: 7885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3088995 , [Content] ='US - MRKT 1'
 WHERE id=191562225


   --row number: 7886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3088995 , [Content] ='AMS'
 WHERE id=191562226


   --row number: 7887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3088995 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191562227


   --row number: 7888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3088995 , [Content] ='Business Strategy'
 WHERE id=191562228


   --row number: 7889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3088995 , [Content] ='6013 - Business Analytics IC3'
 WHERE id=191562229


   --row number: 7890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3088995 , [Content] ='Business Analytics'
 WHERE id=191562230


   --row number: 7891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3088995 , [Content] ='IC3'
 WHERE id=191562231


   --row number: 7892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3088995 , [Content] ='USD'
 WHERE id=191562233


   --row number: 7893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3088995 , [Content] ='88,600 / 103,250 / 117,900 / 132,500 / 147,100'
 WHERE id=191562234


   --row number: 7894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3088995 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=191562235


   --row number: 7895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3088995 , [Content] ='10%'
 WHERE id=191562236


   --row number: 7896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3088995 , [Content] ='Yes'
 WHERE id=191562237


   --row number: 7897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3088995 , [Content] ='EXEMPT'
 WHERE id=191562238


   --row number: 7898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3088995 , [Content] ='NO'
 WHERE id=191562239


   --row number: 7899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089402 , [Content] ='NO'
 WHERE id=191596918


   --row number: 7900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089402 , [Content] ='2 - Professionals'
 WHERE id=191596919


   --row number: 7901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089402 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191596920


   --row number: 7902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089402 , [Content] ='Technical'
 WHERE id=191596921


   --row number: 7903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089402 , [Content] ='7/20/2018'
 WHERE id=191596922


   --row number: 7904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089402 , [Content] ='5373 US - MRKT 2'
 WHERE id=191596898


   --row number: 7905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089402 , [Content] ='US - MRKT 2'
 WHERE id=191596899


   --row number: 7906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089402 , [Content] ='AMS'
 WHERE id=191596900


   --row number: 7907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089402 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191596901


   --row number: 7908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089402 , [Content] ='Engineering'
 WHERE id=191596902


   --row number: 7909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089402 , [Content] ='5373 - Project (Design) Manager IC3'
 WHERE id=191596903


   --row number: 7910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089402 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=191596904


   --row number: 7911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089402 , [Content] ='IC3'
 WHERE id=191596905


   --row number: 7912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089402 , [Content] ='USD'
 WHERE id=191596907


   --row number: 7913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089402 , [Content] ='81,900 / 96,650 / 111,400 / 126,150 / 140,900'
 WHERE id=191596908


   --row number: 7914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089402 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=191596910


   --row number: 7915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089402 , [Content] ='15%'
 WHERE id=191596912


   --row number: 7916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089402 , [Content] ='Yes'
 WHERE id=191596914


   --row number: 7917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089402 , [Content] ='EXEMPT'
 WHERE id=191596916


   --row number: 7918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3053485 , [Content] ='Technical'
 WHERE id=191567080


   --row number: 7919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089409 , [Content] ='2 - Professionals'
 WHERE id=191597366


   --row number: 7920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089409 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191597367


   --row number: 7921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089409 , [Content] ='Technical'
 WHERE id=191597368


   --row number: 7922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089409 , [Content] ='7/20/18'
 WHERE id=191597369


   --row number: 7923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089409 , [Content] ='5144 IND'
 WHERE id=191597350


   --row number: 7924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089409 , [Content] ='IND'
 WHERE id=191597351


   --row number: 7925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089409 , [Content] ='APAC'
 WHERE id=191597352


   --row number: 7926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089409 , [Content] ='INDIA'
 WHERE id=191597353


   --row number: 7927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089409 , [Content] ='Engineering'
 WHERE id=191597354


   --row number: 7928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089409 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=191597355


   --row number: 7929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089409 , [Content] ='Software'
 WHERE id=191597356


   --row number: 7930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089409 , [Content] ='IC4'
 WHERE id=191597357


   --row number: 7931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089409 , [Content] ='INR'
 WHERE id=191597359


   --row number: 7932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089409 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=191597360


   --row number: 7933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089409 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=191597361


   --row number: 7934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089409 , [Content] ='20%'
 WHERE id=191597362


   --row number: 7935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089409 , [Content] ='Yes'
 WHERE id=191597363


   --row number: 7936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089415 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191597750


   --row number: 7937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089415 , [Content] ='Technical'
 WHERE id=191597751


   --row number: 7938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089415 , [Content] ='2145 US - MRKT 1'
 WHERE id=191597734


   --row number: 7939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089415 , [Content] ='US - MRKT 1'
 WHERE id=191597735


   --row number: 7940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089415 , [Content] ='AMS'
 WHERE id=191597736


   --row number: 7941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089415 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191597737


   --row number: 7942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089415 , [Content] ='Engineering'
 WHERE id=191597738


   --row number: 7943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089415 , [Content] ='2145 - Dir, Software Engrg Mgmt M5'
 WHERE id=191597739


   --row number: 7944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089415 , [Content] ='Software'
 WHERE id=191597740


   --row number: 7945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089415 , [Content] ='M5'
 WHERE id=191597741


   --row number: 7946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089415 , [Content] ='154,400 / 189,150 / 223,900 / 258,650 / 293,400'
 WHERE id=191597743


   --row number: 7947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089415 , [Content] ='312,000 / 468,000 / 624,000 / 780,000 / 936,000'
 WHERE id=191597744


   --row number: 7948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089415 , [Content] ='25%'
 WHERE id=191597745


   --row number: 7949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089415 , [Content] ='Yes'
 WHERE id=191597746


   --row number: 7950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089415 , [Content] ='EXEMPT'
 WHERE id=191597747


   --row number: 7951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089415 , [Content] ='NO'
 WHERE id=191597748


   --row number: 7952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089415 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=191597749


   --row number: 7953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089435 , [Content] ='2 - Professionals'
 WHERE id=191599006


   --row number: 7954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089435 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599007


   --row number: 7955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089435 , [Content] ='Technical'
 WHERE id=191599008


   --row number: 7956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089435 , [Content] ='6/27/2018'
 WHERE id=191599009


   --row number: 7957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089435 , [Content] ='5144 US - MRKT 2'
 WHERE id=191598990


   --row number: 7958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089435 , [Content] ='US - MRKT 2'
 WHERE id=191598991


   --row number: 7959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089435 , [Content] ='AMS'
 WHERE id=191598992


   --row number: 7960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089435 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191598993


   --row number: 7961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089435 , [Content] ='Engineering'
 WHERE id=191598994


   --row number: 7962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089435 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=191598995


   --row number: 7963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089435 , [Content] ='Software'
 WHERE id=191598996


   --row number: 7964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089435 , [Content] ='IC4'
 WHERE id=191598997


   --row number: 7965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089435 , [Content] ='USD'
 WHERE id=191598999


   --row number: 7966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089435 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=191599000


   --row number: 7967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089435 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=191599001


   --row number: 7968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089435 , [Content] ='20%'
 WHERE id=191599002


   --row number: 7969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089435 , [Content] ='Yes'
 WHERE id=191599003


   --row number: 7970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089435 , [Content] ='EXEMPT'
 WHERE id=191599004


   --row number: 7971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089435 , [Content] ='NO'
 WHERE id=191599005


   --row number: 7972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089436 , [Content] ='2 - Professionals'
 WHERE id=191599079


   --row number: 7973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089436 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599080


   --row number: 7974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089436 , [Content] ='Technical'
 WHERE id=191599081


   --row number: 7975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089436 , [Content] ='6/27/2018'
 WHERE id=191599082


   --row number: 7976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089436 , [Content] ='5144 US - MRKT 2'
 WHERE id=191599063


   --row number: 7977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089436 , [Content] ='US - MRKT 2'
 WHERE id=191599064


   --row number: 7978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089436 , [Content] ='AMS'
 WHERE id=191599065


   --row number: 7979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089436 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599066


   --row number: 7980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089436 , [Content] ='Engineering'
 WHERE id=191599067


   --row number: 7981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089436 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=191599068


   --row number: 7982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089436 , [Content] ='Software'
 WHERE id=191599069


   --row number: 7983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089436 , [Content] ='IC4'
 WHERE id=191599070


   --row number: 7984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089436 , [Content] ='USD'
 WHERE id=191599072


   --row number: 7985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089436 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=191599073


   --row number: 7986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089436 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=191599074


   --row number: 7987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089436 , [Content] ='20%'
 WHERE id=191599075


   --row number: 7988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089436 , [Content] ='Yes'
 WHERE id=191599076


   --row number: 7989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089436 , [Content] ='EXEMPT'
 WHERE id=191599077


   --row number: 7990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089436 , [Content] ='NO'
 WHERE id=191599078


   --row number: 7991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089437 , [Content] ='2 - Professionals'
 WHERE id=191599191


   --row number: 7992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089437 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599192


   --row number: 7993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089437 , [Content] ='Technical'
 WHERE id=191599193


   --row number: 7994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089437 , [Content] ='6/27/2018'
 WHERE id=191599194


   --row number: 7995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089437 , [Content] ='5144 US - MRKT 2'
 WHERE id=191599175


   --row number: 7996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089437 , [Content] ='US - MRKT 2'
 WHERE id=191599176


   --row number: 7997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089437 , [Content] ='AMS'
 WHERE id=191599177


   --row number: 7998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089437 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599178


   --row number: 7999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089437 , [Content] ='Engineering'
 WHERE id=191599179


   --row number: 8000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089437 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=191599180


   --row number: 8001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089437 , [Content] ='Software'
 WHERE id=191599181


   --row number: 8002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089437 , [Content] ='IC4'
 WHERE id=191599182


   --row number: 8003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089437 , [Content] ='USD'
 WHERE id=191599184


   --row number: 8004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089437 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=191599185


   --row number: 8005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089437 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=191599186


   --row number: 8006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089437 , [Content] ='20%'
 WHERE id=191599187


   --row number: 8007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089437 , [Content] ='Yes'
 WHERE id=191599188


   --row number: 8008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089437 , [Content] ='EXEMPT'
 WHERE id=191599189


   --row number: 8009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089437 , [Content] ='NO'
 WHERE id=191599190


   --row number: 8010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089439 , [Content] ='2 - Professionals'
 WHERE id=191599300


   --row number: 8011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089439 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599301


   --row number: 8012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089439 , [Content] ='Technical'
 WHERE id=191599302


   --row number: 8013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089439 , [Content] ='6/27/2018'
 WHERE id=191599303


   --row number: 8014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089439 , [Content] ='5144 US - MRKT 2'
 WHERE id=191599284


   --row number: 8015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089439 , [Content] ='US - MRKT 2'
 WHERE id=191599285


   --row number: 8016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089439 , [Content] ='AMS'
 WHERE id=191599286


   --row number: 8017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089439 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599287


   --row number: 8018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089439 , [Content] ='Engineering'
 WHERE id=191599288


   --row number: 8019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089439 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=191599289


   --row number: 8020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089439 , [Content] ='Software'
 WHERE id=191599290


   --row number: 8021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089439 , [Content] ='IC4'
 WHERE id=191599291


   --row number: 8022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089439 , [Content] ='USD'
 WHERE id=191599293


   --row number: 8023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089439 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=191599294


   --row number: 8024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089439 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=191599295


   --row number: 8025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089439 , [Content] ='20%'
 WHERE id=191599296


   --row number: 8026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089439 , [Content] ='Yes'
 WHERE id=191599297


   --row number: 8027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089439 , [Content] ='EXEMPT'
 WHERE id=191599298


   --row number: 8028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089439 , [Content] ='NO'
 WHERE id=191599299


   --row number: 8029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089448 , [Content] ='2 - Professionals'
 WHERE id=191599742


   --row number: 8030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089448 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599743


   --row number: 8031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089448 , [Content] ='Technical'
 WHERE id=191599744


   --row number: 8032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089448 , [Content] ='06/08/18'
 WHERE id=191599745


   --row number: 8033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089448 , [Content] ='5143 US - MRKT 2'
 WHERE id=191599726


   --row number: 8034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089448 , [Content] ='US - MRKT 2'
 WHERE id=191599727


   --row number: 8035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089448 , [Content] ='AMS'
 WHERE id=191599728


   --row number: 8036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089448 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599729


   --row number: 8037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089448 , [Content] ='Engineering'
 WHERE id=191599730


   --row number: 8038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089448 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=191599731


   --row number: 8039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089448 , [Content] ='Software'
 WHERE id=191599732


   --row number: 8040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089448 , [Content] ='IC3'
 WHERE id=191599733


   --row number: 8041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089448 , [Content] ='USD'
 WHERE id=191599735


   --row number: 8042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089448 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=191599736


   --row number: 8043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089448 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=191599737


   --row number: 8044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089448 , [Content] ='15%'
 WHERE id=191599738


   --row number: 8045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089448 , [Content] ='Yes'
 WHERE id=191599739


   --row number: 8046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089448 , [Content] ='EXEMPT'
 WHERE id=191599740


   --row number: 8047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089448 , [Content] ='NO'
 WHERE id=191599741


   --row number: 8048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089449 , [Content] ='NO'
 WHERE id=191599811


   --row number: 8049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089449 , [Content] ='2 - Professionals'
 WHERE id=191599812


   --row number: 8050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089449 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599813


   --row number: 8051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089449 , [Content] ='Technical'
 WHERE id=191599814


   --row number: 8052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089449 , [Content] ='06/08/18'
 WHERE id=191599815


   --row number: 8053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089450 , [Content] ='5143 US - MRKT 2'
 WHERE id=191599843


   --row number: 8054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089450 , [Content] ='US - MRKT 2'
 WHERE id=191599844


   --row number: 8055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089450 , [Content] ='AMS'
 WHERE id=191599845


   --row number: 8056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089450 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599846


   --row number: 8057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089450 , [Content] ='Engineering'
 WHERE id=191599847


   --row number: 8058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089450 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=191599848


   --row number: 8059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089450 , [Content] ='Software'
 WHERE id=191599849


   --row number: 8060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089450 , [Content] ='IC3'
 WHERE id=191599850


   --row number: 8061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089450 , [Content] ='USD'
 WHERE id=191599852


   --row number: 8062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089450 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=191599853


   --row number: 8063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089450 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=191599854


   --row number: 8064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089450 , [Content] ='15%'
 WHERE id=191599855


   --row number: 8065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089450 , [Content] ='Yes'
 WHERE id=191599856


   --row number: 8066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089450 , [Content] ='EXEMPT'
 WHERE id=191599857


   --row number: 8067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089450 , [Content] ='NO'
 WHERE id=191599858


   --row number: 8068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089450 , [Content] ='2 - Professionals'
 WHERE id=191599859


   --row number: 8069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089449 , [Content] ='5143 US - MRKT 2'
 WHERE id=191599796


   --row number: 8070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089449 , [Content] ='US - MRKT 2'
 WHERE id=191599797


   --row number: 8071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089449 , [Content] ='AMS'
 WHERE id=191599798


   --row number: 8072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089449 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599799


   --row number: 8073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089449 , [Content] ='Engineering'
 WHERE id=191599800


   --row number: 8074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089449 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=191599801


   --row number: 8075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089449 , [Content] ='Software'
 WHERE id=191599802


   --row number: 8076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089449 , [Content] ='IC3'
 WHERE id=191599803


   --row number: 8077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089449 , [Content] ='USD'
 WHERE id=191599805


   --row number: 8078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089449 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=191599806


   --row number: 8079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089449 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=191599807


   --row number: 8080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089449 , [Content] ='15%'
 WHERE id=191599808


   --row number: 8081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089449 , [Content] ='Yes'
 WHERE id=191599809


   --row number: 8082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089449 , [Content] ='EXEMPT'
 WHERE id=191599810


   --row number: 8083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089450 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599860


   --row number: 8084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089450 , [Content] ='Technical'
 WHERE id=191599861


   --row number: 8085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089450 , [Content] ='06/08/18'
 WHERE id=191599862


   --row number: 8086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089451 , [Content] ='5143 US - MRKT 2'
 WHERE id=191599908


   --row number: 8087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089451 , [Content] ='US - MRKT 2'
 WHERE id=191599909


   --row number: 8088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089451 , [Content] ='AMS'
 WHERE id=191599910


   --row number: 8089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089451 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191599911


   --row number: 8090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089451 , [Content] ='Engineering'
 WHERE id=191599912


   --row number: 8091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089451 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=191599913


   --row number: 8092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089451 , [Content] ='Software'
 WHERE id=191599914


   --row number: 8093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089451 , [Content] ='IC3'
 WHERE id=191599915


   --row number: 8094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089451 , [Content] ='USD'
 WHERE id=191599917


   --row number: 8095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089451 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=191599918


   --row number: 8096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089451 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=191599919


   --row number: 8097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089451 , [Content] ='15%'
 WHERE id=191599920


   --row number: 8098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089451 , [Content] ='Yes'
 WHERE id=191599921


   --row number: 8099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089451 , [Content] ='EXEMPT'
 WHERE id=191599922


   --row number: 8100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089451 , [Content] ='NO'
 WHERE id=191599923


   --row number: 8101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089451 , [Content] ='2 - Professionals'
 WHERE id=191599924


   --row number: 8102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089451 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191599925


   --row number: 8103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089451 , [Content] ='Technical'
 WHERE id=191599926


   --row number: 8104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089451 , [Content] ='06/08/18'
 WHERE id=191599929


   --row number: 8105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089542 , [Content] ='S1413 US - MRKT 1'
 WHERE id=191607686


   --row number: 8106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089542 , [Content] ='US - MRKT 1'
 WHERE id=191607687


   --row number: 8107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089542 , [Content] ='AMS'
 WHERE id=191607688


   --row number: 8108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089542 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191607689


   --row number: 8109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089542 , [Content] ='Solution Consulting'
 WHERE id=191607690


   --row number: 8110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089542 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=191607691


   --row number: 8111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089542 , [Content] ='Solution Consultant Core'
 WHERE id=191607692


   --row number: 8112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089542 , [Content] ='IC3'
 WHERE id=191607693


   --row number: 8113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089542 , [Content] ='USD'
 WHERE id=191607695


   --row number: 8114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089542 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=191607696


   --row number: 8115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089542 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=191607697


   --row number: 8116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3089542 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=191607698


   --row number: 8117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3089542 , [Content] ='75/25'
 WHERE id=191607699


   --row number: 8118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089542 , [Content] ='Yes'
 WHERE id=191607700


   --row number: 8119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089542 , [Content] ='EXEMPT'
 WHERE id=191607701


   --row number: 8120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089542 , [Content] ='NO'
 WHERE id=191607702


   --row number: 8121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089542 , [Content] ='4 - Sales Workers'
 WHERE id=191607703


   --row number: 8122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089542 , [Content] ='8742-Salespersons - Outside'
 WHERE id=191607704


   --row number: 8123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089542 , [Content] ='Technical'
 WHERE id=191607705


   --row number: 8124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089542 , [Content] ='7/20/2018'
 WHERE id=191607706


   --row number: 8125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089699 , [Content] ='5172 US - MRKT 1'
 WHERE id=191622006


   --row number: 8126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089699 , [Content] ='US - MRKT 1'
 WHERE id=191622007


   --row number: 8127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089699 , [Content] ='AMS'
 WHERE id=191622008


   --row number: 8128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089699 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191622009


   --row number: 8129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089699 , [Content] ='Engineering'
 WHERE id=191622010


   --row number: 8130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089699 , [Content] ='5172 - Machine Learning Engineer IC2'
 WHERE id=191622011


   --row number: 8131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089699 , [Content] ='Machine Learning'
 WHERE id=191622012


   --row number: 8132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089699 , [Content] ='IC2'
 WHERE id=191622013


   --row number: 8133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089699 , [Content] ='USD'
 WHERE id=191622015


   --row number: 8134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089699 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=191622016


   --row number: 8135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089699 , [Content] ='10%'
 WHERE id=191622017


   --row number: 8136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089699 , [Content] ='Yes'
 WHERE id=191622018


   --row number: 8137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089699 , [Content] ='EXEMPT'
 WHERE id=191622019


   --row number: 8138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089699 , [Content] ='NO'
 WHERE id=191622020


   --row number: 8139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089699 , [Content] ='2 - Professionals'
 WHERE id=191622021


   --row number: 8140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089699 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191622022


   --row number: 8141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089699 , [Content] ='Technical'
 WHERE id=191622023


   --row number: 8142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089699 , [Content] ='7/20/2018'
 WHERE id=191622024


   --row number: 8143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3089703 , [Content] ='5465 US - MRKT 1'
 WHERE id=191622233


   --row number: 8144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3089703 , [Content] ='US - MRKT 1'
 WHERE id=191622234


   --row number: 8145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3089703 , [Content] ='AMS'
 WHERE id=191622235


   --row number: 8146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3089703 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191622236


   --row number: 8147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3089703 , [Content] ='Marketing'
 WHERE id=191622237


   --row number: 8148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3089703 , [Content] ='5465 - Product Portfolio Mgr IC5'
 WHERE id=191622238


   --row number: 8149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3089703 , [Content] ='Product Mgrs'
 WHERE id=191622239


   --row number: 8150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3089703 , [Content] ='IC5'
 WHERE id=191622240


   --row number: 8151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089703 , [Content] ='USD'
 WHERE id=191622242


   --row number: 8152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3089703 , [Content] ='130,700 / 160,100 / 189,500 / 218,900 / 248,300'
 WHERE id=191622243


   --row number: 8153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3089703 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=191622244


   --row number: 8154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3089703 , [Content] ='25%'
 WHERE id=191622245


   --row number: 8155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3089703 , [Content] ='Yes'
 WHERE id=191622246


   --row number: 8156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3089703 , [Content] ='EXEMPT'
 WHERE id=191622247


   --row number: 8157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3089703 , [Content] ='NO'
 WHERE id=191622248


   --row number: 8158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3089703 , [Content] ='2 - Professionals'
 WHERE id=191622249


   --row number: 8159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3089703 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191622250


   --row number: 8160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3089703 , [Content] ='Technical'
 WHERE id=191622251


   --row number: 8161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089703 , [Content] ='7/20/2018'
 WHERE id=191622252


   --row number: 8162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090150 , [Content] ='S1332 US - MRKT 2'
 WHERE id=191780216


   --row number: 8163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090150 , [Content] ='US - MRKT 2'
 WHERE id=191780217


   --row number: 8164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090150 , [Content] ='AMS'
 WHERE id=191780218


   --row number: 8165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090150 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191780219


   --row number: 8166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090150 , [Content] ='Sales'
 WHERE id=191780220


   --row number: 8167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090150 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=191780221


   --row number: 8168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090150 , [Content] ='Inside Sales'
 WHERE id=191780222


   --row number: 8169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090150 , [Content] ='A2'
 WHERE id=191780223


   --row number: 8170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090150 , [Content] ='USD'
 WHERE id=191780225


   --row number: 8171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3090150 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=191780226


   --row number: 8172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3090150 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=191780227


   --row number: 8173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3090150 , [Content] ='60/40'
 WHERE id=191780228


   --row number: 8174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090150 , [Content] ='No'
 WHERE id=191780229


   --row number: 8175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3090150 , [Content] ='NON-EXEMPT'
 WHERE id=191780230


   --row number: 8176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3090150 , [Content] ='NO'
 WHERE id=191780231


   --row number: 8177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090150 , [Content] ='4 - Sales Workers'
 WHERE id=191780232


   --row number: 8178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090150 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191780233


   --row number: 8179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090150 , [Content] ='Non Technical'
 WHERE id=191780234


   --row number: 8180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090150 , [Content] ='04/05/18'
 WHERE id=191780235


   --row number: 8181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090163 , [Content] ='6013 SGP'
 WHERE id=191783319


   --row number: 8182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090163 , [Content] ='SGP'
 WHERE id=191783320


   --row number: 8183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090163 , [Content] ='APAC'
 WHERE id=191783321


   --row number: 8184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090163 , [Content] ='SINGAPORE'
 WHERE id=191783322


   --row number: 8185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090163 , [Content] ='Business Strategy'
 WHERE id=191783323


   --row number: 8186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090163 , [Content] ='6013 - Business Analytics IC3'
 WHERE id=191783324


   --row number: 8187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090163 , [Content] ='Business Analytics'
 WHERE id=191783325


   --row number: 8188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090163 , [Content] ='IC3'
 WHERE id=191783326


   --row number: 8189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090163 , [Content] ='SGD'
 WHERE id=191783328


   --row number: 8190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3090163 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=191783329


   --row number: 8191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3090163 , [Content] ='34,800 / 48,600 / 62,400 / 76,200 / 90,000'
 WHERE id=191783330


   --row number: 8192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3090163 , [Content] ='10%'
 WHERE id=191783331


   --row number: 8193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090163 , [Content] ='Yes'
 WHERE id=191783332


   --row number: 8194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090163 , [Content] ='2 - Professionals'
 WHERE id=191783333


   --row number: 8195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090163 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191783334


   --row number: 8196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090163 , [Content] ='Non Technical'
 WHERE id=191783335


   --row number: 8197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090163 , [Content] ='7/20/2018'
 WHERE id=191783336


   --row number: 8198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090269 , [Content] ='S635 HKG'
 WHERE id=191811843


   --row number: 8199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090269 , [Content] ='HKG'
 WHERE id=191811844


   --row number: 8200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090269 , [Content] ='APAC'
 WHERE id=191811845


   --row number: 8201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090269 , [Content] ='HONG KONG'
 WHERE id=191811846


   --row number: 8202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090269 , [Content] ='Sales'
 WHERE id=191811847


   --row number: 8203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090269 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=191811848


   --row number: 8204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090269 , [Content] ='Enterprise Accounts'
 WHERE id=191811849


   --row number: 8205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090269 , [Content] ='IC5'
 WHERE id=191811850


   --row number: 8206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090269 , [Content] ='HKD'
 WHERE id=191811852


   --row number: 8207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3090269 , [Content] ='807,500 / 878,750 / 950,000 / 1,021,250 / 1,092,500'
 WHERE id=191811853


   --row number: 8208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3090269 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=191811854


   --row number: 8209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3090269 , [Content] ='1,615,000 / 1,757,500 / 1,900,000 / 2,042,500 / 2,185,000'
 WHERE id=191811855


   --row number: 8210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3090269 , [Content] ='50/50'
 WHERE id=191811856


   --row number: 8211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090269 , [Content] ='Yes'
 WHERE id=191811857


   --row number: 8212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090269 , [Content] ='4 - Sales Workers'
 WHERE id=191811858


   --row number: 8213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090269 , [Content] ='8742-Salespersons - Outside'
 WHERE id=191811859


   --row number: 8214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090269 , [Content] ='Technical'
 WHERE id=191811860


   --row number: 8215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090269 , [Content] ='7/20/2018'
 WHERE id=191811861


   --row number: 8216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090280 , [Content] ='6532 IND'
 WHERE id=191813244


   --row number: 8217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090280 , [Content] ='IND'
 WHERE id=191813245


   --row number: 8218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090415 , [Content] ='5224 ISR'
 WHERE id=191827619


   --row number: 8219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090415 , [Content] ='ISR'
 WHERE id=191827620


   --row number: 8220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090415 , [Content] ='EMEA'
 WHERE id=191827621


   --row number: 8221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090415 , [Content] ='ISRAEL'
 WHERE id=191827622


   --row number: 8222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090415 , [Content] ='Engineering'
 WHERE id=191827623


   --row number: 8223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090415 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=191827624


   --row number: 8224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090415 , [Content] ='Product Mgmt Mgr'
 WHERE id=191827625


   --row number: 8225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090415 , [Content] ='IC4'
 WHERE id=191827626


   --row number: 8226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090415 , [Content] ='ILS'
 WHERE id=191827628


   --row number: 8227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3090415 , [Content] ='272,300 / 329,350 / 386,400 / 443,450 / 500,500'
 WHERE id=191827629


   --row number: 8228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3090415 , [Content] ='132,000 / 186,000 / 240,000 / 294,000 / 348,000'
 WHERE id=191827630


   --row number: 8229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3090415 , [Content] ='20%'
 WHERE id=191827631


   --row number: 8230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090415 , [Content] ='Yes'
 WHERE id=191827632


   --row number: 8231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090415 , [Content] ='2 - Professionals'
 WHERE id=191827633


   --row number: 8232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090415 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191827634


   --row number: 8233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090415 , [Content] ='Technical'
 WHERE id=191827635


   --row number: 8234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090415 , [Content] ='7/20/2018'
 WHERE id=191827636


   --row number: 8235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090280 , [Content] ='7/20/2018'
 WHERE id=191813259


   --row number: 8236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090280 , [Content] ='Technical'
 WHERE id=191813258


   --row number: 8237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090280 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191813257


   --row number: 8238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090280 , [Content] ='2 - Professionals'
 WHERE id=191813256


   --row number: 8239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090280 , [Content] ='No'
 WHERE id=191813255


   --row number: 8240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3090280 , [Content] ='10%'
 WHERE id=191813254


   --row number: 8241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090280 , [Content] ='INR'
 WHERE id=191813253


   --row number: 8242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090280 , [Content] ='IC2'
 WHERE id=191813251


   --row number: 8243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090280 , [Content] ='Web Development'
 WHERE id=191813250


   --row number: 8244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090280 , [Content] ='6532 - Web Developer IC2'
 WHERE id=191813249


   --row number: 8245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090280 , [Content] ='Info Systems/Technology'
 WHERE id=191813248


   --row number: 8246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090280 , [Content] ='INDIA'
 WHERE id=191813247


   --row number: 8247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090280 , [Content] ='APAC'
 WHERE id=191813246


   --row number: 8248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090432 , [Content] ='7/20/2018'
 WHERE id=191829149


   --row number: 8249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090432 , [Content] ='2894 DEU'
 WHERE id=191829133


   --row number: 8250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090432 , [Content] ='DEU'
 WHERE id=191829134


   --row number: 8251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090432 , [Content] ='EMEA'
 WHERE id=191829135


   --row number: 8252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090432 , [Content] ='GERMANY'
 WHERE id=191829136


   --row number: 8253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090432 , [Content] ='Professional Services'
 WHERE id=191829137


   --row number: 8254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090432 , [Content] ='2894 - Sr Mgr, Delivery Mgmt M4'
 WHERE id=191829138


   --row number: 8255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090432 , [Content] ='Delivery Mgrs'
 WHERE id=191829139


   --row number: 8256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090432 , [Content] ='M4'
 WHERE id=191829140


   --row number: 8257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090432 , [Content] ='EUR'
 WHERE id=191829142


   --row number: 8258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3090432 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=191829143


   --row number: 8259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3090432 , [Content] ='25%'
 WHERE id=191829144


   --row number: 8260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090432 , [Content] ='Yes'
 WHERE id=191829145


   --row number: 8261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090432 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=191829146


   --row number: 8262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090432 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191829147


   --row number: 8263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090432 , [Content] ='Technical'
 WHERE id=191829148


   --row number: 8264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090435 , [Content] ='Technical'
 WHERE id=191829399


   --row number: 8265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090435 , [Content] ='7/20/2018'
 WHERE id=191829400


   --row number: 8266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090435 , [Content] ='6803 NLD'
 WHERE id=191829383


   --row number: 8267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090435 , [Content] ='NLD'
 WHERE id=191829384


   --row number: 8268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090435 , [Content] ='EMEA'
 WHERE id=191829385


   --row number: 8269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090435 , [Content] ='NETHERLANDS'
 WHERE id=191829386


   --row number: 8270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090435 , [Content] ='Info Systems/Technology'
 WHERE id=191829387


   --row number: 8271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090435 , [Content] ='6803 - UI/ UX Designer IC3'
 WHERE id=191829388


   --row number: 8272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090435 , [Content] ='UI/UX Designer'
 WHERE id=191829389


   --row number: 8273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090435 , [Content] ='IC3'
 WHERE id=191829390


   --row number: 8274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090435 , [Content] ='EUR'
 WHERE id=191829392


   --row number: 8275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3090435 , [Content] ='52,400 / 61,850 / 71,300 / 80,700 / 90,100'
 WHERE id=191829393


   --row number: 8276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3090435 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=191829394


   --row number: 8277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3090435 , [Content] ='15%'
 WHERE id=191829395


   --row number: 8278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090435 , [Content] ='Yes'
 WHERE id=191829396


   --row number: 8279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090435 , [Content] ='2 - Professionals'
 WHERE id=191829397


   --row number: 8280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090435 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191829398


   --row number: 8281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3090465 , [Content] ='5783 IND'
 WHERE id=191832378


   --row number: 8282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3090465 , [Content] ='IND'
 WHERE id=191832379


   --row number: 8283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3090465 , [Content] ='APAC'
 WHERE id=191832380


   --row number: 8284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3090465 , [Content] ='INDIA'
 WHERE id=191832381


   --row number: 8285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3090465 , [Content] ='Engineering Operations'
 WHERE id=191832382


   --row number: 8286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3090465 , [Content] ='5783 - Sr Knowledge Engineer IC3'
 WHERE id=191832383


   --row number: 8287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3090465 , [Content] ='Knowledge'
 WHERE id=191832384


   --row number: 8288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3090465 , [Content] ='IC3'
 WHERE id=191832385


   --row number: 8289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3090465 , [Content] ='INR'
 WHERE id=191832387


   --row number: 8290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3090465 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=191832388


   --row number: 8291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3090465 , [Content] ='15%'
 WHERE id=191832389


   --row number: 8292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3090465 , [Content] ='Yes'
 WHERE id=191832390


   --row number: 8293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3090465 , [Content] ='2 - Professionals'
 WHERE id=191832391


   --row number: 8294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3090465 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191832392


   --row number: 8295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3090465 , [Content] ='Technical'
 WHERE id=191832393


   --row number: 8296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3090465 , [Content] ='7/20/2018'
 WHERE id=191832394


   --row number: 8297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3091106 , [Content] ='2 - Professionals'
 WHERE id=191891156


   --row number: 8298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3091106 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191891157


   --row number: 8299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3091106 , [Content] ='Technical'
 WHERE id=191891158


   --row number: 8300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3091106 , [Content] ='10/05/18'
 WHERE id=191891159


   --row number: 8301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3091106 , [Content] ='5142 US - MRKT 2'
 WHERE id=191891140


   --row number: 8302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3091106 , [Content] ='US - MRKT 2'
 WHERE id=191891141


   --row number: 8303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3091106 , [Content] ='AMS'
 WHERE id=191891142


   --row number: 8304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3091106 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191891143


   --row number: 8305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3091106 , [Content] ='Engineering'
 WHERE id=191891144


   --row number: 8306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3091106 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=191891145


   --row number: 8307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3091106 , [Content] ='Software'
 WHERE id=191891146


   --row number: 8308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3091106 , [Content] ='IC2'
 WHERE id=191891147


   --row number: 8309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3091106 , [Content] ='USD'
 WHERE id=191891149


   --row number: 8310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3091106 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=191891150


   --row number: 8311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3091106 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=191891151


   --row number: 8312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3091106 , [Content] ='10%'
 WHERE id=191891152


   --row number: 8313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3091106 , [Content] ='Yes'
 WHERE id=191891153


   --row number: 8314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3091106 , [Content] ='EXEMPT'
 WHERE id=191891154


   --row number: 8315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3091106 , [Content] ='NO'
 WHERE id=191891155


   --row number: 8316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3091108 , [Content] ='2 - Professionals'
 WHERE id=191891406


   --row number: 8317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3091108 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191891407


   --row number: 8318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3091108 , [Content] ='Technical'
 WHERE id=191891408


   --row number: 8319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3091108 , [Content] ='10/05/18'
 WHERE id=191891409


   --row number: 8320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3091108 , [Content] ='5143 US - MRKT 2'
 WHERE id=191891390


   --row number: 8321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3091108 , [Content] ='US - MRKT 2'
 WHERE id=191891391


   --row number: 8322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3091108 , [Content] ='AMS'
 WHERE id=191891392


   --row number: 8323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3091108 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191891393


   --row number: 8324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3091108 , [Content] ='Engineering'
 WHERE id=191891394


   --row number: 8325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3091108 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=191891395


   --row number: 8326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3091108 , [Content] ='Software'
 WHERE id=191891396


   --row number: 8327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3091108 , [Content] ='IC3'
 WHERE id=191891397


   --row number: 8328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3091108 , [Content] ='USD'
 WHERE id=191891399


   --row number: 8329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3091108 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=191891400


   --row number: 8330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3091108 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=191891401


   --row number: 8331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3091108 , [Content] ='15%'
 WHERE id=191891402


   --row number: 8332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3091108 , [Content] ='Yes'
 WHERE id=191891403


   --row number: 8333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3091108 , [Content] ='EXEMPT'
 WHERE id=191891404


   --row number: 8334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3091108 , [Content] ='NO'
 WHERE id=191891405


   --row number: 8335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3091112 , [Content] ='2 - Professionals'
 WHERE id=191891758


   --row number: 8336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3091112 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=191891759


   --row number: 8337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3091112 , [Content] ='Technical'
 WHERE id=191891760


   --row number: 8338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3091112 , [Content] ='10/05/18'
 WHERE id=191891761


   --row number: 8339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3091112 , [Content] ='5143 US - MRKT 2'
 WHERE id=191891742


   --row number: 8340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3091112 , [Content] ='US - MRKT 2'
 WHERE id=191891743


   --row number: 8341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3091112 , [Content] ='AMS'
 WHERE id=191891744


   --row number: 8342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3091112 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191891745


   --row number: 8343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3091112 , [Content] ='Engineering'
 WHERE id=191891746


   --row number: 8344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3091112 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=191891747


   --row number: 8345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3091112 , [Content] ='Software'
 WHERE id=191891748


   --row number: 8346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3091112 , [Content] ='IC3'
 WHERE id=191891749


   --row number: 8347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3091112 , [Content] ='USD'
 WHERE id=191891751


   --row number: 8348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3091112 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=191891752


   --row number: 8349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3091112 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=191891753


   --row number: 8350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3091112 , [Content] ='15%'
 WHERE id=191891754


   --row number: 8351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3091112 , [Content] ='Yes'
 WHERE id=191891755


   --row number: 8352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3091112 , [Content] ='EXEMPT'
 WHERE id=191891756


   --row number: 8353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3091112 , [Content] ='NO'
 WHERE id=191891757


   --row number: 8354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3091215 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=191902031


   --row number: 8355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3091215 , [Content] ='8810-Clerical Office Employees'
 WHERE id=191902032


   --row number: 8356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3091215 , [Content] ='Non Technical'
 WHERE id=191902033


   --row number: 8357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3091215 , [Content] ='7/20/2018'
 WHERE id=191902034


   --row number: 8358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3091215 , [Content] ='2773 US - MRKT 2'
 WHERE id=191902015


   --row number: 8359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3091215 , [Content] ='US - MRKT 2'
 WHERE id=191902016


   --row number: 8360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3091215 , [Content] ='AMS'
 WHERE id=191902017


   --row number: 8361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3091215 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=191902018


   --row number: 8362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3091215 , [Content] ='Info Systems/Technology'
 WHERE id=191902019


   --row number: 8363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3091215 , [Content] ='2773 - Mgr, Compliance Mgmt M3'
 WHERE id=191902020


   --row number: 8364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3091215 , [Content] ='Compliance'
 WHERE id=191902021


   --row number: 8365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3091215 , [Content] ='M3'
 WHERE id=191902022


   --row number: 8366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3091215 , [Content] ='USD'
 WHERE id=191902024


   --row number: 8367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3091215 , [Content] ='76,700 / 92,750 / 108,800 / 124,900 / 141,000'
 WHERE id=191902025


   --row number: 8368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3091215 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=191902026


   --row number: 8369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3091215 , [Content] ='20%'
 WHERE id=191902027


   --row number: 8370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3091215 , [Content] ='Yes'
 WHERE id=191902028


   --row number: 8371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3091215 , [Content] ='EXEMPT'
 WHERE id=191902029


   --row number: 8372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3091215 , [Content] ='NO'
 WHERE id=191902030


   --row number: 8373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3092465 , [Content] ='A3'
 WHERE id=192056313


   --row number: 8374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3092465 , [Content] ='Non Technical'
 WHERE id=192056322


   --row number: 8375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3092465 , [Content] ='04/05/18'
 WHERE id=192056323


   --row number: 8376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3092465 , [Content] ='GBP'
 WHERE id=192056315


   --row number: 8377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3092465 , [Content] ='29,580 / 32,190 / 34,800 / 37,410 / 40,020'
 WHERE id=192056316


   --row number: 8378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3092465 , [Content] ='49,300 / 53,650 / 58,000 / 62,350 / 66,700'
 WHERE id=192056317


   --row number: 8379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3092465 , [Content] ='60/40'
 WHERE id=192056318


   --row number: 8380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3092465 , [Content] ='No'
 WHERE id=192056319


   --row number: 8381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3092465 , [Content] ='4 - Sales Workers'
 WHERE id=192056320


   --row number: 8382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3092465 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192056321


   --row number: 8383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3092465 , [Content] ='S1333 UK'
 WHERE id=192056306


   --row number: 8384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3092465 , [Content] ='UK'
 WHERE id=192056307


   --row number: 8385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3092465 , [Content] ='EMEA'
 WHERE id=192056308


   --row number: 8386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3092465 , [Content] ='UNITED KINGDOM'
 WHERE id=192056309


   --row number: 8387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3092465 , [Content] ='Sales'
 WHERE id=192056310


   --row number: 8388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3092465 , [Content] ='S1333 - Account Development Rep A3'
 WHERE id=192056311


   --row number: 8389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3092465 , [Content] ='Inside Sales'
 WHERE id=192056312


   --row number: 8390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3092846 , [Content] ='S1413 US - MRKT 1'
 WHERE id=192093114


   --row number: 8391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3092846 , [Content] ='US - MRKT 1'
 WHERE id=192093115


   --row number: 8392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3092846 , [Content] ='AMS'
 WHERE id=192093116


   --row number: 8393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3092846 , [Content] ='EXEMPT'
 WHERE id=192093129


   --row number: 8394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3092846 , [Content] ='NO'
 WHERE id=192093130


   --row number: 8395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3092846 , [Content] ='4 - Sales Workers'
 WHERE id=192093131


   --row number: 8396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3092846 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192093132


   --row number: 8397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3092846 , [Content] ='Technical'
 WHERE id=192093133


   --row number: 8398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3092846 , [Content] ='7/20/2018'
 WHERE id=192093134


   --row number: 8399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3092846 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192093117


   --row number: 8400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3092846 , [Content] ='Solution Consulting'
 WHERE id=192093118


   --row number: 8401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3092846 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=192093119


   --row number: 8402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3092846 , [Content] ='Solution Consultant Core'
 WHERE id=192093120


   --row number: 8403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3092846 , [Content] ='IC3'
 WHERE id=192093121


   --row number: 8404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3092846 , [Content] ='USD'
 WHERE id=192093123


   --row number: 8405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3092846 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=192093124


   --row number: 8406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3092846 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=192093125


   --row number: 8407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3092846 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=192093126


   --row number: 8408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3092846 , [Content] ='75/25'
 WHERE id=192093127


   --row number: 8409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3092846 , [Content] ='Yes'
 WHERE id=192093128


   --row number: 8410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3093351 , [Content] ='NO'
 WHERE id=192135033


   --row number: 8411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3093351 , [Content] ='2 - Professionals'
 WHERE id=192135034


   --row number: 8412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3093351 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192135035


   --row number: 8413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3093351 , [Content] ='Technical'
 WHERE id=192135036


   --row number: 8414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3093351 , [Content] ='1/29/2018'
 WHERE id=192135037


   --row number: 8415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3093351 , [Content] ='5142 US - MRKT 1'
 WHERE id=192135018


   --row number: 8416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3093351 , [Content] ='US - MRKT 1'
 WHERE id=192135019


   --row number: 8417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3093351 , [Content] ='AMS'
 WHERE id=192135020


   --row number: 8418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3093351 , [Content] ='US'
 WHERE id=192135021


   --row number: 8419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3093351 , [Content] ='Engineering'
 WHERE id=192135022


   --row number: 8420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3093351 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192135023


   --row number: 8421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3093351 , [Content] ='Software'
 WHERE id=192135024


   --row number: 8422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3093351 , [Content] ='IC2'
 WHERE id=192135025


   --row number: 8423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3093351 , [Content] ='USD'
 WHERE id=192135027


   --row number: 8424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3093351 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=192135028


   --row number: 8425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3093351 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=192135029


   --row number: 8426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3093351 , [Content] ='10%'
 WHERE id=192135030


   --row number: 8427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3093351 , [Content] ='Yes'
 WHERE id=192135031


   --row number: 8428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3093351 , [Content] ='EXEMPT'
 WHERE id=192135032


   --row number: 8429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3093432 , [Content] ='2 - Professionals'
 WHERE id=192143906


   --row number: 8430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3093432 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192143907


   --row number: 8431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3093432 , [Content] ='Technical'
 WHERE id=192143908


   --row number: 8432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3093432 , [Content] ='7/20/2018'
 WHERE id=192143909


   --row number: 8433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3093432 , [Content] ='5143 US - MRKT 2'
 WHERE id=192143888


   --row number: 8434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3093432 , [Content] ='US - MRKT 2'
 WHERE id=192143889


   --row number: 8435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3093432 , [Content] ='AMS'
 WHERE id=192143891


   --row number: 8436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3093432 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192143893


   --row number: 8437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3093432 , [Content] ='Engineering'
 WHERE id=192143894


   --row number: 8438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3093432 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192143895


   --row number: 8439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3093432 , [Content] ='Software'
 WHERE id=192143896


   --row number: 8440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3093432 , [Content] ='IC3'
 WHERE id=192143897


   --row number: 8441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3093432 , [Content] ='USD'
 WHERE id=192143899


   --row number: 8442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3093432 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=192143900


   --row number: 8443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3093432 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=192143901


   --row number: 8444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3093432 , [Content] ='15%'
 WHERE id=192143902


   --row number: 8445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3093432 , [Content] ='Yes'
 WHERE id=192143903


   --row number: 8446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3093432 , [Content] ='EXEMPT'
 WHERE id=192143904


   --row number: 8447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3093432 , [Content] ='NO'
 WHERE id=192143905


   --row number: 8448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3093856 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192170080


   --row number: 8449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3093856 , [Content] ='Technical'
 WHERE id=192170081


   --row number: 8450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3093856 , [Content] ='7/20/2018'
 WHERE id=192170082


   --row number: 8451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3093856 , [Content] ='6624 US - MRKT 2'
 WHERE id=192170063


   --row number: 8452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3093856 , [Content] ='US - MRKT 2'
 WHERE id=192170064


   --row number: 8453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3093856 , [Content] ='AMS'
 WHERE id=192170065


   --row number: 8454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3093856 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192170066


   --row number: 8455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3093856 , [Content] ='Info Systems/Technology'
 WHERE id=192170067


   --row number: 8456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3093856 , [Content] ='6624 - Project (Information Systems) Mgr IC4'
 WHERE id=192170068


   --row number: 8457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3093856 , [Content] ='IT Project/Program Mgrs'
 WHERE id=192170069


   --row number: 8458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3093856 , [Content] ='IC4'
 WHERE id=192170070


   --row number: 8459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3093856 , [Content] ='USD'
 WHERE id=192170072


   --row number: 8460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3093856 , [Content] ='95,700 / 115,750 / 135,800 / 155,850 / 175,900'
 WHERE id=192170073


   --row number: 8461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3093856 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=192170074


   --row number: 8462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3093856 , [Content] ='20%'
 WHERE id=192170075


   --row number: 8463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3093856 , [Content] ='Yes'
 WHERE id=192170076


   --row number: 8464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3093856 , [Content] ='EXEMPT'
 WHERE id=192170077


   --row number: 8465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3093856 , [Content] ='NO'
 WHERE id=192170078


   --row number: 8466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3093856 , [Content] ='2 - Professionals'
 WHERE id=192170079


   --row number: 8467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3094308 , [Content] ='Technical'
 WHERE id=192228519


   --row number: 8468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3094308 , [Content] ='7/20/2018'
 WHERE id=192228520


   --row number: 8469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3094308 , [Content] ='5144 IND'
 WHERE id=192228503


   --row number: 8470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3094308 , [Content] ='IND'
 WHERE id=192228504


   --row number: 8471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3094308 , [Content] ='APAC'
 WHERE id=192228505


   --row number: 8472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3094308 , [Content] ='INDIA'
 WHERE id=192228506


   --row number: 8473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3094308 , [Content] ='Engineering'
 WHERE id=192228507


   --row number: 8474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3094308 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=192228508


   --row number: 8475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3094308 , [Content] ='Software'
 WHERE id=192228509


   --row number: 8476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3094308 , [Content] ='IC4'
 WHERE id=192228510


   --row number: 8477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3094308 , [Content] ='INR'
 WHERE id=192228512


   --row number: 8478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3094308 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=192228513


   --row number: 8479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3094308 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=192228514


   --row number: 8480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3094308 , [Content] ='20%'
 WHERE id=192228515


   --row number: 8481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3094308 , [Content] ='Yes'
 WHERE id=192228516


   --row number: 8482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3094308 , [Content] ='2 - Professionals'
 WHERE id=192228517


   --row number: 8483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3094308 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192228518


   --row number: 8484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3094310 , [Content] ='Technical'
 WHERE id=192228665


   --row number: 8485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3094310 , [Content] ='10/05/18'
 WHERE id=192228666


   --row number: 8486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3094310 , [Content] ='5143 IND'
 WHERE id=192228649


   --row number: 8487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3094310 , [Content] ='IND'
 WHERE id=192228650


   --row number: 8488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3094310 , [Content] ='APAC'
 WHERE id=192228651


   --row number: 8489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3094310 , [Content] ='INDIA'
 WHERE id=192228652


   --row number: 8490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3094310 , [Content] ='Engineering'
 WHERE id=192228653


   --row number: 8491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3094310 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192228654


   --row number: 8492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3094310 , [Content] ='Software'
 WHERE id=192228655


   --row number: 8493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3094310 , [Content] ='IC3'
 WHERE id=192228656


   --row number: 8494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3094310 , [Content] ='INR'
 WHERE id=192228658


   --row number: 8495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3094310 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=192228659


   --row number: 8496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3094310 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=192228660


   --row number: 8497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3094310 , [Content] ='15%'
 WHERE id=192228661


   --row number: 8498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3094310 , [Content] ='Yes'
 WHERE id=192228662


   --row number: 8499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3094310 , [Content] ='2 - Professionals'
 WHERE id=192228663


   --row number: 8500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3094310 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192228664


   --row number: 8501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3094546 , [Content] ='6/27/2018'
 WHERE id=192258059


   --row number: 8502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3094546 , [Content] ='5182 UK'
 WHERE id=192258043


   --row number: 8503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3094546 , [Content] ='UK'
 WHERE id=192258044


   --row number: 8504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3094546 , [Content] ='EMEA'
 WHERE id=192258045


   --row number: 8505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3094546 , [Content] ='UNITED KINGDOM'
 WHERE id=192258046


   --row number: 8506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3094546 , [Content] ='Engineering'
 WHERE id=192258047


   --row number: 8507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3094546 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=192258048


   --row number: 8508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3094546 , [Content] ='Quality'
 WHERE id=192258049


   --row number: 8509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3094546 , [Content] ='IC2'
 WHERE id=192258050


   --row number: 8510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3094546 , [Content] ='GBP'
 WHERE id=192258052


   --row number: 8511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3094546 , [Content] ='29,400 / 34,250 / 39,100 / 43,950 / 48,800'
 WHERE id=192258053


   --row number: 8512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3094546 , [Content] ='10%'
 WHERE id=192258054


   --row number: 8513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3094546 , [Content] ='No'
 WHERE id=192258055


   --row number: 8514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3094546 , [Content] ='2 - Professionals'
 WHERE id=192258056


   --row number: 8515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3094546 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192258057


   --row number: 8516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3094546 , [Content] ='Technical'
 WHERE id=192258058


   --row number: 8517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3094944 , [Content] ='2 - Professionals'
 WHERE id=192286660


   --row number: 8518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3094944 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192286661


   --row number: 8519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3094944 , [Content] ='Technical'
 WHERE id=192286662


   --row number: 8520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3094944 , [Content] ='7/20/2018'
 WHERE id=192286663


   --row number: 8521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3094944 , [Content] ='5225 US - MRKT 1'
 WHERE id=192286644


   --row number: 8522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3094944 , [Content] ='US - MRKT 1'
 WHERE id=192286645


   --row number: 8523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3094944 , [Content] ='AMS'
 WHERE id=192286646


   --row number: 8524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3094944 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192286647


   --row number: 8525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3094944 , [Content] ='Engineering'
 WHERE id=192286648


   --row number: 8526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3094944 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=192286649


   --row number: 8527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3094944 , [Content] ='Product Mgmt Mgr'
 WHERE id=192286650


   --row number: 8528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3094944 , [Content] ='IC5'
 WHERE id=192286651


   --row number: 8529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3094944 , [Content] ='USD'
 WHERE id=192286653


   --row number: 8530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3094944 , [Content] ='123,800 / 151,650 / 179,500 / 207,350 / 235,200'
 WHERE id=192286654


   --row number: 8531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3094944 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=192286655


   --row number: 8532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3094944 , [Content] ='25%'
 WHERE id=192286656


   --row number: 8533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3094944 , [Content] ='Yes'
 WHERE id=192286657


   --row number: 8534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3094944 , [Content] ='EXEMPT'
 WHERE id=192286658


   --row number: 8535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3094944 , [Content] ='NO'
 WHERE id=192286659


   --row number: 8536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3095475 , [Content] ='NO'
 WHERE id=192331058


   --row number: 8537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3095475 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192331060


   --row number: 8538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3095475 , [Content] ='Technical'
 WHERE id=192331061


   --row number: 8539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3095475 , [Content] ='7/20/2018'
 WHERE id=192331062


   --row number: 8540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3095475 , [Content] ='2 - Professionals'
 WHERE id=192331059


   --row number: 8541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3095475 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=192331054


   --row number: 8542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3095475 , [Content] ='10%'
 WHERE id=192331055


   --row number: 8543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3095475 , [Content] ='Yes'
 WHERE id=192331056


   --row number: 8544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3095475 , [Content] ='EXEMPT'
 WHERE id=192331057


   --row number: 8545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3095475 , [Content] ='5312 US - MRKT 2'
 WHERE id=192331042


   --row number: 8546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3095475 , [Content] ='US - MRKT 2'
 WHERE id=192331043


   --row number: 8547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3095475 , [Content] ='AMS'
 WHERE id=192331044


   --row number: 8548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3095475 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192331045


   --row number: 8549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3095475 , [Content] ='Engineering Operations'
 WHERE id=192331046


   --row number: 8550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3095475 , [Content] ='5312 - Technical Writer IC2'
 WHERE id=192331047


   --row number: 8551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3095475 , [Content] ='Technical Writer'
 WHERE id=192331048


   --row number: 8552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3095475 , [Content] ='IC2'
 WHERE id=192331049


   --row number: 8553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3095475 , [Content] ='USD'
 WHERE id=192331052


   --row number: 8554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3095475 , [Content] ='55,600 / 63,550 / 71,500 / 79,400 / 87,300'
 WHERE id=192331053


   --row number: 8555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3091275 , [Content] ='Solution Consultant Core'
 WHERE id=192331799


   --row number: 8556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3091275 , [Content] ='US - MRKT 1'
 WHERE id=192331800


   --row number: 8557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3091275 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192331805


   --row number: 8558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3091275 , [Content] ='Solution Consulting'
 WHERE id=192331806


   --row number: 8559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3091275 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=192331807


   --row number: 8560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3091275 , [Content] ='S1405 - Dir, Solution Consulting M5'
 WHERE id=192331808


   --row number: 8561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3091275 , [Content] ='EXEMPT'
 WHERE id=192331801


   --row number: 8562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3091275 , [Content] ='NO'
 WHERE id=192331802


   --row number: 8563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3091275 , [Content] ='AMS'
 WHERE id=192331803


   --row number: 8564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3091275 , [Content] ='Yes'
 WHERE id=192331804


   --row number: 8565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3095775 , [Content] ='Sales'
 WHERE id=192354384


   --row number: 8566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3095775 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=192354385


   --row number: 8567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3095775 , [Content] ='Product Line Sales'
 WHERE id=192354386


   --row number: 8568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3095775 , [Content] ='IC5'
 WHERE id=192354387


   --row number: 8569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3095775 , [Content] ='USD'
 WHERE id=192354389


   --row number: 8570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3095775 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=192354390


   --row number: 8571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3095775 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=192354391


   --row number: 8572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3095775 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=192354392


   --row number: 8573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3095775 , [Content] ='60/40'
 WHERE id=192354393


   --row number: 8574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3095775 , [Content] ='Yes'
 WHERE id=192354394


   --row number: 8575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3095775 , [Content] ='EXEMPT'
 WHERE id=192354395


   --row number: 8576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3095775 , [Content] ='NO'
 WHERE id=192354396


   --row number: 8577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3095775 , [Content] ='4 - Sales Workers'
 WHERE id=192354397


   --row number: 8578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3095775 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192354398


   --row number: 8579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3095775 , [Content] ='Technical'
 WHERE id=192354399


   --row number: 8580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3095775 , [Content] ='7/20/2018'
 WHERE id=192354400


   --row number: 8581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3091275 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192331809


   --row number: 8582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3091275 , [Content] ='M5'
 WHERE id=192331810


   --row number: 8583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3091275 , [Content] ='Technical'
 WHERE id=192331811


   --row number: 8584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3091275 , [Content] ='7/20/2018'
 WHERE id=192331813


   --row number: 8585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3091275 , [Content] ='242,250 / 263,625 / 285,000 / 306,375 / 327,750'
 WHERE id=192331814


   --row number: 8586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3091275 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=192331815


   --row number: 8587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3091275 , [Content] ='181,688 / 197,719 / 213,750 / 229,781 / 245,813'
 WHERE id=192331816


   --row number: 8588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3091275 , [Content] ='75/25'
 WHERE id=192331818


   --row number: 8589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3091275 , [Content] ='S1405 US - MRKT 1'
 WHERE id=192331819


   --row number: 8590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3091275 , [Content] ='USD'
 WHERE id=192331820


   --row number: 8591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3095775 , [Content] ='S665 US - MRKT 1'
 WHERE id=192354380


   --row number: 8592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3095775 , [Content] ='US - MRKT 1'
 WHERE id=192354381


   --row number: 8593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3095775 , [Content] ='AMS'
 WHERE id=192354382


   --row number: 8594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3095775 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192354383


   --row number: 8595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096183 , [Content] ='5824 US - MRKT 1'
 WHERE id=192412977


   --row number: 8596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096183 , [Content] ='US - MRKT 1'
 WHERE id=192412978


   --row number: 8597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096183 , [Content] ='AMS'
 WHERE id=192412979


   --row number: 8598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096183 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192412980


   --row number: 8599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096183 , [Content] ='Customer Support'
 WHERE id=192412981


   --row number: 8600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096183 , [Content] ='5824 - Staff Tech Support Engineer IC4'
 WHERE id=192412982


   --row number: 8601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096183 , [Content] ='Technical Support'
 WHERE id=192412983


   --row number: 8602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096183 , [Content] ='IC4'
 WHERE id=192412984


   --row number: 8603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096183 , [Content] ='USD'
 WHERE id=192412986


   --row number: 8604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096183 , [Content] ='86,700 / 104,850 / 123,000 / 141,200 / 159,400'
 WHERE id=192412987


   --row number: 8605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3096183 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=192412988


   --row number: 8606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096183 , [Content] ='20%'
 WHERE id=192412989


   --row number: 8607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3096183 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=192412990


   --row number: 8608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096183 , [Content] ='Yes'
 WHERE id=192412991


   --row number: 8609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3096183 , [Content] ='EXEMPT'
 WHERE id=192412992


   --row number: 8610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3096183 , [Content] ='YES'
 WHERE id=192412993


   --row number: 8611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096183 , [Content] ='2 - Professionals'
 WHERE id=192412994


   --row number: 8612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096183 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192412995


   --row number: 8613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3095936 , [Content] ='6001 US - MRKT 1'
 WHERE id=192366807


   --row number: 8614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3095936 , [Content] ='US - MRKT 1'
 WHERE id=192366808


   --row number: 8615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3095936 , [Content] ='AMS'
 WHERE id=192366809


   --row number: 8616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3095936 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192366810


   --row number: 8617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3095936 , [Content] ='Finance'
 WHERE id=192366811


   --row number: 8618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3095936 , [Content] ='6001 - FP&A Analyst IC1'
 WHERE id=192366812


   --row number: 8619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3095936 , [Content] ='FP&A'
 WHERE id=192366813


   --row number: 8620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3095936 , [Content] ='IC1'
 WHERE id=192366814


   --row number: 8621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3095936 , [Content] ='USD'
 WHERE id=192366816


   --row number: 8622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3095936 , [Content] ='56,600 / 64,300 / 72,000 / 79,650 / 87,300'
 WHERE id=192366817


   --row number: 8623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3095936 , [Content] ='10%'
 WHERE id=192366818


   --row number: 8624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3095936 , [Content] ='No'
 WHERE id=192366819


   --row number: 8625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3095936 , [Content] ='NON-EXEMPT'
 WHERE id=192366820


   --row number: 8626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3095936 , [Content] ='NO'
 WHERE id=192366821


   --row number: 8627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3095936 , [Content] ='2 - Professionals'
 WHERE id=192366822


   --row number: 8628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3095936 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192366823


   --row number: 8629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3095936 , [Content] ='Non Technical'
 WHERE id=192366824


   --row number: 8630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3095936 , [Content] ='7/20/2018'
 WHERE id=192366825


   --row number: 8631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096183 , [Content] ='Technical'
 WHERE id=192412996


   --row number: 8632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3096215 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=192419703


   --row number: 8633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096215 , [Content] ='15%'
 WHERE id=192419704


   --row number: 8634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096215 , [Content] ='Yes'
 WHERE id=192419705


   --row number: 8635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096215 , [Content] ='2 - Professionals'
 WHERE id=192419706


   --row number: 8636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096215 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192419707


   --row number: 8637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096215 , [Content] ='Technical'
 WHERE id=192419708


   --row number: 8638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096215 , [Content] ='7/20/2018'
 WHERE id=192419709


   --row number: 8639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096183 , [Content] ='7/20/2018'
 WHERE id=192412997


   --row number: 8640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096215 , [Content] ='6593 AUS'
 WHERE id=192419692


   --row number: 8641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096215 , [Content] ='AUS'
 WHERE id=192419693


   --row number: 8642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096215 , [Content] ='APAC'
 WHERE id=192419694


   --row number: 8643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096215 , [Content] ='AUSTRALIA'
 WHERE id=192419695


   --row number: 8644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096215 , [Content] ='Info Systems/Technology'
 WHERE id=192419696


   --row number: 8645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096215 , [Content] ='6593 - Sr Database Engineer IC3'
 WHERE id=192419697


   --row number: 8646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096215 , [Content] ='Database Engineer'
 WHERE id=192419698


   --row number: 8647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096215 , [Content] ='IC3'
 WHERE id=192419699


   --row number: 8648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096215 , [Content] ='AUD'
 WHERE id=192419701


   --row number: 8649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096215 , [Content] ='80,100 / 94,550 / 109,000 / 123,400 / 137,800'
 WHERE id=192419702


   --row number: 8650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096295 , [Content] ='7/20/2018'
 WHERE id=192427511


   --row number: 8651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096295 , [Content] ='5141 IND'
 WHERE id=192427495


   --row number: 8652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096295 , [Content] ='IND'
 WHERE id=192427496


   --row number: 8653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096295 , [Content] ='APAC'
 WHERE id=192427497


   --row number: 8654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096295 , [Content] ='INDIA'
 WHERE id=192427498


   --row number: 8655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096295 , [Content] ='Engineering'
 WHERE id=192427499


   --row number: 8656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096295 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=192427500


   --row number: 8657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096295 , [Content] ='Software'
 WHERE id=192427501


   --row number: 8658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096295 , [Content] ='IC1'
 WHERE id=192427502


   --row number: 8659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096295 , [Content] ='INR'
 WHERE id=192427504


   --row number: 8660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096295 , [Content] ='703,500 / 861,800 / 1,020,100 / 1,178,400 / 1,336,700'
 WHERE id=192427505


   --row number: 8661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096295 , [Content] ='10%'
 WHERE id=192427506


   --row number: 8662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096295 , [Content] ='No'
 WHERE id=192427507


   --row number: 8663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096295 , [Content] ='2 - Professionals'
 WHERE id=192427508


   --row number: 8664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096295 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192427509


   --row number: 8665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096295 , [Content] ='Technical'
 WHERE id=192427510


   --row number: 8666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096314 , [Content] ='5883 IND'
 WHERE id=192429515


   --row number: 8667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096314 , [Content] ='IND'
 WHERE id=192429516


   --row number: 8668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096314 , [Content] ='APAC'
 WHERE id=192429517


   --row number: 8669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096314 , [Content] ='INDIA'
 WHERE id=192429518


   --row number: 8670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096314 , [Content] ='Professional Services'
 WHERE id=192429519


   --row number: 8671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096314 , [Content] ='5883 - Customer/Technical Trainer IC3'
 WHERE id=192429520


   --row number: 8672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096314 , [Content] ='Customer/Tech Training'
 WHERE id=192429521


   --row number: 8673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096314 , [Content] ='IC3'
 WHERE id=192429522


   --row number: 8674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096314 , [Content] ='INR'
 WHERE id=192429524


   --row number: 8675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096314 , [Content] ='7/20/2018'
 WHERE id=192429531


   --row number: 8676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096314 , [Content] ='1,103,400 / 1,351,700 / 1,600,000 / 1,848,250 / 2,096,500'
 WHERE id=192429525


   --row number: 8677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096314 , [Content] ='10%'
 WHERE id=192429526


   --row number: 8678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096314 , [Content] ='No'
 WHERE id=192429527


   --row number: 8679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096314 , [Content] ='2 - Professionals'
 WHERE id=192429528


   --row number: 8680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096314 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192429529


   --row number: 8681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096314 , [Content] ='Technical'
 WHERE id=192429530


   --row number: 8682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096315 , [Content] ='7/20/2018'
 WHERE id=192429713


   --row number: 8683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096315 , [Content] ='INR'
 WHERE id=192429706


   --row number: 8684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096315 , [Content] ='5883 IND'
 WHERE id=192429697


   --row number: 8685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096315 , [Content] ='IND'
 WHERE id=192429698


   --row number: 8686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096315 , [Content] ='APAC'
 WHERE id=192429699


   --row number: 8687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096315 , [Content] ='INDIA'
 WHERE id=192429700


   --row number: 8688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096315 , [Content] ='Professional Services'
 WHERE id=192429701


   --row number: 8689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096315 , [Content] ='5883 - Customer/Technical Trainer IC3'
 WHERE id=192429702


   --row number: 8690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096315 , [Content] ='Customer/Tech Training'
 WHERE id=192429703


   --row number: 8691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096315 , [Content] ='IC3'
 WHERE id=192429704


   --row number: 8692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096315 , [Content] ='1,103,400 / 1,351,700 / 1,600,000 / 1,848,250 / 2,096,500'
 WHERE id=192429707


   --row number: 8693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096315 , [Content] ='10%'
 WHERE id=192429708


   --row number: 8694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096315 , [Content] ='No'
 WHERE id=192429709


   --row number: 8695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096315 , [Content] ='2 - Professionals'
 WHERE id=192429710


   --row number: 8696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096315 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192429711


   --row number: 8697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096315 , [Content] ='Technical'
 WHERE id=192429712


   --row number: 8698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096593 , [Content] ='2 - Professionals'
 WHERE id=192463722


   --row number: 8699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096593 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192463723


   --row number: 8700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096593 , [Content] ='Technical'
 WHERE id=192463724


   --row number: 8701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096593 , [Content] ='06/08/18'
 WHERE id=192463725


   --row number: 8702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096593 , [Content] ='5204 IRL'
 WHERE id=192463708


   --row number: 8703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096593 , [Content] ='IRL'
 WHERE id=192463709


   --row number: 8704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096593 , [Content] ='EMEA'
 WHERE id=192463710


   --row number: 8705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096593 , [Content] ='IRELAND'
 WHERE id=192463711


   --row number: 8706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096593 , [Content] ='Engineering'
 WHERE id=192463712


   --row number: 8707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096593 , [Content] ='5204 - Staff Systems Design Engineer IC4'
 WHERE id=192463713


   --row number: 8708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096593 , [Content] ='Systems Design'
 WHERE id=192463714


   --row number: 8709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096593 , [Content] ='IC4'
 WHERE id=192463715


   --row number: 8710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096593 , [Content] ='EUR'
 WHERE id=192463717


   --row number: 8711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096593 , [Content] ='55,700 / 67,350 / 79,000 / 90,700 / 102,400'
 WHERE id=192463718


   --row number: 8712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3096593 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=192463719


   --row number: 8713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096593 , [Content] ='20%'
 WHERE id=192463720


   --row number: 8714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096593 , [Content] ='Yes'
 WHERE id=192463721


   --row number: 8715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096612 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192464880


   --row number: 8716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096612 , [Content] ='Technical'
 WHERE id=192464881


   --row number: 8717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096612 , [Content] ='04/05/18'
 WHERE id=192464882


   --row number: 8718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096612 , [Content] ='5204 UK'
 WHERE id=192464865


   --row number: 8719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096612 , [Content] ='UK'
 WHERE id=192464866


   --row number: 8720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096612 , [Content] ='EMEA'
 WHERE id=192464867


   --row number: 8721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096612 , [Content] ='UNITED KINGDOM'
 WHERE id=192464868


   --row number: 8722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096612 , [Content] ='Engineering'
 WHERE id=192464869


   --row number: 8723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096612 , [Content] ='5204 - Staff Systems Design Engineer IC4'
 WHERE id=192464870


   --row number: 8724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096612 , [Content] ='Systems Design'
 WHERE id=192464871


   --row number: 8725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096612 , [Content] ='IC4'
 WHERE id=192464872


   --row number: 8726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096612 , [Content] ='GBP'
 WHERE id=192464874


   --row number: 8727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096612 , [Content] ='52,400 / 63,350 / 74,300 / 85,300 / 96,300'
 WHERE id=192464875


   --row number: 8728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3096612 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=192464876


   --row number: 8729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096612 , [Content] ='20%'
 WHERE id=192464877


   --row number: 8730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096612 , [Content] ='Yes'
 WHERE id=192464878


   --row number: 8731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096612 , [Content] ='2 - Professionals'
 WHERE id=192464879


   --row number: 8732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096775 , [Content] ='Technical'
 WHERE id=192479654


   --row number: 8733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096775 , [Content] ='7/20/2018'
 WHERE id=192479655


   --row number: 8734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096775 , [Content] ='5143 IND'
 WHERE id=192479638


   --row number: 8735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096775 , [Content] ='IND'
 WHERE id=192479639


   --row number: 8736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096775 , [Content] ='APAC'
 WHERE id=192479640


   --row number: 8737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096775 , [Content] ='INDIA'
 WHERE id=192479641


   --row number: 8738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096775 , [Content] ='Engineering'
 WHERE id=192479642


   --row number: 8739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096775 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192479643


   --row number: 8740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096775 , [Content] ='Software'
 WHERE id=192479644


   --row number: 8741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096775 , [Content] ='IC3'
 WHERE id=192479645


   --row number: 8742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096775 , [Content] ='INR'
 WHERE id=192479647


   --row number: 8743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096775 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=192479648


   --row number: 8744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3096775 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=192479649


   --row number: 8745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096775 , [Content] ='15%'
 WHERE id=192479650


   --row number: 8746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096775 , [Content] ='Yes'
 WHERE id=192479651


   --row number: 8747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096775 , [Content] ='2 - Professionals'
 WHERE id=192479652


   --row number: 8748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096775 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192479653


   --row number: 8749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3096783 , [Content] ='Technical'
 WHERE id=192480461


   --row number: 8750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3096783 , [Content] ='7/20/2018'
 WHERE id=192480462


   --row number: 8751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3096783 , [Content] ='5143 IND'
 WHERE id=192480443


   --row number: 8752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3096783 , [Content] ='IND'
 WHERE id=192480444


   --row number: 8753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3096783 , [Content] ='APAC'
 WHERE id=192480445


   --row number: 8754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3096783 , [Content] ='INDIA'
 WHERE id=192480446


   --row number: 8755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3096783 , [Content] ='Engineering'
 WHERE id=192480447


   --row number: 8756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3096783 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192480448


   --row number: 8757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3096783 , [Content] ='Software'
 WHERE id=192480449


   --row number: 8758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3096783 , [Content] ='IC3'
 WHERE id=192480450


   --row number: 8759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3096783 , [Content] ='INR'
 WHERE id=192480452


   --row number: 8760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3096783 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=192480453


   --row number: 8761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3096783 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=192480456


   --row number: 8762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3096783 , [Content] ='15%'
 WHERE id=192480457


   --row number: 8763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3096783 , [Content] ='Yes'
 WHERE id=192480458


   --row number: 8764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3096783 , [Content] ='2 - Professionals'
 WHERE id=192480459


   --row number: 8765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3096783 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192480460


   --row number: 8766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3097008 , [Content] ='6474 US - MRKT 1'
 WHERE id=192502113


   --row number: 8767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3097008 , [Content] ='US - MRKT 1'
 WHERE id=192502114


   --row number: 8768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3097008 , [Content] ='AMS'
 WHERE id=192502115


   --row number: 8769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3097008 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192502116


   --row number: 8770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3097008 , [Content] ='Info Systems/Technology'
 WHERE id=192502117


   --row number: 8771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3097008 , [Content] ='6474 - Staff Network Engineer IC4'
 WHERE id=192502118


   --row number: 8772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3097008 , [Content] ='Network Engineer'
 WHERE id=192502119


   --row number: 8773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3097008 , [Content] ='IC4'
 WHERE id=192502120


   --row number: 8774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3097008 , [Content] ='105,900 / 150,300 / 194,700'
 WHERE id=192502122


   --row number: 8775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3097008 , [Content] ='700 / 1,100 / 1,500'
 WHERE id=192502123


   --row number: 8776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3097008 , [Content] ='20%'
 WHERE id=192502124


   --row number: 8777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3097008 , [Content] ='Yes'
 WHERE id=192502125


   --row number: 8778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3097008 , [Content] ='EXEMPT'
 WHERE id=192502126


   --row number: 8779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3097008 , [Content] ='NO'
 WHERE id=192502127


   --row number: 8780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3097008 , [Content] ='2 - Professionals'
 WHERE id=192502128


   --row number: 8781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3097008 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192502129


   --row number: 8782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3097008 , [Content] ='Technical'
 WHERE id=192502130


   --row number: 8783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3097551 , [Content] ='2 - Professionals'
 WHERE id=192555111


   --row number: 8784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3097551 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192555112


   --row number: 8785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3097551 , [Content] ='Technical'
 WHERE id=192555113


   --row number: 8786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3097551 , [Content] ='7/20/2018'
 WHERE id=192555114


   --row number: 8787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3097551 , [Content] ='5142 US - MRKT 2'
 WHERE id=192555095


   --row number: 8788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3097551 , [Content] ='US - MRKT 2'
 WHERE id=192555096


   --row number: 8789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3097551 , [Content] ='AMS'
 WHERE id=192555097


   --row number: 8790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3097551 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192555098


   --row number: 8791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3097551 , [Content] ='Engineering'
 WHERE id=192555099


   --row number: 8792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3097551 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192555100


   --row number: 8793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3097551 , [Content] ='Software'
 WHERE id=192555101


   --row number: 8794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3097551 , [Content] ='IC2'
 WHERE id=192555102


   --row number: 8795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3097551 , [Content] ='USD'
 WHERE id=192555104


   --row number: 8796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3097551 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=192555105


   --row number: 8797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3097551 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=192555106


   --row number: 8798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3097551 , [Content] ='10%'
 WHERE id=192555107


   --row number: 8799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3097551 , [Content] ='Yes'
 WHERE id=192555108


   --row number: 8800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3097551 , [Content] ='EXEMPT'
 WHERE id=192555109


   --row number: 8801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3097551 , [Content] ='NO'
 WHERE id=192555110


   --row number: 8802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3097698 , [Content] ='5143 US - MRKT 1'
 WHERE id=192567985


   --row number: 8803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3097698 , [Content] ='US - MRKT 1'
 WHERE id=192567986


   --row number: 8804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3084296 , [Content] ='1,138,000 / 1,394,000 / 1,650,000 / 1,906,100 / 2,162,200'
 WHERE id=198281750


   --row number: 8805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3089415 , [Content] ='09/05/18'
 WHERE id=199629082


   --row number: 8806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3089415 , [Content] ='193,000 / 236,450 / 279,900 / 323,350 / 366,800'
 WHERE id=199629083


   --row number: 8807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3089415 , [Content] ='USD'
 WHERE id=199629084


   --row number: 8808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3042700 , [Content] ='1,181,700 / 1,447,600 / 1,713,500 / 1,979,400 / 2,245,300'
 WHERE id=200355393


   --row number: 8809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3042700 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=200355394


   --row number: 8810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3040240 , [Content] ='62,600 / 73,850 / 85,100 / 96,350 / 107,600'
 WHERE id=201163238


   --row number: 8811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3040240 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=201163239


   --row number: 8812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3062079 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=201866388


   --row number: 8813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3062079 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=201866389


   --row number: 8814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3062079 , [Content] ='50/50'
 WHERE id=201866390


   --row number: 8815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3071793 , [Content] ='137,400 / 168,250 / 199,100 / 230,050 / 261,000'
 WHERE id=203006699


   --row number: 8816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3056763 , [Content] ='1,546,500 / 1,894,500 / 2,242,500 / 2,590,450 / 2,938,400'
 WHERE id=203425608


   --row number: 8817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3056763 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=203425609


   --row number: 8818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3032489 , [Content] ='139,300 / 170,600 / 201,900 / 233,250 / 264,600'
 WHERE id=203153820


   --row number: 8819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3054948 , [Content] ='148,200 / 179,200 / 210,200 / 241,300 / 272,400'
 WHERE id=204615211


   --row number: 8820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3091112 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=204625684


   --row number: 8821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3091106 , [Content] ='84,400 / 98,300 / 112,200 / 126,100 / 140,000'
 WHERE id=204364202


   --row number: 8822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3079001 , [Content] ='90,400 / 105,300 / 120,200 / 135,200 / 150,200'
 WHERE id=205552346


   --row number: 8823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3079001 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=205552347


   --row number: 8824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3064774 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=205151619


   --row number: 8825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3094310 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=205178697


   --row number: 8826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3030968 , [Content] ='157,900 / 193,400 / 228,900 / 264,450 / 300,000'
 WHERE id=205519097


   --row number: 8827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3012725 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=205361076


   --row number: 8828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3030968 , [Content] ='126,300 / 154,700 / 183,100 / 211,550 / 240,000'
 WHERE id=205519098


   --row number: 8829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3067330 , [Content] ='81,700 / 93,400 / 105,100 / 116,750 / 128,400'
 WHERE id=205579937


   --row number: 8830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2990351 , [Content] ='10/05/18'
 WHERE id=205851966


   --row number: 8831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2990351 , [Content] ='144,500 / 157,250 / 170,000 / 182,750 / 195,500'
 WHERE id=205851967


   --row number: 8832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2990351 , [Content] ='72,250 / 78,625 / 85,000 / 91,375 / 97,750'
 WHERE id=205851968


   --row number: 8833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2990351 , [Content] ='EUR'
 WHERE id=205851971


   --row number: 8834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3097698 , [Content] ='AMS'
 WHERE id=192567987


   --row number: 8835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3097698 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192567988


   --row number: 8836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3097698 , [Content] ='Engineering'
 WHERE id=192567989


   --row number: 8837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3097698 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192567990


   --row number: 8838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3097698 , [Content] ='Software'
 WHERE id=192567991


   --row number: 8839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3097698 , [Content] ='IC3'
 WHERE id=192567992


   --row number: 8840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3097698 , [Content] ='USD'
 WHERE id=192567994


   --row number: 8841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3097698 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=192567995


   --row number: 8842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3097698 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=192567996


   --row number: 8843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3097698 , [Content] ='15%'
 WHERE id=192567997


   --row number: 8844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3097698 , [Content] ='Yes'
 WHERE id=192567998


   --row number: 8845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3097698 , [Content] ='EXEMPT'
 WHERE id=192567999


   --row number: 8846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3097698 , [Content] ='NO'
 WHERE id=192568000


   --row number: 8847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3097698 , [Content] ='2 - Professionals'
 WHERE id=192568001


   --row number: 8848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3097698 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192568002


   --row number: 8849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3097698 , [Content] ='Technical'
 WHERE id=192568003


   --row number: 8850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3097698 , [Content] ='7/20/2018'
 WHERE id=192568004


   --row number: 8851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3097830 , [Content] ='NO'
 WHERE id=192578687


   --row number: 8852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3097830 , [Content] ='4 - Sales Workers'
 WHERE id=192578688


   --row number: 8853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3097830 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192578689


   --row number: 8854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3097830 , [Content] ='Technical'
 WHERE id=192578690


   --row number: 8855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3097830 , [Content] ='7/20/2018'
 WHERE id=192578691


   --row number: 8856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3097830 , [Content] ='S1414 US - MRKT 1'
 WHERE id=192578671


   --row number: 8857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3097830 , [Content] ='US - MRKT 1'
 WHERE id=192578672


   --row number: 8858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3097830 , [Content] ='AMS'
 WHERE id=192578673


   --row number: 8859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3097830 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192578674


   --row number: 8860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3097830 , [Content] ='Solution Consulting'
 WHERE id=192578675


   --row number: 8861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3097830 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=192578676


   --row number: 8862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3097830 , [Content] ='Solution Consultant Core'
 WHERE id=192578677


   --row number: 8863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3097830 , [Content] ='IC4'
 WHERE id=192578678


   --row number: 8864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3097830 , [Content] ='USD'
 WHERE id=192578680


   --row number: 8865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3097830 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=192578681


   --row number: 8866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3097830 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=192578682


   --row number: 8867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3097830 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=192578683


   --row number: 8868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3097830 , [Content] ='75/25'
 WHERE id=192578684


   --row number: 8869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3097830 , [Content] ='Yes'
 WHERE id=192578685


   --row number: 8870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3097830 , [Content] ='EXEMPT'
 WHERE id=192578686


   --row number: 8871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3097915 , [Content] ='4 - Sales Workers'
 WHERE id=192587065


   --row number: 8872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3097915 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192587066


   --row number: 8873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3097915 , [Content] ='Technical'
 WHERE id=192587067


   --row number: 8874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3097915 , [Content] ='7/20/2018'
 WHERE id=192587068


   --row number: 8875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3097915 , [Content] ='S1411 US - MRKT 2'
 WHERE id=192587048


   --row number: 8876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3097915 , [Content] ='US - MRKT 2'
 WHERE id=192587049


   --row number: 8877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3097915 , [Content] ='AMS'
 WHERE id=192587050


   --row number: 8878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3097915 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192587051


   --row number: 8879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3097915 , [Content] ='Solution Consulting'
 WHERE id=192587052


   --row number: 8880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3097915 , [Content] ='S1411 - Assoc Solution Consultant IC1'
 WHERE id=192587053


   --row number: 8881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3097915 , [Content] ='Solution Consultant Core'
 WHERE id=192587054


   --row number: 8882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3097915 , [Content] ='IC1'
 WHERE id=192587055


   --row number: 8883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3097915 , [Content] ='USD'
 WHERE id=192587057


   --row number: 8884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3097915 , [Content] ='63,750 / 69,375 / 75,000 / 80,625 / 86,250'
 WHERE id=192587058


   --row number: 8885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3097915 , [Content] ='24,600 / 29,100 / 33,600 / 38,400 / 43,200'
 WHERE id=192587059


   --row number: 8886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3097915 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=192587060


   --row number: 8887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3097915 , [Content] ='75/25'
 WHERE id=192587061


   --row number: 8888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3097915 , [Content] ='Yes'
 WHERE id=192587062


   --row number: 8889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3097915 , [Content] ='EXEMPT'
 WHERE id=192587063


   --row number: 8890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3097915 , [Content] ='NO'
 WHERE id=192587064


   --row number: 8891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3097918 , [Content] ='4 - Sales Workers'
 WHERE id=192587432


   --row number: 8892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3097918 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192587433


   --row number: 8893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3097918 , [Content] ='Technical'
 WHERE id=192587434


   --row number: 8894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3097918 , [Content] ='7/20/2018'
 WHERE id=192587435


   --row number: 8895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3097918 , [Content] ='S1411 US - MRKT 2'
 WHERE id=192587415


   --row number: 8896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3097918 , [Content] ='US - MRKT 2'
 WHERE id=192587416


   --row number: 8897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3097918 , [Content] ='AMS'
 WHERE id=192587417


   --row number: 8898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3097918 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192587418


   --row number: 8899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3097918 , [Content] ='Solution Consulting'
 WHERE id=192587419


   --row number: 8900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3097918 , [Content] ='S1411 - Assoc Solution Consultant IC1'
 WHERE id=192587420


   --row number: 8901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3097918 , [Content] ='Solution Consultant Core'
 WHERE id=192587421


   --row number: 8902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3097918 , [Content] ='IC1'
 WHERE id=192587422


   --row number: 8903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3097918 , [Content] ='USD'
 WHERE id=192587424


   --row number: 8904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3097918 , [Content] ='63,750 / 69,375 / 75,000 / 80,625 / 86,250'
 WHERE id=192587425


   --row number: 8905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3097918 , [Content] ='24,600 / 29,100 / 33,600 / 38,400 / 43,200'
 WHERE id=192587426


   --row number: 8906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3097918 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=192587427


   --row number: 8907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3097918 , [Content] ='75/25'
 WHERE id=192587428


   --row number: 8908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3097918 , [Content] ='Yes'
 WHERE id=192587429


   --row number: 8909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3097918 , [Content] ='EXEMPT'
 WHERE id=192587430


   --row number: 8910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3097918 , [Content] ='NO'
 WHERE id=192587431


   --row number: 8911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3098523 , [Content] ='8742-Salespersons - Outside'
 WHERE id=192646246


   --row number: 8912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3098523 , [Content] ='Technical'
 WHERE id=192646247


   --row number: 8913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3098523 , [Content] ='7/20/2018'
 WHERE id=192646248


   --row number: 8914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3098523 , [Content] ='S1411 JPN'
 WHERE id=192646230


   --row number: 8915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3098523 , [Content] ='JPN'
 WHERE id=192646231


   --row number: 8916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3098523 , [Content] ='APAC'
 WHERE id=192646232


   --row number: 8917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3098523 , [Content] ='JAPAN'
 WHERE id=192646233


   --row number: 8918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3098523 , [Content] ='Solution Consulting'
 WHERE id=192646234


   --row number: 8919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3098523 , [Content] ='S1411 - Assoc Solution Consultant IC1'
 WHERE id=192646235


   --row number: 8920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3098523 , [Content] ='Solution Consultant Core'
 WHERE id=192646236


   --row number: 8921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3098523 , [Content] ='IC1'
 WHERE id=192646237


   --row number: 8922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3098523 , [Content] ='JPY'
 WHERE id=192646239


   --row number: 8923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3098523 , [Content] ='4,271,250 / 4,648,125 / 5,025,000 / 5,401,875 / 5,778,750'
 WHERE id=192646240


   --row number: 8924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3098523 , [Content] ='13,200 / 18,600 / 24,000 / 29,400 / 34,800'
 WHERE id=192646241


   --row number: 8925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3098523 , [Content] ='5,695,000 / 6,197,500 / 6,700,000 / 7,202,500 / 7,705,000'
 WHERE id=192646242


   --row number: 8926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3098523 , [Content] ='75/25'
 WHERE id=192646243


   --row number: 8927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3098523 , [Content] ='Yes'
 WHERE id=192646244


   --row number: 8928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3098523 , [Content] ='4 - Sales Workers'
 WHERE id=192646245


   --row number: 8929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3098682 , [Content] ='5182 IND'
 WHERE id=192659957


   --row number: 8930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3098682 , [Content] ='IND'
 WHERE id=192659958


   --row number: 8931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3098682 , [Content] ='APAC'
 WHERE id=192659959


   --row number: 8932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3098682 , [Content] ='INDIA'
 WHERE id=192659960


   --row number: 8933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3098682 , [Content] ='Engineering'
 WHERE id=192659961


   --row number: 8934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3098682 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=192659962


   --row number: 8935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3098682 , [Content] ='Quality'
 WHERE id=192659963


   --row number: 8936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3098682 , [Content] ='IC2'
 WHERE id=192659964


   --row number: 8937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3098682 , [Content] ='INR'
 WHERE id=192659966


   --row number: 8938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3098682 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=192659967


   --row number: 8939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3098682 , [Content] ='10%'
 WHERE id=192659968


   --row number: 8940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3098682 , [Content] ='No'
 WHERE id=192659969


   --row number: 8941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3098682 , [Content] ='2 - Professionals'
 WHERE id=192659970


   --row number: 8942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3098682 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192659971


   --row number: 8943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3098682 , [Content] ='Technical'
 WHERE id=192659972


   --row number: 8944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3098682 , [Content] ='7/20/2018'
 WHERE id=192659973


   --row number: 8945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099307 , [Content] ='09/05/18'
 WHERE id=192703049


   --row number: 8946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099307 , [Content] ='5143 IND'
 WHERE id=192703033


   --row number: 8947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099307 , [Content] ='IND'
 WHERE id=192703034


   --row number: 8948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099307 , [Content] ='APAC'
 WHERE id=192703035


   --row number: 8949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099307 , [Content] ='INDIA'
 WHERE id=192703036


   --row number: 8950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099307 , [Content] ='Engineering'
 WHERE id=192703037


   --row number: 8951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099307 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192703038


   --row number: 8952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099307 , [Content] ='Software'
 WHERE id=192703039


   --row number: 8953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099307 , [Content] ='IC3'
 WHERE id=192703040


   --row number: 8954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099307 , [Content] ='INR'
 WHERE id=192703042


   --row number: 8955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099307 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=192703043


   --row number: 8956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099307 , [Content] ='15%'
 WHERE id=192703044


   --row number: 8957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099307 , [Content] ='Yes'
 WHERE id=192703045


   --row number: 8958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099307 , [Content] ='2 - Professionals'
 WHERE id=192703046


   --row number: 8959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099307 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192703047


   --row number: 8960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099307 , [Content] ='Technical'
 WHERE id=192703048


   --row number: 8961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099319 , [Content] ='7/20/2018'
 WHERE id=192704380


   --row number: 8962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099319 , [Content] ='5142 IND'
 WHERE id=192704364


   --row number: 8963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099319 , [Content] ='IND'
 WHERE id=192704365


   --row number: 8964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099319 , [Content] ='APAC'
 WHERE id=192704366


   --row number: 8965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099319 , [Content] ='INDIA'
 WHERE id=192704367


   --row number: 8966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099319 , [Content] ='Engineering'
 WHERE id=192704368


   --row number: 8967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099319 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192704369


   --row number: 8968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099319 , [Content] ='Software'
 WHERE id=192704370


   --row number: 8969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099319 , [Content] ='IC2'
 WHERE id=192704371


   --row number: 8970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099319 , [Content] ='INR'
 WHERE id=192704373


   --row number: 8971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099319 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192704374


   --row number: 8972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099319 , [Content] ='10%'
 WHERE id=192704375


   --row number: 8973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099319 , [Content] ='No'
 WHERE id=192704376


   --row number: 8974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099319 , [Content] ='2 - Professionals'
 WHERE id=192704377


   --row number: 8975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099319 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192704378


   --row number: 8976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099319 , [Content] ='Technical'
 WHERE id=192704379


   --row number: 8977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099323 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192704625


   --row number: 8978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099323 , [Content] ='Technical'
 WHERE id=192704626


   --row number: 8979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099323 , [Content] ='7/20/2018'
 WHERE id=192704627


   --row number: 8980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099323 , [Content] ='3495 US - MRKT 1'
 WHERE id=192704608


   --row number: 8981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099323 , [Content] ='US - MRKT 1'
 WHERE id=192704609


   --row number: 8982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099323 , [Content] ='AMS'
 WHERE id=192704610


   --row number: 8983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099323 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192704611


   --row number: 8984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099323 , [Content] ='Info Systems/Technology'
 WHERE id=192704612


   --row number: 8985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099323 , [Content] ='3495 - Dir, Applications Development Mgmt M5'
 WHERE id=192704613


   --row number: 8986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099323 , [Content] ='Enterprise Applications'
 WHERE id=192704614


   --row number: 8987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099323 , [Content] ='M5'
 WHERE id=192704615


   --row number: 8988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099323 , [Content] ='USD'
 WHERE id=192704617


   --row number: 8989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099323 , [Content] ='134,100 / 164,300 / 194,500 / 224,650 / 254,800'
 WHERE id=192704618


   --row number: 8990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3099323 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=192704619


   --row number: 8991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099323 , [Content] ='25%'
 WHERE id=192704620


   --row number: 8992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099323 , [Content] ='Yes'
 WHERE id=192704621


   --row number: 8993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3099323 , [Content] ='EXEMPT'
 WHERE id=192704622


   --row number: 8994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3099323 , [Content] ='NO'
 WHERE id=192704623


   --row number: 8995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099323 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=192704624


   --row number: 8996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099333 , [Content] ='10/05/18'
 WHERE id=192705144


   --row number: 8997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099333 , [Content] ='5143 IND'
 WHERE id=192705128


   --row number: 8998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099333 , [Content] ='IND'
 WHERE id=192705129


   --row number: 8999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099333 , [Content] ='APAC'
 WHERE id=192705130


   --row number: 9000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099333 , [Content] ='INDIA'
 WHERE id=192705131

