
--Total 3000




   --row number: 3001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2903851 , [Content] ='JAPAN'
 WHERE id=173123149


   --row number: 3002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2903851 , [Content] ='Solution Consulting'
 WHERE id=173123150


   --row number: 3003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2904889 , [Content] ='8810-Clerical Office Employees'
 WHERE id=173226903


   --row number: 3004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2904889 , [Content] ='Technical'
 WHERE id=173226904


   --row number: 3005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2904889 , [Content] ='04/05/18'
 WHERE id=173226905


   --row number: 3006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2904889 , [Content] ='5224 US - MRKT 2'
 WHERE id=173226886


   --row number: 3007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2904889 , [Content] ='US - MRKT 2'
 WHERE id=173226887


   --row number: 3008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2904889 , [Content] ='AMS'
 WHERE id=173226888


   --row number: 3009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2904889 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=173226889


   --row number: 3010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2904889 , [Content] ='Engineering'
 WHERE id=173226890


   --row number: 3011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2904889 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=173226891


   --row number: 3012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2904889 , [Content] ='Product Mgmt Mgr'
 WHERE id=173226892


   --row number: 3013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2904889 , [Content] ='IC4'
 WHERE id=173226893


   --row number: 3014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2904889 , [Content] ='USD'
 WHERE id=173226895


   --row number: 3015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2904889 , [Content] ='101,800 / 123,150 / 144,500 / 165,800 / 187,100'
 WHERE id=173226896


   --row number: 3016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2904889 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=173226897


   --row number: 3017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2904889 , [Content] ='20%'
 WHERE id=173226898


   --row number: 3018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2904889 , [Content] ='Yes'
 WHERE id=173226899


   --row number: 3019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2904889 , [Content] ='EXEMPT'
 WHERE id=173226900


   --row number: 3020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2904889 , [Content] ='NO'
 WHERE id=173226901


   --row number: 3021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2904889 , [Content] ='2 - Professionals'
 WHERE id=173226902


   --row number: 3022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2905525 , [Content] ='2 - Professionals'
 WHERE id=173276500


   --row number: 3023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2905525 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=173276501


   --row number: 3024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2905525 , [Content] ='Technical'
 WHERE id=173276502


   --row number: 3025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2905525 , [Content] ='04/05/18'
 WHERE id=173276503


   --row number: 3026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2905525 , [Content] ='5206 US - MRKT 2'
 WHERE id=173276484


   --row number: 3027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2905525 , [Content] ='US - MRKT 2'
 WHERE id=173276485


   --row number: 3028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2905525 , [Content] ='AMS'
 WHERE id=173276486


   --row number: 3029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2905525 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=173276487


   --row number: 3030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2905525 , [Content] ='Engineering'
 WHERE id=173276488


   --row number: 3031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2905525 , [Content] ='5206 - Principal Systems Design Engineer IC6'
 WHERE id=173276489


   --row number: 3032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2905525 , [Content] ='Systems Design'
 WHERE id=173276490


   --row number: 3033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2905525 , [Content] ='IC6'
 WHERE id=173276491


   --row number: 3034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2905525 , [Content] ='USD'
 WHERE id=173276493


   --row number: 3035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2905525 , [Content] ='142,600 / 174,650 / 206,700 / 238,800 / 270,900'
 WHERE id=173276494


   --row number: 3036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2905525 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=173276495


   --row number: 3037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2905525 , [Content] ='25%'
 WHERE id=173276496


   --row number: 3038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2905525 , [Content] ='Yes'
 WHERE id=173276497


   --row number: 3039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2905525 , [Content] ='EXEMPT'
 WHERE id=173276498


   --row number: 3040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2905525 , [Content] ='NO'
 WHERE id=173276499


   --row number: 3041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2906077 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=173340432


   --row number: 3042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2906077 , [Content] ='20%'
 WHERE id=173340433


   --row number: 3043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2906077 , [Content] ='Yes'
 WHERE id=173340434


   --row number: 3044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2906077 , [Content] ='2 - Professionals'
 WHERE id=173340435


   --row number: 3045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2906077 , [Content] ='8810-Clerical Office Employees'
 WHERE id=173340436


   --row number: 3046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2906077 , [Content] ='Technical'
 WHERE id=173340437


   --row number: 3047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2906077 , [Content] ='7/20/18'
 WHERE id=173340438


   --row number: 3048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2906077 , [Content] ='5224 IND'
 WHERE id=173340421


   --row number: 3049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2906077 , [Content] ='IND'
 WHERE id=173340422


   --row number: 3050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2906077 , [Content] ='APAC'
 WHERE id=173340423


   --row number: 3051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2906077 , [Content] ='INDIA'
 WHERE id=173340424


   --row number: 3052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2906077 , [Content] ='Engineering'
 WHERE id=173340425


   --row number: 3053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2906077 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=173340426


   --row number: 3054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2906077 , [Content] ='Product Mgmt Mgr'
 WHERE id=173340427


   --row number: 3055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2906077 , [Content] ='IC4'
 WHERE id=173340428


   --row number: 3056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2906077 , [Content] ='INR'
 WHERE id=173340430


   --row number: 3057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2906077 , [Content] ='2,310,300 / 2,830,150 / 3,350,000 / 3,869,800 / 4,389,600'
 WHERE id=173340431


   --row number: 3058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2906098 , [Content] ='5225 IND'
 WHERE id=173340826


   --row number: 3059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2906098 , [Content] ='IND'
 WHERE id=173340827


   --row number: 3060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2906098 , [Content] ='APAC'
 WHERE id=173340828


   --row number: 3061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2906098 , [Content] ='INDIA'
 WHERE id=173340829


   --row number: 3062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2906098 , [Content] ='Engineering'
 WHERE id=173340830


   --row number: 3063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2906098 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=173340831


   --row number: 3064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2906098 , [Content] ='Product Mgmt Mgr'
 WHERE id=173340832


   --row number: 3065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2906098 , [Content] ='IC5'
 WHERE id=173340833


   --row number: 3066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2906098 , [Content] ='INR'
 WHERE id=173340835


   --row number: 3067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2906098 , [Content] ='2,917,200 / 3,573,600 / 4,230,000 / 4,886,350 / 5,542,700'
 WHERE id=173340836


   --row number: 3068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2906098 , [Content] ='117,000 / 163,500 / 210,000 / 256,500 / 303,000'
 WHERE id=173340837


   --row number: 3069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2906098 , [Content] ='25%'
 WHERE id=173340838


   --row number: 3070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2906098 , [Content] ='Yes'
 WHERE id=173340839


   --row number: 3071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2906098 , [Content] ='2 - Professionals'
 WHERE id=173340840


   --row number: 3072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2906098 , [Content] ='8810-Clerical Office Employees'
 WHERE id=173340841


   --row number: 3073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2906098 , [Content] ='Technical'
 WHERE id=173340842


   --row number: 3074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2906098 , [Content] ='6/27/2018'
 WHERE id=173340843


   --row number: 3075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2908003 , [Content] ='75/25'
 WHERE id=173412358


   --row number: 3076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2908003 , [Content] ='4 - Sales Workers'
 WHERE id=173412362


   --row number: 3077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2908003 , [Content] ='8742-Salespersons - Outside'
 WHERE id=173412363


   --row number: 3078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2908003 , [Content] ='Technical'
 WHERE id=173412364


   --row number: 3079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2908003 , [Content] ='10/05/18'
 WHERE id=173412365


   --row number: 3080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2908003 , [Content] ='Yes'
 WHERE id=173412359


   --row number: 3081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2908003 , [Content] ='S1415A US - MRKT 2'
 WHERE id=173412345


   --row number: 3082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2908003 , [Content] ='US - MRKT 2'
 WHERE id=173412346


   --row number: 3083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2908003 , [Content] ='AMS'
 WHERE id=173412347


   --row number: 3084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2908003 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=173412348


   --row number: 3085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2908003 , [Content] ='Solution Consulting'
 WHERE id=173412349


   --row number: 3086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2908003 , [Content] ='S1415A - Sr Advisory Solution Architect IC5'
 WHERE id=173412350


   --row number: 3087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2908003 , [Content] ='Solution Consultant Architect'
 WHERE id=173412351


   --row number: 3088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2908003 , [Content] ='IC5'
 WHERE id=173412352


   --row number: 3089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2908003 , [Content] ='USD'
 WHERE id=173412354


   --row number: 3090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2908003 , [Content] ='147,900 / 160,950 / 174,000 / 187,050 / 200,100'
 WHERE id=173412355


   --row number: 3091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2908003 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=173412356


   --row number: 3092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2908003 , [Content] ='197,200 / 214,600 / 232,000 / 249,400 / 266,800'
 WHERE id=173412357


   --row number: 3093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2908003 , [Content] ='EXEMPT'
 WHERE id=173412360


   --row number: 3094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2908003 , [Content] ='NO'
 WHERE id=173412361


   --row number: 3095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2913663 , [Content] ='8810-Clerical Office Employees'
 WHERE id=173966322


   --row number: 3096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2913663 , [Content] ='Technical'
 WHERE id=173966323


   --row number: 3097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2913663 , [Content] ='04/05/18'
 WHERE id=173966324


   --row number: 3098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2913663 , [Content] ='5705 US - MRKT 3'
 WHERE id=173966306


   --row number: 3099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2913663 , [Content] ='US - MRKT 3'
 WHERE id=173966307


   --row number: 3100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2913663 , [Content] ='AMS'
 WHERE id=173966308


   --row number: 3101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2913663 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=173966309


   --row number: 3102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2913663 , [Content] ='Professional Services'
 WHERE id=173966310


   --row number: 3103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2913663 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=173966311


   --row number: 3104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2913663 , [Content] ='Partner Support'
 WHERE id=173966312


   --row number: 3105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2913663 , [Content] ='IC5'
 WHERE id=173966313


   --row number: 3106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2913663 , [Content] ='USD'
 WHERE id=173966315


   --row number: 3107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2913663 , [Content] ='93,300 / 114,300 / 135,300 / 156,300 / 177,300'
 WHERE id=173966316


   --row number: 3108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2913663 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=173966317


   --row number: 3109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2913663 , [Content] ='25%'
 WHERE id=173966318


   --row number: 3110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2913663 , [Content] ='Yes'
 WHERE id=173966319


   --row number: 3111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2913663 , [Content] ='EXEMPT'
 WHERE id=173966320


   --row number: 3112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2913663 , [Content] ='2 - Professionals'
 WHERE id=173966321


   --row number: 3113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2914189 , [Content] ='Non Technical'
 WHERE id=174033624


   --row number: 3114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2914189 , [Content] ='04/05/18'
 WHERE id=174033625


   --row number: 3115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2914189 , [Content] ='23,970 / 26,085 / 28,200 / 30,315 / 32,430'
 WHERE id=174033618


   --row number: 3116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2914189 , [Content] ='39,950 / 43,475 / 47,000 / 50,525 / 54,050'
 WHERE id=174033619


   --row number: 3117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2914189 , [Content] ='60/40'
 WHERE id=174033620


   --row number: 3118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2914189 , [Content] ='No'
 WHERE id=174033621


   --row number: 3119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2914189 , [Content] ='4 - Sales Workers'
 WHERE id=174033622


   --row number: 3120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2914189 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174033623


   --row number: 3121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2914189 , [Content] ='S1332 UK'
 WHERE id=174033608


   --row number: 3122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2914189 , [Content] ='UK'
 WHERE id=174033609


   --row number: 3123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2914189 , [Content] ='EMEA'
 WHERE id=174033610


   --row number: 3124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2914189 , [Content] ='UNITED KINGDOM'
 WHERE id=174033611


   --row number: 3125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2914189 , [Content] ='Sales'
 WHERE id=174033612


   --row number: 3126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2914189 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=174033613


   --row number: 3127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2914189 , [Content] ='Inside Sales'
 WHERE id=174033614


   --row number: 3128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2914189 , [Content] ='A2'
 WHERE id=174033615


   --row number: 3129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2914189 , [Content] ='GBP'
 WHERE id=174033617


   --row number: 3130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2914241 , [Content] ='6102 NLD'
 WHERE id=174036090


   --row number: 3131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2914241 , [Content] ='NLD'
 WHERE id=174036091


   --row number: 3132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2914241 , [Content] ='EMEA'
 WHERE id=174036092


   --row number: 3133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2914241 , [Content] ='NETHERLANDS'
 WHERE id=174036093


   --row number: 3134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2914241 , [Content] ='Finance'
 WHERE id=174036094


   --row number: 3135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2914241 , [Content] ='6102 - Accountant IC2'
 WHERE id=174036095


   --row number: 3136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2914241 , [Content] ='Accounting'
 WHERE id=174036096


   --row number: 3137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2914241 , [Content] ='IC2'
 WHERE id=174036097


   --row number: 3138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2914241 , [Content] ='EUR'
 WHERE id=174036099


   --row number: 3139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2914241 , [Content] ='35,400 / 40,450 / 45,500 / 50,550 / 55,600'
 WHERE id=174036100


   --row number: 3140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2914241 , [Content] ='10%'
 WHERE id=174036101


   --row number: 3141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2914241 , [Content] ='No'
 WHERE id=174036102


   --row number: 3142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2914241 , [Content] ='2 - Professionals'
 WHERE id=174036103


   --row number: 3143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2914241 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174036104


   --row number: 3144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2914241 , [Content] ='Non Technical'
 WHERE id=174036105


   --row number: 3145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2914241 , [Content] ='04/05/18'
 WHERE id=174036106


   --row number: 3146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2915858 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174166485


   --row number: 3147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2915858 , [Content] ='Non Technical'
 WHERE id=174166486


   --row number: 3148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2915858 , [Content] ='7/20/18'
 WHERE id=174166487


   --row number: 3149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2915858 , [Content] ='5516 US - MRKT 1'
 WHERE id=174166467


   --row number: 3150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2915858 , [Content] ='US - MRKT 1'
 WHERE id=174166468


   --row number: 3151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2915858 , [Content] ='AMS'
 WHERE id=174166469


   --row number: 3152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2915858 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=174166470


   --row number: 3153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2915858 , [Content] ='Marketing'
 WHERE id=174166472


   --row number: 3154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2915858 , [Content] ='5516 - Public Relations Mgr IC6'
 WHERE id=174166473


   --row number: 3155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2915858 , [Content] ='Public Relations'
 WHERE id=174166474


   --row number: 3156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2915858 , [Content] ='IC6'
 WHERE id=174166475


   --row number: 3157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2915858 , [Content] ='USD'
 WHERE id=174166477


   --row number: 3158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2915858 , [Content] ='142,100 / 174,050 / 206,000 / 238,000 / 270,000'
 WHERE id=174166478


   --row number: 3159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2915858 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=174166479


   --row number: 3160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2915858 , [Content] ='25%'
 WHERE id=174166480


   --row number: 3161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2915858 , [Content] ='Yes'
 WHERE id=174166481


   --row number: 3162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2915858 , [Content] ='EXEMPT'
 WHERE id=174166482


   --row number: 3163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2915858 , [Content] ='NO'
 WHERE id=174166483


   --row number: 3164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2915858 , [Content] ='2 - Professionals'
 WHERE id=174166484


   --row number: 3165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2915903 , [Content] ='6464 US - MRKT 1'
 WHERE id=174172348


   --row number: 3166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2915903 , [Content] ='US - MRKT 1'
 WHERE id=174172349


   --row number: 3167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2915903 , [Content] ='AMS'
 WHERE id=174172350


   --row number: 3168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2915903 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=174172351


   --row number: 3169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2915903 , [Content] ='Info Systems/Technology'
 WHERE id=174172352


   --row number: 3170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2915903 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=174172353


   --row number: 3171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2915903 , [Content] ='Business Systems Analysis'
 WHERE id=174172354


   --row number: 3172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2915903 , [Content] ='IC4'
 WHERE id=174172355


   --row number: 3173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2915903 , [Content] ='04/05/18'
 WHERE id=174172367


   --row number: 3174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2915903 , [Content] ='USD'
 WHERE id=174172357


   --row number: 3175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2915903 , [Content] ='104,200 / 122,950 / 141,700 / 160,450 / 179,200'
 WHERE id=174172358


   --row number: 3176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2915903 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=174172359


   --row number: 3177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2915903 , [Content] ='15%'
 WHERE id=174172360


   --row number: 3178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2915903 , [Content] ='Yes'
 WHERE id=174172361


   --row number: 3179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2915903 , [Content] ='EXEMPT'
 WHERE id=174172362


   --row number: 3180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2915903 , [Content] ='NO'
 WHERE id=174172363


   --row number: 3181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2915903 , [Content] ='2 - Professionals'
 WHERE id=174172364


   --row number: 3182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2915903 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174172365


   --row number: 3183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2915903 , [Content] ='Technical'
 WHERE id=174172366


   --row number: 3184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2915925 , [Content] ='6102 - Accountant IC2'
 WHERE id=174176863


   --row number: 3185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2915925 , [Content] ='Accounting'
 WHERE id=174176864


   --row number: 3186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2915925 , [Content] ='IC2'
 WHERE id=174176865


   --row number: 3187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2915925 , [Content] ='6102 SGP'
 WHERE id=174176858


   --row number: 3188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2915925 , [Content] ='SGP'
 WHERE id=174176859


   --row number: 3189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2915925 , [Content] ='APAC'
 WHERE id=174176860


   --row number: 3190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2915925 , [Content] ='SINGAPORE'
 WHERE id=174176861


   --row number: 3191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2915925 , [Content] ='Finance'
 WHERE id=174176862


   --row number: 3192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2915925 , [Content] ='SGD'
 WHERE id=174176867


   --row number: 3193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2915925 , [Content] ='19,200 / 26,400 / 33,600 / 40,800 / 48,000'
 WHERE id=174176868


   --row number: 3194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2915925 , [Content] ='10%'
 WHERE id=174176869


   --row number: 3195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2915925 , [Content] ='Yes'
 WHERE id=174176870


   --row number: 3196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2915925 , [Content] ='2 - Professionals'
 WHERE id=174176871


   --row number: 3197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2915925 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174176872


   --row number: 3198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2915925 , [Content] ='Non Technical'
 WHERE id=174176873


   --row number: 3199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2915925 , [Content] ='5/22/2018'
 WHERE id=174176874


   --row number: 3200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2915928 , [Content] ='9999 AUS'
 WHERE id=174177592


   --row number: 3201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2915928 , [Content] ='AUS'
 WHERE id=174177593


   --row number: 3202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2915928 , [Content] ='APAC'
 WHERE id=174177594


   --row number: 3203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2915928 , [Content] ='Australia'
 WHERE id=174177595


   --row number: 3204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2915928 , [Content] ='9999 - Intern'
 WHERE id=174177596


   --row number: 3205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2915928 , [Content] ='AUD'
 WHERE id=174177597


   --row number: 3206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2915928 , [Content] ='No'
 WHERE id=174177598


   --row number: 3207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2915928 , [Content] ='04/05/18'
 WHERE id=174177599


   --row number: 3208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2916289 , [Content] ='9999 DEU'
 WHERE id=174225531


   --row number: 3209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2916289 , [Content] ='DEU'
 WHERE id=174225532


   --row number: 3210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2916289 , [Content] ='EMEA'
 WHERE id=174225533


   --row number: 3211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2916289 , [Content] ='Germany'
 WHERE id=174225534


   --row number: 3212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2916289 , [Content] ='9999 - Intern'
 WHERE id=174225535


   --row number: 3213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2916289 , [Content] ='EUR'
 WHERE id=174225536


   --row number: 3214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2916289 , [Content] ='No'
 WHERE id=174225537


   --row number: 3215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2916289 , [Content] ='04/05/18'
 WHERE id=174225538


   --row number: 3216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2916288 , [Content] ='9999 DEU'
 WHERE id=174225499


   --row number: 3217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2916288 , [Content] ='DEU'
 WHERE id=174225500


   --row number: 3218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2916288 , [Content] ='EMEA'
 WHERE id=174225501


   --row number: 3219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2916288 , [Content] ='Germany'
 WHERE id=174225502


   --row number: 3220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2916288 , [Content] ='9999 - Intern'
 WHERE id=174225503


   --row number: 3221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2916288 , [Content] ='EUR'
 WHERE id=174225504


   --row number: 3222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2916288 , [Content] ='No'
 WHERE id=174225505


   --row number: 3223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2916288 , [Content] ='04/05/18'
 WHERE id=174225506


   --row number: 3224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2916317 , [Content] ='2506 FRA'
 WHERE id=174226807


   --row number: 3225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2916317 , [Content] ='FRA'
 WHERE id=174226808


   --row number: 3226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2916317 , [Content] ='EMEA'
 WHERE id=174226809


   --row number: 3227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2916317 , [Content] ='FRANCE'
 WHERE id=174226810


   --row number: 3228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2916317 , [Content] ='Marketing'
 WHERE id=174226811


   --row number: 3229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2916317 , [Content] ='2506 - Sr Dir, Marketing Mgmt M6'
 WHERE id=174226812


   --row number: 3230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2916317 , [Content] ='Marketing'
 WHERE id=174226813


   --row number: 3231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2916317 , [Content] ='M6'
 WHERE id=174226814


   --row number: 3232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2916317 , [Content] ='EUR'
 WHERE id=174226816


   --row number: 3233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2916317 , [Content] ='30%'
 WHERE id=174226817


   --row number: 3234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2916317 , [Content] ='No'
 WHERE id=174226818


   --row number: 3235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2916317 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=174226819


   --row number: 3236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2916317 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174226820


   --row number: 3237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2916317 , [Content] ='Non Technical'
 WHERE id=174226821


   --row number: 3238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2916317 , [Content] ='04/05/18'
 WHERE id=174226823


   --row number: 3239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2916333 , [Content] ='2506 ESP'
 WHERE id=174227433


   --row number: 3240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2916333 , [Content] ='ESP'
 WHERE id=174227434


   --row number: 3241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2916333 , [Content] ='EMEA'
 WHERE id=174227435


   --row number: 3242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2916333 , [Content] ='SPAIN'
 WHERE id=174227436


   --row number: 3243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2916333 , [Content] ='Marketing'
 WHERE id=174227437


   --row number: 3244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2916333 , [Content] ='2506 - Sr Dir, Marketing Mgmt M6'
 WHERE id=174227438


   --row number: 3245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2916333 , [Content] ='Marketing'
 WHERE id=174227439


   --row number: 3246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2916333 , [Content] ='M6'
 WHERE id=174227440


   --row number: 3247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2916333 , [Content] ='EUR'
 WHERE id=174227442


   --row number: 3248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2916333 , [Content] ='150,000 / 225,000 / 300,000 / 375,000 / 450,000'
 WHERE id=174227443


   --row number: 3249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2916333 , [Content] ='30%'
 WHERE id=174227444


   --row number: 3250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2916333 , [Content] ='Yes'
 WHERE id=174227445


   --row number: 3251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2916333 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=174227446


   --row number: 3252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2916333 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174227447


   --row number: 3253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2916333 , [Content] ='Non Technical'
 WHERE id=174227448


   --row number: 3254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2916333 , [Content] ='04/05/18'
 WHERE id=174227450


   --row number: 3255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2917312 , [Content] ='5143 IND'
 WHERE id=174313937


   --row number: 3256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2917312 , [Content] ='IND'
 WHERE id=174313938


   --row number: 3257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2917312 , [Content] ='APAC'
 WHERE id=174313939


   --row number: 3258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2917312 , [Content] ='INDIA'
 WHERE id=174313940


   --row number: 3259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2917312 , [Content] ='Engineering'
 WHERE id=174313941


   --row number: 3260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2917312 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=174313942


   --row number: 3261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2917312 , [Content] ='Software'
 WHERE id=174313943


   --row number: 3262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2917312 , [Content] ='IC3'
 WHERE id=174313944


   --row number: 3263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2917312 , [Content] ='INR'
 WHERE id=174313946


   --row number: 3264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2917312 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=174313947


   --row number: 3265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2917312 , [Content] ='15%'
 WHERE id=174313948


   --row number: 3266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2917312 , [Content] ='Yes'
 WHERE id=174313949


   --row number: 3267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2917312 , [Content] ='2 - Professionals'
 WHERE id=174313950


   --row number: 3268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2917312 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=174313951


   --row number: 3269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2917312 , [Content] ='Technical'
 WHERE id=174313952


   --row number: 3270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2917312 , [Content] ='09/05/18'
 WHERE id=174313953


   --row number: 3271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2917597 , [Content] ='10/05/18'
 WHERE id=174339521


   --row number: 3272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2917597 , [Content] ='5595 US - MRKT 3'
 WHERE id=174339502


   --row number: 3273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2917597 , [Content] ='US - MRKT 3'
 WHERE id=174339503


   --row number: 3274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2917597 , [Content] ='AMS'
 WHERE id=174339504


   --row number: 3275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2917597 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=174339505


   --row number: 3276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2917597 , [Content] ='Marketing'
 WHERE id=174339506


   --row number: 3277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2917597 , [Content] ='5595 - Product Marketing Mgr IC5'
 WHERE id=174339507


   --row number: 3278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2917597 , [Content] ='Product Marketing'
 WHERE id=174339508


   --row number: 3279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2917597 , [Content] ='IC5'
 WHERE id=174339509


   --row number: 3280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2917597 , [Content] ='USD'
 WHERE id=174339511


   --row number: 3281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2917597 , [Content] ='99,900 / 122,350 / 144,800 / 167,300 / 189,800'
 WHERE id=174339512


   --row number: 3282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2917597 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=174339513


   --row number: 3283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2917597 , [Content] ='25%'
 WHERE id=174339514


   --row number: 3284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2917597 , [Content] ='Yes'
 WHERE id=174339515


   --row number: 3285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2917597 , [Content] ='EXEMPT'
 WHERE id=174339516


   --row number: 3286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2917597 , [Content] ='2 - Professionals'
 WHERE id=174339518


   --row number: 3287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2917597 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174339519


   --row number: 3288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2917597 , [Content] ='Technical'
 WHERE id=174339520


   --row number: 3289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2917615 , [Content] ='5823 US - MRKT 3'
 WHERE id=174340638


   --row number: 3290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2917615 , [Content] ='US - MRKT 3'
 WHERE id=174340639


   --row number: 3291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2917615 , [Content] ='AMS'
 WHERE id=174340640


   --row number: 3292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2917615 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=174340641


   --row number: 3293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2917615 , [Content] ='Customer Support'
 WHERE id=174340642


   --row number: 3294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2917615 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=174340643


   --row number: 3295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2917615 , [Content] ='Technical Support'
 WHERE id=174340644


   --row number: 3296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2917615 , [Content] ='IC3'
 WHERE id=174340645


   --row number: 3297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2917615 , [Content] ='USD'
 WHERE id=174340647


   --row number: 3298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2917615 , [Content] ='Technical'
 WHERE id=174340655


   --row number: 3299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2917615 , [Content] ='04/05/18'
 WHERE id=174340656


   --row number: 3300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2917615 , [Content] ='62,000 / 73,150 / 84,300 / 95,450 / 106,600'
 WHERE id=174340648


   --row number: 3301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2917615 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=174340649


   --row number: 3302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2917615 , [Content] ='15%'
 WHERE id=174340650


   --row number: 3303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2917615 , [Content] ='Yes'
 WHERE id=174340651


   --row number: 3304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2917615 , [Content] ='EXEMPT'
 WHERE id=174340652


   --row number: 3305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2917615 , [Content] ='2 - Professionals'
 WHERE id=174340653


   --row number: 3306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2917615 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174340654


   --row number: 3307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2920298 , [Content] ='6394 IRL'
 WHERE id=174682191


   --row number: 3308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2920296 , [Content] ='EUR'
 WHERE id=174682080


   --row number: 3309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2920296 , [Content] ='89,500 / 109,650 / 129,800 / 149,950 / 170,100'
 WHERE id=174682081


   --row number: 3310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2920296 , [Content] ='6394 NLD'
 WHERE id=174682071


   --row number: 3311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2920296 , [Content] ='NLD'
 WHERE id=174682072


   --row number: 3312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2920296 , [Content] ='EMEA'
 WHERE id=174682073


   --row number: 3313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2920296 , [Content] ='NETHERLANDS'
 WHERE id=174682074


   --row number: 3314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2920296 , [Content] ='Legal'
 WHERE id=174682075


   --row number: 3315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2920296 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=174682076


   --row number: 3316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2920296 , [Content] ='Legal Counsel'
 WHERE id=174682077


   --row number: 3317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2920296 , [Content] ='IC4'
 WHERE id=174682078


   --row number: 3318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2920296 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=174682082


   --row number: 3319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2920296 , [Content] ='25%'
 WHERE id=174682083


   --row number: 3320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2920296 , [Content] ='Yes'
 WHERE id=174682084


   --row number: 3321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2920296 , [Content] ='2 - Professionals'
 WHERE id=174682085


   --row number: 3322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2920296 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174682086


   --row number: 3323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2920296 , [Content] ='Non Technical'
 WHERE id=174682087


   --row number: 3324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2920296 , [Content] ='04/05/18'
 WHERE id=174682088


   --row number: 3325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2920298 , [Content] ='IRL'
 WHERE id=174682192


   --row number: 3326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2920298 , [Content] ='EMEA'
 WHERE id=174682193


   --row number: 3327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2920300 , [Content] ='UK'
 WHERE id=174683800


   --row number: 3328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2920300 , [Content] ='EMEA'
 WHERE id=174683801


   --row number: 3329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2920300 , [Content] ='UNITED KINGDOM'
 WHERE id=174683802


   --row number: 3330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2920300 , [Content] ='Legal'
 WHERE id=174683803


   --row number: 3331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2920300 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=174683804


   --row number: 3332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2920300 , [Content] ='Legal Counsel'
 WHERE id=174683805


   --row number: 3333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2920300 , [Content] ='IC4'
 WHERE id=174683806


   --row number: 3334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2920300 , [Content] ='GBP'
 WHERE id=174683808


   --row number: 3335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2920300 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=174683809


   --row number: 3336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2920300 , [Content] ='25%'
 WHERE id=174683810


   --row number: 3337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2920300 , [Content] ='Yes'
 WHERE id=174683811


   --row number: 3338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2920300 , [Content] ='2 - Professionals'
 WHERE id=174683812


   --row number: 3339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2920300 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174683813


   --row number: 3340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2920300 , [Content] ='Non Technical'
 WHERE id=174683814


   --row number: 3341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2920300 , [Content] ='04/05/18'
 WHERE id=174683815


   --row number: 3342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2920298 , [Content] ='IRELAND'
 WHERE id=174682194


   --row number: 3343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2920298 , [Content] ='Legal'
 WHERE id=174682195


   --row number: 3344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2920298 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=174682196


   --row number: 3345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2920298 , [Content] ='Legal Counsel'
 WHERE id=174682197


   --row number: 3346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2920298 , [Content] ='IC4'
 WHERE id=174682198


   --row number: 3347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2920298 , [Content] ='EUR'
 WHERE id=174682200


   --row number: 3348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2920298 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=174682201


   --row number: 3349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2920298 , [Content] ='25%'
 WHERE id=174682202


   --row number: 3350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2920298 , [Content] ='Yes'
 WHERE id=174682203


   --row number: 3351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2920298 , [Content] ='2 - Professionals'
 WHERE id=174682204


   --row number: 3352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2920298 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174682205


   --row number: 3353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2920298 , [Content] ='Non Technical'
 WHERE id=174682206


   --row number: 3354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2920298 , [Content] ='06/08/18'
 WHERE id=174682207


   --row number: 3355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2920300 , [Content] ='6394 UK'
 WHERE id=174683799


   --row number: 3356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2920334 , [Content] ='10%'
 WHERE id=174687217


   --row number: 3357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2920334 , [Content] ='No'
 WHERE id=174687218


   --row number: 3358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2920334 , [Content] ='2 - Professionals'
 WHERE id=174687219


   --row number: 3359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2920334 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174687220


   --row number: 3360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2920334 , [Content] ='Non Technical'
 WHERE id=174687221


   --row number: 3361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2920334 , [Content] ='09/05/18'
 WHERE id=174687222


   --row number: 3362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2920334 , [Content] ='5923 NLD'
 WHERE id=174687207


   --row number: 3363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2920334 , [Content] ='NLD'
 WHERE id=174687208


   --row number: 3364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2920334 , [Content] ='EMEA'
 WHERE id=174687209


   --row number: 3365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2920334 , [Content] ='NETHERLANDS'
 WHERE id=174687210


   --row number: 3366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2920334 , [Content] ='Info Systems/Technology'
 WHERE id=174687211


   --row number: 3367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2920334 , [Content] ='5923 - Compliance Analyst IC3'
 WHERE id=174687212


   --row number: 3368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2920334 , [Content] ='Compliance'
 WHERE id=174687213


   --row number: 3369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2920334 , [Content] ='IC3'
 WHERE id=174687214


   --row number: 3370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2920334 , [Content] ='EUR'
 WHERE id=174687216


   --row number: 3371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2920372 , [Content] ='S1331 NLD'
 WHERE id=174689600


   --row number: 3372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2920372 , [Content] ='NLD'
 WHERE id=174689601


   --row number: 3373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2920372 , [Content] ='EMEA'
 WHERE id=174689602


   --row number: 3374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2920372 , [Content] ='NETHERLANDS'
 WHERE id=174689603


   --row number: 3375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2920372 , [Content] ='Sales'
 WHERE id=174689604


   --row number: 3376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2920372 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=174689605


   --row number: 3377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2920372 , [Content] ='Inside Sales'
 WHERE id=174689606


   --row number: 3378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2920372 , [Content] ='A1'
 WHERE id=174689607


   --row number: 3379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2920372 , [Content] ='EUR'
 WHERE id=174689609


   --row number: 3380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2920372 , [Content] ='60/40'
 WHERE id=174689612


   --row number: 3381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2920372 , [Content] ='No'
 WHERE id=174689613


   --row number: 3382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2920372 , [Content] ='4 - Sales Workers'
 WHERE id=174689614


   --row number: 3383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2920372 , [Content] ='8810-Clerical Office Employees'
 WHERE id=174689615


   --row number: 3384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2920372 , [Content] ='Non Technical'
 WHERE id=174689616


   --row number: 3385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2920372 , [Content] ='7/20/18'
 WHERE id=174689617


   --row number: 3386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2922544 , [Content] ='6572 NLD'
 WHERE id=175063070


   --row number: 3387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2922544 , [Content] ='NLD'
 WHERE id=175063071


   --row number: 3388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2922544 , [Content] ='EMEA'
 WHERE id=175063072


   --row number: 3389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2922544 , [Content] ='NETHERLANDS'
 WHERE id=175063073


   --row number: 3390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2922544 , [Content] ='Info Systems/Technology'
 WHERE id=175063074


   --row number: 3391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2922544 , [Content] ='6572 - IT Systems/Support Analyst IC2'
 WHERE id=175063075


   --row number: 3392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2922544 , [Content] ='IT Systems/Support'
 WHERE id=175063076


   --row number: 3393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2922544 , [Content] ='IC2'
 WHERE id=175063077


   --row number: 3394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2922544 , [Content] ='EUR'
 WHERE id=175063079


   --row number: 3395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2922544 , [Content] ='33,500 / 38,250 / 43,000 / 47,800 / 52,600'
 WHERE id=175063080


   --row number: 3396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2922544 , [Content] ='10%'
 WHERE id=175063081


   --row number: 3397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2922544 , [Content] ='No'
 WHERE id=175063082


   --row number: 3398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2922544 , [Content] ='2 - Professionals'
 WHERE id=175063083


   --row number: 3399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2922544 , [Content] ='8810-Clerical Office Employees'
 WHERE id=175063084


   --row number: 3400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2922544 , [Content] ='Technical'
 WHERE id=175063085


   --row number: 3401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2922544 , [Content] ='4/25/2018'
 WHERE id=175063086


   --row number: 3402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2924751 , [Content] ='4/25/2018'
 WHERE id=175420409


   --row number: 3403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2924751 , [Content] ='5224 IND'
 WHERE id=175420392


   --row number: 3404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2924751 , [Content] ='IND'
 WHERE id=175420393


   --row number: 3405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2924751 , [Content] ='APAC'
 WHERE id=175420394


   --row number: 3406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2924751 , [Content] ='INDIA'
 WHERE id=175420395


   --row number: 3407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2924751 , [Content] ='Engineering'
 WHERE id=175420396


   --row number: 3408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2924751 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=175420397


   --row number: 3409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2924751 , [Content] ='Product Mgmt Mgr'
 WHERE id=175420398


   --row number: 3410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2924751 , [Content] ='IC4'
 WHERE id=175420399


   --row number: 3411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2924751 , [Content] ='INR'
 WHERE id=175420401


   --row number: 3412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2924751 , [Content] ='2,310,300 / 2,830,150 / 3,350,000 / 3,869,800 / 4,389,600'
 WHERE id=175420402


   --row number: 3413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2924751 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=175420403


   --row number: 3414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2924751 , [Content] ='20%'
 WHERE id=175420404


   --row number: 3415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2924751 , [Content] ='Yes'
 WHERE id=175420405


   --row number: 3416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2924751 , [Content] ='2 - Professionals'
 WHERE id=175420406


   --row number: 3417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2924751 , [Content] ='8810-Clerical Office Employees'
 WHERE id=175420407


   --row number: 3418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2924751 , [Content] ='Technical'
 WHERE id=175420408


   --row number: 3419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2925160 , [Content] ='9999 US - MRKT 2'
 WHERE id=175454681


   --row number: 3420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2925160 , [Content] ='US - MRKT 2'
 WHERE id=175454682


   --row number: 3421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2925160 , [Content] ='AMS'
 WHERE id=175454683


   --row number: 3422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2925160 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=175454684


   --row number: 3423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2925160 , [Content] ='9999 - Intern'
 WHERE id=175454685


   --row number: 3424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2925160 , [Content] ='USD'
 WHERE id=175454686


   --row number: 3425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2925160 , [Content] ='No'
 WHERE id=175454688


   --row number: 3426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2925160 , [Content] ='NON-EXEMPT'
 WHERE id=175454689


   --row number: 3427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2925160 , [Content] ='4/25/2018'
 WHERE id=175454690


   --row number: 3428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2925724 , [Content] ='5596 US - MRKT 1'
 WHERE id=175507268


   --row number: 3429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2925724 , [Content] ='US - MRKT 1'
 WHERE id=175507269


   --row number: 3430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2925724 , [Content] ='AMS'
 WHERE id=175507270


   --row number: 3431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2925724 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=175507271


   --row number: 3432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2925724 , [Content] ='Marketing'
 WHERE id=175507272


   --row number: 3433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2925724 , [Content] ='5596 - Product Marketing Mgr IC6'
 WHERE id=175507273


   --row number: 3434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2925724 , [Content] ='Product Marketing'
 WHERE id=175507274


   --row number: 3435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2925724 , [Content] ='IC6'
 WHERE id=175507275


   --row number: 3436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2925724 , [Content] ='USD'
 WHERE id=175507277


   --row number: 3437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2925724 , [Content] ='139,500 / 170,900 / 202,300 / 233,700 / 265,100'
 WHERE id=175507278


   --row number: 3438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2925724 , [Content] ='Technical'
 WHERE id=175507286


   --row number: 3439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2925724 , [Content] ='5/22/2018'
 WHERE id=175507287


   --row number: 3440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2925724 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=175507279


   --row number: 3441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2925724 , [Content] ='25%'
 WHERE id=175507280


   --row number: 3442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2925724 , [Content] ='Yes'
 WHERE id=175507281


   --row number: 3443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2925724 , [Content] ='EXEMPT'
 WHERE id=175507282


   --row number: 3444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2925724 , [Content] ='NO'
 WHERE id=175507283


   --row number: 3445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2925724 , [Content] ='2 - Professionals'
 WHERE id=175507284


   --row number: 3446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2925724 , [Content] ='8810-Clerical Office Employees'
 WHERE id=175507285


   --row number: 3447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2926649 , [Content] ='SPAIN'
 WHERE id=175670607


   --row number: 3448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2926649 , [Content] ='2 - Professionals'
 WHERE id=175670618


   --row number: 3449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2926649 , [Content] ='8810-Clerical Office Employees'
 WHERE id=175670619


   --row number: 3450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2926649 , [Content] ='Technical'
 WHERE id=175670620


   --row number: 3451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2926649 , [Content] ='4/25/2018'
 WHERE id=175670621


   --row number: 3452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2926649 , [Content] ='Professional Services'
 WHERE id=175670608


   --row number: 3453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2926649 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=175670609


   --row number: 3454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2926649 , [Content] ='Technology Consultant'
 WHERE id=175670610


   --row number: 3455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2926649 , [Content] ='IC4'
 WHERE id=175670611


   --row number: 3456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2926649 , [Content] ='EUR'
 WHERE id=175670613


   --row number: 3457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2926649 , [Content] ='40,000 / 48,350 / 56,700 / 65,100 / 73,500'
 WHERE id=175670614


   --row number: 3458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2926649 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=175670615


   --row number: 3459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2926649 , [Content] ='20%'
 WHERE id=175670616


   --row number: 3460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2926649 , [Content] ='Yes'
 WHERE id=175670617


   --row number: 3461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2926649 , [Content] ='5764 ESP'
 WHERE id=175670604


   --row number: 3462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2926649 , [Content] ='ESP'
 WHERE id=175670605


   --row number: 3463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2926649 , [Content] ='EMEA'
 WHERE id=175670606


   --row number: 3464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2927333 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=175793947


   --row number: 3465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2927333 , [Content] ='8742-Salespersons - Outside'
 WHERE id=175793948


   --row number: 3466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2927333 , [Content] ='Technical'
 WHERE id=175793949


   --row number: 3467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2927333 , [Content] ='4/25/2018'
 WHERE id=175793950


   --row number: 3468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2927333 , [Content] ='50/50'
 WHERE id=175793944


   --row number: 3469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2927333 , [Content] ='Yes'
 WHERE id=175793945


   --row number: 3470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2927333 , [Content] ='EXEMPT'
 WHERE id=175793946


   --row number: 3471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2927333 , [Content] ='S314 US - MRKT 3'
 WHERE id=175793931


   --row number: 3472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2927333 , [Content] ='US - MRKT 3'
 WHERE id=175793932


   --row number: 3473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2927333 , [Content] ='AMS'
 WHERE id=175793933


   --row number: 3474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2927333 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=175793934


   --row number: 3475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2927333 , [Content] ='Sales'
 WHERE id=175793935


   --row number: 3476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2927333 , [Content] ='S314 - Sr Mgr, Sales M4'
 WHERE id=175793936


   --row number: 3477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2927333 , [Content] ='Sales Management'
 WHERE id=175793937


   --row number: 3478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2927333 , [Content] ='M4'
 WHERE id=175793938


   --row number: 3479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2927333 , [Content] ='USD'
 WHERE id=175793940


   --row number: 3480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2927333 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=175793941


   --row number: 3481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2927333 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=175793942


   --row number: 3482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2927333 , [Content] ='280,500 / 305,250 / 330,000 / 354,750 / 379,500'
 WHERE id=175793943


   --row number: 3483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2929073 , [Content] ='4/25/2018'
 WHERE id=176167410


   --row number: 3484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2929073 , [Content] ='6611 IND'
 WHERE id=176167394


   --row number: 3485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2929073 , [Content] ='IND'
 WHERE id=176167395


   --row number: 3486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2929073 , [Content] ='APAC'
 WHERE id=176167396


   --row number: 3487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2929073 , [Content] ='INDIA'
 WHERE id=176167397


   --row number: 3488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2929073 , [Content] ='Info Systems/Technology'
 WHERE id=176167398


   --row number: 3489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2929073 , [Content] ='6611 - Assoc Storage Engineer IC1'
 WHERE id=176167399


   --row number: 3490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2929073 , [Content] ='Storage'
 WHERE id=176167400


   --row number: 3491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2929073 , [Content] ='IC1'
 WHERE id=176167401


   --row number: 3492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2929073 , [Content] ='INR'
 WHERE id=176167403


   --row number: 3493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2929073 , [Content] ='450,000 / 551,250 / 652,500 / 753,750 / 855,000'
 WHERE id=176167404


   --row number: 3494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2929073 , [Content] ='10%'
 WHERE id=176167405


   --row number: 3495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2929073 , [Content] ='No'
 WHERE id=176167406


   --row number: 3496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2929073 , [Content] ='2 - Professionals'
 WHERE id=176167407


   --row number: 3497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2929073 , [Content] ='8810-Clerical Office Employees'
 WHERE id=176167408


   --row number: 3498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2929073 , [Content] ='Technical'
 WHERE id=176167409


   --row number: 3499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2929621 , [Content] ='Non Technical'
 WHERE id=176234246


   --row number: 3500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2929621 , [Content] ='4/25/2018'
 WHERE id=176234247


   --row number: 3501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2929621 , [Content] ='5565 US - MRKT 1'
 WHERE id=176234228


   --row number: 3502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2929621 , [Content] ='US - MRKT 1'
 WHERE id=176234229


   --row number: 3503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2929621 , [Content] ='AMS'
 WHERE id=176234230


   --row number: 3504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2929621 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=176234231


   --row number: 3505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2929621 , [Content] ='Marketing'
 WHERE id=176234232


   --row number: 3506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2929621 , [Content] ='5565 - Marketing Communications Mgr IC5'
 WHERE id=176234233


   --row number: 3507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2929621 , [Content] ='Marcom'
 WHERE id=176234234


   --row number: 3508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2929621 , [Content] ='IC5'
 WHERE id=176234235


   --row number: 3509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2929621 , [Content] ='USD'
 WHERE id=176234237


   --row number: 3510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2929621 , [Content] ='117,500 / 142,150 / 166,800 / 191,400 / 216,000'
 WHERE id=176234238


   --row number: 3511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2929621 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=176234239


   --row number: 3512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2929621 , [Content] ='20%'
 WHERE id=176234240


   --row number: 3513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2929621 , [Content] ='Yes'
 WHERE id=176234241


   --row number: 3514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2929621 , [Content] ='EXEMPT'
 WHERE id=176234242


   --row number: 3515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2929621 , [Content] ='NO'
 WHERE id=176234243


   --row number: 3516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2929621 , [Content] ='2 - Professionals'
 WHERE id=176234244


   --row number: 3517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2929621 , [Content] ='8810-Clerical Office Employees'
 WHERE id=176234245


   --row number: 3518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2930045 , [Content] ='8810-Clerical Office Employees'
 WHERE id=176333979


   --row number: 3519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2930045 , [Content] ='Technical'
 WHERE id=176333980


   --row number: 3520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2930045 , [Content] ='4/25/2018'
 WHERE id=176333981


   --row number: 3521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2930045 , [Content] ='5764 US - MRKT 1'
 WHERE id=176333962


   --row number: 3522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2930045 , [Content] ='US - MRKT 1'
 WHERE id=176333963


   --row number: 3523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2930045 , [Content] ='AMS'
 WHERE id=176333964


   --row number: 3524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2930045 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=176333965


   --row number: 3525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2930045 , [Content] ='Professional Services'
 WHERE id=176333966


   --row number: 3526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2930045 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=176333967


   --row number: 3527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2930045 , [Content] ='Technology Consultant'
 WHERE id=176333968


   --row number: 3528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2930045 , [Content] ='IC4'
 WHERE id=176333969


   --row number: 3529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2930045 , [Content] ='USD'
 WHERE id=176333971


   --row number: 3530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2930045 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=176333972


   --row number: 3531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2930045 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=176333973


   --row number: 3532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2930045 , [Content] ='20%'
 WHERE id=176333974


   --row number: 3533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2930045 , [Content] ='Yes'
 WHERE id=176333975


   --row number: 3534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2930045 , [Content] ='EXEMPT'
 WHERE id=176333976


   --row number: 3535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2930045 , [Content] ='NO'
 WHERE id=176333977


   --row number: 3536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2930045 , [Content] ='2 - Professionals'
 WHERE id=176333978


   --row number: 3537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2930890 , [Content] ='5142 IND'
 WHERE id=176635959


   --row number: 3538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2930890 , [Content] ='IND'
 WHERE id=176635960


   --row number: 3539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2930890 , [Content] ='APAC'
 WHERE id=176635961


   --row number: 3540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2930890 , [Content] ='INDIA'
 WHERE id=176635962


   --row number: 3541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2930890 , [Content] ='Engineering'
 WHERE id=176635963


   --row number: 3542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2930890 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=176635964


   --row number: 3543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2930890 , [Content] ='Software'
 WHERE id=176635965


   --row number: 3544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2930890 , [Content] ='IC2'
 WHERE id=176635966


   --row number: 3545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2930890 , [Content] ='INR'
 WHERE id=176635968


   --row number: 3546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2930890 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=176635969


   --row number: 3547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2930890 , [Content] ='10%'
 WHERE id=176635971


   --row number: 3548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2930890 , [Content] ='No'
 WHERE id=176635972


   --row number: 3549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2930890 , [Content] ='2 - Professionals'
 WHERE id=176635973


   --row number: 3550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2930890 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=176635974


   --row number: 3551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2930890 , [Content] ='Technical'
 WHERE id=176635975


   --row number: 3552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2930890 , [Content] ='6/27/2018'
 WHERE id=176635976


   --row number: 3553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2933561 , [Content] ='4/25/2018'
 WHERE id=177215469


   --row number: 3554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2933561 , [Content] ='5813 US - MRKT 3'
 WHERE id=177215451


   --row number: 3555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2933561 , [Content] ='US - MRKT 3'
 WHERE id=177215452


   --row number: 3556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2933561 , [Content] ='AMS'
 WHERE id=177215453


   --row number: 3557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2933561 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=177215454


   --row number: 3558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2933561 , [Content] ='Customer Support'
 WHERE id=177215455


   --row number: 3559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2933561 , [Content] ='5813 - Customer Support Rep IC3'
 WHERE id=177215456


   --row number: 3560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2933561 , [Content] ='Customer Support'
 WHERE id=177215457


   --row number: 3561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2933561 , [Content] ='IC3'
 WHERE id=177215458


   --row number: 3562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2933561 , [Content] ='USD'
 WHERE id=177215460


   --row number: 3563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2933561 , [Content] ='58,400 / 66,700 / 75,000 / 83,350 / 91,700'
 WHERE id=177215461


   --row number: 3564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2933561 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=177215462


   --row number: 3565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2933561 , [Content] ='10%'
 WHERE id=177215463


   --row number: 3566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2933561 , [Content] ='Yes'
 WHERE id=177215464


   --row number: 3567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2933561 , [Content] ='EXEMPT'
 WHERE id=177215465


   --row number: 3568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2933561 , [Content] ='2 - Professionals'
 WHERE id=177215466


   --row number: 3569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2933561 , [Content] ='8810-Clerical Office Employees'
 WHERE id=177215467


   --row number: 3570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2933561 , [Content] ='Technical'
 WHERE id=177215468


   --row number: 3571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2934257 , [Content] ='Non Technical'
 WHERE id=177270107


   --row number: 3572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2934257 , [Content] ='10/05/18'
 WHERE id=177270108


   --row number: 3573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2934257 , [Content] ='6222 US - MRKT 1'
 WHERE id=177270089


   --row number: 3574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2934257 , [Content] ='US - MRKT 1'
 WHERE id=177270090


   --row number: 3575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2934257 , [Content] ='AMS'
 WHERE id=177270091


   --row number: 3576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2934257 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=177270092


   --row number: 3577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2934257 , [Content] ='Human Resources'
 WHERE id=177270093


   --row number: 3578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2934257 , [Content] ='6222 - Recruiter/Staffing Representative IC2'
 WHERE id=177270094


   --row number: 3579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2934257 , [Content] ='Staffing'
 WHERE id=177270095


   --row number: 3580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2934257 , [Content] ='IC2'
 WHERE id=177270096


   --row number: 3581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2934257 , [Content] ='USD'
 WHERE id=177270098


   --row number: 3582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2934257 , [Content] ='67,200 / 76,800 / 86,400 / 95,950 / 105,500'
 WHERE id=177270099


   --row number: 3583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2934257 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=177270100


   --row number: 3584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2934257 , [Content] ='10%'
 WHERE id=177270101


   --row number: 3585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2934257 , [Content] ='Yes'
 WHERE id=177270102


   --row number: 3586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2934257 , [Content] ='EXEMPT'
 WHERE id=177270103


   --row number: 3587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2934257 , [Content] ='NO'
 WHERE id=177270104


   --row number: 3588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2934257 , [Content] ='2 - Professionals'
 WHERE id=177270105


   --row number: 3589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2934257 , [Content] ='8810-Clerical Office Employees'
 WHERE id=177270106


   --row number: 3590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2936673 , [Content] ='Non Technical'
 WHERE id=177478707


   --row number: 3591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2936673 , [Content] ='4/25/2018'
 WHERE id=177478708


   --row number: 3592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2936673 , [Content] ='3116 US - MRKT 1'
 WHERE id=177478689


   --row number: 3593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2936673 , [Content] ='US - MRKT 1'
 WHERE id=177478690


   --row number: 3594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2936673 , [Content] ='AMS'
 WHERE id=177478691


   --row number: 3595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2936673 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=177478692


   --row number: 3596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2936673 , [Content] ='Finance'
 WHERE id=177478693


   --row number: 3597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2936673 , [Content] ='3116 - Sr Dir, FP&A Mgmt M6'
 WHERE id=177478694


   --row number: 3598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2936673 , [Content] ='FP&A'
 WHERE id=177478695


   --row number: 3599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2936673 , [Content] ='M6'
 WHERE id=177478696


   --row number: 3600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2936673 , [Content] ='USD'
 WHERE id=177478698


   --row number: 3601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2936673 , [Content] ='170,300 / 208,650 / 247,000 / 285,300 / 323,600'
 WHERE id=177478699


   --row number: 3602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2936673 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=177478700


   --row number: 3603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2936673 , [Content] ='30%'
 WHERE id=177478701


   --row number: 3604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2936673 , [Content] ='Yes'
 WHERE id=177478702


   --row number: 3605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2936673 , [Content] ='EXEMPT'
 WHERE id=177478703


   --row number: 3606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2936673 , [Content] ='NO'
 WHERE id=177478704


   --row number: 3607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2936673 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=177478705


   --row number: 3608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2936673 , [Content] ='8810-Clerical Office Employees'
 WHERE id=177478706


   --row number: 3609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2936881 , [Content] ='5143 IND'
 WHERE id=177509701


   --row number: 3610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2936881 , [Content] ='IND'
 WHERE id=177509702


   --row number: 3611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2936881 , [Content] ='APAC'
 WHERE id=177509703


   --row number: 3612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2936881 , [Content] ='INDIA'
 WHERE id=177509704


   --row number: 3613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2936881 , [Content] ='Engineering'
 WHERE id=177509705


   --row number: 3614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2936881 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=177509706


   --row number: 3615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2936881 , [Content] ='Software'
 WHERE id=177509707


   --row number: 3616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2936881 , [Content] ='IC3'
 WHERE id=177509708


   --row number: 3617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2936881 , [Content] ='INR'
 WHERE id=177509710


   --row number: 3618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2936881 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=177509711


   --row number: 3619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2936881 , [Content] ='15%'
 WHERE id=177509712


   --row number: 3620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2936881 , [Content] ='Yes'
 WHERE id=177509713


   --row number: 3621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2936881 , [Content] ='2 - Professionals'
 WHERE id=177509714


   --row number: 3622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2936881 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=177509715


   --row number: 3623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2936881 , [Content] ='Technical'
 WHERE id=177509716


   --row number: 3624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2936881 , [Content] ='09/05/18'
 WHERE id=177509717


   --row number: 3625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2936928 , [Content] ='5183 IND'
 WHERE id=177510451


   --row number: 3626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2936928 , [Content] ='IND'
 WHERE id=177510452


   --row number: 3627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2936928 , [Content] ='APAC'
 WHERE id=177510453


   --row number: 3628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2936928 , [Content] ='INDIA'
 WHERE id=177510454


   --row number: 3629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2936928 , [Content] ='Engineering'
 WHERE id=177510455


   --row number: 3630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2936928 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=177510456


   --row number: 3631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2936928 , [Content] ='4/25/2018'
 WHERE id=177510468


   --row number: 3632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2936928 , [Content] ='Quality'
 WHERE id=177510457


   --row number: 3633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2936928 , [Content] ='IC3'
 WHERE id=177510458


   --row number: 3634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2936928 , [Content] ='INR'
 WHERE id=177510460


   --row number: 3635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2936928 , [Content] ='1,344,800 / 1,647,400 / 1,950,000 / 2,252,550 / 2,555,100'
 WHERE id=177510461


   --row number: 3636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2936928 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=177510462


   --row number: 3637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2936928 , [Content] ='15%'
 WHERE id=177510463


   --row number: 3638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2936928 , [Content] ='Yes'
 WHERE id=177510464


   --row number: 3639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2936928 , [Content] ='2 - Professionals'
 WHERE id=177510465


   --row number: 3640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2936928 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=177510466


   --row number: 3641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2936928 , [Content] ='Technical'
 WHERE id=177510467


   --row number: 3642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2942626 , [Content] ='9914 - Administrative Assistant A4'
 WHERE id=177745208


   --row number: 3643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2942626 , [Content] ='Administrative Assistant'
 WHERE id=177745209


   --row number: 3644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2942626 , [Content] ='9914 NLD'
 WHERE id=177745203


   --row number: 3645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2942626 , [Content] ='NLD'
 WHERE id=177745204


   --row number: 3646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2942626 , [Content] ='EMEA'
 WHERE id=177745205


   --row number: 3647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2942626 , [Content] ='NETHERLANDS'
 WHERE id=177745206


   --row number: 3648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2942626 , [Content] ='Administration'
 WHERE id=177745207


   --row number: 3649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2942626 , [Content] ='A4'
 WHERE id=177745210


   --row number: 3650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2942626 , [Content] ='EUR'
 WHERE id=177745212


   --row number: 3651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2942626 , [Content] ='38,200 / 43,400 / 48,600 / 53,750 / 58,900'
 WHERE id=177745213


   --row number: 3652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2942626 , [Content] ='10%'
 WHERE id=177745214


   --row number: 3653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2942626 , [Content] ='No'
 WHERE id=177745215


   --row number: 3654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2942626 , [Content] ='5 - Administrative Support Workers'
 WHERE id=177745216


   --row number: 3655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2942626 , [Content] ='8810-Clerical Office Employees'
 WHERE id=177745217


   --row number: 3656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2942626 , [Content] ='Non Technical'
 WHERE id=177745218


   --row number: 3657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2942626 , [Content] ='4/25/2018'
 WHERE id=177745219


   --row number: 3658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2942712 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=177752257


   --row number: 3659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2942712 , [Content] ='Technical'
 WHERE id=177752258


   --row number: 3660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2942712 , [Content] ='4/25/2018'
 WHERE id=177752259


   --row number: 3661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2942712 , [Content] ='2143 US - MRKT 2'
 WHERE id=177752240


   --row number: 3662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2942712 , [Content] ='US - MRKT 2'
 WHERE id=177752241


   --row number: 3663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2942712 , [Content] ='AMS'
 WHERE id=177752242


   --row number: 3664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2942712 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=177752243


   --row number: 3665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2942712 , [Content] ='Engineering'
 WHERE id=177752244


   --row number: 3666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2942712 , [Content] ='2143 - Mgr, Software Engrg Mgmt M3'
 WHERE id=177752245


   --row number: 3667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2942712 , [Content] ='Software'
 WHERE id=177752246


   --row number: 3668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2942712 , [Content] ='M3'
 WHERE id=177752247


   --row number: 3669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2942712 , [Content] ='USD'
 WHERE id=177752249


   --row number: 3670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2942712 , [Content] ='111,000 / 134,250 / 157,500 / 180,750 / 204,000'
 WHERE id=177752250


   --row number: 3671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2942712 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=177752251


   --row number: 3672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2942712 , [Content] ='20%'
 WHERE id=177752252


   --row number: 3673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2942712 , [Content] ='Yes'
 WHERE id=177752253


   --row number: 3674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2942712 , [Content] ='EXEMPT'
 WHERE id=177752254


   --row number: 3675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2942712 , [Content] ='NO'
 WHERE id=177752255


   --row number: 3676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2942712 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=177752256


   --row number: 3677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2943442 , [Content] ='2 - Professionals'
 WHERE id=177804152


   --row number: 3678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2943442 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=177804153


   --row number: 3679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2943442 , [Content] ='Technical'
 WHERE id=177804154


   --row number: 3680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2943442 , [Content] ='4/25/2018'
 WHERE id=177804155


   --row number: 3681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2943442 , [Content] ='5143 US - MRKT 1'
 WHERE id=177804136


   --row number: 3682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2943442 , [Content] ='US - MRKT 1'
 WHERE id=177804137


   --row number: 3683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2943442 , [Content] ='AMS'
 WHERE id=177804138


   --row number: 3684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2943442 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=177804139


   --row number: 3685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2943442 , [Content] ='Engineering'
 WHERE id=177804140


   --row number: 3686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2943442 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=177804141


   --row number: 3687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2943442 , [Content] ='Software'
 WHERE id=177804142


   --row number: 3688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2943442 , [Content] ='IC3'
 WHERE id=177804143


   --row number: 3689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2943442 , [Content] ='USD'
 WHERE id=177804145


   --row number: 3690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2943442 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=177804146


   --row number: 3691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2943442 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=177804147


   --row number: 3692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2943442 , [Content] ='15%'
 WHERE id=177804148


   --row number: 3693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2943442 , [Content] ='Yes'
 WHERE id=177804149


   --row number: 3694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2943442 , [Content] ='EXEMPT'
 WHERE id=177804150


   --row number: 3695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2943442 , [Content] ='NO'
 WHERE id=177804151


   --row number: 3696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2944265 , [Content] ='6102 IND'
 WHERE id=177899042


   --row number: 3697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2944265 , [Content] ='IND'
 WHERE id=177899043


   --row number: 3698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2944265 , [Content] ='APAC'
 WHERE id=177899044


   --row number: 3699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2944265 , [Content] ='INDIA'
 WHERE id=177899045


   --row number: 3700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2944265 , [Content] ='Finance'
 WHERE id=177899046


   --row number: 3701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2944265 , [Content] ='6102 - Accountant IC2'
 WHERE id=177899047


   --row number: 3702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2944265 , [Content] ='Accounting'
 WHERE id=177899048


   --row number: 3703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2944265 , [Content] ='IC2'
 WHERE id=177899049


   --row number: 3704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2944265 , [Content] ='INR'
 WHERE id=177899051


   --row number: 3705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2944265 , [Content] ='620,700 / 760,350 / 900,000 / 1,039,650 / 1,179,300'
 WHERE id=177899052


   --row number: 3706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2944265 , [Content] ='10%'
 WHERE id=177899053


   --row number: 3707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2944265 , [Content] ='No'
 WHERE id=177899054


   --row number: 3708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2944265 , [Content] ='2 - Professionals'
 WHERE id=177899055


   --row number: 3709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2944265 , [Content] ='8810-Clerical Office Employees'
 WHERE id=177899056


   --row number: 3710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2944265 , [Content] ='Non Technical'
 WHERE id=177899057


   --row number: 3711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2944265 , [Content] ='4/25/2018'
 WHERE id=177899058


   --row number: 3712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2945331 , [Content] ='No'
 WHERE id=178078632


   --row number: 3713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2945331 , [Content] ='8810-Clerical Office Employees'
 WHERE id=178078636


   --row number: 3714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2945331 , [Content] ='Non Technical'
 WHERE id=178078637


   --row number: 3715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2945331 , [Content] ='4/25/2018'
 WHERE id=178078638


   --row number: 3716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2945331 , [Content] ='NON-EXEMPT'
 WHERE id=178078633


   --row number: 3717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2945331 , [Content] ='NO'
 WHERE id=178078634


   --row number: 3718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2945331 , [Content] ='4 - Sales Workers'
 WHERE id=178078635


   --row number: 3719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2945331 , [Content] ='S1332 US - MRKT 2'
 WHERE id=178078619


   --row number: 3720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2945331 , [Content] ='US - MRKT 2'
 WHERE id=178078620


   --row number: 3721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2945331 , [Content] ='AMS'
 WHERE id=178078621


   --row number: 3722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2945331 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=178078622


   --row number: 3723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2945331 , [Content] ='Sales'
 WHERE id=178078623


   --row number: 3724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2945331 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=178078624


   --row number: 3725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2945331 , [Content] ='Inside Sales'
 WHERE id=178078625


   --row number: 3726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2945331 , [Content] ='A2'
 WHERE id=178078626


   --row number: 3727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2945331 , [Content] ='USD'
 WHERE id=178078628


   --row number: 3728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2945331 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=178078629


   --row number: 3729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2945331 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=178078630


   --row number: 3730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2945331 , [Content] ='60/40'
 WHERE id=178078631


   --row number: 3731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2946228 , [Content] ='4 - Sales Workers'
 WHERE id=178177420


   --row number: 3732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2946228 , [Content] ='8742-Salespersons - Outside'
 WHERE id=178177421


   --row number: 3733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2946228 , [Content] ='Technical'
 WHERE id=178177422


   --row number: 3734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2946228 , [Content] ='7/20/2018'
 WHERE id=178177423


   --row number: 3735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2946228 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=178177415


   --row number: 3736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2946228 , [Content] ='195,500 / 212,750 / 230,000 / 247,250 / 264,500'
 WHERE id=178177416


   --row number: 3737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2946228 , [Content] ='50/50'
 WHERE id=178177417


   --row number: 3738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2946228 , [Content] ='Yes'
 WHERE id=178177418


   --row number: 3739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2946228 , [Content] ='EXEMPT'
 WHERE id=178177419


   --row number: 3740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2946228 , [Content] ='R3613B US - MRKT 2'
 WHERE id=178177404


   --row number: 3741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2946228 , [Content] ='US - MRKT 2'
 WHERE id=178177405


   --row number: 3742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2946228 , [Content] ='AMS'
 WHERE id=178177406


   --row number: 3743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2946228 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=178177407


   --row number: 3744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2946228 , [Content] ='Sales'
 WHERE id=178177408


   --row number: 3745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2946228 , [Content] ='R3613B - Commercial Account Exec IC3'
 WHERE id=178177409


   --row number: 3746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2946228 , [Content] ='Commercial Accounts'
 WHERE id=178177410


   --row number: 3747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2946228 , [Content] ='IC3'
 WHERE id=178177411


   --row number: 3748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2946228 , [Content] ='USD'
 WHERE id=178177413


   --row number: 3749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2946228 , [Content] ='97,750 / 106,375 / 115,000 / 123,625 / 132,250'
 WHERE id=178177414


   --row number: 3750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2946579 , [Content] ='5184 IND'
 WHERE id=178212414


   --row number: 3751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2946579 , [Content] ='IND'
 WHERE id=178212415


   --row number: 3752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2946579 , [Content] ='APAC'
 WHERE id=178212416


   --row number: 3753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2946579 , [Content] ='INDIA'
 WHERE id=178212417


   --row number: 3754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2946579 , [Content] ='Engineering'
 WHERE id=178212418


   --row number: 3755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2946579 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=178212419


   --row number: 3756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2946579 , [Content] ='Quality'
 WHERE id=178212420


   --row number: 3757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2946579 , [Content] ='4/25/2018'
 WHERE id=178212431


   --row number: 3758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2946579 , [Content] ='IC4'
 WHERE id=178212421


   --row number: 3759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2946579 , [Content] ='INR'
 WHERE id=178212423


   --row number: 3760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2946579 , [Content] ='1,851,700 / 2,268,350 / 2,685,000 / 3,101,600 / 3,518,200'
 WHERE id=178212424


   --row number: 3761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2946579 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=178212425


   --row number: 3762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2946579 , [Content] ='20%'
 WHERE id=178212426


   --row number: 3763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2946579 , [Content] ='Yes'
 WHERE id=178212427


   --row number: 3764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2946579 , [Content] ='2 - Professionals'
 WHERE id=178212428


   --row number: 3765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2946579 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=178212429


   --row number: 3766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2946579 , [Content] ='Technical'
 WHERE id=178212430


   --row number: 3767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2946589 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=178212855


   --row number: 3768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2946589 , [Content] ='Quality'
 WHERE id=178212856


   --row number: 3769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2946589 , [Content] ='5182 IND'
 WHERE id=178212850


   --row number: 3770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2946589 , [Content] ='IND'
 WHERE id=178212851


   --row number: 3771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2946589 , [Content] ='APAC'
 WHERE id=178212852


   --row number: 3772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2946589 , [Content] ='INDIA'
 WHERE id=178212853


   --row number: 3773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2946589 , [Content] ='Engineering'
 WHERE id=178212854


   --row number: 3774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2946589 , [Content] ='IC2'
 WHERE id=178212857


   --row number: 3775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2946589 , [Content] ='INR'
 WHERE id=178212859


   --row number: 3776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2946589 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=178212860


   --row number: 3777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2946589 , [Content] ='10%'
 WHERE id=178212861


   --row number: 3778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2946589 , [Content] ='No'
 WHERE id=178212862


   --row number: 3779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2946589 , [Content] ='2 - Professionals'
 WHERE id=178212863


   --row number: 3780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2946589 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=178212864


   --row number: 3781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2946589 , [Content] ='Technical'
 WHERE id=178212865


   --row number: 3782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2946589 , [Content] ='4/25/2018'
 WHERE id=178212866


   --row number: 3783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2946592 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=178213168


   --row number: 3784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2946592 , [Content] ='5182 IND'
 WHERE id=178213154


   --row number: 3785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2946592 , [Content] ='IND'
 WHERE id=178213155


   --row number: 3786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2946592 , [Content] ='APAC'
 WHERE id=178213156


   --row number: 3787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2946592 , [Content] ='INDIA'
 WHERE id=178213157


   --row number: 3788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2946592 , [Content] ='Engineering'
 WHERE id=178213158


   --row number: 3789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2946592 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=178213159


   --row number: 3790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2946592 , [Content] ='Quality'
 WHERE id=178213160


   --row number: 3791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2946592 , [Content] ='IC2'
 WHERE id=178213161


   --row number: 3792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2946592 , [Content] ='INR'
 WHERE id=178213163


   --row number: 3793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2946592 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=178213164


   --row number: 3794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2946592 , [Content] ='10%'
 WHERE id=178213165


   --row number: 3795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2946592 , [Content] ='No'
 WHERE id=178213166


   --row number: 3796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2946592 , [Content] ='2 - Professionals'
 WHERE id=178213167


   --row number: 3797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2946592 , [Content] ='Technical'
 WHERE id=178213169


   --row number: 3798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2946592 , [Content] ='4/25/2018'
 WHERE id=178213170


   --row number: 3799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2946647 , [Content] ='Technical'
 WHERE id=178217897


   --row number: 3800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2946647 , [Content] ='4/25/2018'
 WHERE id=178217898


   --row number: 3801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2946647 , [Content] ='S315 FRA'
 WHERE id=178217881


   --row number: 3802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2946647 , [Content] ='FRA'
 WHERE id=178217882


   --row number: 3803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2946647 , [Content] ='EMEA'
 WHERE id=178217883


   --row number: 3804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2946647 , [Content] ='FRANCE'
 WHERE id=178217884


   --row number: 3805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2946647 , [Content] ='Sales'
 WHERE id=178217885


   --row number: 3806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2946647 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=178217886


   --row number: 3807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2946647 , [Content] ='Sales Management'
 WHERE id=178217887


   --row number: 3808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2946647 , [Content] ='M5'
 WHERE id=178217888


   --row number: 3809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2946647 , [Content] ='EUR'
 WHERE id=178217890


   --row number: 3810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2946647 , [Content] ='114,750 / 124,875 / 135,000 / 145,125 / 155,250'
 WHERE id=178217891


   --row number: 3811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2946647 , [Content] ='229,500 / 249,750 / 270,000 / 290,250 / 310,500'
 WHERE id=178217892


   --row number: 3812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2946647 , [Content] ='50/50'
 WHERE id=178217893


   --row number: 3813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2946647 , [Content] ='No'
 WHERE id=178217894


   --row number: 3814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2946647 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=178217895


   --row number: 3815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2946647 , [Content] ='8742-Salespersons - Outside'
 WHERE id=178217896


   --row number: 3816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2949056 , [Content] ='NO'
 WHERE id=178440467


   --row number: 3817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2949056 , [Content] ='2 - Professionals'
 WHERE id=178440468


   --row number: 3818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2949056 , [Content] ='8810-Clerical Office Employees'
 WHERE id=178440469


   --row number: 3819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2949056 , [Content] ='Technical'
 WHERE id=178440470


   --row number: 3820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2949056 , [Content] ='4/25/2018'
 WHERE id=178440471


   --row number: 3821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2949056 , [Content] ='4684 US - MRKT 1'
 WHERE id=178440452


   --row number: 3822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2949056 , [Content] ='US - MRKT 1'
 WHERE id=178440453


   --row number: 3823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2949056 , [Content] ='AMS'
 WHERE id=178440454


   --row number: 3824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2949056 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=178440455


   --row number: 3825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2949056 , [Content] ='Business Strategy'
 WHERE id=178440456


   --row number: 3826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2949056 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=178440457


   --row number: 3827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2949056 , [Content] ='Business Process'
 WHERE id=178440458


   --row number: 3828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2949056 , [Content] ='IC4'
 WHERE id=178440459


   --row number: 3829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2949056 , [Content] ='USD'
 WHERE id=178440461


   --row number: 3830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2949056 , [Content] ='106,000 / 125,100 / 144,200 / 163,250 / 182,300'
 WHERE id=178440462


   --row number: 3831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2949056 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=178440463


   --row number: 3832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2949056 , [Content] ='15%'
 WHERE id=178440464


   --row number: 3833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2949056 , [Content] ='Yes'
 WHERE id=178440465


   --row number: 3834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2949056 , [Content] ='EXEMPT'
 WHERE id=178440466


   --row number: 3835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2952056 , [Content] ='8810-Clerical Office Employees'
 WHERE id=178681067


   --row number: 3836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2952056 , [Content] ='Technical'
 WHERE id=178681068


   --row number: 3837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2952056 , [Content] ='4/25/2018'
 WHERE id=178681069


   --row number: 3838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2952056 , [Content] ='5875 US - MRKT 2'
 WHERE id=178681050


   --row number: 3839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2952056 , [Content] ='US - MRKT 2'
 WHERE id=178681051


   --row number: 3840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2952056 , [Content] ='AMS'
 WHERE id=178681052


   --row number: 3841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2952056 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=178681053


   --row number: 3842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2952056 , [Content] ='Professional Services'
 WHERE id=178681054


   --row number: 3843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2952056 , [Content] ='5875 - Engagement Mgr IC5'
 WHERE id=178681055


   --row number: 3844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2952056 , [Content] ='Engagement Mgrs'
 WHERE id=178681056


   --row number: 3845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2952056 , [Content] ='IC5'
 WHERE id=178681057


   --row number: 3846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2952056 , [Content] ='USD'
 WHERE id=178681059


   --row number: 3847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2952056 , [Content] ='104,600 / 128,150 / 151,700 / 175,200 / 198,700'
 WHERE id=178681060


   --row number: 3848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2952056 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=178681061


   --row number: 3849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2952056 , [Content] ='25%'
 WHERE id=178681062


   --row number: 3850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2952056 , [Content] ='Yes'
 WHERE id=178681063


   --row number: 3851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2952056 , [Content] ='EXEMPT'
 WHERE id=178681064


   --row number: 3852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2952056 , [Content] ='NO'
 WHERE id=178681065


   --row number: 3853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2952056 , [Content] ='2 - Professionals'
 WHERE id=178681066


   --row number: 3854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2967793 , [Content] ='04/05/18'
 WHERE id=179255475


   --row number: 3855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2967793 , [Content] ='5705 AUS'
 WHERE id=179255458


   --row number: 3856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2967793 , [Content] ='AUS'
 WHERE id=179255459


   --row number: 3857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2967793 , [Content] ='APAC'
 WHERE id=179255460


   --row number: 3858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2967793 , [Content] ='AUSTRALIA'
 WHERE id=179255461


   --row number: 3859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2967793 , [Content] ='Professional Services'
 WHERE id=179255462


   --row number: 3860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2967793 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=179255463


   --row number: 3861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2967793 , [Content] ='Partner Support'
 WHERE id=179255464


   --row number: 3862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2967793 , [Content] ='IC5'
 WHERE id=179255465


   --row number: 3863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2967793 , [Content] ='AUD'
 WHERE id=179255467


   --row number: 3864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2967793 , [Content] ='120,800 / 148,000 / 175,200 / 202,350 / 229,500'
 WHERE id=179255468


   --row number: 3865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2967793 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=179255469


   --row number: 3866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2967793 , [Content] ='25%'
 WHERE id=179255470


   --row number: 3867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2967793 , [Content] ='Yes'
 WHERE id=179255471


   --row number: 3868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2967793 , [Content] ='2 - Professionals'
 WHERE id=179255472


   --row number: 3869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2967793 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179255473


   --row number: 3870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2967793 , [Content] ='Technical'
 WHERE id=179255474


   --row number: 3871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2969924 , [Content] ='6212 IND'
 WHERE id=179463495


   --row number: 3872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2969924 , [Content] ='IND'
 WHERE id=179463496


   --row number: 3873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2969924 , [Content] ='APAC'
 WHERE id=179463497


   --row number: 3874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2969924 , [Content] ='INDIA'
 WHERE id=179463498


   --row number: 3875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2969924 , [Content] ='Human Resources'
 WHERE id=179463499


   --row number: 3876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2969924 , [Content] ='6212 - Shared Services Representative IC2'
 WHERE id=179463500


   --row number: 3877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2969924 , [Content] ='HR Shared Srvcs'
 WHERE id=179463501


   --row number: 3878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2969924 , [Content] ='IC2'
 WHERE id=179463502


   --row number: 3879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2969924 , [Content] ='INR'
 WHERE id=179463504


   --row number: 3880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2969924 , [Content] ='10%'
 WHERE id=179463505


   --row number: 3881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2969924 , [Content] ='No'
 WHERE id=179463506


   --row number: 3882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2969924 , [Content] ='2 - Professionals'
 WHERE id=179463507


   --row number: 3883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2969924 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179463508


   --row number: 3884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2969924 , [Content] ='Non Technical'
 WHERE id=179463509


   --row number: 3885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2969924 , [Content] ='7/20/18'
 WHERE id=179463510


   --row number: 3886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2970115 , [Content] ='S1515 SWE'
 WHERE id=179486128


   --row number: 3887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2970115 , [Content] ='SWE'
 WHERE id=179486129


   --row number: 3888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2970115 , [Content] ='EMEA'
 WHERE id=179486130


   --row number: 3889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2970115 , [Content] ='SWEDEN'
 WHERE id=179486131


   --row number: 3890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2970115 , [Content] ='Professional Services'
 WHERE id=179486132


   --row number: 3891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2970115 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=179486133


   --row number: 3892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2970115 , [Content] ='Solution Architect'
 WHERE id=179486134


   --row number: 3893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2970115 , [Content] ='IC5'
 WHERE id=179486135


   --row number: 3894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2970115 , [Content] ='SEK'
 WHERE id=179486137


   --row number: 3895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2970115 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=179486138


   --row number: 3896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2970115 , [Content] ='25%'
 WHERE id=179486139


   --row number: 3897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2970115 , [Content] ='Yes'
 WHERE id=179486140


   --row number: 3898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2970115 , [Content] ='4 - Sales Workers'
 WHERE id=179486141


   --row number: 3899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2970115 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179486142


   --row number: 3900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2970115 , [Content] ='Technical'
 WHERE id=179486143


   --row number: 3901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2970115 , [Content] ='4/25/2018'
 WHERE id=179486144


   --row number: 3902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2970117 , [Content] ='S1515 SWE'
 WHERE id=179486206


   --row number: 3903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2970117 , [Content] ='SWE'
 WHERE id=179486207


   --row number: 3904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2970117 , [Content] ='EMEA'
 WHERE id=179486208


   --row number: 3905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2970117 , [Content] ='SWEDEN'
 WHERE id=179486209


   --row number: 3906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2970117 , [Content] ='Professional Services'
 WHERE id=179486210


   --row number: 3907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2970117 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=179486211


   --row number: 3908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2970117 , [Content] ='Solution Architect'
 WHERE id=179486212


   --row number: 3909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2970117 , [Content] ='IC5'
 WHERE id=179486213


   --row number: 3910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2970117 , [Content] ='SEK'
 WHERE id=179486215


   --row number: 3911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2970117 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=179486216


   --row number: 3912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2970117 , [Content] ='25%'
 WHERE id=179486217


   --row number: 3913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2970117 , [Content] ='Yes'
 WHERE id=179486218


   --row number: 3914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2970117 , [Content] ='4 - Sales Workers'
 WHERE id=179486219


   --row number: 3915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2970117 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179486220


   --row number: 3916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2970117 , [Content] ='Technical'
 WHERE id=179486221


   --row number: 3917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2970117 , [Content] ='4/25/2018'
 WHERE id=179486222


   --row number: 3918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2970120 , [Content] ='S1515 DNK'
 WHERE id=179486545


   --row number: 3919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2970120 , [Content] ='DNK'
 WHERE id=179486546


   --row number: 3920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2970120 , [Content] ='EMEA'
 WHERE id=179486547


   --row number: 3921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2970120 , [Content] ='DENMARK'
 WHERE id=179486548


   --row number: 3922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2970120 , [Content] ='Professional Services'
 WHERE id=179486549


   --row number: 3923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2970120 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=179486550


   --row number: 3924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2970120 , [Content] ='Solution Architect'
 WHERE id=179486551


   --row number: 3925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2970120 , [Content] ='IC5'
 WHERE id=179486552


   --row number: 3926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2970120 , [Content] ='DKK'
 WHERE id=179486554


   --row number: 3927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2970120 , [Content] ='25%'
 WHERE id=179486555


   --row number: 3928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2970120 , [Content] ='No'
 WHERE id=179486556


   --row number: 3929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2970120 , [Content] ='4 - Sales Workers'
 WHERE id=179486557


   --row number: 3930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2970120 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179486558


   --row number: 3931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2970120 , [Content] ='Technical'
 WHERE id=179486559


   --row number: 3932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2970120 , [Content] ='4/25/2018'
 WHERE id=179486560


   --row number: 3933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2970430 , [Content] ='4/25/2018'
 WHERE id=179509963


   --row number: 3934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2970430 , [Content] ='5143 IND'
 WHERE id=179509946


   --row number: 3935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2970430 , [Content] ='IND'
 WHERE id=179509947


   --row number: 3936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2970430 , [Content] ='APAC'
 WHERE id=179509948


   --row number: 3937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2970430 , [Content] ='INDIA'
 WHERE id=179509949


   --row number: 3938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2970430 , [Content] ='Engineering'
 WHERE id=179509950


   --row number: 3939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2970430 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=179509951


   --row number: 3940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2970430 , [Content] ='Software'
 WHERE id=179509952


   --row number: 3941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2970430 , [Content] ='IC3'
 WHERE id=179509953


   --row number: 3942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2970430 , [Content] ='INR'
 WHERE id=179509955


   --row number: 3943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2970430 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=179509956


   --row number: 3944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2970430 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=179509957


   --row number: 3945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2970430 , [Content] ='15%'
 WHERE id=179509958


   --row number: 3946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2970430 , [Content] ='Yes'
 WHERE id=179509959


   --row number: 3947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2970430 , [Content] ='2 - Professionals'
 WHERE id=179509960


   --row number: 3948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2970430 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=179509961


   --row number: 3949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2970430 , [Content] ='Technical'
 WHERE id=179509962


   --row number: 3950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2970783 , [Content] ='Technical'
 WHERE id=179545183


   --row number: 3951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2970783 , [Content] ='4/25/2018'
 WHERE id=179545184


   --row number: 3952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2970783 , [Content] ='2183 US - MRKT 1'
 WHERE id=179545165


   --row number: 3953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2970783 , [Content] ='US - MRKT 1'
 WHERE id=179545166


   --row number: 3954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2970783 , [Content] ='AMS'
 WHERE id=179545167


   --row number: 3955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2970783 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179545168


   --row number: 3956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2970783 , [Content] ='Engineering'
 WHERE id=179545169


   --row number: 3957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2970783 , [Content] ='2183 - Mgr,  Software QA Engineering Mgmt M3'
 WHERE id=179545170


   --row number: 3958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2970783 , [Content] ='Quality'
 WHERE id=179545171


   --row number: 3959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2970783 , [Content] ='M3'
 WHERE id=179545172


   --row number: 3960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2970783 , [Content] ='USD'
 WHERE id=179545174


   --row number: 3961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2970783 , [Content] ='114,900 / 139,000 / 163,100 / 187,150 / 211,200'
 WHERE id=179545175


   --row number: 3962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2970783 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=179545176


   --row number: 3963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2970783 , [Content] ='20%'
 WHERE id=179545177


   --row number: 3964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2970783 , [Content] ='Yes'
 WHERE id=179545178


   --row number: 3965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2970783 , [Content] ='EXEMPT'
 WHERE id=179545179


   --row number: 3966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2970783 , [Content] ='NO'
 WHERE id=179545180


   --row number: 3967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2970783 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=179545181


   --row number: 3968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2970783 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=179545182


   --row number: 3969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2971284 , [Content] ='S1333 IRL'
 WHERE id=179590710


   --row number: 3970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2971284 , [Content] ='IRL'
 WHERE id=179590711


   --row number: 3971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2971284 , [Content] ='EMEA'
 WHERE id=179590712


   --row number: 3972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2971284 , [Content] ='IRELAND'
 WHERE id=179590713


   --row number: 3973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2971284 , [Content] ='Sales'
 WHERE id=179590714


   --row number: 3974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2971284 , [Content] ='S1333 - Account Development Rep A3'
 WHERE id=179590715


   --row number: 3975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2971284 , [Content] ='Inside Sales'
 WHERE id=179590716


   --row number: 3976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2971284 , [Content] ='A3'
 WHERE id=179590717


   --row number: 3977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2971284 , [Content] ='EUR'
 WHERE id=179590719


   --row number: 3978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2971284 , [Content] ='31,110 / 33,855 / 36,600 / 39,345 / 42,090'
 WHERE id=179590720


   --row number: 3979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2971284 , [Content] ='51,850 / 56,425 / 61,000 / 65,575 / 70,150'
 WHERE id=179590721


   --row number: 3980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2971284 , [Content] ='60/40'
 WHERE id=179590722


   --row number: 3981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2971284 , [Content] ='No'
 WHERE id=179590723


   --row number: 3982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2971284 , [Content] ='4 - Sales Workers'
 WHERE id=179590724


   --row number: 3983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2971284 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179590725


   --row number: 3984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2971284 , [Content] ='Non Technical'
 WHERE id=179590726


   --row number: 3985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2971284 , [Content] ='06/08/18'
 WHERE id=179590727


   --row number: 3986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2971339 , [Content] ='S1806 US - MRKT 1'
 WHERE id=179595291


   --row number: 3987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2971339 , [Content] ='US - MRKT 1'
 WHERE id=179595292


   --row number: 3988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2971339 , [Content] ='AMS'
 WHERE id=179595293


   --row number: 3989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2971339 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179595294


   --row number: 3990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2971339 , [Content] ='Sales Operations'
 WHERE id=179595295


   --row number: 3991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2971339 , [Content] ='S1806 - Sr Dir, Sales Operations Mgmt M6'
 WHERE id=179595296


   --row number: 3992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2971339 , [Content] ='Sales Operations'
 WHERE id=179595297


   --row number: 3993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2971339 , [Content] ='M6'
 WHERE id=179595298


   --row number: 3994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2971339 , [Content] ='USD'
 WHERE id=179595300


   --row number: 3995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2971339 , [Content] ='153,700 / 188,300 / 222,900 / 257,450 / 292,000'
 WHERE id=179595301


   --row number: 3996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2971339 , [Content] ='Technical'
 WHERE id=179595309


   --row number: 3997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2971339 , [Content] ='4/25/2018'
 WHERE id=179595310


   --row number: 3998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2971339 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=179595302


   --row number: 3999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2971339 , [Content] ='30%'
 WHERE id=179595303


   --row number: 4000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2971339 , [Content] ='Yes'
 WHERE id=179595304


   --row number: 4001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2971339 , [Content] ='EXEMPT'
 WHERE id=179595305


   --row number: 4002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2971339 , [Content] ='NO'
 WHERE id=179595306


   --row number: 4003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2971339 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=179595307


   --row number: 4004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2971339 , [Content] ='8742-Salespersons - Outside'
 WHERE id=179595308


   --row number: 4005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2971767 , [Content] ='IC5'
 WHERE id=179662273


   --row number: 4006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2971767 , [Content] ='4 - Sales Workers'
 WHERE id=179662283


   --row number: 4007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2971767 , [Content] ='8742-Salespersons - Outside'
 WHERE id=179662284


   --row number: 4008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2971767 , [Content] ='Technical'
 WHERE id=179662285


   --row number: 4009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2971767 , [Content] ='10/05/18'
 WHERE id=179662286


   --row number: 4010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2971767 , [Content] ='USD'
 WHERE id=179662275


   --row number: 4011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2971767 , [Content] ='S1415 US - MRKT 1'
 WHERE id=179662266


   --row number: 4012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2971767 , [Content] ='US - MRKT 1'
 WHERE id=179662267


   --row number: 4013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2971767 , [Content] ='AMS'
 WHERE id=179662268


   --row number: 4014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2971767 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179662269


   --row number: 4015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2971767 , [Content] ='Solution Consulting'
 WHERE id=179662270


   --row number: 4016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2971767 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=179662271


   --row number: 4017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2971767 , [Content] ='Solution Consultant Core'
 WHERE id=179662272


   --row number: 4018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2971767 , [Content] ='140,888 / 153,319 / 165,750 / 178,181 / 190,613'
 WHERE id=179662276


   --row number: 4019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2971767 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=179662277


   --row number: 4020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2971767 , [Content] ='187,850 / 204,425 / 221,000 / 237,575 / 254,150'
 WHERE id=179662278


   --row number: 4021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2971767 , [Content] ='75/25'
 WHERE id=179662279


   --row number: 4022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2971767 , [Content] ='Yes'
 WHERE id=179662280


   --row number: 4023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2971767 , [Content] ='EXEMPT'
 WHERE id=179662281


   --row number: 4024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2971767 , [Content] ='NO'
 WHERE id=179662282


   --row number: 4025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2972231 , [Content] ='Technical'
 WHERE id=179714435


   --row number: 4026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2972231 , [Content] ='5/16/2018'
 WHERE id=179714436


   --row number: 4027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2972231 , [Content] ='S635 TUR'
 WHERE id=179714418


   --row number: 4028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2972231 , [Content] ='TUR'
 WHERE id=179714419


   --row number: 4029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2972231 , [Content] ='EMEA'
 WHERE id=179714420


   --row number: 4030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2972231 , [Content] ='TURKEY'
 WHERE id=179714421


   --row number: 4031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2972231 , [Content] ='Sales'
 WHERE id=179714422


   --row number: 4032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2972231 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=179714423


   --row number: 4033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2972231 , [Content] ='Enterprise Accounts'
 WHERE id=179714424


   --row number: 4034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2972231 , [Content] ='IC5'
 WHERE id=179714425


   --row number: 4035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2972231 , [Content] ='TRY'
 WHERE id=179714427


   --row number: 4036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2972231 , [Content] ='225,250 / 245,125 / 265,000 / 284,875 / 304,750'
 WHERE id=179714428


   --row number: 4037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2972231 , [Content] ='53,400 / 74,700 / 96,000 / 117,300 / 138,600'
 WHERE id=179714429


   --row number: 4038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2972231 , [Content] ='450,500 / 490,250 / 530,000 / 569,750 / 609,500'
 WHERE id=179714430


   --row number: 4039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2972231 , [Content] ='50/50'
 WHERE id=179714431


   --row number: 4040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2972231 , [Content] ='Yes'
 WHERE id=179714432


   --row number: 4041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2972231 , [Content] ='4 - Sales Workers'
 WHERE id=179714433


   --row number: 4042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2972231 , [Content] ='8742-Salespersons - Outside'
 WHERE id=179714434


   --row number: 4043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2973093 , [Content] ='2 - Professionals'
 WHERE id=179782232


   --row number: 4044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2973093 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=179782233


   --row number: 4045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2973093 , [Content] ='Technical'
 WHERE id=179782234


   --row number: 4046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2973093 , [Content] ='5/16/2018'
 WHERE id=179782235


   --row number: 4047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2973093 , [Content] ='5143 US - MRKT 2'
 WHERE id=179782216


   --row number: 4048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2973093 , [Content] ='US - MRKT 2'
 WHERE id=179782217


   --row number: 4049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2973093 , [Content] ='AMS'
 WHERE id=179782218


   --row number: 4050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2973093 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179782219


   --row number: 4051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2973093 , [Content] ='Engineering'
 WHERE id=179782220


   --row number: 4052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2973093 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=179782221


   --row number: 4053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2973093 , [Content] ='Software'
 WHERE id=179782222


   --row number: 4054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2973093 , [Content] ='IC3'
 WHERE id=179782223


   --row number: 4055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2973093 , [Content] ='USD'
 WHERE id=179782225


   --row number: 4056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2973093 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=179782226


   --row number: 4057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2973093 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=179782227


   --row number: 4058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2973093 , [Content] ='15%'
 WHERE id=179782228


   --row number: 4059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2973093 , [Content] ='Yes'
 WHERE id=179782229


   --row number: 4060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2973093 , [Content] ='EXEMPT'
 WHERE id=179782230


   --row number: 4061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2973093 , [Content] ='NO'
 WHERE id=179782231


   --row number: 4062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2973103 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=179782751


   --row number: 4063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2973103 , [Content] ='Technical'
 WHERE id=179782752


   --row number: 4064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2973103 , [Content] ='6/27/2018'
 WHERE id=179782753


   --row number: 4065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2973103 , [Content] ='5142 US - MRKT 2'
 WHERE id=179782734


   --row number: 4066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2973103 , [Content] ='US - MRKT 2'
 WHERE id=179782735


   --row number: 4067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2973103 , [Content] ='AMS'
 WHERE id=179782736


   --row number: 4068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2973103 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179782737


   --row number: 4069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2973103 , [Content] ='Engineering'
 WHERE id=179782738


   --row number: 4070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2973103 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=179782739


   --row number: 4071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2973103 , [Content] ='Software'
 WHERE id=179782740


   --row number: 4072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2973103 , [Content] ='IC2'
 WHERE id=179782741


   --row number: 4073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2973103 , [Content] ='USD'
 WHERE id=179782743


   --row number: 4074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2973103 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=179782744


   --row number: 4075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2973103 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=179782745


   --row number: 4076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2973103 , [Content] ='10%'
 WHERE id=179782746


   --row number: 4077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2973103 , [Content] ='Yes'
 WHERE id=179782747


   --row number: 4078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2973103 , [Content] ='EXEMPT'
 WHERE id=179782748


   --row number: 4079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2973103 , [Content] ='NO'
 WHERE id=179782749


   --row number: 4080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2973103 , [Content] ='2 - Professionals'
 WHERE id=179782750


   --row number: 4081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2974239 , [Content] ='Non Technical'
 WHERE id=179823499


   --row number: 4082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2974239 , [Content] ='5/16/2018'
 WHERE id=179823500


   --row number: 4083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2974239 , [Content] ='5614 US - MRKT 1'
 WHERE id=179823481


   --row number: 4084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2974239 , [Content] ='US - MRKT 1'
 WHERE id=179823482


   --row number: 4085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2974239 , [Content] ='AMS'
 WHERE id=179823483


   --row number: 4086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2974239 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179823484


   --row number: 4087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2974239 , [Content] ='Marketing'
 WHERE id=179823485


   --row number: 4088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2974239 , [Content] ='5614 - Marketing Mgr IC4'
 WHERE id=179823486


   --row number: 4089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2974239 , [Content] ='Marketing'
 WHERE id=179823487


   --row number: 4090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2974239 , [Content] ='IC4'
 WHERE id=179823488


   --row number: 4091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2974239 , [Content] ='USD'
 WHERE id=179823490


   --row number: 4092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2974239 , [Content] ='107,200 / 126,500 / 145,800 / 165,100 / 184,400'
 WHERE id=179823491


   --row number: 4093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2974239 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=179823492


   --row number: 4094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2974239 , [Content] ='15%'
 WHERE id=179823493


   --row number: 4095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2974239 , [Content] ='Yes'
 WHERE id=179823494


   --row number: 4096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2974239 , [Content] ='EXEMPT'
 WHERE id=179823495


   --row number: 4097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2974239 , [Content] ='NO'
 WHERE id=179823496


   --row number: 4098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2974239 , [Content] ='2 - Professionals'
 WHERE id=179823497


   --row number: 4099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2974239 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179823498


   --row number: 4100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2975486 , [Content] ='6223 UK'
 WHERE id=179919490


   --row number: 4101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2975486 , [Content] ='UK'
 WHERE id=179919491


   --row number: 4102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2975486 , [Content] ='EMEA'
 WHERE id=179919492


   --row number: 4103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2975486 , [Content] ='UNITED KINGDOM'
 WHERE id=179919493


   --row number: 4104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2975486 , [Content] ='Human Resources'
 WHERE id=179919494


   --row number: 4105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2975486 , [Content] ='6223 - Recruiter/Staffing Representative IC3'
 WHERE id=179919495


   --row number: 4106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2975486 , [Content] ='Staffing'
 WHERE id=179919496


   --row number: 4107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2975486 , [Content] ='IC3'
 WHERE id=179919497


   --row number: 4108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2975486 , [Content] ='GBP'
 WHERE id=179919499


   --row number: 4109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2975486 , [Content] ='38,600 / 45,000 / 51,400 / 57,750 / 64,100'
 WHERE id=179919500


   --row number: 4110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2975486 , [Content] ='10%'
 WHERE id=179919501


   --row number: 4111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2975486 , [Content] ='No'
 WHERE id=179919502


   --row number: 4112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2975486 , [Content] ='2 - Professionals'
 WHERE id=179919503


   --row number: 4113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2975486 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179919504


   --row number: 4114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2975486 , [Content] ='Non Technical'
 WHERE id=179919505


   --row number: 4115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2975486 , [Content] ='5/16/2018'
 WHERE id=179919506


   --row number: 4116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2975537 , [Content] ='6224 UK'
 WHERE id=179922832


   --row number: 4117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2975537 , [Content] ='UK'
 WHERE id=179922833


   --row number: 4118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2975537 , [Content] ='EMEA'
 WHERE id=179922834


   --row number: 4119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2975537 , [Content] ='UNITED KINGDOM'
 WHERE id=179922835


   --row number: 4120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2975537 , [Content] ='Human Resources'
 WHERE id=179922836


   --row number: 4121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2975537 , [Content] ='6224 - Recruiter/Staffing Representative IC4'
 WHERE id=179922837


   --row number: 4122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2975537 , [Content] ='Staffing'
 WHERE id=179922838


   --row number: 4123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2975537 , [Content] ='IC4'
 WHERE id=179922839


   --row number: 4124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2975537 , [Content] ='GBP'
 WHERE id=179922841


   --row number: 4125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2975537 , [Content] ='47,600 / 56,150 / 64,700 / 73,300 / 81,900'
 WHERE id=179922842


   --row number: 4126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2975537 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=179922843


   --row number: 4127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2975537 , [Content] ='15%'
 WHERE id=179922844


   --row number: 4128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2975537 , [Content] ='Yes'
 WHERE id=179922845


   --row number: 4129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2975537 , [Content] ='2 - Professionals'
 WHERE id=179922846


   --row number: 4130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2975537 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179922847


   --row number: 4131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2975537 , [Content] ='Non Technical'
 WHERE id=179922848


   --row number: 4132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2975537 , [Content] ='5/16/2018'
 WHERE id=179922849


   --row number: 4133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2975563 , [Content] ='Technical'
 WHERE id=179924504


   --row number: 4134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2975563 , [Content] ='5/16/2018'
 WHERE id=179924505


   --row number: 4135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2975563 , [Content] ='S1414 NLD'
 WHERE id=179924487


   --row number: 4136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2975563 , [Content] ='NLD'
 WHERE id=179924488


   --row number: 4137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2975563 , [Content] ='EMEA'
 WHERE id=179924489


   --row number: 4138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2975563 , [Content] ='NETHERLANDS'
 WHERE id=179924490


   --row number: 4139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2975563 , [Content] ='Solution Consulting'
 WHERE id=179924491


   --row number: 4140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2975563 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=179924492


   --row number: 4141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2975563 , [Content] ='Solution Consultant Core'
 WHERE id=179924493


   --row number: 4142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2975563 , [Content] ='IC4'
 WHERE id=179924494


   --row number: 4143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2975563 , [Content] ='EUR'
 WHERE id=179924496


   --row number: 4144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2975563 , [Content] ='72,038 / 78,394 / 84,750 / 91,106 / 97,463'
 WHERE id=179924497


   --row number: 4145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2975563 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=179924498


   --row number: 4146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2975563 , [Content] ='96,050 / 104,525 / 113,000 / 121,475 / 129,950'
 WHERE id=179924499


   --row number: 4147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2975563 , [Content] ='75/25'
 WHERE id=179924500


   --row number: 4148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2975563 , [Content] ='Yes'
 WHERE id=179924501


   --row number: 4149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2975563 , [Content] ='4 - Sales Workers'
 WHERE id=179924502


   --row number: 4150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2975563 , [Content] ='8742-Salespersons - Outside'
 WHERE id=179924503


   --row number: 4151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2975922 , [Content] ='Technical'
 WHERE id=179948443


   --row number: 4152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2975922 , [Content] ='5/16/2018'
 WHERE id=179948444


   --row number: 4153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2975922 , [Content] ='5223 US - MRKT 2'
 WHERE id=179948425


   --row number: 4154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2975922 , [Content] ='US - MRKT 2'
 WHERE id=179948426


   --row number: 4155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2975922 , [Content] ='AMS'
 WHERE id=179948427


   --row number: 4156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2975922 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179948428


   --row number: 4157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2975922 , [Content] ='Engineering'
 WHERE id=179948429


   --row number: 4158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2975922 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=179948430


   --row number: 4159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2975922 , [Content] ='Product Mgmt Mgr'
 WHERE id=179948431


   --row number: 4160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2975922 , [Content] ='IC3'
 WHERE id=179948432


   --row number: 4161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2975922 , [Content] ='USD'
 WHERE id=179948434


   --row number: 4162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2975922 , [Content] ='89,000 / 105,000 / 121,000 / 137,050 / 153,100'
 WHERE id=179948435


   --row number: 4163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2975922 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=179948436


   --row number: 4164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2975922 , [Content] ='15%'
 WHERE id=179948437


   --row number: 4165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2975922 , [Content] ='Yes'
 WHERE id=179948438


   --row number: 4166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2975922 , [Content] ='EXEMPT'
 WHERE id=179948439


   --row number: 4167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2975922 , [Content] ='NO'
 WHERE id=179948440


   --row number: 4168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2975922 , [Content] ='2 - Professionals'
 WHERE id=179948441


   --row number: 4169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2975922 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179948442


   --row number: 4170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2976401 , [Content] ='Technical'
 WHERE id=179978640


   --row number: 4171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2976401 , [Content] ='5/16/2018'
 WHERE id=179978641


   --row number: 4172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2976401 , [Content] ='5725 US - MRKT 1'
 WHERE id=179978622


   --row number: 4173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2976401 , [Content] ='US - MRKT 1'
 WHERE id=179978623


   --row number: 4174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2976401 , [Content] ='AMS'
 WHERE id=179978624


   --row number: 4175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2976401 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=179978625


   --row number: 4176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2976401 , [Content] ='Professional Services'
 WHERE id=179978626


   --row number: 4177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2976401 , [Content] ='5725 - Expert Services Consultant IC5'
 WHERE id=179978627


   --row number: 4178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2976401 , [Content] ='Expert Services'
 WHERE id=179978628


   --row number: 4179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2976401 , [Content] ='IC5'
 WHERE id=179978629


   --row number: 4180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2976401 , [Content] ='USD'
 WHERE id=179978631


   --row number: 4181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2976401 , [Content] ='125,400 / 153,650 / 181,900 / 210,100 / 238,300'
 WHERE id=179978632


   --row number: 4182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2976401 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=179978633


   --row number: 4183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2976401 , [Content] ='25%'
 WHERE id=179978634


   --row number: 4184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2976401 , [Content] ='Yes'
 WHERE id=179978635


   --row number: 4185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2976401 , [Content] ='EXEMPT'
 WHERE id=179978636


   --row number: 4186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2976401 , [Content] ='NO'
 WHERE id=179978637


   --row number: 4187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2976401 , [Content] ='2 - Professionals'
 WHERE id=179978638


   --row number: 4188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2976401 , [Content] ='8810-Clerical Office Employees'
 WHERE id=179978639


   --row number: 4189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2977001 , [Content] ='5182 IND'
 WHERE id=180218647


   --row number: 4190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2977001 , [Content] ='IND'
 WHERE id=180218648


   --row number: 4191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2977001 , [Content] ='APAC'
 WHERE id=180218649


   --row number: 4192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2977001 , [Content] ='INDIA'
 WHERE id=180218650


   --row number: 4193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2977001 , [Content] ='Engineering'
 WHERE id=180218651


   --row number: 4194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2977001 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=180218652


   --row number: 4195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2977001 , [Content] ='Quality'
 WHERE id=180218653


   --row number: 4196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2977001 , [Content] ='IC2'
 WHERE id=180218654


   --row number: 4197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2977001 , [Content] ='INR'
 WHERE id=180218656


   --row number: 4198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2977001 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=180218657


   --row number: 4199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2977001 , [Content] ='10%'
 WHERE id=180218659


   --row number: 4200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2977001 , [Content] ='No'
 WHERE id=180218660


   --row number: 4201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2977001 , [Content] ='2 - Professionals'
 WHERE id=180218661


   --row number: 4202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2977001 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180218662


   --row number: 4203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2977001 , [Content] ='Technical'
 WHERE id=180218663


   --row number: 4204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2977001 , [Content] ='6/27/2018'
 WHERE id=180218664


   --row number: 4205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2977228 , [Content] ='5142 IND'
 WHERE id=180246904


   --row number: 4206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2977228 , [Content] ='IND'
 WHERE id=180246905


   --row number: 4207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2977228 , [Content] ='APAC'
 WHERE id=180246906


   --row number: 4208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2977228 , [Content] ='INDIA'
 WHERE id=180246907


   --row number: 4209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2977228 , [Content] ='Engineering'
 WHERE id=180246908


   --row number: 4210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2977228 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=180246909


   --row number: 4211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2977228 , [Content] ='Software'
 WHERE id=180246910


   --row number: 4212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2977228 , [Content] ='IC2'
 WHERE id=180246911


   --row number: 4213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2977228 , [Content] ='INR'
 WHERE id=180246913


   --row number: 4214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2977228 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=180246914


   --row number: 4215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2977228 , [Content] ='10%'
 WHERE id=180246915


   --row number: 4216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2977228 , [Content] ='No'
 WHERE id=180246916


   --row number: 4217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2977228 , [Content] ='2 - Professionals'
 WHERE id=180246917


   --row number: 4218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2977228 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180246918


   --row number: 4219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2977228 , [Content] ='Technical'
 WHERE id=180246919


   --row number: 4220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2977228 , [Content] ='10/05/18'
 WHERE id=180246920


   --row number: 4221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2977257 , [Content] ='6402 IND'
 WHERE id=180248962


   --row number: 4222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2977257 , [Content] ='IND'
 WHERE id=180248963


   --row number: 4223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2977257 , [Content] ='APAC'
 WHERE id=180248964


   --row number: 4224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2977257 , [Content] ='INDIA'
 WHERE id=180248965


   --row number: 4225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2977257 , [Content] ='Info Systems/Technology'
 WHERE id=180248966


   --row number: 4226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2977257 , [Content] ='6402 - Information Systems Engineer IC2'
 WHERE id=180248967


   --row number: 4227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2977257 , [Content] ='Information Systems'
 WHERE id=180248968


   --row number: 4228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2977257 , [Content] ='IC2'
 WHERE id=180248969


   --row number: 4229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2977257 , [Content] ='INR'
 WHERE id=180248971


   --row number: 4230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2977257 , [Content] ='758,600 / 929,300 / 1,100,000 / 1,270,650 / 1,441,300'
 WHERE id=180248972


   --row number: 4231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2977257 , [Content] ='10%'
 WHERE id=180248973


   --row number: 4232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2977257 , [Content] ='No'
 WHERE id=180248974


   --row number: 4233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2977257 , [Content] ='2 - Professionals'
 WHERE id=180248975


   --row number: 4234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2977257 , [Content] ='8810-Clerical Office Employees'
 WHERE id=180248976


   --row number: 4235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2977257 , [Content] ='Technical'
 WHERE id=180248977


   --row number: 4236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2977257 , [Content] ='5/16/2018'
 WHERE id=180248978


   --row number: 4237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2977265 , [Content] ='6462 IND'
 WHERE id=180249645


   --row number: 4238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2977265 , [Content] ='IND'
 WHERE id=180249646


   --row number: 4239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2977265 , [Content] ='APAC'
 WHERE id=180249647


   --row number: 4240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2977265 , [Content] ='INDIA'
 WHERE id=180249648


   --row number: 4241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2977265 , [Content] ='Info Systems/Technology'
 WHERE id=180249649


   --row number: 4242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2977265 , [Content] ='6462 - Business Systems Analyst IC2'
 WHERE id=180249650


   --row number: 4243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2977265 , [Content] ='Business Systems Analysis'
 WHERE id=180249651


   --row number: 4244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2977265 , [Content] ='IC2'
 WHERE id=180249652


   --row number: 4245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2977265 , [Content] ='INR'
 WHERE id=180249654


   --row number: 4246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2977265 , [Content] ='717,200 / 878,600 / 1,040,000 / 1,201,350 / 1,362,700'
 WHERE id=180249655


   --row number: 4247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2977265 , [Content] ='10%'
 WHERE id=180249656


   --row number: 4248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2977265 , [Content] ='No'
 WHERE id=180249657


   --row number: 4249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2977265 , [Content] ='2 - Professionals'
 WHERE id=180249658


   --row number: 4250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2977265 , [Content] ='8810-Clerical Office Employees'
 WHERE id=180249659


   --row number: 4251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2977265 , [Content] ='Technical'
 WHERE id=180249660


   --row number: 4252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2977265 , [Content] ='5/16/2018'
 WHERE id=180249661


   --row number: 4253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2977999 , [Content] ='5/16/2018'
 WHERE id=180315813


   --row number: 4254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2977999 , [Content] ='5143 IND'
 WHERE id=180315796


   --row number: 4255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2977999 , [Content] ='IND'
 WHERE id=180315797


   --row number: 4256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2977999 , [Content] ='APAC'
 WHERE id=180315798


   --row number: 4257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2977999 , [Content] ='INDIA'
 WHERE id=180315799


   --row number: 4258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2977999 , [Content] ='Engineering'
 WHERE id=180315800


   --row number: 4259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2977999 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=180315801


   --row number: 4260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2977999 , [Content] ='Software'
 WHERE id=180315802


   --row number: 4261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2977999 , [Content] ='IC3'
 WHERE id=180315803


   --row number: 4262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2977999 , [Content] ='INR'
 WHERE id=180315805


   --row number: 4263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2977999 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=180315806


   --row number: 4264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2977999 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=180315807


   --row number: 4265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2977999 , [Content] ='15%'
 WHERE id=180315808


   --row number: 4266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2977999 , [Content] ='Yes'
 WHERE id=180315809


   --row number: 4267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2977999 , [Content] ='2 - Professionals'
 WHERE id=180315810


   --row number: 4268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2977999 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180315811


   --row number: 4269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2977999 , [Content] ='Technical'
 WHERE id=180315812


   --row number: 4270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2978011 , [Content] ='Technical'
 WHERE id=180316841


   --row number: 4271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2978011 , [Content] ='5/16/2018'
 WHERE id=180316842


   --row number: 4272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2978011 , [Content] ='5143 IND'
 WHERE id=180316825


   --row number: 4273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2978011 , [Content] ='IND'
 WHERE id=180316826


   --row number: 4274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2978011 , [Content] ='APAC'
 WHERE id=180316827


   --row number: 4275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2978011 , [Content] ='INDIA'
 WHERE id=180316828


   --row number: 4276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2978011 , [Content] ='Engineering'
 WHERE id=180316829


   --row number: 4277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2978011 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=180316830


   --row number: 4278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2978011 , [Content] ='Software'
 WHERE id=180316831


   --row number: 4279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2978011 , [Content] ='IC3'
 WHERE id=180316832


   --row number: 4280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2978011 , [Content] ='INR'
 WHERE id=180316834


   --row number: 4281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2978011 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=180316835


   --row number: 4282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2978011 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=180316836


   --row number: 4283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2978011 , [Content] ='15%'
 WHERE id=180316837


   --row number: 4284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2978011 , [Content] ='Yes'
 WHERE id=180316838


   --row number: 4285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2978011 , [Content] ='2 - Professionals'
 WHERE id=180316839


   --row number: 4286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2978011 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180316840


   --row number: 4287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2978388 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180360704


   --row number: 4288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2978388 , [Content] ='Technical'
 WHERE id=180360705


   --row number: 4289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2978388 , [Content] ='5143 US - MRKT 1'
 WHERE id=180360688


   --row number: 4290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2978388 , [Content] ='US - MRKT 1'
 WHERE id=180360689


   --row number: 4291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2978388 , [Content] ='AMS'
 WHERE id=180360690


   --row number: 4292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2978388 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=180360691


   --row number: 4293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2978388 , [Content] ='Engineering'
 WHERE id=180360692


   --row number: 4294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2978388 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=180360693


   --row number: 4295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2978388 , [Content] ='Software'
 WHERE id=180360694


   --row number: 4296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2978388 , [Content] ='IC3'
 WHERE id=180360695


   --row number: 4297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2978388 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=180360697


   --row number: 4298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2978388 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=180360698


   --row number: 4299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2978388 , [Content] ='15%'
 WHERE id=180360699


   --row number: 4300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2978388 , [Content] ='Yes'
 WHERE id=180360700


   --row number: 4301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2978388 , [Content] ='EXEMPT'
 WHERE id=180360701


   --row number: 4302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2978388 , [Content] ='NO'
 WHERE id=180360702


   --row number: 4303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2978388 , [Content] ='2 - Professionals'
 WHERE id=180360703


   --row number: 4304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2978411 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180363376


   --row number: 4305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2978411 , [Content] ='Technical'
 WHERE id=180363377


   --row number: 4306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2978411 , [Content] ='5/22/18'
 WHERE id=180363378


   --row number: 4307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2978411 , [Content] ='5234 US - MRKT 3'
 WHERE id=180363359


   --row number: 4308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2978411 , [Content] ='US - MRKT 3'
 WHERE id=180363360


   --row number: 4309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2978411 , [Content] ='AMS'
 WHERE id=180363361


   --row number: 4310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2978411 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=180363362


   --row number: 4311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2978411 , [Content] ='Engineering'
 WHERE id=180363363


   --row number: 4312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2978411 , [Content] ='5234 - Staff UI Engineer IC4'
 WHERE id=180363364


   --row number: 4313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2978411 , [Content] ='UI'
 WHERE id=180363365


   --row number: 4314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2978411 , [Content] ='IC4'
 WHERE id=180363366


   --row number: 4315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2978411 , [Content] ='USD'
 WHERE id=180363368


   --row number: 4316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2978411 , [Content] ='89,400 / 108,150 / 126,900 / 145,600 / 164,300'
 WHERE id=180363369


   --row number: 4317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2978411 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=180363370


   --row number: 4318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2978411 , [Content] ='20%'
 WHERE id=180363371


   --row number: 4319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2978411 , [Content] ='Yes'
 WHERE id=180363372


   --row number: 4320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2978411 , [Content] ='EXEMPT'
 WHERE id=180363373


   --row number: 4321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2978411 , [Content] ='2 - Professionals'
 WHERE id=180363375


   --row number: 4322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2979055 , [Content] ='5142 IND'
 WHERE id=180451332


   --row number: 4323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2979055 , [Content] ='IND'
 WHERE id=180451333


   --row number: 4324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2979055 , [Content] ='APAC'
 WHERE id=180451334


   --row number: 4325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2979055 , [Content] ='INDIA'
 WHERE id=180451335


   --row number: 4326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2979055 , [Content] ='Engineering'
 WHERE id=180451336


   --row number: 4327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2979055 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=180451337


   --row number: 4328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2979055 , [Content] ='Software'
 WHERE id=180451338


   --row number: 4329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2979055 , [Content] ='IC2'
 WHERE id=180451339


   --row number: 4330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2979055 , [Content] ='INR'
 WHERE id=180451341


   --row number: 4331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2979055 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=180451342


   --row number: 4332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2979055 , [Content] ='10%'
 WHERE id=180451343


   --row number: 4333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2979055 , [Content] ='No'
 WHERE id=180451344


   --row number: 4334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2979055 , [Content] ='2 - Professionals'
 WHERE id=180451345


   --row number: 4335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2979055 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180451346


   --row number: 4336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2979055 , [Content] ='Technical'
 WHERE id=180451347


   --row number: 4337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2979055 , [Content] ='5/16/2018'
 WHERE id=180451348


   --row number: 4338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2979057 , [Content] ='5142 IND'
 WHERE id=180451471


   --row number: 4339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2979057 , [Content] ='IND'
 WHERE id=180451472


   --row number: 4340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2979057 , [Content] ='APAC'
 WHERE id=180451473


   --row number: 4341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2979057 , [Content] ='INDIA'
 WHERE id=180451474


   --row number: 4342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2979057 , [Content] ='Engineering'
 WHERE id=180451475


   --row number: 4343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2979057 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=180451476


   --row number: 4344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2979057 , [Content] ='Software'
 WHERE id=180451477


   --row number: 4345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2979057 , [Content] ='IC2'
 WHERE id=180451478


   --row number: 4346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2979057 , [Content] ='INR'
 WHERE id=180451480


   --row number: 4347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2979057 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=180451481


   --row number: 4348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2979057 , [Content] ='10%'
 WHERE id=180451482


   --row number: 4349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2979057 , [Content] ='No'
 WHERE id=180451483


   --row number: 4350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2979057 , [Content] ='2 - Professionals'
 WHERE id=180451484


   --row number: 4351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2979057 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180451485


   --row number: 4352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2979057 , [Content] ='Technical'
 WHERE id=180451486


   --row number: 4353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2979057 , [Content] ='5/16/2018'
 WHERE id=180451487


   --row number: 4354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2979207 , [Content] ='5143 IND'
 WHERE id=180459989


   --row number: 4355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2979207 , [Content] ='IND'
 WHERE id=180459990


   --row number: 4356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2979207 , [Content] ='APAC'
 WHERE id=180459991


   --row number: 4357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2979207 , [Content] ='INDIA'
 WHERE id=180459992


   --row number: 4358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2979207 , [Content] ='Engineering'
 WHERE id=180459993


   --row number: 4359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2979207 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=180459994


   --row number: 4360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2979207 , [Content] ='Software'
 WHERE id=180459995


   --row number: 4361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2979207 , [Content] ='IC3'
 WHERE id=180459996


   --row number: 4362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2979207 , [Content] ='INR'
 WHERE id=180459998


   --row number: 4363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2979207 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=180459999


   --row number: 4364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2979207 , [Content] ='7/20/18'
 WHERE id=180460006


   --row number: 4365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2979207 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=180460000


   --row number: 4366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2979207 , [Content] ='15%'
 WHERE id=180460001


   --row number: 4367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2979207 , [Content] ='Yes'
 WHERE id=180460002


   --row number: 4368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2979207 , [Content] ='2 - Professionals'
 WHERE id=180460003


   --row number: 4369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2979207 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180460004


   --row number: 4370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2979207 , [Content] ='Technical'
 WHERE id=180460005


   --row number: 4371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2979212 , [Content] ='5143 IND'
 WHERE id=180460232


   --row number: 4372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2979212 , [Content] ='IND'
 WHERE id=180460233


   --row number: 4373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2979212 , [Content] ='APAC'
 WHERE id=180460234


   --row number: 4374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2979212 , [Content] ='INDIA'
 WHERE id=180460235


   --row number: 4375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2979212 , [Content] ='Engineering'
 WHERE id=180460236


   --row number: 4376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2982251 , [Content] ='NO'
 WHERE id=180711317


   --row number: 4377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2982251 , [Content] ='2 - Professionals'
 WHERE id=180711318


   --row number: 4378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2982251 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180711319


   --row number: 4379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2982251 , [Content] ='Technical'
 WHERE id=180711320


   --row number: 4380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2982251 , [Content] ='5/22/2018'
 WHERE id=180711321


   --row number: 4381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2982251 , [Content] ='AMS'
 WHERE id=180711304


   --row number: 4382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2982251 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=180711305


   --row number: 4383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2982251 , [Content] ='Engineering'
 WHERE id=180711306


   --row number: 4384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2982251 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=180711307


   --row number: 4385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2982251 , [Content] ='Quality'
 WHERE id=180711308


   --row number: 4386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2982251 , [Content] ='IC3'
 WHERE id=180711309


   --row number: 4387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2982251 , [Content] ='USD'
 WHERE id=180711311


   --row number: 4388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2982251 , [Content] ='95,500 / 112,700 / 129,900 / 147,100 / 164,300'
 WHERE id=180711312


   --row number: 4389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2982251 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=180711313


   --row number: 4390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2982251 , [Content] ='15%'
 WHERE id=180711314


   --row number: 4391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2982251 , [Content] ='Yes'
 WHERE id=180711315


   --row number: 4392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2982251 , [Content] ='EXEMPT'
 WHERE id=180711316


   --row number: 4393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2982251 , [Content] ='5183 US - MRKT 1'
 WHERE id=180711302


   --row number: 4394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2982251 , [Content] ='US - MRKT 1'
 WHERE id=180711303


   --row number: 4395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2915925 , [Content] ='52,300 / 59,750 / 67,200 / 74,650 / 82,100'
 WHERE id=180577003


   --row number: 4396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2982838 , [Content] ='6174 IND'
 WHERE id=180805447


   --row number: 4397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2982838 , [Content] ='IND'
 WHERE id=180805448


   --row number: 4398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2982838 , [Content] ='APAC'
 WHERE id=180805449


   --row number: 4399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2982838 , [Content] ='INDIA'
 WHERE id=180805450


   --row number: 4400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2982838 , [Content] ='Finance'
 WHERE id=180805451


   --row number: 4401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2982838 , [Content] ='6174 - Sr. Internal Auditor IC4'
 WHERE id=180805452


   --row number: 4402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2982838 , [Content] ='Internal Audit'
 WHERE id=180805453


   --row number: 4403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2982838 , [Content] ='IC4'
 WHERE id=180805454


   --row number: 4404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2982838 , [Content] ='5/22/2018'
 WHERE id=180805463


   --row number: 4405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2982838 , [Content] ='INR'
 WHERE id=180805456


   --row number: 4406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2982838 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=180805457


   --row number: 4407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2982838 , [Content] ='15%'
 WHERE id=180805458


   --row number: 4408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2982838 , [Content] ='Yes'
 WHERE id=180805459


   --row number: 4409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2982838 , [Content] ='2 - Professionals'
 WHERE id=180805460


   --row number: 4410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2982838 , [Content] ='8810-Clerical Office Employees'
 WHERE id=180805461


   --row number: 4411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2982838 , [Content] ='Non Technical'
 WHERE id=180805462


   --row number: 4412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2946228 , [Content] ='NO'
 WHERE id=191964553


   --row number: 4413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2920372 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=194348962


   --row number: 4414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2920372 , [Content] ='23,715 / 25,808 / 27,900 / 29,993 / 32,085'
 WHERE id=194348963


   --row number: 4415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2969924 , [Content] ='620,700 / 760,350 / 900,000 / 1,039,650 / 1,179,300'
 WHERE id=180594906


   --row number: 4416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2891805 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=193418489


   --row number: 4417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2849445 , [Content] ='81,700 / 100,100 / 118,500 / 136,850 / 155,200'
 WHERE id=194752307


   --row number: 4418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2936881 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=199003839


   --row number: 4419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2936881 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=199003840


   --row number: 4420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2917312 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=199923299


   --row number: 4421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2917312 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=199923300


   --row number: 4422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2856311 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=199256605


   --row number: 4423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2896863 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=202301337


   --row number: 4424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2917597 , [Content] ='124,900 / 152,950 / 181,000 / 209,150 / 237,300'
 WHERE id=204233444


   --row number: 4425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2979212 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=180460237


   --row number: 4426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2979212 , [Content] ='Software'
 WHERE id=180460238


   --row number: 4427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2979212 , [Content] ='IC3'
 WHERE id=180460239


   --row number: 4428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2979212 , [Content] ='INR'
 WHERE id=180460241


   --row number: 4429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2979212 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=180460242


   --row number: 4430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2979212 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=180460243


   --row number: 4431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2979212 , [Content] ='15%'
 WHERE id=180460244


   --row number: 4432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2979212 , [Content] ='Yes'
 WHERE id=180460245


   --row number: 4433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2979212 , [Content] ='2 - Professionals'
 WHERE id=180460246


   --row number: 4434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2979212 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180460247


   --row number: 4435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2979212 , [Content] ='Technical'
 WHERE id=180460248


   --row number: 4436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2979212 , [Content] ='7/20/18'
 WHERE id=180460249


   --row number: 4437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2977228 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=205384330


   --row number: 4438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2979464 , [Content] ='Technical'
 WHERE id=180479488


   --row number: 4439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2979464 , [Content] ='5/16/2018'
 WHERE id=180479489


   --row number: 4440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2979464 , [Content] ='6804 US - MRKT 1'
 WHERE id=180479470


   --row number: 4441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2979464 , [Content] ='US - MRKT 1'
 WHERE id=180479471


   --row number: 4442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2979464 , [Content] ='AMS'
 WHERE id=180479472


   --row number: 4443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2979464 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=180479473


   --row number: 4444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2979464 , [Content] ='Info Systems/Technology'
 WHERE id=180479474


   --row number: 4445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2979464 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=180479475


   --row number: 4446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2979464 , [Content] ='UI/UX Designer'
 WHERE id=180479476


   --row number: 4447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2979464 , [Content] ='IC4'
 WHERE id=180479477


   --row number: 4448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2979464 , [Content] ='USD'
 WHERE id=180479479


   --row number: 4449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2979464 , [Content] ='110,800 / 134,000 / 157,200 / 180,450 / 203,700'
 WHERE id=180479480


   --row number: 4450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2979464 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=180479481


   --row number: 4451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2979464 , [Content] ='20%'
 WHERE id=180479482


   --row number: 4452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2979464 , [Content] ='Yes'
 WHERE id=180479483


   --row number: 4453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2979464 , [Content] ='EXEMPT'
 WHERE id=180479484


   --row number: 4454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2979464 , [Content] ='NO'
 WHERE id=180479485


   --row number: 4455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2979464 , [Content] ='2 - Professionals'
 WHERE id=180479486


   --row number: 4456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2979464 , [Content] ='8810-Clerical Office Employees'
 WHERE id=180479487


   --row number: 4457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2980739 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180574330


   --row number: 4458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2980739 , [Content] ='Technical'
 WHERE id=180574331


   --row number: 4459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2980739 , [Content] ='1/29/18'
 WHERE id=180574332


   --row number: 4460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2980739 , [Content] ='5182 US - MRKT 2'
 WHERE id=180574313


   --row number: 4461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2980739 , [Content] ='US - MRKT 2'
 WHERE id=180574314


   --row number: 4462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2980739 , [Content] ='AMS'
 WHERE id=180574315


   --row number: 4463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2980739 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=180574316


   --row number: 4464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2980739 , [Content] ='Engineering'
 WHERE id=180574317


   --row number: 4465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2980739 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=180574318


   --row number: 4466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2980739 , [Content] ='Quality'
 WHERE id=180574319


   --row number: 4467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2980739 , [Content] ='IC2'
 WHERE id=180574320


   --row number: 4468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2980739 , [Content] ='USD'
 WHERE id=180574322


   --row number: 4469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2980739 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=180574323


   --row number: 4470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2980739 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=180574324


   --row number: 4471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2980739 , [Content] ='10%'
 WHERE id=180574325


   --row number: 4472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2980739 , [Content] ='Yes'
 WHERE id=180574326


   --row number: 4473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2980739 , [Content] ='EXEMPT'
 WHERE id=180574327


   --row number: 4474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2980739 , [Content] ='NO'
 WHERE id=180574328


   --row number: 4475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2980739 , [Content] ='2 - Professionals'
 WHERE id=180574329


   --row number: 4476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2982004 , [Content] ='5/22/2018'
 WHERE id=180689446


   --row number: 4477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2982004 , [Content] ='5144 IND'
 WHERE id=180689429


   --row number: 4478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2982004 , [Content] ='IND'
 WHERE id=180689430


   --row number: 4479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2982004 , [Content] ='APAC'
 WHERE id=180689431


   --row number: 4480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2982004 , [Content] ='INDIA'
 WHERE id=180689432


   --row number: 4481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2982004 , [Content] ='Engineering'
 WHERE id=180689433


   --row number: 4482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2982004 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=180689434


   --row number: 4483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2982004 , [Content] ='Software'
 WHERE id=180689435


   --row number: 4484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2982004 , [Content] ='IC4'
 WHERE id=180689436


   --row number: 4485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2982004 , [Content] ='INR'
 WHERE id=180689438


   --row number: 4486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2982004 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=180689439


   --row number: 4487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2982004 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=180689440


   --row number: 4488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2982004 , [Content] ='20%'
 WHERE id=180689441


   --row number: 4489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2982004 , [Content] ='Yes'
 WHERE id=180689442


   --row number: 4490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2982004 , [Content] ='2 - Professionals'
 WHERE id=180689443


   --row number: 4491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2982004 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180689444


   --row number: 4492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2982004 , [Content] ='Technical'
 WHERE id=180689445


   --row number: 4493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2982118 , [Content] ='5142 IND'
 WHERE id=180699328


   --row number: 4494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2982118 , [Content] ='IND'
 WHERE id=180699329


   --row number: 4495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2982118 , [Content] ='APAC'
 WHERE id=180699330


   --row number: 4496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2982118 , [Content] ='INDIA'
 WHERE id=180699331


   --row number: 4497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2982118 , [Content] ='Engineering'
 WHERE id=180699332


   --row number: 4498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2982118 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=180699333


   --row number: 4499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2982118 , [Content] ='Software'
 WHERE id=180699334


   --row number: 4500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2982118 , [Content] ='IC2'
 WHERE id=180699335


   --row number: 4501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2982118 , [Content] ='INR'
 WHERE id=180699337


   --row number: 4502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2982118 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=180699338


   --row number: 4503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2982118 , [Content] ='10%'
 WHERE id=180699339


   --row number: 4504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2982118 , [Content] ='No'
 WHERE id=180699340


   --row number: 4505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2982118 , [Content] ='2 - Professionals'
 WHERE id=180699341


   --row number: 4506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2982118 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=180699342


   --row number: 4507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2982118 , [Content] ='Technical'
 WHERE id=180699343


   --row number: 4508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2982118 , [Content] ='5/22/2018'
 WHERE id=180699344


   --row number: 4509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2983253 , [Content] ='S1412 FRA'
 WHERE id=180843794


   --row number: 4510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2983253 , [Content] ='FRA'
 WHERE id=180843795


   --row number: 4511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2983253 , [Content] ='EMEA'
 WHERE id=180843796


   --row number: 4512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2983253 , [Content] ='FRANCE'
 WHERE id=180843797


   --row number: 4513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2983253 , [Content] ='Solution Consulting'
 WHERE id=180843798


   --row number: 4514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2983253 , [Content] ='S1412 - Solution Consultant IC2'
 WHERE id=180843799


   --row number: 4515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2983253 , [Content] ='Solution Consultant Core'
 WHERE id=180843800


   --row number: 4516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2983253 , [Content] ='IC2'
 WHERE id=180843801


   --row number: 4517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2983253 , [Content] ='EUR'
 WHERE id=180843803


   --row number: 4518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2983253 , [Content] ='44,625 / 48,563 / 52,500 / 56,438 / 60,375'
 WHERE id=180843804


   --row number: 4519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2983253 , [Content] ='59,500 / 64,750 / 70,000 / 75,250 / 80,500'
 WHERE id=180843805


   --row number: 4520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2983253 , [Content] ='75/25'
 WHERE id=180843806


   --row number: 4521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2983253 , [Content] ='No'
 WHERE id=180843807


   --row number: 4522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2983253 , [Content] ='4 - Sales Workers'
 WHERE id=180843808


   --row number: 4523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2983253 , [Content] ='8742-Salespersons - Outside'
 WHERE id=180843809


   --row number: 4524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2983253 , [Content] ='Technical'
 WHERE id=180843810


   --row number: 4525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2983253 , [Content] ='10/05/18'
 WHERE id=180843811


   --row number: 4526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2983878 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=180889154


   --row number: 4527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2983878 , [Content] ='8810-Clerical Office Employees'
 WHERE id=180889155


   --row number: 4528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2983878 , [Content] ='Technical'
 WHERE id=180889156


   --row number: 4529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2983878 , [Content] ='5/22/2018'
 WHERE id=180889157


   --row number: 4530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2983878 , [Content] ='1684 US - MRKT 1'
 WHERE id=180889138


   --row number: 4531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2983878 , [Content] ='US - MRKT 1'
 WHERE id=180889139


   --row number: 4532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2983878 , [Content] ='AMS'
 WHERE id=180889140


   --row number: 4533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2983878 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=180889141


   --row number: 4534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2983878 , [Content] ='Business Strategy'
 WHERE id=180889142


   --row number: 4535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2983878 , [Content] ='1684 - Sr Mgr, Business Process Mgmt M4'
 WHERE id=180889143


   --row number: 4536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2983878 , [Content] ='Business Process'
 WHERE id=180889144


   --row number: 4537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2983878 , [Content] ='M4'
 WHERE id=180889145


   --row number: 4538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2983878 , [Content] ='USD'
 WHERE id=180889147


   --row number: 4539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2983878 , [Content] ='123,000 / 150,650 / 178,300 / 206,000 / 233,700'
 WHERE id=180889148


   --row number: 4540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2983878 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=180889149


   --row number: 4541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2983878 , [Content] ='25%'
 WHERE id=180889150


   --row number: 4542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2983878 , [Content] ='Yes'
 WHERE id=180889151


   --row number: 4543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2983878 , [Content] ='EXEMPT'
 WHERE id=180889152


   --row number: 4544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2983878 , [Content] ='NO'
 WHERE id=180889153


   --row number: 4545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2985317 , [Content] ='6464 IND'
 WHERE id=181008591


   --row number: 4546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2985317 , [Content] ='IND'
 WHERE id=181008592


   --row number: 4547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2985317 , [Content] ='APAC'
 WHERE id=181008593


   --row number: 4548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2985317 , [Content] ='INDIA'
 WHERE id=181008594


   --row number: 4549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2985317 , [Content] ='Info Systems/Technology'
 WHERE id=181008595


   --row number: 4550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2985317 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=181008596


   --row number: 4551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2985317 , [Content] ='Business Systems Analysis'
 WHERE id=181008597


   --row number: 4552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2985317 , [Content] ='IC4'
 WHERE id=181008598


   --row number: 4553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2985317 , [Content] ='INR'
 WHERE id=181008600


   --row number: 4554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2985317 , [Content] ='1,724,100 / 2,112,050 / 2,500,000 / 2,887,900 / 3,275,800'
 WHERE id=181008601


   --row number: 4555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2985317 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=181008602


   --row number: 4556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2985317 , [Content] ='15%'
 WHERE id=181008603


   --row number: 4557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2985317 , [Content] ='Yes'
 WHERE id=181008604


   --row number: 4558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2985317 , [Content] ='2 - Professionals'
 WHERE id=181008605


   --row number: 4559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2985317 , [Content] ='8810-Clerical Office Employees'
 WHERE id=181008606


   --row number: 4560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2985317 , [Content] ='Technical'
 WHERE id=181008607


   --row number: 4561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2985317 , [Content] ='5/22/2018'
 WHERE id=181008608


   --row number: 4562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2986922 , [Content] ='5/22/2018'
 WHERE id=181124251


   --row number: 4563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2986922 , [Content] ='5224 IND'
 WHERE id=181124234


   --row number: 4564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2986922 , [Content] ='IND'
 WHERE id=181124235


   --row number: 4565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2986922 , [Content] ='APAC'
 WHERE id=181124236


   --row number: 4566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2986922 , [Content] ='INDIA'
 WHERE id=181124237


   --row number: 4567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2986922 , [Content] ='Engineering'
 WHERE id=181124238


   --row number: 4568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2986922 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=181124239


   --row number: 4569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2986922 , [Content] ='Product Mgmt Mgr'
 WHERE id=181124240


   --row number: 4570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2986922 , [Content] ='IC4'
 WHERE id=181124241


   --row number: 4571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2986922 , [Content] ='INR'
 WHERE id=181124243


   --row number: 4572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2986922 , [Content] ='2,310,300 / 2,830,150 / 3,350,000 / 3,869,800 / 4,389,600'
 WHERE id=181124244


   --row number: 4573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2986922 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=181124245


   --row number: 4574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2986922 , [Content] ='20%'
 WHERE id=181124246


   --row number: 4575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2986922 , [Content] ='Yes'
 WHERE id=181124247


   --row number: 4576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2986922 , [Content] ='2 - Professionals'
 WHERE id=181124248


   --row number: 4577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2986922 , [Content] ='8810-Clerical Office Employees'
 WHERE id=181124249


   --row number: 4578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2986922 , [Content] ='Technical'
 WHERE id=181124250


   --row number: 4579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2987214 , [Content] ='5/22/2018'
 WHERE id=181287784


   --row number: 4580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2987214 , [Content] ='5764 JPN'
 WHERE id=181287767


   --row number: 4581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2987214 , [Content] ='JPN'
 WHERE id=181287768


   --row number: 4582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2987214 , [Content] ='APAC'
 WHERE id=181287769


   --row number: 4583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2987214 , [Content] ='JAPAN'
 WHERE id=181287770


   --row number: 4584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2987214 , [Content] ='Professional Services'
 WHERE id=181287771


   --row number: 4585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2987214 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=181287772


   --row number: 4586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2987214 , [Content] ='Technology Consultant'
 WHERE id=181287773


   --row number: 4587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2987214 , [Content] ='IC4'
 WHERE id=181287774


   --row number: 4588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2987214 , [Content] ='JPY'
 WHERE id=181287776


   --row number: 4589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2987214 , [Content] ='8,295,800 / 10,034,000 / 11,772,200 / 13,510,350 / 15,248,500'
 WHERE id=181287777


   --row number: 4590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2987214 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=181287778


   --row number: 4591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2987214 , [Content] ='20%'
 WHERE id=181287779


   --row number: 4592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2987214 , [Content] ='Yes'
 WHERE id=181287780


   --row number: 4593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2987214 , [Content] ='2 - Professionals'
 WHERE id=181287781


   --row number: 4594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2987214 , [Content] ='8810-Clerical Office Employees'
 WHERE id=181287782


   --row number: 4595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2987214 , [Content] ='Technical'
 WHERE id=181287783


   --row number: 4596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2987255 , [Content] ='5/22/2018'
 WHERE id=181296817


   --row number: 4597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2987255 , [Content] ='5705 SGP'
 WHERE id=181296800


   --row number: 4598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2987255 , [Content] ='SGP'
 WHERE id=181296801


   --row number: 4599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2987255 , [Content] ='APAC'
 WHERE id=181296802


   --row number: 4600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2987255 , [Content] ='SINGAPORE'
 WHERE id=181296803


   --row number: 4601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2987255 , [Content] ='Professional Services'
 WHERE id=181296804


   --row number: 4602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2987255 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=181296805


   --row number: 4603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2987255 , [Content] ='Partner Support'
 WHERE id=181296806


   --row number: 4604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2987255 , [Content] ='IC5'
 WHERE id=181296807


   --row number: 4605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2987255 , [Content] ='SGD'
 WHERE id=181296809


   --row number: 4606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2987255 , [Content] ='131,000 / 160,500 / 190,000 / 219,450 / 248,900'
 WHERE id=181296810


   --row number: 4607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2987255 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=181296811


   --row number: 4608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2987255 , [Content] ='25%'
 WHERE id=181296812


   --row number: 4609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2987255 , [Content] ='Yes'
 WHERE id=181296813


   --row number: 4610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2987255 , [Content] ='2 - Professionals'
 WHERE id=181296814


   --row number: 4611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2987255 , [Content] ='8810-Clerical Office Employees'
 WHERE id=181296815


   --row number: 4612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2987255 , [Content] ='Technical'
 WHERE id=181296816


   --row number: 4613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2987260 , [Content] ='5706 JPN'
 WHERE id=181297575


   --row number: 4614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2987260 , [Content] ='JPN'
 WHERE id=181297576


   --row number: 4615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2987260 , [Content] ='APAC'
 WHERE id=181297577


   --row number: 4616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2987260 , [Content] ='JAPAN'
 WHERE id=181297578


   --row number: 4617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2987260 , [Content] ='Professional Services'
 WHERE id=181297579


   --row number: 4618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2987260 , [Content] ='5706 - Client Relationship Manager IC6'
 WHERE id=181297580


   --row number: 4619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2987260 , [Content] ='Partner Support'
 WHERE id=181297581


   --row number: 4620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2987260 , [Content] ='IC6'
 WHERE id=181297582


   --row number: 4621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2987260 , [Content] ='JPY'
 WHERE id=181297584


   --row number: 4622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2987260 , [Content] ='12,069,000 / 14,784,500 / 17,500,000 / 20,215,550 / 22,931,100'
 WHERE id=181297585


   --row number: 4623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2987260 , [Content] ='117,000 / 175,500 / 234,000 / 291,000 / 348,000'
 WHERE id=181297586


   --row number: 4624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2987260 , [Content] ='25%'
 WHERE id=181297587


   --row number: 4625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2987260 , [Content] ='Yes'
 WHERE id=181297588


   --row number: 4626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2987260 , [Content] ='2 - Professionals'
 WHERE id=181297589


   --row number: 4627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2987260 , [Content] ='8810-Clerical Office Employees'
 WHERE id=181297590


   --row number: 4628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2987260 , [Content] ='Technical'
 WHERE id=181297591


   --row number: 4629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2987260 , [Content] ='7/20/2018'
 WHERE id=181297592


   --row number: 4630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2988866 , [Content] ='Technical'
 WHERE id=181487642


   --row number: 4631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2988866 , [Content] ='5/22/2018'
 WHERE id=181487643


   --row number: 4632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2988866 , [Content] ='2143 IND'
 WHERE id=181487626


   --row number: 4633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2988866 , [Content] ='IND'
 WHERE id=181487627


   --row number: 4634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2988866 , [Content] ='APAC'
 WHERE id=181487628


   --row number: 4635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2988866 , [Content] ='INDIA'
 WHERE id=181487629


   --row number: 4636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2988866 , [Content] ='Engineering'
 WHERE id=181487630


   --row number: 4637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2988866 , [Content] ='2143 - Mgr, Software Engrg Mgmt M3'
 WHERE id=181487631


   --row number: 4638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2988866 , [Content] ='Software'
 WHERE id=181487632


   --row number: 4639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2988866 , [Content] ='M3'
 WHERE id=181487633


   --row number: 4640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2988866 , [Content] ='INR'
 WHERE id=181487635


   --row number: 4641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2988866 , [Content] ='2,451,700 / 3,003,350 / 3,555,000 / 4,106,600 / 4,658,200'
 WHERE id=181487636


   --row number: 4642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2988866 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=181487637


   --row number: 4643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2988866 , [Content] ='20%'
 WHERE id=181487638


   --row number: 4644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2988866 , [Content] ='Yes'
 WHERE id=181487639


   --row number: 4645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2988866 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=181487640


   --row number: 4646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2988866 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=181487641


   --row number: 4647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2988983 , [Content] ='2 - Professionals'
 WHERE id=181498619


   --row number: 4648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2988983 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=181498620


   --row number: 4649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2988983 , [Content] ='Technical'
 WHERE id=181498621


   --row number: 4650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2988983 , [Content] ='5/22/2018'
 WHERE id=181498622


   --row number: 4651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2988983 , [Content] ='5142 US - MRKT 2'
 WHERE id=181498603


   --row number: 4652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2988983 , [Content] ='US - MRKT 2'
 WHERE id=181498604


   --row number: 4653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2988983 , [Content] ='AMS'
 WHERE id=181498605


   --row number: 4654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2988983 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=181498606


   --row number: 4655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2988983 , [Content] ='Engineering'
 WHERE id=181498607


   --row number: 4656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2988983 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=181498608


   --row number: 4657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2988983 , [Content] ='Software'
 WHERE id=181498609


   --row number: 4658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2988983 , [Content] ='IC2'
 WHERE id=181498610


   --row number: 4659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2988983 , [Content] ='USD'
 WHERE id=181498612


   --row number: 4660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2988983 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=181498613


   --row number: 4661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2988983 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=181498614


   --row number: 4662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2988983 , [Content] ='10%'
 WHERE id=181498615


   --row number: 4663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2988983 , [Content] ='Yes'
 WHERE id=181498616


   --row number: 4664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2988983 , [Content] ='EXEMPT'
 WHERE id=181498617


   --row number: 4665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2988983 , [Content] ='NO'
 WHERE id=181498618


   --row number: 4666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2989446 , [Content] ='Non Technical'
 WHERE id=181536535


   --row number: 4667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2989446 , [Content] ='5/22/2018'
 WHERE id=181536536


   --row number: 4668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2989446 , [Content] ='S1332 US - MRKT 2'
 WHERE id=181536517


   --row number: 4669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2989446 , [Content] ='US - MRKT 2'
 WHERE id=181536518


   --row number: 4670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2989446 , [Content] ='AMS'
 WHERE id=181536519


   --row number: 4671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2989446 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=181536520


   --row number: 4672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2989446 , [Content] ='Sales'
 WHERE id=181536521


   --row number: 4673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2989446 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=181536522


   --row number: 4674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2989446 , [Content] ='Inside Sales'
 WHERE id=181536523


   --row number: 4675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2989446 , [Content] ='A2'
 WHERE id=181536524


   --row number: 4676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2989446 , [Content] ='USD'
 WHERE id=181536526


   --row number: 4677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2989446 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=181536527


   --row number: 4678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2989446 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=181536528


   --row number: 4679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2989446 , [Content] ='60/40'
 WHERE id=181536529


   --row number: 4680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2989446 , [Content] ='No'
 WHERE id=181536530


   --row number: 4681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2989446 , [Content] ='NON-EXEMPT'
 WHERE id=181536531


   --row number: 4682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2989446 , [Content] ='NO'
 WHERE id=181536532


   --row number: 4683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2989446 , [Content] ='4 - Sales Workers'
 WHERE id=181536533


   --row number: 4684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2989446 , [Content] ='8810-Clerical Office Employees'
 WHERE id=181536534


   --row number: 4685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2990351 , [Content] ='S634 BEL'
 WHERE id=181618554


   --row number: 4686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2990351 , [Content] ='BEL'
 WHERE id=181618555


   --row number: 4687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2990351 , [Content] ='EMEA'
 WHERE id=181618556


   --row number: 4688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2990351 , [Content] ='BELGIUM'
 WHERE id=181618557


   --row number: 4689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2990351 , [Content] ='Sales'
 WHERE id=181618558


   --row number: 4690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2990351 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=181618559


   --row number: 4691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2990351 , [Content] ='Enterprise Accounts'
 WHERE id=181618560


   --row number: 4692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2990351 , [Content] ='IC4'
 WHERE id=181618561


   --row number: 4693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2990351 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=181618563


   --row number: 4694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2990351 , [Content] ='50/50'
 WHERE id=181618564


   --row number: 4695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2990351 , [Content] ='Yes'
 WHERE id=181618565


   --row number: 4696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2990351 , [Content] ='4 - Sales Workers'
 WHERE id=181618566


   --row number: 4697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2990351 , [Content] ='8742-Salespersons - Outside'
 WHERE id=181618567


   --row number: 4698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2990351 , [Content] ='Technical'
 WHERE id=181618568


   --row number: 4699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2998193 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182052994


   --row number: 4700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2998193 , [Content] ='Technical'
 WHERE id=182052995


   --row number: 4701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2998193 , [Content] ='5/22/2018'
 WHERE id=182052996


   --row number: 4702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2998193 , [Content] ='5764 US - MRKT 2'
 WHERE id=182052977


   --row number: 4703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2998193 , [Content] ='US - MRKT 2'
 WHERE id=182052978


   --row number: 4704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2998193 , [Content] ='AMS'
 WHERE id=182052979


   --row number: 4705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2998193 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182052980


   --row number: 4706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2998193 , [Content] ='Professional Services'
 WHERE id=182052981


   --row number: 4707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2998193 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=182052982


   --row number: 4708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2998193 , [Content] ='Technology Consultant'
 WHERE id=182052983


   --row number: 4709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2998193 , [Content] ='IC4'
 WHERE id=182052984


   --row number: 4710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2998193 , [Content] ='USD'
 WHERE id=182052986


   --row number: 4711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2998193 , [Content] ='88,800 / 107,400 / 126,000 / 144,600 / 163,200'
 WHERE id=182052987


   --row number: 4712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2998193 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=182052988


   --row number: 4713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2998193 , [Content] ='20%'
 WHERE id=182052989


   --row number: 4714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2998193 , [Content] ='Yes'
 WHERE id=182052990


   --row number: 4715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2998193 , [Content] ='EXEMPT'
 WHERE id=182052991


   --row number: 4716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2998193 , [Content] ='NO'
 WHERE id=182052992


   --row number: 4717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2998193 , [Content] ='2 - Professionals'
 WHERE id=182052993


   --row number: 4718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2998557 , [Content] ='4 - Sales Workers'
 WHERE id=182074962


   --row number: 4719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2998557 , [Content] ='8742-Salespersons - Outside'
 WHERE id=182074963


   --row number: 4720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2998557 , [Content] ='Technical'
 WHERE id=182074964


   --row number: 4721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2998557 , [Content] ='09/05/18'
 WHERE id=182074965


   --row number: 4722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2998557 , [Content] ='S1415A US - MRKT 1'
 WHERE id=182074945


   --row number: 4723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2998557 , [Content] ='US - MRKT 1'
 WHERE id=182074946


   --row number: 4724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2998557 , [Content] ='AMS'
 WHERE id=182074947


   --row number: 4725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2998557 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182074948


   --row number: 4726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2998557 , [Content] ='Solution Consulting'
 WHERE id=182074949


   --row number: 4727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2998557 , [Content] ='S1415A - Sr Advisory Solution Architect IC5'
 WHERE id=182074950


   --row number: 4728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2998557 , [Content] ='Solution Consultant Architect'
 WHERE id=182074951


   --row number: 4729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2998557 , [Content] ='IC5'
 WHERE id=182074952


   --row number: 4730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2998557 , [Content] ='USD'
 WHERE id=182074954


   --row number: 4731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2998557 , [Content] ='147,900 / 160,950 / 174,000 / 187,050 / 200,100'
 WHERE id=182074955


   --row number: 4732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2998557 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=182074956


   --row number: 4733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2998557 , [Content] ='197,200 / 214,600 / 232,000 / 249,400 / 266,800'
 WHERE id=182074957


   --row number: 4734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2998557 , [Content] ='75/25'
 WHERE id=182074958


   --row number: 4735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2998557 , [Content] ='Yes'
 WHERE id=182074959


   --row number: 4736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2998557 , [Content] ='EXEMPT'
 WHERE id=182074960


   --row number: 4737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2998557 , [Content] ='NO'
 WHERE id=182074961


   --row number: 4738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2999524 , [Content] ='5872 DEU'
 WHERE id=182285605


   --row number: 4739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2999524 , [Content] ='DEU'
 WHERE id=182285606


   --row number: 4740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2999524 , [Content] ='EMEA'
 WHERE id=182285607


   --row number: 4741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2999524 , [Content] ='GERMANY'
 WHERE id=182285608


   --row number: 4742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2999524 , [Content] ='Professional Services'
 WHERE id=182285609


   --row number: 4743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2999524 , [Content] ='5872 - Engagement Mgr IC2'
 WHERE id=182285610


   --row number: 4744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2999524 , [Content] ='Engagement Mgrs'
 WHERE id=182285611


   --row number: 4745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2999524 , [Content] ='IC2'
 WHERE id=182285612


   --row number: 4746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2999524 , [Content] ='EUR'
 WHERE id=182285614


   --row number: 4747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2999524 , [Content] ='42,500 / 49,500 / 56,500 / 63,550 / 70,600'
 WHERE id=182285615


   --row number: 4748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2999524 , [Content] ='10%'
 WHERE id=182285616


   --row number: 4749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2999524 , [Content] ='No'
 WHERE id=182285617


   --row number: 4750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2999524 , [Content] ='2 - Professionals'
 WHERE id=182285618


   --row number: 4751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2999524 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182285619


   --row number: 4752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2999524 , [Content] ='Technical'
 WHERE id=182285620


   --row number: 4753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2999524 , [Content] ='5/22/2018'
 WHERE id=182285621


   --row number: 4754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3000296 , [Content] ='2 - Professionals'
 WHERE id=182354254


   --row number: 4755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3000296 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182354255


   --row number: 4756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3000296 , [Content] ='Technical'
 WHERE id=182354256


   --row number: 4757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3000296 , [Content] ='6706 US - MRKT 1'
 WHERE id=182354238


   --row number: 4758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3000296 , [Content] ='US - MRKT 1'
 WHERE id=182354239


   --row number: 4759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3000296 , [Content] ='AMS'
 WHERE id=182354240


   --row number: 4760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3000296 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182354241


   --row number: 4761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3000296 , [Content] ='Engineering Operations'
 WHERE id=182354242


   --row number: 4762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3000296 , [Content] ='6706 - Data Scientist IC6'
 WHERE id=182354243


   --row number: 4763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3000296 , [Content] ='Data Scientist'
 WHERE id=182354244


   --row number: 4764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3000296 , [Content] ='IC6'
 WHERE id=182354245


   --row number: 4765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3000296 , [Content] ='USD'
 WHERE id=182354247


   --row number: 4766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3000296 , [Content] ='147,400 / 180,550 / 213,700 / 246,900 / 280,100'
 WHERE id=182354248


   --row number: 4767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3000296 , [Content] ='312,000 / 468,000 / 624,000 / 780,000 / 936,000'
 WHERE id=182354249


   --row number: 4768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3000296 , [Content] ='25%'
 WHERE id=182354250


   --row number: 4769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3000296 , [Content] ='Yes'
 WHERE id=182354251


   --row number: 4770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3000296 , [Content] ='EXEMPT'
 WHERE id=182354252


   --row number: 4771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3000296 , [Content] ='NO'
 WHERE id=182354253


   --row number: 4772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3000296 , [Content] ='7/20/18'
 WHERE id=182354257


   --row number: 4773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3000583 , [Content] ='NO'
 WHERE id=182378445


   --row number: 4774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3000583 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=182378447


   --row number: 4775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3000583 , [Content] ='Technical'
 WHERE id=182378448


   --row number: 4776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3000583 , [Content] ='04/05/18'
 WHERE id=182378449


   --row number: 4777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3000583 , [Content] ='2 - Professionals'
 WHERE id=182378446


   --row number: 4778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3000583 , [Content] ='5143 US - MRKT 1'
 WHERE id=182378430


   --row number: 4779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3000583 , [Content] ='US - MRKT 1'
 WHERE id=182378431


   --row number: 4780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3000583 , [Content] ='AMS'
 WHERE id=182378432


   --row number: 4781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3000583 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182378433


   --row number: 4782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3000583 , [Content] ='Engineering'
 WHERE id=182378434


   --row number: 4783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3000583 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=182378435


   --row number: 4784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3000583 , [Content] ='Software'
 WHERE id=182378436


   --row number: 4785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3000583 , [Content] ='IC3'
 WHERE id=182378437


   --row number: 4786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3000583 , [Content] ='USD'
 WHERE id=182378439


   --row number: 4787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3000583 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=182378440


   --row number: 4788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3000583 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=182378441


   --row number: 4789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3000583 , [Content] ='15%'
 WHERE id=182378442


   --row number: 4790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3000583 , [Content] ='Yes'
 WHERE id=182378443


   --row number: 4791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3000583 , [Content] ='EXEMPT'
 WHERE id=182378444


   --row number: 4792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3000772 , [Content] ='2 - Professionals'
 WHERE id=182392420


   --row number: 4793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3000772 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182392421


   --row number: 4794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3000772 , [Content] ='Technical'
 WHERE id=182392422


   --row number: 4795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3000772 , [Content] ='5/22/18'
 WHERE id=182392423


   --row number: 4796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3000772 , [Content] ='5764 US - MRKT 2'
 WHERE id=182392404


   --row number: 4797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3000772 , [Content] ='US - MRKT 2'
 WHERE id=182392405


   --row number: 4798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3000772 , [Content] ='AMS'
 WHERE id=182392406


   --row number: 4799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3000772 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182392407


   --row number: 4800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3000772 , [Content] ='Professional Services'
 WHERE id=182392408


   --row number: 4801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3000772 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=182392409


   --row number: 4802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3000772 , [Content] ='Technology Consultant'
 WHERE id=182392410


   --row number: 4803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3000772 , [Content] ='IC4'
 WHERE id=182392411


   --row number: 4804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3000772 , [Content] ='USD'
 WHERE id=182392413


   --row number: 4805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3000772 , [Content] ='88,800 / 107,400 / 126,000 / 144,600 / 163,200'
 WHERE id=182392414


   --row number: 4806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3000772 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=182392415


   --row number: 4807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3000772 , [Content] ='20%'
 WHERE id=182392416


   --row number: 4808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3000772 , [Content] ='Yes'
 WHERE id=182392417


   --row number: 4809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3000772 , [Content] ='EXEMPT'
 WHERE id=182392418


   --row number: 4810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3000772 , [Content] ='NO'
 WHERE id=182392419


   --row number: 4811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3002472 , [Content] ='6571 UK'
 WHERE id=182510767


   --row number: 4812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3002472 , [Content] ='UK'
 WHERE id=182510768


   --row number: 4813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3002472 , [Content] ='EMEA'
 WHERE id=182510769


   --row number: 4814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3002472 , [Content] ='UNITED KINGDOM'
 WHERE id=182510770


   --row number: 4815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3002472 , [Content] ='Info Systems/Technology'
 WHERE id=182510771


   --row number: 4816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3002472 , [Content] ='6571 - IT Systems/Support Analyst IC1'
 WHERE id=182510772


   --row number: 4817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3002472 , [Content] ='IT Systems/Support'
 WHERE id=182510773


   --row number: 4818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3002472 , [Content] ='IC1'
 WHERE id=182510774


   --row number: 4819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3002472 , [Content] ='GBP'
 WHERE id=182510776


   --row number: 4820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3002472 , [Content] ='24,400 / 27,700 / 31,000 / 34,300 / 37,600'
 WHERE id=182510777


   --row number: 4821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3002472 , [Content] ='10%'
 WHERE id=182510778


   --row number: 4822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3002472 , [Content] ='No'
 WHERE id=182510779


   --row number: 4823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3002472 , [Content] ='2 - Professionals'
 WHERE id=182510780


   --row number: 4824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3002472 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182510781


   --row number: 4825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3002472 , [Content] ='Technical'
 WHERE id=182510782


   --row number: 4826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3002472 , [Content] ='5/22/18'
 WHERE id=182510783


   --row number: 4827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3003815 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182620797


   --row number: 4828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3003815 , [Content] ='Non Technical'
 WHERE id=182620798


   --row number: 4829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3003815 , [Content] ='4/25/2018'
 WHERE id=182620799


   --row number: 4830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3003815 , [Content] ='6195 US - MRKT 1'
 WHERE id=182620780


   --row number: 4831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3003815 , [Content] ='US - MRKT 1'
 WHERE id=182620781


   --row number: 4832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3003815 , [Content] ='AMS'
 WHERE id=182620782


   --row number: 4833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3003815 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182620783


   --row number: 4834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3003815 , [Content] ='Finance'
 WHERE id=182620784


   --row number: 4835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3003815 , [Content] ='6195 - Sr. Financial Reporting Analyst IC5'
 WHERE id=182620785


   --row number: 4836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3003815 , [Content] ='Financial Reporting'
 WHERE id=182620786


   --row number: 4837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3003815 , [Content] ='IC5'
 WHERE id=182620787


   --row number: 4838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3003815 , [Content] ='USD'
 WHERE id=182620789


   --row number: 4839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3003815 , [Content] ='120,500 / 145,750 / 171,000 / 196,250 / 221,500'
 WHERE id=182620790


   --row number: 4840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3003815 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=182620791


   --row number: 4841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3003815 , [Content] ='20%'
 WHERE id=182620792


   --row number: 4842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3003815 , [Content] ='Yes'
 WHERE id=182620793


   --row number: 4843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3003815 , [Content] ='EXEMPT'
 WHERE id=182620794


   --row number: 4844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3003815 , [Content] ='NO'
 WHERE id=182620795


   --row number: 4845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3003815 , [Content] ='2 - Professionals'
 WHERE id=182620796


   --row number: 4846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3003841 , [Content] ='4 - Sales Workers'
 WHERE id=182623814


   --row number: 4847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3003841 , [Content] ='8742-Salespersons - Outside'
 WHERE id=182623815


   --row number: 4848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3003841 , [Content] ='Technical'
 WHERE id=182623816


   --row number: 4849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3003841 , [Content] ='5/22/18'
 WHERE id=182623817


   --row number: 4850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3003841 , [Content] ='S1416-S US - MRKT 1'
 WHERE id=182623797


   --row number: 4851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3003841 , [Content] ='US - MRKT 1'
 WHERE id=182623798


   --row number: 4852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3003841 , [Content] ='AMS'
 WHERE id=182623799


   --row number: 4853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3003841 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182623800


   --row number: 4854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3003841 , [Content] ='Solution Consulting'
 WHERE id=182623801


   --row number: 4855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3003841 , [Content] ='S1416-S - Principal Enterprise (Client) Strategist IC6'
 WHERE id=182623802


   --row number: 4856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3003841 , [Content] ='Solution Consultant Strategy'
 WHERE id=182623803


   --row number: 4857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3003841 , [Content] ='IC6'
 WHERE id=182623804


   --row number: 4858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3003841 , [Content] ='USD'
 WHERE id=182623806


   --row number: 4859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3003841 , [Content] ='181,688 / 197,719 / 213,750 / 229,781 / 245,813'
 WHERE id=182623807


   --row number: 4860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3003841 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=182623808


   --row number: 4861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3003841 , [Content] ='242,250 / 263,625 / 285,000 / 306,375 / 327,750'
 WHERE id=182623809


   --row number: 4862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3003841 , [Content] ='75/25'
 WHERE id=182623810


   --row number: 4863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3003841 , [Content] ='Yes'
 WHERE id=182623811


   --row number: 4864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3003841 , [Content] ='EXEMPT'
 WHERE id=182623812


   --row number: 4865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3003841 , [Content] ='NO'
 WHERE id=182623813


   --row number: 4866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3004593 , [Content] ='5/22/18'
 WHERE id=182692795


   --row number: 4867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3004593 , [Content] ='5142 IND'
 WHERE id=182692779


   --row number: 4868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3004593 , [Content] ='IND'
 WHERE id=182692780


   --row number: 4869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3004593 , [Content] ='APAC'
 WHERE id=182692781


   --row number: 4870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3004593 , [Content] ='INDIA'
 WHERE id=182692782


   --row number: 4871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3004593 , [Content] ='Engineering'
 WHERE id=182692783


   --row number: 4872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3004593 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=182692784


   --row number: 4873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3004593 , [Content] ='Software'
 WHERE id=182692785


   --row number: 4874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3004593 , [Content] ='IC2'
 WHERE id=182692786


   --row number: 4875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3004593 , [Content] ='INR'
 WHERE id=182692788


   --row number: 4876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3004593 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=182692789


   --row number: 4877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3004593 , [Content] ='10%'
 WHERE id=182692790


   --row number: 4878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3004593 , [Content] ='No'
 WHERE id=182692791


   --row number: 4879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3004593 , [Content] ='2 - Professionals'
 WHERE id=182692792


   --row number: 4880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3004593 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=182692793


   --row number: 4881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3004593 , [Content] ='Technical'
 WHERE id=182692794


   --row number: 4882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3005212 , [Content] ='Non Technical'
 WHERE id=182736247


   --row number: 4883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3005212 , [Content] ='5/22/18'
 WHERE id=182736248


   --row number: 4884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3005212 , [Content] ='6004 US - MRKT 1'
 WHERE id=182736229


   --row number: 4885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3005212 , [Content] ='US - MRKT 1'
 WHERE id=182736230


   --row number: 4886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3005212 , [Content] ='AMS'
 WHERE id=182736231


   --row number: 4887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3005212 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=182736232


   --row number: 4888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3005212 , [Content] ='Finance'
 WHERE id=182736233


   --row number: 4889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3005212 , [Content] ='6004 - Sr. FP&A Analyst IC4'
 WHERE id=182736234


   --row number: 4890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3005212 , [Content] ='FP&A'
 WHERE id=182736235


   --row number: 4891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3005212 , [Content] ='IC4'
 WHERE id=182736236


   --row number: 4892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3005212 , [Content] ='USD'
 WHERE id=182736238


   --row number: 4893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3005212 , [Content] ='97,100 / 114,550 / 132,000 / 149,500 / 167,000'
 WHERE id=182736239


   --row number: 4894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3005212 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=182736240


   --row number: 4895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3005212 , [Content] ='15%'
 WHERE id=182736241


   --row number: 4896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3005212 , [Content] ='Yes'
 WHERE id=182736242


   --row number: 4897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3005212 , [Content] ='EXEMPT'
 WHERE id=182736243


   --row number: 4898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3005212 , [Content] ='NO'
 WHERE id=182736244


   --row number: 4899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3005212 , [Content] ='2 - Professionals'
 WHERE id=182736245


   --row number: 4900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3005212 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182736246


   --row number: 4901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3006107 , [Content] ='4/25/2018'
 WHERE id=182817832


   --row number: 4902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3006107 , [Content] ='5876A AUS'
 WHERE id=182817815


   --row number: 4903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3006107 , [Content] ='AUS'
 WHERE id=182817816


   --row number: 4904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3006107 , [Content] ='APAC'
 WHERE id=182817817


   --row number: 4905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3006107 , [Content] ='AUSTRALIA'
 WHERE id=182817818


   --row number: 4906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3006107 , [Content] ='Professional Services'
 WHERE id=182817819


   --row number: 4907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3006107 , [Content] ='5876A - Services Program Mgr IC6'
 WHERE id=182817820


   --row number: 4908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3006107 , [Content] ='Srvcs Program Mgrs'
 WHERE id=182817821


   --row number: 4909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3006107 , [Content] ='IC6'
 WHERE id=182817822


   --row number: 4910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3006107 , [Content] ='AUD'
 WHERE id=182817824


   --row number: 4911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3006107 , [Content] ='142,700 / 174,800 / 206,900 / 239,000 / 271,100'
 WHERE id=182817825


   --row number: 4912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3006107 , [Content] ='117,000 / 175,500 / 234,000 / 291,000 / 348,000'
 WHERE id=182817826


   --row number: 4913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3006107 , [Content] ='25%'
 WHERE id=182817827


   --row number: 4914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3006107 , [Content] ='Yes'
 WHERE id=182817828


   --row number: 4915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3006107 , [Content] ='2 - Professionals'
 WHERE id=182817829


   --row number: 4916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3006107 , [Content] ='8810-Clerical Office Employees'
 WHERE id=182817830


   --row number: 4917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3006107 , [Content] ='Technical'
 WHERE id=182817831


   --row number: 4918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3006239 , [Content] ='8742-Salespersons - Outside'
 WHERE id=182905194


   --row number: 4919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3006239 , [Content] ='Technical'
 WHERE id=182905195


   --row number: 4920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3006239 , [Content] ='5/22/18'
 WHERE id=182905196


   --row number: 4921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3006239 , [Content] ='S634 HKG'
 WHERE id=182905178


   --row number: 4922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3006239 , [Content] ='HKG'
 WHERE id=182905179


   --row number: 4923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3006239 , [Content] ='APAC'
 WHERE id=182905180


   --row number: 4924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3006239 , [Content] ='HONG KONG'
 WHERE id=182905181


   --row number: 4925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3006239 , [Content] ='Sales'
 WHERE id=182905182


   --row number: 4926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3006239 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=182905183


   --row number: 4927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3006239 , [Content] ='Enterprise Accounts'
 WHERE id=182905184


   --row number: 4928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3006239 , [Content] ='IC4'
 WHERE id=182905185


   --row number: 4929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3006239 , [Content] ='HKD'
 WHERE id=182905187


   --row number: 4930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3006239 , [Content] ='680,000 / 740,000 / 800,000 / 860,000 / 920,000'
 WHERE id=182905188


   --row number: 4931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3006239 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=182905189


   --row number: 4932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3006239 , [Content] ='1,360,000 / 1,480,000 / 1,600,000 / 1,720,000 / 1,840,000'
 WHERE id=182905190


   --row number: 4933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3006239 , [Content] ='50/50'
 WHERE id=182905191


   --row number: 4934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3006239 , [Content] ='Yes'
 WHERE id=182905192


   --row number: 4935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3006239 , [Content] ='4 - Sales Workers'
 WHERE id=182905193


   --row number: 4936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3006468 , [Content] ='Technical'
 WHERE id=183054232


   --row number: 4937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3006468 , [Content] ='7/20/18'
 WHERE id=183054233


   --row number: 4938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3006468 , [Content] ='S1415 NLD'
 WHERE id=183054215


   --row number: 4939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3006468 , [Content] ='NLD'
 WHERE id=183054216


   --row number: 4940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3006468 , [Content] ='EMEA'
 WHERE id=183054217


   --row number: 4941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3006468 , [Content] ='NETHERLANDS'
 WHERE id=183054218


   --row number: 4942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3006468 , [Content] ='Solution Consulting'
 WHERE id=183054219


   --row number: 4943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3006468 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=183054220


   --row number: 4944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3006468 , [Content] ='Solution Consultant Core'
 WHERE id=183054221


   --row number: 4945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3006468 , [Content] ='IC5'
 WHERE id=183054222


   --row number: 4946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3006468 , [Content] ='EUR'
 WHERE id=183054224


   --row number: 4947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3006468 , [Content] ='85,425 / 92,963 / 100,500 / 108,038 / 115,575'
 WHERE id=183054225


   --row number: 4948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3006468 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=183054226


   --row number: 4949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3006468 , [Content] ='113,900 / 123,950 / 134,000 / 144,050 / 154,100'
 WHERE id=183054227


   --row number: 4950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3006468 , [Content] ='75/25'
 WHERE id=183054228


   --row number: 4951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3006468 , [Content] ='Yes'
 WHERE id=183054229


   --row number: 4952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3006468 , [Content] ='4 - Sales Workers'
 WHERE id=183054230


   --row number: 4953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3006468 , [Content] ='8742-Salespersons - Outside'
 WHERE id=183054231


   --row number: 4954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3007723 , [Content] ='4 - Sales Workers'
 WHERE id=183158383


   --row number: 4955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3007723 , [Content] ='8742-Salespersons - Outside'
 WHERE id=183158384


   --row number: 4956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3007723 , [Content] ='Technical'
 WHERE id=183158385


   --row number: 4957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3007723 , [Content] ='5/22/18'
 WHERE id=183158386


   --row number: 4958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3007723 , [Content] ='S1413 US - MRKT 3'
 WHERE id=183158367


   --row number: 4959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3007723 , [Content] ='US - MRKT 3'
 WHERE id=183158368


   --row number: 4960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3007723 , [Content] ='AMS'
 WHERE id=183158369


   --row number: 4961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3007723 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=183158370


   --row number: 4962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3007723 , [Content] ='Solution Consulting'
 WHERE id=183158371


   --row number: 4963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3007723 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=183158372


   --row number: 4964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3007723 , [Content] ='Solution Consultant Core'
 WHERE id=183158373


   --row number: 4965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3007723 , [Content] ='IC3'
 WHERE id=183158374


   --row number: 4966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3007723 , [Content] ='USD'
 WHERE id=183158376


   --row number: 4967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3007723 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=183158377


   --row number: 4968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3007723 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=183158378


   --row number: 4969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3007723 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=183158379


   --row number: 4970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3007723 , [Content] ='75/25'
 WHERE id=183158380


   --row number: 4971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3007723 , [Content] ='Yes'
 WHERE id=183158381


   --row number: 4972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3007723 , [Content] ='EXEMPT'
 WHERE id=183158382


   --row number: 4973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3008473 , [Content] ='Technical'
 WHERE id=183859811


   --row number: 4974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3008473 , [Content] ='10/05/18'
 WHERE id=183859812


   --row number: 4975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3008473 , [Content] ='S1404 UK'
 WHERE id=183859794


   --row number: 4976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3008473 , [Content] ='UK'
 WHERE id=183859795


   --row number: 4977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3008473 , [Content] ='EMEA'
 WHERE id=183859796


   --row number: 4978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3008473 , [Content] ='UNITED KINGDOM'
 WHERE id=183859797


   --row number: 4979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3008473 , [Content] ='Solution Consulting'
 WHERE id=183859798


   --row number: 4980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3008473 , [Content] ='S1404 - Sr Mgr, Solution Consulting M4'
 WHERE id=183859799


   --row number: 4981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3008473 , [Content] ='Solution Consultant Core'
 WHERE id=183859800


   --row number: 4982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3008473 , [Content] ='M4'
 WHERE id=183859801


   --row number: 4983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3008473 , [Content] ='GBP'
 WHERE id=183859803


   --row number: 4984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3008473 , [Content] ='89,569 / 97,472 / 105,375 / 113,278 / 121,181'
 WHERE id=183859804


   --row number: 4985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3008473 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=183859805


   --row number: 4986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3008473 , [Content] ='119,425 / 129,963 / 140,500 / 151,038 / 161,575'
 WHERE id=183859806


   --row number: 4987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3008473 , [Content] ='75/25'
 WHERE id=183859807


   --row number: 4988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3008473 , [Content] ='Yes'
 WHERE id=183859808


   --row number: 4989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3008473 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=183859809


   --row number: 4990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3008473 , [Content] ='8742-Salespersons - Outside'
 WHERE id=183859810


   --row number: 4991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3011436 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=184180525


   --row number: 4992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3011436 , [Content] ='Technical'
 WHERE id=184180526


   --row number: 4993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3011436 , [Content] ='5/22/18'
 WHERE id=184180527


   --row number: 4994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3011436 , [Content] ='5233 US - MRKT 1'
 WHERE id=184180508


   --row number: 4995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3011436 , [Content] ='US - MRKT 1'
 WHERE id=184180509


   --row number: 4996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3011436 , [Content] ='AMS'
 WHERE id=184180510


   --row number: 4997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3011436 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184180511


   --row number: 4998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3011436 , [Content] ='Engineering'
 WHERE id=184180512


   --row number: 4999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3011436 , [Content] ='5233 - Sr UI Engineer IC3'
 WHERE id=184180513


   --row number: 5000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3011436 , [Content] ='UI'
 WHERE id=184180514


   --row number: 5001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3011436 , [Content] ='IC3'
 WHERE id=184180515


   --row number: 5002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3011436 , [Content] ='USD'
 WHERE id=184180517


   --row number: 5003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3011436 , [Content] ='98,500 / 116,200 / 133,900 / 151,650 / 169,400'
 WHERE id=184180518


   --row number: 5004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3011436 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=184180519


   --row number: 5005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3011436 , [Content] ='15%'
 WHERE id=184180520


   --row number: 5006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3011436 , [Content] ='Yes'
 WHERE id=184180521


   --row number: 5007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3011436 , [Content] ='EXEMPT'
 WHERE id=184180522


   --row number: 5008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3011436 , [Content] ='NO'
 WHERE id=184180523


   --row number: 5009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3011436 , [Content] ='2 - Professionals'
 WHERE id=184180524


   --row number: 5010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3012725 , [Content] ='10/05/18'
 WHERE id=184315999


   --row number: 5011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3012725 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=184315993


   --row number: 5012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3012725 , [Content] ='10%'
 WHERE id=184315994


   --row number: 5013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3012725 , [Content] ='No'
 WHERE id=184315995


   --row number: 5014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3012725 , [Content] ='2 - Professionals'
 WHERE id=184315996


   --row number: 5015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3012725 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=184315997


   --row number: 5016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3012725 , [Content] ='Technical'
 WHERE id=184315998


   --row number: 5017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3012725 , [Content] ='5142 IND'
 WHERE id=184315983


   --row number: 5018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3012725 , [Content] ='IND'
 WHERE id=184315984


   --row number: 5019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3012725 , [Content] ='APAC'
 WHERE id=184315985


   --row number: 5020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3012725 , [Content] ='INDIA'
 WHERE id=184315986


   --row number: 5021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3012725 , [Content] ='Engineering'
 WHERE id=184315987


   --row number: 5022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3012725 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=184315988


   --row number: 5023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3012725 , [Content] ='Software'
 WHERE id=184315989


   --row number: 5024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3012725 , [Content] ='IC2'
 WHERE id=184315990


   --row number: 5025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3012725 , [Content] ='INR'
 WHERE id=184315992


   --row number: 5026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3012909 , [Content] ='Technical'
 WHERE id=184326754


   --row number: 5027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3012909 , [Content] ='06/08/18'
 WHERE id=184326755


   --row number: 5028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3012909 , [Content] ='S1414 NLD'
 WHERE id=184326737


   --row number: 5029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3012909 , [Content] ='NLD'
 WHERE id=184326738


   --row number: 5030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3012909 , [Content] ='EMEA'
 WHERE id=184326739


   --row number: 5031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3012909 , [Content] ='NETHERLANDS'
 WHERE id=184326740


   --row number: 5032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3012909 , [Content] ='Solution Consulting'
 WHERE id=184326741


   --row number: 5033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3012909 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=184326742


   --row number: 5034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3012909 , [Content] ='Solution Consultant Core'
 WHERE id=184326743


   --row number: 5035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3012909 , [Content] ='IC4'
 WHERE id=184326744


   --row number: 5036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3012909 , [Content] ='EUR'
 WHERE id=184326746


   --row number: 5037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3012909 , [Content] ='72,038 / 78,394 / 84,750 / 91,106 / 97,463'
 WHERE id=184326747


   --row number: 5038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3012909 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=184326748


   --row number: 5039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3012909 , [Content] ='96,050 / 104,525 / 113,000 / 121,475 / 129,950'
 WHERE id=184326749


   --row number: 5040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3012909 , [Content] ='75/25'
 WHERE id=184326750


   --row number: 5041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3012909 , [Content] ='Yes'
 WHERE id=184326751


   --row number: 5042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3012909 , [Content] ='4 - Sales Workers'
 WHERE id=184326752


   --row number: 5043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3012909 , [Content] ='8742-Salespersons - Outside'
 WHERE id=184326753


   --row number: 5044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3013602 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184375857


   --row number: 5045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3013602 , [Content] ='Technical'
 WHERE id=184375858


   --row number: 5046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3013602 , [Content] ='5/22/18'
 WHERE id=184375859


   --row number: 5047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3013602 , [Content] ='5765 US - MRKT 1'
 WHERE id=184375840


   --row number: 5048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3013602 , [Content] ='US - MRKT 1'
 WHERE id=184375841


   --row number: 5049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3013602 , [Content] ='AMS'
 WHERE id=184375842


   --row number: 5050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3013602 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184375843


   --row number: 5051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3013602 , [Content] ='Professional Services'
 WHERE id=184375844


   --row number: 5052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3013602 , [Content] ='5765 - Technology Consultant IC5'
 WHERE id=184375845


   --row number: 5053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3013602 , [Content] ='Technology Consultant'
 WHERE id=184375846


   --row number: 5054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3013602 , [Content] ='IC5'
 WHERE id=184375847


   --row number: 5055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3013602 , [Content] ='USD'
 WHERE id=184375849


   --row number: 5056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3013602 , [Content] ='110,000 / 134,750 / 159,500 / 184,250 / 209,000'
 WHERE id=184375850


   --row number: 5057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3013602 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=184375851


   --row number: 5058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3013602 , [Content] ='25%'
 WHERE id=184375852


   --row number: 5059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3013602 , [Content] ='Yes'
 WHERE id=184375853


   --row number: 5060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3013602 , [Content] ='EXEMPT'
 WHERE id=184375854


   --row number: 5061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3013602 , [Content] ='NO'
 WHERE id=184375855


   --row number: 5062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3013602 , [Content] ='2 - Professionals'
 WHERE id=184375856


   --row number: 5063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3014365 , [Content] ='Technical'
 WHERE id=184433345


   --row number: 5064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3014365 , [Content] ='06/08/18'
 WHERE id=184433346


   --row number: 5065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3014365 , [Content] ='3594 US - MRKT 1'
 WHERE id=184433327


   --row number: 5066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3014365 , [Content] ='US - MRKT 1'
 WHERE id=184433328


   --row number: 5067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3014365 , [Content] ='AMS'
 WHERE id=184433329


   --row number: 5068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3014365 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184433330


   --row number: 5069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3014365 , [Content] ='Info Systems/Technology'
 WHERE id=184433331


   --row number: 5070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3014365 , [Content] ='3594 - Sr Mgr, Data Informatics Mgmt M4'
 WHERE id=184433332


   --row number: 5071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3014365 , [Content] ='Data Informatics'
 WHERE id=184433333


   --row number: 5072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3014365 , [Content] ='M4'
 WHERE id=184433334


   --row number: 5073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3014365 , [Content] ='USD'
 WHERE id=184433336


   --row number: 5074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3014365 , [Content] ='118,800 / 145,500 / 172,200 / 198,950 / 225,700'
 WHERE id=184433337


   --row number: 5075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3014365 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=184433338


   --row number: 5076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3014365 , [Content] ='25%'
 WHERE id=184433339


   --row number: 5077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3014365 , [Content] ='Yes'
 WHERE id=184433340


   --row number: 5078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3014365 , [Content] ='EXEMPT'
 WHERE id=184433341


   --row number: 5079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3014365 , [Content] ='NO'
 WHERE id=184433342


   --row number: 5080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3014365 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=184433343


   --row number: 5081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3014365 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184433344


   --row number: 5082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3014763 , [Content] ='Technical'
 WHERE id=184480411


   --row number: 5083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3014763 , [Content] ='06/08/18'
 WHERE id=184480412


   --row number: 5084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3014763 , [Content] ='5324 IND'
 WHERE id=184480396


   --row number: 5085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3014763 , [Content] ='IND'
 WHERE id=184480397


   --row number: 5086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3014763 , [Content] ='APAC'
 WHERE id=184480398


   --row number: 5087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3014763 , [Content] ='INDIA'
 WHERE id=184480399


   --row number: 5088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3014763 , [Content] ='Engineering Operations'
 WHERE id=184480400


   --row number: 5089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3014763 , [Content] ='5324 - Technical Editor IC4'
 WHERE id=184480401


   --row number: 5090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3014763 , [Content] ='Technical Editor'
 WHERE id=184480402


   --row number: 5091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3014763 , [Content] ='IC4'
 WHERE id=184480403


   --row number: 5092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3014763 , [Content] ='INR'
 WHERE id=184480405


   --row number: 5093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3014763 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=184480406


   --row number: 5094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3014763 , [Content] ='15%'
 WHERE id=184480407


   --row number: 5095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3014763 , [Content] ='Yes'
 WHERE id=184480408


   --row number: 5096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3014763 , [Content] ='2 - Professionals'
 WHERE id=184480409


   --row number: 5097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3014763 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184480410


   --row number: 5098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3015771 , [Content] ='6572 IND'
 WHERE id=184538378


   --row number: 5099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3015771 , [Content] ='IND'
 WHERE id=184538379


   --row number: 5100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3015771 , [Content] ='APAC'
 WHERE id=184538380


   --row number: 5101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3015771 , [Content] ='INDIA'
 WHERE id=184538381


   --row number: 5102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3015771 , [Content] ='Info Systems/Technology'
 WHERE id=184538382


   --row number: 5103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3015771 , [Content] ='6572 - IT Systems/Support Analyst IC2'
 WHERE id=184538383


   --row number: 5104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3015771 , [Content] ='IT Systems/Support'
 WHERE id=184538384


   --row number: 5105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3015771 , [Content] ='IC2'
 WHERE id=184538385


   --row number: 5106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3015771 , [Content] ='INR'
 WHERE id=184538387


   --row number: 5107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3015771 , [Content] ='503,400 / 616,700 / 730,000 / 843,250 / 956,500'
 WHERE id=184538388


   --row number: 5108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3015771 , [Content] ='10%'
 WHERE id=184538389


   --row number: 5109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3015771 , [Content] ='No'
 WHERE id=184538390


   --row number: 5110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3015771 , [Content] ='2 - Professionals'
 WHERE id=184538391


   --row number: 5111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3015771 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184538392


   --row number: 5112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3015771 , [Content] ='Technical'
 WHERE id=184538393


   --row number: 5113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3015771 , [Content] ='06/08/18'
 WHERE id=184538394


   --row number: 5114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3016262 , [Content] ='06/08/18'
 WHERE id=184574709


   --row number: 5115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3016262 , [Content] ='5706 US - MRKT 3'
 WHERE id=184574691


   --row number: 5116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3016262 , [Content] ='US - MRKT 3'
 WHERE id=184574692


   --row number: 5117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3016262 , [Content] ='AMS'
 WHERE id=184574693


   --row number: 5118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3016262 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184574694


   --row number: 5119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3016262 , [Content] ='Professional Services'
 WHERE id=184574695


   --row number: 5120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3016262 , [Content] ='5706 - Client Relationship Manager IC6'
 WHERE id=184574696


   --row number: 5121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3016262 , [Content] ='Partner Support'
 WHERE id=184574697


   --row number: 5122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3016262 , [Content] ='IC6'
 WHERE id=184574698


   --row number: 5123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3016262 , [Content] ='USD'
 WHERE id=184574700


   --row number: 5124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3016262 , [Content] ='112,400 / 137,700 / 163,000 / 188,300 / 213,600'
 WHERE id=184574701


   --row number: 5125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3016262 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=184574702


   --row number: 5126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3016262 , [Content] ='25%'
 WHERE id=184574703


   --row number: 5127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3016262 , [Content] ='Yes'
 WHERE id=184574704


   --row number: 5128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3016262 , [Content] ='Exempt'
 WHERE id=184574705


   --row number: 5129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3016262 , [Content] ='2 - Professionals'
 WHERE id=184574706


   --row number: 5130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3016262 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184574707


   --row number: 5131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3016262 , [Content] ='Technical'
 WHERE id=184574708


   --row number: 5132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3016325 , [Content] ='Non Technical'
 WHERE id=184579615


   --row number: 5133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3016325 , [Content] ='06/08/18'
 WHERE id=184579616


   --row number: 5134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3016325 , [Content] ='6174 US - MRKT 1'
 WHERE id=184579597


   --row number: 5135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3016325 , [Content] ='US - MRKT 1'
 WHERE id=184579598


   --row number: 5136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3016325 , [Content] ='AMS'
 WHERE id=184579599


   --row number: 5137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3016325 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184579600


   --row number: 5138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3016325 , [Content] ='Finance'
 WHERE id=184579601


   --row number: 5139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3016325 , [Content] ='6174 - Sr. Internal Auditor IC4'
 WHERE id=184579602


   --row number: 5140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3016325 , [Content] ='Internal Audit'
 WHERE id=184579603


   --row number: 5141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3016325 , [Content] ='IC4'
 WHERE id=184579604


   --row number: 5142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3016325 , [Content] ='USD'
 WHERE id=184579606


   --row number: 5143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3016325 , [Content] ='96,200 / 113,500 / 130,800 / 148,150 / 165,500'
 WHERE id=184579607


   --row number: 5144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3016325 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=184579608


   --row number: 5145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3016325 , [Content] ='15%'
 WHERE id=184579609


   --row number: 5146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3016325 , [Content] ='Yes'
 WHERE id=184579610


   --row number: 5147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3016325 , [Content] ='EXEMPT'
 WHERE id=184579611


   --row number: 5148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3016325 , [Content] ='NO'
 WHERE id=184579612


   --row number: 5149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3016325 , [Content] ='2 - Professionals'
 WHERE id=184579613


   --row number: 5150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3016325 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184579614


   --row number: 5151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3016565 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=184596374


   --row number: 5152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3016565 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184596375


   --row number: 5153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3016565 , [Content] ='Technical'
 WHERE id=184596376


   --row number: 5154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3016565 , [Content] ='06/08/18'
 WHERE id=184596377


   --row number: 5155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3016565 , [Content] ='3404 US - MRKT 2'
 WHERE id=184596358


   --row number: 5156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3016565 , [Content] ='US - MRKT 2'
 WHERE id=184596359


   --row number: 5157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3016565 , [Content] ='AMS'
 WHERE id=184596360


   --row number: 5158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3016565 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184596361


   --row number: 5159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3016565 , [Content] ='Info Systems/Technology'
 WHERE id=184596362


   --row number: 5160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3016565 , [Content] ='3404 - Sr Mgr, Information Systems Mgmt M4'
 WHERE id=184596363


   --row number: 5161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3016565 , [Content] ='Information Systems'
 WHERE id=184596364


   --row number: 5162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3016565 , [Content] ='M4'
 WHERE id=184596365


   --row number: 5163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3016565 , [Content] ='USD'
 WHERE id=184596367


   --row number: 5164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3016565 , [Content] ='115,400 / 141,400 / 167,400 / 193,350 / 219,300'
 WHERE id=184596368


   --row number: 5165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3016565 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=184596369


   --row number: 5166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3016565 , [Content] ='25%'
 WHERE id=184596370


   --row number: 5167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3016565 , [Content] ='Yes'
 WHERE id=184596371


   --row number: 5168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3016565 , [Content] ='EXEMPT'
 WHERE id=184596372


   --row number: 5169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3016565 , [Content] ='NO'
 WHERE id=184596373


   --row number: 5170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3016966 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184631594


   --row number: 5171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3016966 , [Content] ='Technical'
 WHERE id=184631595


   --row number: 5172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3016966 , [Content] ='06/08/18'
 WHERE id=184631596


   --row number: 5173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3016966 , [Content] ='6464 US - MRKT 1'
 WHERE id=184631577


   --row number: 5174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3016966 , [Content] ='US - MRKT 1'
 WHERE id=184631578


   --row number: 5175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3016966 , [Content] ='AMS'
 WHERE id=184631579


   --row number: 5176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3016966 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184631580


   --row number: 5177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3016966 , [Content] ='Info Systems/Technology'
 WHERE id=184631581


   --row number: 5178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3016966 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=184631582


   --row number: 5179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3016966 , [Content] ='Business Systems Analysis'
 WHERE id=184631583


   --row number: 5180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3016966 , [Content] ='IC4'
 WHERE id=184631584


   --row number: 5181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3016966 , [Content] ='USD'
 WHERE id=184631586


   --row number: 5182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3016966 , [Content] ='104,200 / 122,950 / 141,700 / 160,450 / 179,200'
 WHERE id=184631587


   --row number: 5183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3016966 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=184631588


   --row number: 5184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3016966 , [Content] ='15%'
 WHERE id=184631589


   --row number: 5185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3016966 , [Content] ='Yes'
 WHERE id=184631590


   --row number: 5186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3016966 , [Content] ='EXEMPT'
 WHERE id=184631591


   --row number: 5187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3016966 , [Content] ='NO'
 WHERE id=184631592


   --row number: 5188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3016966 , [Content] ='2 - Professionals'
 WHERE id=184631593


   --row number: 5189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3017078 , [Content] ='Technical'
 WHERE id=184647916


   --row number: 5190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3017078 , [Content] ='4/25/2018'
 WHERE id=184647917


   --row number: 5191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3017078 , [Content] ='S1515 AUS'
 WHERE id=184647900


   --row number: 5192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3017078 , [Content] ='AUS'
 WHERE id=184647901


   --row number: 5193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3017078 , [Content] ='APAC'
 WHERE id=184647902


   --row number: 5194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3017078 , [Content] ='AUSTRALIA'
 WHERE id=184647903


   --row number: 5195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3017078 , [Content] ='Professional Services'
 WHERE id=184647904


   --row number: 5196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3017078 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=184647905


   --row number: 5197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3017078 , [Content] ='Solution Architect'
 WHERE id=184647906


   --row number: 5198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3017078 , [Content] ='IC5'
 WHERE id=184647907


   --row number: 5199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3017078 , [Content] ='AUD'
 WHERE id=184647909


   --row number: 5200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3017078 , [Content] ='127,200 / 155,800 / 184,400 / 213,050 / 241,700'
 WHERE id=184647910


   --row number: 5201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3017078 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=184647911


   --row number: 5202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3017078 , [Content] ='25%'
 WHERE id=184647912


   --row number: 5203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3017078 , [Content] ='Yes'
 WHERE id=184647913


   --row number: 5204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3017078 , [Content] ='4 - Sales Workers'
 WHERE id=184647914


   --row number: 5205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3017078 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184647915


   --row number: 5206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3017530 , [Content] ='7/20/2018'
 WHERE id=184699153


   --row number: 5207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3017530 , [Content] ='4685 IND'
 WHERE id=184699136


   --row number: 5208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3017530 , [Content] ='IND'
 WHERE id=184699137


   --row number: 5209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3017530 , [Content] ='APAC'
 WHERE id=184699138


   --row number: 5210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3017530 , [Content] ='INDIA'
 WHERE id=184699139


   --row number: 5211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3017530 , [Content] ='Business Strategy'
 WHERE id=184699140


   --row number: 5212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3017530 , [Content] ='4685 - Business Process Analyst IC5'
 WHERE id=184699141


   --row number: 5213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3017530 , [Content] ='Business Process'
 WHERE id=184699142


   --row number: 5214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3017530 , [Content] ='IC5'
 WHERE id=184699143


   --row number: 5215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3017530 , [Content] ='INR'
 WHERE id=184699145


   --row number: 5216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3017530 , [Content] ='1,827,600 / 2,238,800 / 2,650,000 / 3,061,200 / 3,472,400'
 WHERE id=184699146


   --row number: 5217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3017530 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=184699147


   --row number: 5218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3017530 , [Content] ='20%'
 WHERE id=184699148


   --row number: 5219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3017530 , [Content] ='Yes'
 WHERE id=184699149


   --row number: 5220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3017530 , [Content] ='2 - Professionals'
 WHERE id=184699150


   --row number: 5221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3017530 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184699151


   --row number: 5222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3017530 , [Content] ='Technical'
 WHERE id=184699152


   --row number: 5223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3018308 , [Content] ='5775 US - MRKT 2'
 WHERE id=184770597


   --row number: 5224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3018308 , [Content] ='US - MRKT 2'
 WHERE id=184770598


   --row number: 5225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3018308 , [Content] ='AMS'
 WHERE id=184770599


   --row number: 5226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3018308 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184770600


   --row number: 5227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3018308 , [Content] ='Professional Services'
 WHERE id=184770601


   --row number: 5228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3018308 , [Content] ='5775 - Business Process Consultant IC5'
 WHERE id=184770602


   --row number: 5229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3018308 , [Content] ='Business Process Consulting'
 WHERE id=184770603


   --row number: 5230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3018308 , [Content] ='IC5'
 WHERE id=184770604


   --row number: 5231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3018308 , [Content] ='USD'
 WHERE id=184770606


   --row number: 5232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3018308 , [Content] ='106,700 / 129,050 / 151,400 / 173,750 / 196,100'
 WHERE id=184770607


   --row number: 5233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3018308 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184770614


   --row number: 5234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3018308 , [Content] ='Technical'
 WHERE id=184770615


   --row number: 5235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3018308 , [Content] ='7/20/18'
 WHERE id=184770616


   --row number: 5236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3018308 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=184770608


   --row number: 5237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3018308 , [Content] ='20%'
 WHERE id=184770609


   --row number: 5238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3018308 , [Content] ='Yes'
 WHERE id=184770610


   --row number: 5239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3018308 , [Content] ='EXEMPT'
 WHERE id=184770611


   --row number: 5240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3018308 , [Content] ='NO'
 WHERE id=184770612


   --row number: 5241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3018308 , [Content] ='2 - Professionals'
 WHERE id=184770613


   --row number: 5242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3018601 , [Content] ='S623A - Commercial Account Mgr IC3'
 WHERE id=184793603


   --row number: 5243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3018601 , [Content] ='4 - Sales Workers'
 WHERE id=184793614


   --row number: 5244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3018601 , [Content] ='8742-Salespersons - Outside'
 WHERE id=184793615


   --row number: 5245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3018601 , [Content] ='Technical'
 WHERE id=184793616


   --row number: 5246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3018601 , [Content] ='06/08/18'
 WHERE id=184793617


   --row number: 5247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3018601 , [Content] ='Commercial Accounts'
 WHERE id=184793604


   --row number: 5248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3018601 , [Content] ='IC3'
 WHERE id=184793605


   --row number: 5249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3018601 , [Content] ='USD'
 WHERE id=184793607


   --row number: 5250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3018601 , [Content] ='S623A US - MRKT 1'
 WHERE id=184793598


   --row number: 5251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3018601 , [Content] ='US - MRKT 1'
 WHERE id=184793599


   --row number: 5252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3018601 , [Content] ='AMS'
 WHERE id=184793600


   --row number: 5253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3018601 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184793601


   --row number: 5254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3018601 , [Content] ='Sales'
 WHERE id=184793602


   --row number: 5255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3018601 , [Content] ='119,000 / 129,500 / 140,000 / 150,500 / 161,000'
 WHERE id=184793608


   --row number: 5256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3018601 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=184793609


   --row number: 5257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3018601 , [Content] ='70/30'
 WHERE id=184793610


   --row number: 5258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3018601 , [Content] ='No'
 WHERE id=184793611


   --row number: 5259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3018601 , [Content] ='EXEMPT'
 WHERE id=184793612


   --row number: 5260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3018601 , [Content] ='NO'
 WHERE id=184793613


   --row number: 5261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3018612 , [Content] ='8742-Salespersons - Outside'
 WHERE id=184794295


   --row number: 5262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3018612 , [Content] ='Technical'
 WHERE id=184794296


   --row number: 5263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3018612 , [Content] ='06/08/18'
 WHERE id=184794297


   --row number: 5264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3018612 , [Content] ='S623A US - MRKT 1'
 WHERE id=184794278


   --row number: 5265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3018612 , [Content] ='US - MRKT 1'
 WHERE id=184794279


   --row number: 5266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3018612 , [Content] ='AMS'
 WHERE id=184794280


   --row number: 5267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3018612 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184794281


   --row number: 5268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3018612 , [Content] ='Sales'
 WHERE id=184794282


   --row number: 5269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3018612 , [Content] ='S623A - Commercial Account Mgr IC3'
 WHERE id=184794283


   --row number: 5270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3018612 , [Content] ='Commercial Accounts'
 WHERE id=184794284


   --row number: 5271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3018612 , [Content] ='IC3'
 WHERE id=184794285


   --row number: 5272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3018612 , [Content] ='USD'
 WHERE id=184794287


   --row number: 5273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3018612 , [Content] ='119,000 / 129,500 / 140,000 / 150,500 / 161,000'
 WHERE id=184794288


   --row number: 5274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3018612 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=184794289


   --row number: 5275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3018612 , [Content] ='70/30'
 WHERE id=184794290


   --row number: 5276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3018612 , [Content] ='No'
 WHERE id=184794291


   --row number: 5277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3018612 , [Content] ='EXEMPT'
 WHERE id=184794292


   --row number: 5278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3018612 , [Content] ='NO'
 WHERE id=184794293


   --row number: 5279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3018612 , [Content] ='4 - Sales Workers'
 WHERE id=184794294


   --row number: 5280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3018622 , [Content] ='4 - Sales Workers'
 WHERE id=184794979


   --row number: 5281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3018622 , [Content] ='8742-Salespersons - Outside'
 WHERE id=184794980


   --row number: 5282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3018622 , [Content] ='Technical'
 WHERE id=184794981


   --row number: 5283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3018622 , [Content] ='06/08/18'
 WHERE id=184794982


   --row number: 5284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3018622 , [Content] ='S623A US - MRKT 1'
 WHERE id=184794963


   --row number: 5285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3018622 , [Content] ='US - MRKT 1'
 WHERE id=184794964


   --row number: 5286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3018622 , [Content] ='AMS'
 WHERE id=184794965


   --row number: 5287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3018622 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=184794966


   --row number: 5288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3018622 , [Content] ='Sales'
 WHERE id=184794967


   --row number: 5289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3018622 , [Content] ='S623A - Commercial Account Mgr IC3'
 WHERE id=184794968


   --row number: 5290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3018622 , [Content] ='Commercial Accounts'
 WHERE id=184794969


   --row number: 5291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3018622 , [Content] ='IC3'
 WHERE id=184794970


   --row number: 5292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3018622 , [Content] ='USD'
 WHERE id=184794972


   --row number: 5293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3018622 , [Content] ='119,000 / 129,500 / 140,000 / 150,500 / 161,000'
 WHERE id=184794973


   --row number: 5294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3018622 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=184794974


   --row number: 5295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3018622 , [Content] ='70/30'
 WHERE id=184794975


   --row number: 5296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3018622 , [Content] ='No'
 WHERE id=184794976


   --row number: 5297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3018622 , [Content] ='EXEMPT'
 WHERE id=184794977


   --row number: 5298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3018622 , [Content] ='NO'
 WHERE id=184794978


   --row number: 5299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3019108 , [Content] ='5763 JPN'
 WHERE id=184847453


   --row number: 5300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3019108 , [Content] ='JPN'
 WHERE id=184847454


   --row number: 5301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3019108 , [Content] ='APAC'
 WHERE id=184847455


   --row number: 5302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3019108 , [Content] ='JAPAN'
 WHERE id=184847456


   --row number: 5303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3019108 , [Content] ='Professional Services'
 WHERE id=184847457


   --row number: 5304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3019108 , [Content] ='5763 - Technology Consultant IC3'
 WHERE id=184847458


   --row number: 5305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3019108 , [Content] ='Technology Consultant'
 WHERE id=184847459


   --row number: 5306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3019108 , [Content] ='IC3'
 WHERE id=184847460


   --row number: 5307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3019108 , [Content] ='JPY'
 WHERE id=184847462


   --row number: 5308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3019108 , [Content] ='06/08/18'
 WHERE id=184847470


   --row number: 5309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3023859 , [Content] ='Product Line Sales'
 WHERE id=185253417


   --row number: 5310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3023859 , [Content] ='IC5'
 WHERE id=185253418


   --row number: 5311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3023859 , [Content] ='USD'
 WHERE id=185253420


   --row number: 5312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3023859 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=185253421


   --row number: 5313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3023859 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=185253422


   --row number: 5314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3023859 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=185253423


   --row number: 5315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3023859 , [Content] ='60/40'
 WHERE id=185253424


   --row number: 5316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3023859 , [Content] ='Yes'
 WHERE id=185253425


   --row number: 5317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3023859 , [Content] ='EXEMPT'
 WHERE id=185253426


   --row number: 5318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3023859 , [Content] ='NO'
 WHERE id=185253427


   --row number: 5319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3023859 , [Content] ='4 - Sales Workers'
 WHERE id=185253428


   --row number: 5320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3023859 , [Content] ='8742-Salespersons - Outside'
 WHERE id=185253429


   --row number: 5321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3023859 , [Content] ='Technical'
 WHERE id=185253430


   --row number: 5322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3023859 , [Content] ='06/08/18'
 WHERE id=185253432


   --row number: 5323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3023859 , [Content] ='S665 US - MRKT 1'
 WHERE id=185253411


   --row number: 5324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3023859 , [Content] ='US - MRKT 1'
 WHERE id=185253412


   --row number: 5325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3023859 , [Content] ='AMS'
 WHERE id=185253413


   --row number: 5326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3023859 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185253414


   --row number: 5327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3023859 , [Content] ='Sales'
 WHERE id=185253415


   --row number: 5328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3023859 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=185253416


   --row number: 5329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3019108 , [Content] ='6,437,500 / 7,596,250 / 8,755,000 / 9,913,750 / 11,072,500'
 WHERE id=184847463


   --row number: 5330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3019108 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=184847464


   --row number: 5331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3019108 , [Content] ='15%'
 WHERE id=184847465


   --row number: 5332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3019108 , [Content] ='Yes'
 WHERE id=184847466


   --row number: 5333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3019108 , [Content] ='2 - Professionals'
 WHERE id=184847467


   --row number: 5334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3019108 , [Content] ='8810-Clerical Office Employees'
 WHERE id=184847468


   --row number: 5335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3019108 , [Content] ='Technical'
 WHERE id=184847469


   --row number: 5336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3023864 , [Content] ='2 - Professionals'
 WHERE id=185253836


   --row number: 5337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3023864 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185253837


   --row number: 5338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3023864 , [Content] ='Technical'
 WHERE id=185253838


   --row number: 5339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3023864 , [Content] ='06/08/18'
 WHERE id=185253839


   --row number: 5340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3023864 , [Content] ='5774 US - MRKT 1'
 WHERE id=185253820


   --row number: 5341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3023864 , [Content] ='US - MRKT 1'
 WHERE id=185253821


   --row number: 5342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3023864 , [Content] ='AMS'
 WHERE id=185253822


   --row number: 5343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3023864 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185253823


   --row number: 5344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3023864 , [Content] ='Professional Services'
 WHERE id=185253824


   --row number: 5345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3023864 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=185253825


   --row number: 5346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3023864 , [Content] ='Business Process Consulting'
 WHERE id=185253826


   --row number: 5347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3023864 , [Content] ='IC4'
 WHERE id=185253827


   --row number: 5348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3023864 , [Content] ='USD'
 WHERE id=185253829


   --row number: 5349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3023864 , [Content] ='94,600 / 111,650 / 128,700 / 145,700 / 162,700'
 WHERE id=185253830


   --row number: 5350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3023864 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=185253831


   --row number: 5351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3023864 , [Content] ='15%'
 WHERE id=185253832


   --row number: 5352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3023864 , [Content] ='Yes'
 WHERE id=185253833


   --row number: 5353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3023864 , [Content] ='EXEMPT'
 WHERE id=185253834


   --row number: 5354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3023864 , [Content] ='NO'
 WHERE id=185253835


   --row number: 5355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3024068 , [Content] ='4 - Sales Workers'
 WHERE id=185279248


   --row number: 5356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3024068 , [Content] ='8742-Salespersons - Outside'
 WHERE id=185279249


   --row number: 5357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3024068 , [Content] ='Technical'
 WHERE id=185279250


   --row number: 5358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3024068 , [Content] ='06/08/18'
 WHERE id=185279251


   --row number: 5359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3024068 , [Content] ='S665 US - MRKT 2'
 WHERE id=185279231


   --row number: 5360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3024068 , [Content] ='US - MRKT 2'
 WHERE id=185279232


   --row number: 5361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3024068 , [Content] ='AMS'
 WHERE id=185279233


   --row number: 5362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3024068 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185279234


   --row number: 5363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3024068 , [Content] ='Sales'
 WHERE id=185279235


   --row number: 5364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3024068 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=185279236


   --row number: 5365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3024068 , [Content] ='Product Line Sales'
 WHERE id=185279237


   --row number: 5366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3024068 , [Content] ='IC5'
 WHERE id=185279238


   --row number: 5367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3024068 , [Content] ='USD'
 WHERE id=185279240


   --row number: 5368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3024068 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=185279241


   --row number: 5369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3024068 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=185279242


   --row number: 5370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3024068 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=185279243


   --row number: 5371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3024068 , [Content] ='60/40'
 WHERE id=185279244


   --row number: 5372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3024068 , [Content] ='Yes'
 WHERE id=185279245


   --row number: 5373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3024068 , [Content] ='EXEMPT'
 WHERE id=185279246


   --row number: 5374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3024068 , [Content] ='NO'
 WHERE id=185279247


   --row number: 5375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3024262 , [Content] ='5612 IND'
 WHERE id=185319063


   --row number: 5376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3024262 , [Content] ='IND'
 WHERE id=185319064


   --row number: 5377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3024262 , [Content] ='APAC'
 WHERE id=185319065


   --row number: 5378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3024262 , [Content] ='INDIA'
 WHERE id=185319066


   --row number: 5379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3024262 , [Content] ='Marketing'
 WHERE id=185319067


   --row number: 5380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3024262 , [Content] ='5612 - Marketing Mgr IC2'
 WHERE id=185319068


   --row number: 5381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3024262 , [Content] ='Marketing'
 WHERE id=185319069


   --row number: 5382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3024262 , [Content] ='IC2'
 WHERE id=185319070


   --row number: 5383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3024262 , [Content] ='INR'
 WHERE id=185319072


   --row number: 5384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3024262 , [Content] ='634,500 / 777,250 / 920,000 / 1,062,800 / 1,205,600'
 WHERE id=185319073


   --row number: 5385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3024262 , [Content] ='10%'
 WHERE id=185319074


   --row number: 5386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3024262 , [Content] ='No'
 WHERE id=185319075


   --row number: 5387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3024262 , [Content] ='2 - Professionals'
 WHERE id=185319076


   --row number: 5388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3024262 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185319077


   --row number: 5389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3024262 , [Content] ='Non Technical'
 WHERE id=185319078


   --row number: 5390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3024262 , [Content] ='06/08/18'
 WHERE id=185319079


   --row number: 5391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3024425 , [Content] ='7/20/2018'
 WHERE id=185326853


   --row number: 5392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3024425 , [Content] ='5144 NLD'
 WHERE id=185326836


   --row number: 5393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3024425 , [Content] ='NLD'
 WHERE id=185326837


   --row number: 5394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3024425 , [Content] ='EMEA'
 WHERE id=185326838


   --row number: 5395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3024425 , [Content] ='NETHERLANDS'
 WHERE id=185326839


   --row number: 5396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3024425 , [Content] ='Engineering'
 WHERE id=185326840


   --row number: 5397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3024425 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=185326841


   --row number: 5398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3024425 , [Content] ='Software'
 WHERE id=185326842


   --row number: 5399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3024425 , [Content] ='IC4'
 WHERE id=185326843


   --row number: 5400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3024425 , [Content] ='EUR'
 WHERE id=185326845


   --row number: 5401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3024425 , [Content] ='62,700 / 75,850 / 89,000 / 102,100 / 115,200'
 WHERE id=185326846


   --row number: 5402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3024425 , [Content] ='132,000 / 186,000 / 240,000 / 294,000 / 348,000'
 WHERE id=185326847


   --row number: 5403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3024425 , [Content] ='20%'
 WHERE id=185326848


   --row number: 5404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3024425 , [Content] ='Yes'
 WHERE id=185326849


   --row number: 5405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3024425 , [Content] ='2 - Professionals'
 WHERE id=185326850


   --row number: 5406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3024425 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=185326851


   --row number: 5407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3024425 , [Content] ='Technical'
 WHERE id=185326852


   --row number: 5408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3025431 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=185388415


   --row number: 5409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3025431 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185388416


   --row number: 5410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3025431 , [Content] ='Technical'
 WHERE id=185388417


   --row number: 5411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3025431 , [Content] ='06/08/18'
 WHERE id=185388418


   --row number: 5412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3025431 , [Content] ='3425 US - MRKT 2'
 WHERE id=185388399


   --row number: 5413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3025431 , [Content] ='US - MRKT 2'
 WHERE id=185388400


   --row number: 5414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3025431 , [Content] ='AMS'
 WHERE id=185388401


   --row number: 5415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3025431 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185388402


   --row number: 5416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3025431 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=185388403


   --row number: 5417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3025431 , [Content] ='3425 - Dir, Data Center Operations Mgmt M5'
 WHERE id=185388404


   --row number: 5418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3025431 , [Content] ='Data center operations'
 WHERE id=185388405


   --row number: 5419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3025431 , [Content] ='M5'
 WHERE id=185388406


   --row number: 5420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3025431 , [Content] ='USD'
 WHERE id=185388408


   --row number: 5421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3025431 , [Content] ='122,900 / 150,550 / 178,200 / 205,850 / 233,500'
 WHERE id=185388409


   --row number: 5422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3025431 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=185388410


   --row number: 5423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3025431 , [Content] ='25%'
 WHERE id=185388411


   --row number: 5424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3025431 , [Content] ='Yes'
 WHERE id=185388412


   --row number: 5425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3025431 , [Content] ='EXEMPT'
 WHERE id=185388413


   --row number: 5426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3025431 , [Content] ='NO'
 WHERE id=185388414


   --row number: 5427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3026095 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185452378


   --row number: 5428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3026095 , [Content] ='Technical'
 WHERE id=185452379


   --row number: 5429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3026095 , [Content] ='06/08/18'
 WHERE id=185452380


   --row number: 5430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3026095 , [Content] ='5876 US - MRKT 2'
 WHERE id=185452361


   --row number: 5431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3026095 , [Content] ='US - MRKT 2'
 WHERE id=185452362


   --row number: 5432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3026095 , [Content] ='AMS'
 WHERE id=185452363


   --row number: 5433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3026095 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185452364


   --row number: 5434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3026095 , [Content] ='Professional Services'
 WHERE id=185452365


   --row number: 5435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3026095 , [Content] ='5876 - Engagement Mgr IC6'
 WHERE id=185452366


   --row number: 5436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3026095 , [Content] ='Engagement Mgrs'
 WHERE id=185452367


   --row number: 5437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3026095 , [Content] ='IC6'
 WHERE id=185452368


   --row number: 5438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3026095 , [Content] ='USD'
 WHERE id=185452370


   --row number: 5439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3026095 , [Content] ='117,400 / 143,850 / 170,300 / 196,700 / 223,100'
 WHERE id=185452371


   --row number: 5440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3026095 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=185452372


   --row number: 5441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3026095 , [Content] ='25%'
 WHERE id=185452373


   --row number: 5442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3026095 , [Content] ='Yes'
 WHERE id=185452374


   --row number: 5443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3026095 , [Content] ='EXEMPT'
 WHERE id=185452375


   --row number: 5444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3026095 , [Content] ='NO'
 WHERE id=185452376


   --row number: 5445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3026095 , [Content] ='2 - Professionals'
 WHERE id=185452377


   --row number: 5446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3026189 , [Content] ='Non Technical'
 WHERE id=185458629


   --row number: 5447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3026189 , [Content] ='06/08/18'
 WHERE id=185458630


   --row number: 5448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3026189 , [Content] ='3053 US - MRKT 1'
 WHERE id=185458611


   --row number: 5449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3026189 , [Content] ='US - MRKT 1'
 WHERE id=185458612


   --row number: 5450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3026189 , [Content] ='AMS'
 WHERE id=185458613


   --row number: 5451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3026189 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185458614


   --row number: 5452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3026189 , [Content] ='Finance'
 WHERE id=185458615


   --row number: 5453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3026189 , [Content] ='3053 - Mgr, Internal Audit Mgmt M3'
 WHERE id=185458616


   --row number: 5454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3026189 , [Content] ='Internal Audit'
 WHERE id=185458617


   --row number: 5455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3026189 , [Content] ='M3'
 WHERE id=185458618


   --row number: 5456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3026189 , [Content] ='USD'
 WHERE id=185458620


   --row number: 5457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3026189 , [Content] ='114,400 / 138,400 / 162,400 / 186,350 / 210,300'
 WHERE id=185458621


   --row number: 5458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3026189 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=185458622


   --row number: 5459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3026189 , [Content] ='20%'
 WHERE id=185458623


   --row number: 5460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3026189 , [Content] ='Yes'
 WHERE id=185458624


   --row number: 5461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3026189 , [Content] ='EXEMPT'
 WHERE id=185458625


   --row number: 5462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3026189 , [Content] ='NO'
 WHERE id=185458626


   --row number: 5463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3026189 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=185458627


   --row number: 5464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3026189 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185458628


   --row number: 5465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3027762 , [Content] ='2 - Professionals'
 WHERE id=185591120


   --row number: 5466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3027762 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=185591121


   --row number: 5467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3027762 , [Content] ='5142 US - MRKT 2'
 WHERE id=185591104


   --row number: 5468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3027762 , [Content] ='US - MRKT 2'
 WHERE id=185591105


   --row number: 5469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3027762 , [Content] ='AMS'
 WHERE id=185591106


   --row number: 5470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3027762 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185591107


   --row number: 5471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3027762 , [Content] ='Engineering'
 WHERE id=185591108


   --row number: 5472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3027762 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=185591109


   --row number: 5473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3027762 , [Content] ='Software'
 WHERE id=185591110


   --row number: 5474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3027762 , [Content] ='IC2'
 WHERE id=185591111


   --row number: 5475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3027762 , [Content] ='USD'
 WHERE id=185591113


   --row number: 5476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3027762 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=185591114


   --row number: 5477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3027762 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=185591115


   --row number: 5478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3027762 , [Content] ='10%'
 WHERE id=185591116


   --row number: 5479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3027762 , [Content] ='Yes'
 WHERE id=185591117


   --row number: 5480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3027762 , [Content] ='EXEMPT'
 WHERE id=185591118


   --row number: 5481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3027762 , [Content] ='NO'
 WHERE id=185591119


   --row number: 5482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3027762 , [Content] ='Technical'
 WHERE id=185591122


   --row number: 5483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3027762 , [Content] ='04/05/18'
 WHERE id=185591123


   --row number: 5484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3030962 , [Content] ='NO'
 WHERE id=185761311


   --row number: 5485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3030962 , [Content] ='Non Technical'
 WHERE id=185761314


   --row number: 5486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3030962 , [Content] ='06/08/18'
 WHERE id=185761315


   --row number: 5487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3030962 , [Content] ='4 - Sales Workers'
 WHERE id=185761312


   --row number: 5488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3030962 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185761313


   --row number: 5489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3030962 , [Content] ='S1332 US - MRKT 2'
 WHERE id=185761296


   --row number: 5490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3030962 , [Content] ='US - MRKT 2'
 WHERE id=185761297


   --row number: 5491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3030962 , [Content] ='AMS'
 WHERE id=185761298


   --row number: 5492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3030962 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185761299


   --row number: 5493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3030962 , [Content] ='Sales'
 WHERE id=185761300


   --row number: 5494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3030962 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=185761301


   --row number: 5495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3030962 , [Content] ='Inside Sales'
 WHERE id=185761302


   --row number: 5496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3030962 , [Content] ='A2'
 WHERE id=185761303


   --row number: 5497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3030962 , [Content] ='USD'
 WHERE id=185761305


   --row number: 5498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3030962 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=185761306


   --row number: 5499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3030962 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=185761307


   --row number: 5500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3030962 , [Content] ='60/40'
 WHERE id=185761308


   --row number: 5501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3030962 , [Content] ='No'
 WHERE id=185761309


   --row number: 5502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3030962 , [Content] ='NON-EXEMPT'
 WHERE id=185761310


   --row number: 5503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3030968 , [Content] ='5876 CAN'
 WHERE id=185762056


   --row number: 5504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3030968 , [Content] ='CAN'
 WHERE id=185762057


   --row number: 5505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3030968 , [Content] ='AMS'
 WHERE id=185762058


   --row number: 5506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3030968 , [Content] ='CANADA'
 WHERE id=185762059


   --row number: 5507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3030968 , [Content] ='Professional Services'
 WHERE id=185762060


   --row number: 5508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3030968 , [Content] ='5876 - Engagement Mgr IC6'
 WHERE id=185762061


   --row number: 5509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3030968 , [Content] ='Engagement Mgrs'
 WHERE id=185762062


   --row number: 5510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3030968 , [Content] ='IC6'
 WHERE id=185762063


   --row number: 5511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3030968 , [Content] ='CAD'
 WHERE id=185762065


   --row number: 5512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3030968 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=185762067


   --row number: 5513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3030968 , [Content] ='25%'
 WHERE id=185762068


   --row number: 5514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3030968 , [Content] ='Yes'
 WHERE id=185762069


   --row number: 5515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3030968 , [Content] ='2 - Professionals'
 WHERE id=185762070


   --row number: 5516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3030968 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185762071


   --row number: 5517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3030968 , [Content] ='Technical'
 WHERE id=185762072


   --row number: 5518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3030968 , [Content] ='10/05/18'
 WHERE id=185762073


   --row number: 5519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3031022 , [Content] ='3054 IND'
 WHERE id=185765788


   --row number: 5520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3031022 , [Content] ='IND'
 WHERE id=185765789


   --row number: 5521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3031022 , [Content] ='APAC'
 WHERE id=185765790


   --row number: 5522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3031022 , [Content] ='INDIA'
 WHERE id=185765791


   --row number: 5523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3031022 , [Content] ='Finance'
 WHERE id=185765792


   --row number: 5524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3031022 , [Content] ='3054 - Sr Mgr, Internal Audit Mgmt M4'
 WHERE id=185765795


   --row number: 5525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3031022 , [Content] ='Internal Audit'
 WHERE id=185765796


   --row number: 5526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3031022 , [Content] ='M4'
 WHERE id=185765797


   --row number: 5527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3031022 , [Content] ='INR'
 WHERE id=185765799


   --row number: 5528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3031022 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=185765800


   --row number: 5529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3031022 , [Content] ='25%'
 WHERE id=185765801


   --row number: 5530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3031022 , [Content] ='Yes'
 WHERE id=185765802


   --row number: 5531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3031022 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=185765803


   --row number: 5532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3031022 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185765804


   --row number: 5533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3031022 , [Content] ='Non Technical'
 WHERE id=185765805


   --row number: 5534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3031022 , [Content] ='06/08/18'
 WHERE id=185765806


   --row number: 5535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3031049 , [Content] ='6493 IND'
 WHERE id=185767278


   --row number: 5536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3031049 , [Content] ='IND'
 WHERE id=185767279


   --row number: 5537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3031049 , [Content] ='APAC'
 WHERE id=185767280


   --row number: 5538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3031049 , [Content] ='INDIA'
 WHERE id=185767281


   --row number: 5539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3031049 , [Content] ='Info Systems/Technology'
 WHERE id=185767282


   --row number: 5540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3031049 , [Content] ='6493 - Data Informatics Analyst IC3'
 WHERE id=185767283


   --row number: 5541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3031049 , [Content] ='Data Informatics'
 WHERE id=185767284


   --row number: 5542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3031049 , [Content] ='IC3'
 WHERE id=185767285


   --row number: 5543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3031049 , [Content] ='INR'
 WHERE id=185767287


   --row number: 5544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3031049 , [Content] ='1,337,900 / 1,638,950 / 1,940,000 / 2,241,000 / 2,542,000'
 WHERE id=185767288


   --row number: 5545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3031049 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=185767289


   --row number: 5546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3031049 , [Content] ='15%'
 WHERE id=185767290


   --row number: 5547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3031049 , [Content] ='Yes'
 WHERE id=185767291


   --row number: 5548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3031049 , [Content] ='2 - Professionals'
 WHERE id=185767292


   --row number: 5549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3031049 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185767293


   --row number: 5550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3031049 , [Content] ='Technical'
 WHERE id=185767294


   --row number: 5551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3031049 , [Content] ='7/20/2018'
 WHERE id=185767295


   --row number: 5552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3031096 , [Content] ='6493 IND'
 WHERE id=185769302


   --row number: 5553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3031096 , [Content] ='IND'
 WHERE id=185769303


   --row number: 5554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3031096 , [Content] ='APAC'
 WHERE id=185769304


   --row number: 5555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3031096 , [Content] ='INDIA'
 WHERE id=185769305


   --row number: 5556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3031096 , [Content] ='Info Systems/Technology'
 WHERE id=185769306


   --row number: 5557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3031096 , [Content] ='6493 - Data Informatics Analyst IC3'
 WHERE id=185769307


   --row number: 5558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3031096 , [Content] ='Data Informatics'
 WHERE id=185769308


   --row number: 5559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3031096 , [Content] ='IC3'
 WHERE id=185769309


   --row number: 5560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3031096 , [Content] ='INR'
 WHERE id=185769311


   --row number: 5561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3031096 , [Content] ='1,337,900 / 1,638,950 / 1,940,000 / 2,241,000 / 2,542,000'
 WHERE id=185769312


   --row number: 5562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3031096 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=185769313


   --row number: 5563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3031096 , [Content] ='15%'
 WHERE id=185769314


   --row number: 5564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3031096 , [Content] ='Yes'
 WHERE id=185769315


   --row number: 5565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3031096 , [Content] ='2 - Professionals'
 WHERE id=185769316


   --row number: 5566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3031096 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185769317


   --row number: 5567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3031096 , [Content] ='Technical'
 WHERE id=185769318


   --row number: 5568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3031096 , [Content] ='7/20/2018'
 WHERE id=185769319


   --row number: 5569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3031432 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=185787268


   --row number: 5570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3031432 , [Content] ='Technical'
 WHERE id=185787269


   --row number: 5571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3031432 , [Content] ='06/08/18'
 WHERE id=185787270


   --row number: 5572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3031432 , [Content] ='5143 US - MRKT 2'
 WHERE id=185787251


   --row number: 5573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3031432 , [Content] ='US - MRKT 2'
 WHERE id=185787252


   --row number: 5574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3031432 , [Content] ='AMS'
 WHERE id=185787253


   --row number: 5575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3031432 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185787254


   --row number: 5576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3031432 , [Content] ='Engineering'
 WHERE id=185787255


   --row number: 5577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3031432 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=185787256


   --row number: 5578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3031432 , [Content] ='Software'
 WHERE id=185787257


   --row number: 5579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3031432 , [Content] ='IC3'
 WHERE id=185787258


   --row number: 5580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3031432 , [Content] ='USD'
 WHERE id=185787260


   --row number: 5581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3031432 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=185787261


   --row number: 5582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3031432 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=185787262


   --row number: 5583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3031432 , [Content] ='15%'
 WHERE id=185787263


   --row number: 5584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3031432 , [Content] ='Yes'
 WHERE id=185787264


   --row number: 5585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3031432 , [Content] ='EXEMPT'
 WHERE id=185787265


   --row number: 5586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3031432 , [Content] ='NO'
 WHERE id=185787266


   --row number: 5587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3031432 , [Content] ='2 - Professionals'
 WHERE id=185787267


   --row number: 5588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3031913 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185804300


   --row number: 5589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3031913 , [Content] ='Technical'
 WHERE id=185804301


   --row number: 5590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3031913 , [Content] ='06/08/18'
 WHERE id=185804302


   --row number: 5591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3031913 , [Content] ='6625 US - MRKT 1'
 WHERE id=185804283


   --row number: 5592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3031913 , [Content] ='US - MRKT 1'
 WHERE id=185804284


   --row number: 5593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3031913 , [Content] ='AMS'
 WHERE id=185804285


   --row number: 5594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3031913 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185804286


   --row number: 5595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3031913 , [Content] ='Info Systems/Technology'
 WHERE id=185804287


   --row number: 5596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3031913 , [Content] ='6625 - Project (Information Systems) Mgr IC5'
 WHERE id=185804288


   --row number: 5597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3031913 , [Content] ='IT Project/Program Mgrs'
 WHERE id=185804289


   --row number: 5598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3031913 , [Content] ='IC5'
 WHERE id=185804290


   --row number: 5599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3031913 , [Content] ='USD'
 WHERE id=185804292


   --row number: 5600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3031913 , [Content] ='116,200 / 142,350 / 168,500 / 194,650 / 220,800'
 WHERE id=185804293


   --row number: 5601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3031913 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=185804294


   --row number: 5602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3031913 , [Content] ='25%'
 WHERE id=185804295


   --row number: 5603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3031913 , [Content] ='Yes'
 WHERE id=185804296


   --row number: 5604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3031913 , [Content] ='EXEMPT'
 WHERE id=185804297


   --row number: 5605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3031913 , [Content] ='NO'
 WHERE id=185804298


   --row number: 5606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3031913 , [Content] ='2 - Professionals'
 WHERE id=185804299


   --row number: 5607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3032125 , [Content] ='S1332 US - MRKT 2'
 WHERE id=185823274


   --row number: 5608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3032125 , [Content] ='US - MRKT 2'
 WHERE id=185823275


   --row number: 5609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3032125 , [Content] ='AMS'
 WHERE id=185823276


   --row number: 5610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3032125 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185823277


   --row number: 5611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3032125 , [Content] ='Sales'
 WHERE id=185823278


   --row number: 5612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3032125 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=185823279


   --row number: 5613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3032125 , [Content] ='Inside Sales'
 WHERE id=185823280


   --row number: 5614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3032125 , [Content] ='A2'
 WHERE id=185823281


   --row number: 5615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3032125 , [Content] ='USD'
 WHERE id=185823283


   --row number: 5616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3032125 , [Content] ='60/40'
 WHERE id=185823284


   --row number: 5617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3032125 , [Content] ='No'
 WHERE id=185823285


   --row number: 5618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3032125 , [Content] ='NON-EXEMPT'
 WHERE id=185823286


   --row number: 5619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3032125 , [Content] ='NO'
 WHERE id=185823287


   --row number: 5620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3032125 , [Content] ='4 - Sales Workers'
 WHERE id=185823288


   --row number: 5621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3032125 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185823289


   --row number: 5622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3032125 , [Content] ='Non Technical'
 WHERE id=185823290


   --row number: 5623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3032125 , [Content] ='02/09/18'
 WHERE id=185823291


   --row number: 5624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3032489 , [Content] ='Technical'
 WHERE id=185858769


   --row number: 5625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3032489 , [Content] ='09/05/18'
 WHERE id=185858770


   --row number: 5626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3032489 , [Content] ='2845 US - MRKT 2'
 WHERE id=185858751


   --row number: 5627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3032489 , [Content] ='US - MRKT 2'
 WHERE id=185858752


   --row number: 5628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3032489 , [Content] ='AMS'
 WHERE id=185858753


   --row number: 5629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3032489 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=185858754


   --row number: 5630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3032489 , [Content] ='Professional Services'
 WHERE id=185858755


   --row number: 5631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3032489 , [Content] ='2845 - Dir, Customer/Technical Training Mgmt M5'
 WHERE id=185858756


   --row number: 5632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3032489 , [Content] ='Customer/Tech Training'
 WHERE id=185858757


   --row number: 5633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3032489 , [Content] ='M5'
 WHERE id=185858758


   --row number: 5634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3032489 , [Content] ='USD'
 WHERE id=185858760


   --row number: 5635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3032489 , [Content] ='111,400 / 136,450 / 161,500 / 186,600 / 211,700'
 WHERE id=185858761


   --row number: 5636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3032489 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=185858762


   --row number: 5637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3032489 , [Content] ='25%'
 WHERE id=185858763


   --row number: 5638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3032489 , [Content] ='Yes'
 WHERE id=185858764


   --row number: 5639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3032489 , [Content] ='EXEMPT'
 WHERE id=185858765


   --row number: 5640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3032489 , [Content] ='NO'
 WHERE id=185858766


   --row number: 5641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3032489 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=185858767


   --row number: 5642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3032489 , [Content] ='8810-Clerical Office Employees'
 WHERE id=185858768


   --row number: 5643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3033018 , [Content] ='5142 IND'
 WHERE id=185905708


   --row number: 5644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3033018 , [Content] ='IND'
 WHERE id=185905709


   --row number: 5645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3033018 , [Content] ='APAC'
 WHERE id=185905710


   --row number: 5646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3033018 , [Content] ='INDIA'
 WHERE id=185905711


   --row number: 5647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3033018 , [Content] ='Engineering'
 WHERE id=185905712


   --row number: 5648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3033018 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=185905713


   --row number: 5649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3033018 , [Content] ='Software'
 WHERE id=185905714


   --row number: 5650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3033018 , [Content] ='IC2'
 WHERE id=185905715


   --row number: 5651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3033018 , [Content] ='INR'
 WHERE id=185905717


   --row number: 5652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3033018 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=185905718


   --row number: 5653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3033018 , [Content] ='10%'
 WHERE id=185905719


   --row number: 5654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3033018 , [Content] ='No'
 WHERE id=185905720


   --row number: 5655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3033018 , [Content] ='2 - Professionals'
 WHERE id=185905721


   --row number: 5656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3033018 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=185905722


   --row number: 5657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3033018 , [Content] ='Technical'
 WHERE id=185905723


   --row number: 5658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3033018 , [Content] ='06/08/18'
 WHERE id=185905724


   --row number: 5659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3034897 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186007330


   --row number: 5660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3034897 , [Content] ='Technical'
 WHERE id=186007331


   --row number: 5661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3034897 , [Content] ='06/08/18'
 WHERE id=186007333


   --row number: 5662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3034897 , [Content] ='S1413 US - MRKT 3'
 WHERE id=186007313


   --row number: 5663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3034897 , [Content] ='US - MRKT 3'
 WHERE id=186007314


   --row number: 5664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3034897 , [Content] ='AMS'
 WHERE id=186007315


   --row number: 5665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3034897 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186007316


   --row number: 5666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3034897 , [Content] ='Solution Consulting'
 WHERE id=186007317


   --row number: 5667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3034897 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=186007318


   --row number: 5668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3034897 , [Content] ='Solution Consultant Core'
 WHERE id=186007319


   --row number: 5669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3034897 , [Content] ='IC3'
 WHERE id=186007320


   --row number: 5670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3034897 , [Content] ='USD'
 WHERE id=186007322


   --row number: 5671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3034897 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=186007323


   --row number: 5672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3034897 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=186007324


   --row number: 5673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3034897 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=186007325


   --row number: 5674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3034897 , [Content] ='75/25'
 WHERE id=186007326


   --row number: 5675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3034897 , [Content] ='Yes'
 WHERE id=186007327


   --row number: 5676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3034897 , [Content] ='EXEMPT'
 WHERE id=186007328


   --row number: 5677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3034897 , [Content] ='4 - Sales Workers'
 WHERE id=186007329


   --row number: 5678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035143 , [Content] ='Technical'
 WHERE id=186039934


   --row number: 5679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035143 , [Content] ='7/20/18'
 WHERE id=186039935


   --row number: 5680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035143 , [Content] ='5144 IND'
 WHERE id=186039918


   --row number: 5681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035143 , [Content] ='IND'
 WHERE id=186039919


   --row number: 5682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035143 , [Content] ='APAC'
 WHERE id=186039920


   --row number: 5683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035143 , [Content] ='INDIA'
 WHERE id=186039921


   --row number: 5684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035143 , [Content] ='Engineering'
 WHERE id=186039922


   --row number: 5685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035143 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=186039923


   --row number: 5686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035143 , [Content] ='Software'
 WHERE id=186039924


   --row number: 5687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035143 , [Content] ='IC4'
 WHERE id=186039925


   --row number: 5688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035143 , [Content] ='INR'
 WHERE id=186039927


   --row number: 5689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035143 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=186039928


   --row number: 5690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3035143 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=186039929


   --row number: 5691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3035143 , [Content] ='20%'
 WHERE id=186039930


   --row number: 5692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035143 , [Content] ='Yes'
 WHERE id=186039931


   --row number: 5693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035143 , [Content] ='2 - Professionals'
 WHERE id=186039932


   --row number: 5694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035143 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=186039933


   --row number: 5695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035144 , [Content] ='06/08/18'
 WHERE id=186040065


   --row number: 5696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035144 , [Content] ='5143 IND'
 WHERE id=186040048


   --row number: 5697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035144 , [Content] ='IND'
 WHERE id=186040049


   --row number: 5698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035144 , [Content] ='APAC'
 WHERE id=186040050


   --row number: 5699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035144 , [Content] ='INDIA'
 WHERE id=186040051


   --row number: 5700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035144 , [Content] ='Engineering'
 WHERE id=186040052


   --row number: 5701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035144 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=186040053


   --row number: 5702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035144 , [Content] ='Software'
 WHERE id=186040054


   --row number: 5703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035144 , [Content] ='IC3'
 WHERE id=186040055


   --row number: 5704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035144 , [Content] ='INR'
 WHERE id=186040057


   --row number: 5705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035144 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=186040058


   --row number: 5706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3035144 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=186040059


   --row number: 5707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3035144 , [Content] ='15%'
 WHERE id=186040060


   --row number: 5708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035144 , [Content] ='Yes'
 WHERE id=186040061


   --row number: 5709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035144 , [Content] ='2 - Professionals'
 WHERE id=186040062


   --row number: 5710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035144 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=186040063


   --row number: 5711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035144 , [Content] ='Technical'
 WHERE id=186040064


   --row number: 5712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035200 , [Content] ='5313 IND'
 WHERE id=186042755


   --row number: 5713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035200 , [Content] ='IND'
 WHERE id=186042756


   --row number: 5714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035200 , [Content] ='APAC'
 WHERE id=186042757


   --row number: 5715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035200 , [Content] ='INDIA'
 WHERE id=186042758


   --row number: 5716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035200 , [Content] ='Engineering Operations'
 WHERE id=186042759


   --row number: 5717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035200 , [Content] ='5313 - Technical Writer IC3'
 WHERE id=186042760


   --row number: 5718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035200 , [Content] ='Technical Writer'
 WHERE id=186042761


   --row number: 5719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035200 , [Content] ='IC3'
 WHERE id=186042762


   --row number: 5720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035200 , [Content] ='INR'
 WHERE id=186042764


   --row number: 5721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035200 , [Content] ='1,055,200 / 1,292,600 / 1,530,000 / 1,767,450 / 2,004,900'
 WHERE id=186042765


   --row number: 5722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3035200 , [Content] ='10%'
 WHERE id=186042767


   --row number: 5723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035200 , [Content] ='No'
 WHERE id=186042768


   --row number: 5724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035200 , [Content] ='2 - Professionals'
 WHERE id=186042769


   --row number: 5725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035200 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186042770


   --row number: 5726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035200 , [Content] ='Technical'
 WHERE id=186042771


   --row number: 5727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035200 , [Content] ='6/27/2018'
 WHERE id=186042772


   --row number: 5728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035198 , [Content] ='5313 IND'
 WHERE id=186042711


   --row number: 5729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035198 , [Content] ='IND'
 WHERE id=186042712


   --row number: 5730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035198 , [Content] ='APAC'
 WHERE id=186042713


   --row number: 5731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035198 , [Content] ='INDIA'
 WHERE id=186042714


   --row number: 5732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035198 , [Content] ='Engineering Operations'
 WHERE id=186042715


   --row number: 5733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035198 , [Content] ='5313 - Technical Writer IC3'
 WHERE id=186042716


   --row number: 5734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035198 , [Content] ='Technical Writer'
 WHERE id=186042717


   --row number: 5735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035198 , [Content] ='IC3'
 WHERE id=186042718


   --row number: 5736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035198 , [Content] ='INR'
 WHERE id=186042720


   --row number: 5737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035198 , [Content] ='1,055,200 / 1,292,600 / 1,530,000 / 1,767,450 / 2,004,900'
 WHERE id=186042721


   --row number: 5738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3035198 , [Content] ='10%'
 WHERE id=186042723


   --row number: 5739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035198 , [Content] ='No'
 WHERE id=186042724


   --row number: 5740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035198 , [Content] ='2 - Professionals'
 WHERE id=186042725


   --row number: 5741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035198 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186042726


   --row number: 5742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035198 , [Content] ='Technical'
 WHERE id=186042727


   --row number: 5743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035198 , [Content] ='6/27/2018'
 WHERE id=186042728


   --row number: 5744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035377 , [Content] ='06/08/18'
 WHERE id=186099786


   --row number: 5745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035377 , [Content] ='5193 IND'
 WHERE id=186099769


   --row number: 5746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035377 , [Content] ='IND'
 WHERE id=186099770


   --row number: 5747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035377 , [Content] ='APAC'
 WHERE id=186099771


   --row number: 5748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035377 , [Content] ='INDIA'
 WHERE id=186099772


   --row number: 5749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035377 , [Content] ='Engineering'
 WHERE id=186099773


   --row number: 5750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035377 , [Content] ='5193 - Sr Configuration/Release Engineer IC3'
 WHERE id=186099774


   --row number: 5751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035377 , [Content] ='Configuration/Release'
 WHERE id=186099775


   --row number: 5752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035377 , [Content] ='IC3'
 WHERE id=186099776


   --row number: 5753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035377 , [Content] ='INR'
 WHERE id=186099778


   --row number: 5754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035377 , [Content] ='1,172,400 / 1,436,200 / 1,700,000 / 1,963,800 / 2,227,600'
 WHERE id=186099779


   --row number: 5755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3035377 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=186099780


   --row number: 5756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3035377 , [Content] ='15%'
 WHERE id=186099781


   --row number: 5757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035377 , [Content] ='Yes'
 WHERE id=186099782


   --row number: 5758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035377 , [Content] ='2 - Professionals'
 WHERE id=186099783


   --row number: 5759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035377 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=186099784


   --row number: 5760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035377 , [Content] ='Technical'
 WHERE id=186099785


   --row number: 5761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035741 , [Content] ='9999 IND'
 WHERE id=186183246


   --row number: 5762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035741 , [Content] ='IND'
 WHERE id=186183247


   --row number: 5763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035741 , [Content] ='APAC'
 WHERE id=186183248


   --row number: 5764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035741 , [Content] ='INDIA'
 WHERE id=186183249


   --row number: 5765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035741 , [Content] ='9999 - Intern'
 WHERE id=186183250


   --row number: 5766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035741 , [Content] ='INR'
 WHERE id=186183251


   --row number: 5767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035741 , [Content] ='No'
 WHERE id=186183252


   --row number: 5768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035741 , [Content] ='06/08/18'
 WHERE id=186183253


   --row number: 5769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035731 , [Content] ='6222 IND'
 WHERE id=186182526


   --row number: 5770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035731 , [Content] ='IND'
 WHERE id=186182527


   --row number: 5771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035731 , [Content] ='APAC'
 WHERE id=186182528


   --row number: 5772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035731 , [Content] ='India'
 WHERE id=186182529


   --row number: 5773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035731 , [Content] ='Human Resources'
 WHERE id=186182530


   --row number: 5774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035731 , [Content] ='6222 - Recruiter/Staffing Representative IC2'
 WHERE id=186182531


   --row number: 5775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035731 , [Content] ='Staffing'
 WHERE id=186182532


   --row number: 5776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035731 , [Content] ='IC2'
 WHERE id=186182533


   --row number: 5777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035731 , [Content] ='758,600 / 1,100,000 / 1,441,300'
 WHERE id=186182535


   --row number: 5778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3035731 , [Content] ='140 / 275 / 410'
 WHERE id=186182536


   --row number: 5779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3035731 , [Content] ='10%'
 WHERE id=186182537


   --row number: 5780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035731 , [Content] ='2 - Professionals'
 WHERE id=186182538


   --row number: 5781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035731 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186182539


   --row number: 5782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035731 , [Content] ='Non Technical'
 WHERE id=186182540


   --row number: 5783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3035892 , [Content] ='Technical'
 WHERE id=186196922


   --row number: 5784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3035892 , [Content] ='06/08/18'
 WHERE id=186196923


   --row number: 5785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3035892 , [Content] ='S635 NLD'
 WHERE id=186196905


   --row number: 5786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3035892 , [Content] ='NLD'
 WHERE id=186196906


   --row number: 5787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3035892 , [Content] ='EMEA'
 WHERE id=186196907


   --row number: 5788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3035892 , [Content] ='NETHERLANDS'
 WHERE id=186196908


   --row number: 5789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3035892 , [Content] ='Sales'
 WHERE id=186196909


   --row number: 5790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3035892 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=186196910


   --row number: 5791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3035892 , [Content] ='Enterprise Accounts'
 WHERE id=186196911


   --row number: 5792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3035892 , [Content] ='IC5'
 WHERE id=186196912


   --row number: 5793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3035892 , [Content] ='EUR'
 WHERE id=186196914


   --row number: 5794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3035892 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=186196915


   --row number: 5795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3035892 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=186196916


   --row number: 5796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3035892 , [Content] ='170,000 / 185,000 / 200,000 / 215,000 / 230,000'
 WHERE id=186196917


   --row number: 5797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3035892 , [Content] ='50/50'
 WHERE id=186196918


   --row number: 5798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3035892 , [Content] ='Yes'
 WHERE id=186196919


   --row number: 5799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3035892 , [Content] ='4 - Sales Workers'
 WHERE id=186196920


   --row number: 5800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3035892 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186196921


   --row number: 5801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3036184 , [Content] ='Technical'
 WHERE id=186219811


   --row number: 5802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3036184 , [Content] ='06/08/18'
 WHERE id=186219812


   --row number: 5803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3036184 , [Content] ='5823 NLD'
 WHERE id=186219795


   --row number: 5804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3036184 , [Content] ='NLD'
 WHERE id=186219796


   --row number: 5805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3036184 , [Content] ='EMEA'
 WHERE id=186219797


   --row number: 5806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3036184 , [Content] ='NETHERLANDS'
 WHERE id=186219798


   --row number: 5807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3036184 , [Content] ='Customer Support'
 WHERE id=186219799


   --row number: 5808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3036184 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=186219800


   --row number: 5809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3036184 , [Content] ='Technical Support'
 WHERE id=186219801


   --row number: 5810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3036184 , [Content] ='IC3'
 WHERE id=186219802


   --row number: 5811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3036184 , [Content] ='EUR'
 WHERE id=186219804


   --row number: 5812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3036184 , [Content] ='45,500 / 53,700 / 61,900 / 70,100 / 78,300'
 WHERE id=186219805


   --row number: 5813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3036184 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=186219806


   --row number: 5814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3036184 , [Content] ='15%'
 WHERE id=186219807


   --row number: 5815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3036184 , [Content] ='Yes'
 WHERE id=186219808


   --row number: 5816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3036184 , [Content] ='2 - Professionals'
 WHERE id=186219809


   --row number: 5817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3036184 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186219810


   --row number: 5818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3036948 , [Content] ='2 - Professionals'
 WHERE id=186276008


   --row number: 5819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3036948 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186276009


   --row number: 5820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3036948 , [Content] ='Technical'
 WHERE id=186276010


   --row number: 5821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3036948 , [Content] ='06/08/18'
 WHERE id=186276011


   --row number: 5822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3036948 , [Content] ='5225 US - MRKT 1'
 WHERE id=186275992


   --row number: 5823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3036948 , [Content] ='US - MRKT 1'
 WHERE id=186275993


   --row number: 5824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3036948 , [Content] ='AMS'
 WHERE id=186275994


   --row number: 5825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3036948 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186275995


   --row number: 5826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3036948 , [Content] ='Engineering'
 WHERE id=186275996


   --row number: 5827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3036948 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=186275997


   --row number: 5828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3036948 , [Content] ='Product Mgmt Mgr'
 WHERE id=186275998


   --row number: 5829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3036948 , [Content] ='IC5'
 WHERE id=186275999


   --row number: 5830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3036948 , [Content] ='USD'
 WHERE id=186276001


   --row number: 5831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3036948 , [Content] ='123,800 / 151,650 / 179,500 / 207,350 / 235,200'
 WHERE id=186276002


   --row number: 5832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3036948 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=186276003


   --row number: 5833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3036948 , [Content] ='25%'
 WHERE id=186276004


   --row number: 5834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3036948 , [Content] ='Yes'
 WHERE id=186276005


   --row number: 5835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3036948 , [Content] ='EXEMPT'
 WHERE id=186276006


   --row number: 5836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3036948 , [Content] ='NO'
 WHERE id=186276007


   --row number: 5837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3037190 , [Content] ='4 - Sales Workers'
 WHERE id=186296016


   --row number: 5838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3037190 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186296017


   --row number: 5839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3037190 , [Content] ='Technical'
 WHERE id=186296018


   --row number: 5840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3037190 , [Content] ='06/08/18'
 WHERE id=186296019


   --row number: 5841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3037190 , [Content] ='S1415 US - MRKT 2'
 WHERE id=186295999


   --row number: 5842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3037190 , [Content] ='US - MRKT 2'
 WHERE id=186296000


   --row number: 5843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3037190 , [Content] ='AMS'
 WHERE id=186296001


   --row number: 5844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3037190 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186296002


   --row number: 5845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3037190 , [Content] ='Solution Consulting'
 WHERE id=186296003


   --row number: 5846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3037190 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=186296004


   --row number: 5847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3037190 , [Content] ='Solution Consultant Core'
 WHERE id=186296005


   --row number: 5848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3037190 , [Content] ='IC5'
 WHERE id=186296006


   --row number: 5849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3037190 , [Content] ='USD'
 WHERE id=186296008


   --row number: 5850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3037190 , [Content] ='140,888 / 153,319 / 165,750 / 178,181 / 190,613'
 WHERE id=186296009


   --row number: 5851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3037190 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=186296010


   --row number: 5852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3037190 , [Content] ='187,850 / 204,425 / 221,000 / 237,575 / 254,150'
 WHERE id=186296011


   --row number: 5853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3037190 , [Content] ='75/25'
 WHERE id=186296012


   --row number: 5854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3037190 , [Content] ='Yes'
 WHERE id=186296013


   --row number: 5855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3037190 , [Content] ='EXEMPT'
 WHERE id=186296014


   --row number: 5856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3037190 , [Content] ='NO'
 WHERE id=186296015


   --row number: 5857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3037953 , [Content] ='S1515 ITA'
 WHERE id=186384512


   --row number: 5858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3037953 , [Content] ='ITA'
 WHERE id=186384513


   --row number: 5859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3037953 , [Content] ='EMEA'
 WHERE id=186384514


   --row number: 5860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3037953 , [Content] ='ITALY'
 WHERE id=186384515


   --row number: 5861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3037953 , [Content] ='Professional Services'
 WHERE id=186384516


   --row number: 5862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3037953 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=186384517


   --row number: 5863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3037953 , [Content] ='Solution Architect'
 WHERE id=186384518


   --row number: 5864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3037953 , [Content] ='IC5'
 WHERE id=186384519


   --row number: 5865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3037953 , [Content] ='EUR'
 WHERE id=186384521


   --row number: 5866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3037953 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=186384522


   --row number: 5867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3037953 , [Content] ='25%'
 WHERE id=186384523


   --row number: 5868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3037953 , [Content] ='Yes'
 WHERE id=186384524


   --row number: 5869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3037953 , [Content] ='4 - Sales Workers'
 WHERE id=186384525


   --row number: 5870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3037953 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186384526


   --row number: 5871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3037953 , [Content] ='Technical'
 WHERE id=186384527


   --row number: 5872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3037953 , [Content] ='06/08/18'
 WHERE id=186384528


   --row number: 5873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3037957 , [Content] ='06/08/18'
 WHERE id=186385057


   --row number: 5874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3037957 , [Content] ='5874 UK'
 WHERE id=186385038


   --row number: 5875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3037957 , [Content] ='UK'
 WHERE id=186385039


   --row number: 5876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3037957 , [Content] ='EMEA'
 WHERE id=186385040


   --row number: 5877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3037957 , [Content] ='UNITED KINGDOM'
 WHERE id=186385041


   --row number: 5878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3037957 , [Content] ='Professional Services'
 WHERE id=186385042


   --row number: 5879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3037957 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=186385043


   --row number: 5880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3037957 , [Content] ='Engagement Mgrs'
 WHERE id=186385044


   --row number: 5881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3037957 , [Content] ='IC4'
 WHERE id=186385045


   --row number: 5882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3037957 , [Content] ='GBP'
 WHERE id=186385047


   --row number: 5883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3037957 , [Content] ='49,800 / 60,200 / 70,600 / 81,050 / 91,500'
 WHERE id=186385048


   --row number: 5884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3037957 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=186385050


   --row number: 5885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3037957 , [Content] ='20%'
 WHERE id=186385051


   --row number: 5886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3037957 , [Content] ='Yes'
 WHERE id=186385052


   --row number: 5887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3037957 , [Content] ='2 - Professionals'
 WHERE id=186385053


   --row number: 5888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3037957 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186385054


   --row number: 5889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3037957 , [Content] ='Technical'
 WHERE id=186385056


   --row number: 5890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3037982 , [Content] ='06/08/18'
 WHERE id=186387567


   --row number: 5891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3037982 , [Content] ='5704 ITA'
 WHERE id=186387550


   --row number: 5892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3037982 , [Content] ='ITA'
 WHERE id=186387551


   --row number: 5893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3037982 , [Content] ='EMEA'
 WHERE id=186387552


   --row number: 5894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3037982 , [Content] ='ITALY'
 WHERE id=186387553


   --row number: 5895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3037982 , [Content] ='Professional Services'
 WHERE id=186387554


   --row number: 5896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3037982 , [Content] ='5704 - Client Relationship Manager IC4'
 WHERE id=186387555


   --row number: 5897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3037982 , [Content] ='Partner Support'
 WHERE id=186387556


   --row number: 5898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3037982 , [Content] ='IC4'
 WHERE id=186387557


   --row number: 5899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3037982 , [Content] ='EUR'
 WHERE id=186387559


   --row number: 5900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3037982 , [Content] ='50,000 / 60,500 / 71,000 / 81,450 / 91,900'
 WHERE id=186387560


   --row number: 5901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3037982 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=186387561


   --row number: 5902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3037982 , [Content] ='20%'
 WHERE id=186387562


   --row number: 5903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3037982 , [Content] ='Yes'
 WHERE id=186387563


   --row number: 5904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3037982 , [Content] ='2 - Professionals'
 WHERE id=186387564


   --row number: 5905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3037982 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186387565


   --row number: 5906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3037982 , [Content] ='Technical'
 WHERE id=186387566


   --row number: 5907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3039451 , [Content] ='8742-Salespersons - Outside'
 WHERE id=186498237


   --row number: 5908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3039451 , [Content] ='Technical'
 WHERE id=186498238


   --row number: 5909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3039451 , [Content] ='09/05/18'
 WHERE id=186498239


   --row number: 5910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3039451 , [Content] ='S1414 US - MRKT 1'
 WHERE id=186498219


   --row number: 5911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3039451 , [Content] ='US - MRKT 1'
 WHERE id=186498220


   --row number: 5912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3039451 , [Content] ='AMS'
 WHERE id=186498221


   --row number: 5913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3039451 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186498222


   --row number: 5914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3039451 , [Content] ='Solution Consulting'
 WHERE id=186498223


   --row number: 5915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3039451 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=186498224


   --row number: 5916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3039451 , [Content] ='Solution Consultant Core'
 WHERE id=186498225


   --row number: 5917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3039451 , [Content] ='IC4'
 WHERE id=186498226


   --row number: 5918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3039451 , [Content] ='USD'
 WHERE id=186498228


   --row number: 5919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3039451 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=186498229


   --row number: 5920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3039451 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=186498230


   --row number: 5921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3039451 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=186498231


   --row number: 5922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3039451 , [Content] ='75/25'
 WHERE id=186498232


   --row number: 5923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3039451 , [Content] ='Yes'
 WHERE id=186498233


   --row number: 5924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3039451 , [Content] ='EXEMPT'
 WHERE id=186498234


   --row number: 5925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3039451 , [Content] ='NO'
 WHERE id=186498235


   --row number: 5926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3039451 , [Content] ='4 - Sales Workers'
 WHERE id=186498236


   --row number: 5927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3039522 , [Content] ='S1332 SGP'
 WHERE id=186507798


   --row number: 5928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3039522 , [Content] ='SGP'
 WHERE id=186507799


   --row number: 5929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3039522 , [Content] ='APAC'
 WHERE id=186507800


   --row number: 5930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3039522 , [Content] ='SINGAPORE'
 WHERE id=186507801


   --row number: 5931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3039522 , [Content] ='Sales'
 WHERE id=186507802


   --row number: 5932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3039522 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=186507803


   --row number: 5933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3039522 , [Content] ='Inside Sales'
 WHERE id=186507804


   --row number: 5934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3039522 , [Content] ='A2'
 WHERE id=186507805


   --row number: 5935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3039522 , [Content] ='60/40'
 WHERE id=186507807


   --row number: 5936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3039522 , [Content] ='No'
 WHERE id=186507808


   --row number: 5937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3039522 , [Content] ='4 - Sales Workers'
 WHERE id=186507809


   --row number: 5938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3039522 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186507810


   --row number: 5939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3039522 , [Content] ='Non Technical'
 WHERE id=186507811


   --row number: 5940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3040050 , [Content] ='5141 IND'
 WHERE id=186555933


   --row number: 5941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3040050 , [Content] ='IND'
 WHERE id=186555934


   --row number: 5942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3040050 , [Content] ='APAC'
 WHERE id=186555935


   --row number: 5943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3040050 , [Content] ='INDIA'
 WHERE id=186555936


   --row number: 5944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3040050 , [Content] ='Engineering'
 WHERE id=186555937


   --row number: 5945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3040050 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=186555938


   --row number: 5946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3040050 , [Content] ='Software'
 WHERE id=186555939


   --row number: 5947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3040050 , [Content] ='IC1'
 WHERE id=186555940


   --row number: 5948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3040050 , [Content] ='INR'
 WHERE id=186555942


   --row number: 5949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3040050 , [Content] ='703,500 / 861,800 / 1,020,100 / 1,178,400 / 1,336,700'
 WHERE id=186555943


   --row number: 5950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3040050 , [Content] ='10%'
 WHERE id=186555944


   --row number: 5951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3040050 , [Content] ='No'
 WHERE id=186555945


   --row number: 5952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3040050 , [Content] ='2 - Professionals'
 WHERE id=186555946


   --row number: 5953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3040050 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=186555947


   --row number: 5954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3040050 , [Content] ='Technical'
 WHERE id=186555948


   --row number: 5955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3040050 , [Content] ='06/08/18'
 WHERE id=186555949


   --row number: 5956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3040240 , [Content] ='6464 NLD'
 WHERE id=186571973


   --row number: 5957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3040240 , [Content] ='NLD'
 WHERE id=186571974


   --row number: 5958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3040240 , [Content] ='EMEA'
 WHERE id=186571975


   --row number: 5959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3040240 , [Content] ='NETHERLANDS'
 WHERE id=186571976


   --row number: 5960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3040240 , [Content] ='Info Systems/Technology'
 WHERE id=186571977


   --row number: 5961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3040240 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=186571978


   --row number: 5962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3040240 , [Content] ='Business Systems Analysis'
 WHERE id=186571979


   --row number: 5963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3040240 , [Content] ='IC4'
 WHERE id=186571980


   --row number: 5964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3040240 , [Content] ='EUR'
 WHERE id=186571982


   --row number: 5965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3040240 , [Content] ='54,400 / 64,200 / 74,000 / 83,800 / 93,600'
 WHERE id=186571983


   --row number: 5966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3040240 , [Content] ='15%'
 WHERE id=186571984


   --row number: 5967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3040240 , [Content] ='Yes'
 WHERE id=186571985


   --row number: 5968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3040240 , [Content] ='2 - Professionals'
 WHERE id=186571986


   --row number: 5969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3040240 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186571987


   --row number: 5970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3040240 , [Content] ='Technical'
 WHERE id=186571988


   --row number: 5971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3040240 , [Content] ='09/05/18'
 WHERE id=186571989


   --row number: 5972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3040743 , [Content] ='US - MRKT 2'
 WHERE id=186607762


   --row number: 5973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3040743 , [Content] ='Technical'
 WHERE id=186607779


   --row number: 5974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3040743 , [Content] ='06/08/18'
 WHERE id=186607780


   --row number: 5975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3040743 , [Content] ='5312 US - MRKT 2'
 WHERE id=186607761


   --row number: 5976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3040743 , [Content] ='AMS'
 WHERE id=186607763


   --row number: 5977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3040743 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186607764


   --row number: 5978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3040743 , [Content] ='Engineering Operations'
 WHERE id=186607765


   --row number: 5979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3040743 , [Content] ='5312 - Technical Writer IC2'
 WHERE id=186607766


   --row number: 5980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3040743 , [Content] ='Technical Writer'
 WHERE id=186607767


   --row number: 5981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3040743 , [Content] ='IC2'
 WHERE id=186607768


   --row number: 5982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3040743 , [Content] ='USD'
 WHERE id=186607770


   --row number: 5983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3040743 , [Content] ='55,600 / 63,550 / 71,500 / 79,400 / 87,300'
 WHERE id=186607771


   --row number: 5984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3040743 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=186607772


   --row number: 5985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3040743 , [Content] ='10%'
 WHERE id=186607773


   --row number: 5986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3040743 , [Content] ='Yes'
 WHERE id=186607774


   --row number: 5987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3040743 , [Content] ='EXEMPT'
 WHERE id=186607775


   --row number: 5988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3040743 , [Content] ='NO'
 WHERE id=186607776


   --row number: 5989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3040743 , [Content] ='2 - Professionals'
 WHERE id=186607777


   --row number: 5990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3040743 , [Content] ='8810-Clerical Office Employees'
 WHERE id=186607778


   --row number: 5991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3041448 , [Content] ='2507 US - MRKT 1'
 WHERE id=186662534


   --row number: 5992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3041448 , [Content] ='US - MRKT 1'
 WHERE id=186662535


   --row number: 5993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3041448 , [Content] ='AMS'
 WHERE id=186662536


   --row number: 5994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3041448 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=186662537


   --row number: 5995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3041448 , [Content] ='Executive'
 WHERE id=186662538


   --row number: 5996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3041448 , [Content] ='2507 - VP, Marketing M7'
 WHERE id=186662539


   --row number: 5997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3041448 , [Content] ='Vice President'
 WHERE id=186662540


   --row number: 5998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3041448 , [Content] ='M7'
 WHERE id=186662541


   --row number: 5999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3041448 , [Content] ='USD'
 WHERE id=186662543


   --row number: 6000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3041448 , [Content] ='Yes'
 WHERE id=186662544

