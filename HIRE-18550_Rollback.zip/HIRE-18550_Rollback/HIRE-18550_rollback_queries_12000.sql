
--Total  3000


   --row number: 9001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099333 , [Content] ='Engineering'
 WHERE id=192705132


   --row number: 9002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099333 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192705133


   --row number: 9003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099333 , [Content] ='Software'
 WHERE id=192705134


   --row number: 9004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099333 , [Content] ='IC3'
 WHERE id=192705135


   --row number: 9005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099333 , [Content] ='INR'
 WHERE id=192705137


   --row number: 9006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099333 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=192705138


   --row number: 9007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099333 , [Content] ='15%'
 WHERE id=192705139


   --row number: 9008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099333 , [Content] ='Yes'
 WHERE id=192705140


   --row number: 9009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099333 , [Content] ='2 - Professionals'
 WHERE id=192705141


   --row number: 9010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099333 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192705142


   --row number: 9011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099333 , [Content] ='Technical'
 WHERE id=192705143


   --row number: 9012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099351 , [Content] ='5142 IND'
 WHERE id=192706744


   --row number: 9013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099351 , [Content] ='IND'
 WHERE id=192706745


   --row number: 9014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099351 , [Content] ='APAC'
 WHERE id=192706746


   --row number: 9015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099351 , [Content] ='INDIA'
 WHERE id=192706747


   --row number: 9016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099351 , [Content] ='Engineering'
 WHERE id=192706748


   --row number: 9017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099351 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192706749


   --row number: 9018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099351 , [Content] ='Software'
 WHERE id=192706750


   --row number: 9019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099351 , [Content] ='IC2'
 WHERE id=192706751


   --row number: 9020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099351 , [Content] ='7/20/2018'
 WHERE id=192706760


   --row number: 9021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099351 , [Content] ='INR'
 WHERE id=192706753


   --row number: 9022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099351 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192706754


   --row number: 9023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099351 , [Content] ='10%'
 WHERE id=192706755


   --row number: 9024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099351 , [Content] ='No'
 WHERE id=192706756


   --row number: 9025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099351 , [Content] ='2 - Professionals'
 WHERE id=192706757


   --row number: 9026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099351 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192706758


   --row number: 9027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099351 , [Content] ='Technical'
 WHERE id=192706759


   --row number: 9028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099365 , [Content] ='Software'
 WHERE id=192707844


   --row number: 9029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099365 , [Content] ='7/20/2018'
 WHERE id=192707857


   --row number: 9030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099365 , [Content] ='IC2'
 WHERE id=192707846


   --row number: 9031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099365 , [Content] ='5142 IND'
 WHERE id=192707837


   --row number: 9032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099365 , [Content] ='IND'
 WHERE id=192707838


   --row number: 9033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099365 , [Content] ='APAC'
 WHERE id=192707839


   --row number: 9034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099365 , [Content] ='INDIA'
 WHERE id=192707840


   --row number: 9035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099365 , [Content] ='Engineering'
 WHERE id=192707841


   --row number: 9036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099365 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192707842


   --row number: 9037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099365 , [Content] ='INR'
 WHERE id=192707850


   --row number: 9038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099365 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192707851


   --row number: 9039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099365 , [Content] ='10%'
 WHERE id=192707852


   --row number: 9040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099365 , [Content] ='No'
 WHERE id=192707853


   --row number: 9041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099365 , [Content] ='2 - Professionals'
 WHERE id=192707854


   --row number: 9042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099365 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192707855


   --row number: 9043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099365 , [Content] ='Technical'
 WHERE id=192707856


   --row number: 9044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099384 , [Content] ='7/20/2018'
 WHERE id=192709539


   --row number: 9045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099384 , [Content] ='5142 IND'
 WHERE id=192709523


   --row number: 9046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099384 , [Content] ='IND'
 WHERE id=192709524


   --row number: 9047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099384 , [Content] ='APAC'
 WHERE id=192709525


   --row number: 9048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099384 , [Content] ='INDIA'
 WHERE id=192709526


   --row number: 9049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099384 , [Content] ='Engineering'
 WHERE id=192709527


   --row number: 9050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099384 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192709528


   --row number: 9051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099384 , [Content] ='Software'
 WHERE id=192709529


   --row number: 9052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099384 , [Content] ='IC2'
 WHERE id=192709530


   --row number: 9053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099384 , [Content] ='INR'
 WHERE id=192709532


   --row number: 9054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099384 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192709533


   --row number: 9055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099384 , [Content] ='10%'
 WHERE id=192709534


   --row number: 9056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099384 , [Content] ='No'
 WHERE id=192709535


   --row number: 9057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099384 , [Content] ='2 - Professionals'
 WHERE id=192709536


   --row number: 9058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099384 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192709537


   --row number: 9059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099384 , [Content] ='Technical'
 WHERE id=192709538


   --row number: 9060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099710 , [Content] ='Technical'
 WHERE id=192742115


   --row number: 9061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099710 , [Content] ='7/20/2018'
 WHERE id=192742116


   --row number: 9062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099710 , [Content] ='5143 IND'
 WHERE id=192742099


   --row number: 9063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099710 , [Content] ='IND'
 WHERE id=192742100


   --row number: 9064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099710 , [Content] ='APAC'
 WHERE id=192742101


   --row number: 9065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099710 , [Content] ='INDIA'
 WHERE id=192742102


   --row number: 9066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099710 , [Content] ='Engineering'
 WHERE id=192742103


   --row number: 9067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099710 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192742104


   --row number: 9068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099710 , [Content] ='Software'
 WHERE id=192742105


   --row number: 9069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099710 , [Content] ='IC3'
 WHERE id=192742106


   --row number: 9070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099710 , [Content] ='INR'
 WHERE id=192742108


   --row number: 9071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099710 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=192742109


   --row number: 9072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3099710 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=192742110


   --row number: 9073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099710 , [Content] ='15%'
 WHERE id=192742111


   --row number: 9074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099710 , [Content] ='Yes'
 WHERE id=192742112


   --row number: 9075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099710 , [Content] ='2 - Professionals'
 WHERE id=192742113


   --row number: 9076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099710 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192742114


   --row number: 9077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099725 , [Content] ='7/20/18'
 WHERE id=192743592


   --row number: 9078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099725 , [Content] ='5142 IND'
 WHERE id=192743575


   --row number: 9079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099725 , [Content] ='IND'
 WHERE id=192743576


   --row number: 9080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099725 , [Content] ='APAC'
 WHERE id=192743577


   --row number: 9081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099725 , [Content] ='INDIA'
 WHERE id=192743578


   --row number: 9082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099725 , [Content] ='Engineering'
 WHERE id=192743579


   --row number: 9083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099725 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192743580


   --row number: 9084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099725 , [Content] ='Software'
 WHERE id=192743581


   --row number: 9085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099725 , [Content] ='IC2'
 WHERE id=192743582


   --row number: 9086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099725 , [Content] ='INR'
 WHERE id=192743584


   --row number: 9087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099725 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192743585


   --row number: 9088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099725 , [Content] ='10%'
 WHERE id=192743587


   --row number: 9089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099725 , [Content] ='No'
 WHERE id=192743588


   --row number: 9090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099725 , [Content] ='2 - Professionals'
 WHERE id=192743589


   --row number: 9091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099725 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192743590


   --row number: 9092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099725 , [Content] ='Technical'
 WHERE id=192743591


   --row number: 9093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099747 , [Content] ='7/20/2018'
 WHERE id=192745633


   --row number: 9094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099747 , [Content] ='5142 IND'
 WHERE id=192745617


   --row number: 9095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099747 , [Content] ='IND'
 WHERE id=192745618


   --row number: 9096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099747 , [Content] ='APAC'
 WHERE id=192745619


   --row number: 9097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099747 , [Content] ='INDIA'
 WHERE id=192745620


   --row number: 9098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099747 , [Content] ='Engineering'
 WHERE id=192745621


   --row number: 9099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099747 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192745622


   --row number: 9100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099747 , [Content] ='Software'
 WHERE id=192745623


   --row number: 9101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099747 , [Content] ='IC2'
 WHERE id=192745624


   --row number: 9102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099747 , [Content] ='INR'
 WHERE id=192745626


   --row number: 9103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099747 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192745627


   --row number: 9104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099747 , [Content] ='10%'
 WHERE id=192745628


   --row number: 9105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099747 , [Content] ='No'
 WHERE id=192745629


   --row number: 9106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099747 , [Content] ='2 - Professionals'
 WHERE id=192745630


   --row number: 9107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099747 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192745631


   --row number: 9108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099747 , [Content] ='Technical'
 WHERE id=192745632


   --row number: 9109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099787 , [Content] ='7/20/2018'
 WHERE id=192748391


   --row number: 9110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099787 , [Content] ='5142 IND'
 WHERE id=192748375


   --row number: 9111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099787 , [Content] ='IND'
 WHERE id=192748376


   --row number: 9112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099787 , [Content] ='APAC'
 WHERE id=192748377


   --row number: 9113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099787 , [Content] ='INDIA'
 WHERE id=192748378


   --row number: 9114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099787 , [Content] ='Engineering'
 WHERE id=192748379


   --row number: 9115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099787 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=192748380


   --row number: 9116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099787 , [Content] ='Software'
 WHERE id=192748381


   --row number: 9117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099787 , [Content] ='IC2'
 WHERE id=192748382


   --row number: 9118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099787 , [Content] ='INR'
 WHERE id=192748384


   --row number: 9119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099787 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=192748385


   --row number: 9120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099787 , [Content] ='10%'
 WHERE id=192748386


   --row number: 9121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099787 , [Content] ='No'
 WHERE id=192748387


   --row number: 9122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099787 , [Content] ='2 - Professionals'
 WHERE id=192748388


   --row number: 9123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099787 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192748389


   --row number: 9124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099787 , [Content] ='Technical'
 WHERE id=192748390


   --row number: 9125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3099806 , [Content] ='Technical'
 WHERE id=192749814


   --row number: 9126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3099806 , [Content] ='7/20/2018'
 WHERE id=192749815


   --row number: 9127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3099806 , [Content] ='5223 IND'
 WHERE id=192749798


   --row number: 9128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3099806 , [Content] ='IND'
 WHERE id=192749799


   --row number: 9129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3099806 , [Content] ='APAC'
 WHERE id=192749800


   --row number: 9130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3099806 , [Content] ='INDIA'
 WHERE id=192749801


   --row number: 9131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3099806 , [Content] ='Engineering'
 WHERE id=192749802


   --row number: 9132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3099806 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=192749803


   --row number: 9133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3099806 , [Content] ='Product Mgmt Mgr'
 WHERE id=192749804


   --row number: 9134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3099806 , [Content] ='IC3'
 WHERE id=192749805


   --row number: 9135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3099806 , [Content] ='INR'
 WHERE id=192749807


   --row number: 9136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3099806 , [Content] ='1,396,600 / 1,710,800 / 2,025,000 / 2,339,250 / 2,653,500'
 WHERE id=192749808


   --row number: 9137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3099806 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=192749809


   --row number: 9138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3099806 , [Content] ='15%'
 WHERE id=192749810


   --row number: 9139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3099806 , [Content] ='Yes'
 WHERE id=192749811


   --row number: 9140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3099806 , [Content] ='2 - Professionals'
 WHERE id=192749812


   --row number: 9141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3099806 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192749813


   --row number: 9142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3100154 , [Content] ='NO'
 WHERE id=192777739


   --row number: 9143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3100154 , [Content] ='2 - Professionals'
 WHERE id=192777740


   --row number: 9144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3100154 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=192777741


   --row number: 9145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3100154 , [Content] ='Technical'
 WHERE id=192777742


   --row number: 9146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3100154 , [Content] ='7/20/2018'
 WHERE id=192777743


   --row number: 9147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3100154 , [Content] ='5143 US - MRKT 1'
 WHERE id=192777724


   --row number: 9148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3100154 , [Content] ='US - MRKT 1'
 WHERE id=192777725


   --row number: 9149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3100154 , [Content] ='AMS'
 WHERE id=192777726


   --row number: 9150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3100154 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=192777727


   --row number: 9151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3100154 , [Content] ='Engineering'
 WHERE id=192777728


   --row number: 9152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3100154 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=192777729


   --row number: 9153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3100154 , [Content] ='Software'
 WHERE id=192777730


   --row number: 9154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3100154 , [Content] ='IC3'
 WHERE id=192777731


   --row number: 9155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3100154 , [Content] ='USD'
 WHERE id=192777733


   --row number: 9156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3100154 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=192777734


   --row number: 9157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3100154 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=192777735


   --row number: 9158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3100154 , [Content] ='15%'
 WHERE id=192777736


   --row number: 9159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3100154 , [Content] ='Yes'
 WHERE id=192777737


   --row number: 9160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3100154 , [Content] ='EXEMPT'
 WHERE id=192777738


   --row number: 9161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3100699 , [Content] ='Technical'
 WHERE id=192936259


   --row number: 9162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3100699 , [Content] ='7/20/2018'
 WHERE id=192936260


   --row number: 9163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3100699 , [Content] ='5725 AUS'
 WHERE id=192936244


   --row number: 9164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3100699 , [Content] ='AUS'
 WHERE id=192936245


   --row number: 9165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3100699 , [Content] ='APAC'
 WHERE id=192936246


   --row number: 9166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3100699 , [Content] ='AUSTRALIA'
 WHERE id=192936247


   --row number: 9167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3100699 , [Content] ='Professional Services'
 WHERE id=192936248


   --row number: 9168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3100699 , [Content] ='5725 - Expert Services Consultant IC5'
 WHERE id=192936249


   --row number: 9169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3100699 , [Content] ='Expert Services'
 WHERE id=192936250


   --row number: 9170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3100699 , [Content] ='IC5'
 WHERE id=192936251


   --row number: 9171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3100699 , [Content] ='AUD'
 WHERE id=192936253


   --row number: 9172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3100699 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=192936254


   --row number: 9173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3100699 , [Content] ='25%'
 WHERE id=192936255


   --row number: 9174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3100699 , [Content] ='Yes'
 WHERE id=192936256


   --row number: 9175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3100699 , [Content] ='2 - Professionals'
 WHERE id=192936257


   --row number: 9176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3100699 , [Content] ='8810-Clerical Office Employees'
 WHERE id=192936258


   --row number: 9177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101445 , [Content] ='9999 US - MRKT 1'
 WHERE id=193043287


   --row number: 9178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101445 , [Content] ='US - MRKT 1'
 WHERE id=193043288


   --row number: 9179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101445 , [Content] ='AMS'
 WHERE id=193043289


   --row number: 9180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101445 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193043290


   --row number: 9181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101445 , [Content] ='9999 - Intern'
 WHERE id=193043291


   --row number: 9182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3101445 , [Content] ='USD'
 WHERE id=193043292


   --row number: 9183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101445 , [Content] ='No'
 WHERE id=193043293


   --row number: 9184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101445 , [Content] ='NON-EXEMPT'
 WHERE id=193043294


   --row number: 9185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3101445 , [Content] ='7/20/2018'
 WHERE id=193043295


   --row number: 9186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3101621 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193063438


   --row number: 9187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3101621 , [Content] ='Technical'
 WHERE id=193063439


   --row number: 9188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3101621 , [Content] ='7/20/2018'
 WHERE id=193063440


   --row number: 9189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101621 , [Content] ='6555 US - MRKT 1'
 WHERE id=193063421


   --row number: 9190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101621 , [Content] ='US - MRKT 1'
 WHERE id=193063422


   --row number: 9191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101621 , [Content] ='AMS'
 WHERE id=193063423


   --row number: 9192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101621 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193063424


   --row number: 9193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3101621 , [Content] ='Info Systems/Technology'
 WHERE id=193063425


   --row number: 9194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101621 , [Content] ='6555 - Enterprisewide Apps/Sys Developer IC5'
 WHERE id=193063426


   --row number: 9195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3101621 , [Content] ='Enterprise Apps/Systems'
 WHERE id=193063427


   --row number: 9196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3101621 , [Content] ='IC5'
 WHERE id=193063428


   --row number: 9197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3101621 , [Content] ='USD'
 WHERE id=193063430


   --row number: 9198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3101621 , [Content] ='115,800 / 141,850 / 167,900 / 193,950 / 220,000'
 WHERE id=193063431


   --row number: 9199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3101621 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=193063432


   --row number: 9200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3101621 , [Content] ='25%'
 WHERE id=193063433


   --row number: 9201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101621 , [Content] ='Yes'
 WHERE id=193063434


   --row number: 9202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101621 , [Content] ='EXEMPT'
 WHERE id=193063435


   --row number: 9203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3101621 , [Content] ='NO'
 WHERE id=193063436


   --row number: 9204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3101621 , [Content] ='2 - Professionals'
 WHERE id=193063437


   --row number: 9205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101683 , [Content] ='6474 US - MRKT 2'
 WHERE id=193069562


   --row number: 9206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101683 , [Content] ='US - MRKT 2'
 WHERE id=193069563


   --row number: 9207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101683 , [Content] ='AMS'
 WHERE id=193069564


   --row number: 9208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101683 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193069565


   --row number: 9209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3101683 , [Content] ='Info Systems/Technology'
 WHERE id=193069566


   --row number: 9210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101683 , [Content] ='6474 - Staff Network Engineer IC4'
 WHERE id=193069567


   --row number: 9211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3101683 , [Content] ='Network Engineer'
 WHERE id=193069568


   --row number: 9212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3101683 , [Content] ='IC4'
 WHERE id=193069569


   --row number: 9213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3101683 , [Content] ='2 - Professionals'
 WHERE id=193069578


   --row number: 9214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3101683 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193069579


   --row number: 9215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3101683 , [Content] ='Technical'
 WHERE id=193069580


   --row number: 9216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3101683 , [Content] ='7/20/2018'
 WHERE id=193069581


   --row number: 9217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3101683 , [Content] ='USD'
 WHERE id=193069571


   --row number: 9218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3101683 , [Content] ='89,700 / 108,500 / 127,300 / 146,100 / 164,900'
 WHERE id=193069572


   --row number: 9219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3101683 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=193069573


   --row number: 9220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3101683 , [Content] ='20%'
 WHERE id=193069574


   --row number: 9221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101683 , [Content] ='Yes'
 WHERE id=193069575


   --row number: 9222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101683 , [Content] ='EXEMPT'
 WHERE id=193069576


   --row number: 9223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3101683 , [Content] ='NO'
 WHERE id=193069577


   --row number: 9224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101719 , [Content] ='6504 - Executive Assistant IC4'
 WHERE id=193072128


   --row number: 9225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3101719 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193072140


   --row number: 9226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3101719 , [Content] ='Non Technical'
 WHERE id=193072141


   --row number: 9227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3101719 , [Content] ='7/20/2018'
 WHERE id=193072142


   --row number: 9228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3101719 , [Content] ='Executive Assistant'
 WHERE id=193072129


   --row number: 9229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3101719 , [Content] ='IC4'
 WHERE id=193072130


   --row number: 9230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3101719 , [Content] ='USD'
 WHERE id=193072132


   --row number: 9231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101719 , [Content] ='6504 US - MRKT 1'
 WHERE id=193072123


   --row number: 9232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101719 , [Content] ='US - MRKT 1'
 WHERE id=193072124


   --row number: 9233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101719 , [Content] ='AMS'
 WHERE id=193072125


   --row number: 9234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101719 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193072126


   --row number: 9235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3101719 , [Content] ='Administration'
 WHERE id=193072127


   --row number: 9236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3101719 , [Content] ='101,000 / 119,150 / 137,300 / 155,500 / 173,700'
 WHERE id=193072133


   --row number: 9237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3101719 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=193072134


   --row number: 9238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3101719 , [Content] ='15%'
 WHERE id=193072135


   --row number: 9239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101719 , [Content] ='Yes'
 WHERE id=193072136


   --row number: 9240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101719 , [Content] ='EXEMPT'
 WHERE id=193072137


   --row number: 9241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3101719 , [Content] ='NO'
 WHERE id=193072138


   --row number: 9242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3101719 , [Content] ='5 - Administrative Support Workers'
 WHERE id=193072139


   --row number: 9243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101797 , [Content] ='9999 US - MRKT 1'
 WHERE id=193079207


   --row number: 9244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101797 , [Content] ='US - MRKT 1'
 WHERE id=193079208


   --row number: 9245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101797 , [Content] ='AMS'
 WHERE id=193079209


   --row number: 9246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101797 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193079210


   --row number: 9247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101797 , [Content] ='9999 - Intern'
 WHERE id=193079211


   --row number: 9248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3101797 , [Content] ='USD'
 WHERE id=193079212


   --row number: 9249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101797 , [Content] ='No'
 WHERE id=193079213


   --row number: 9250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101797 , [Content] ='NON-EXEMPT'
 WHERE id=193079214


   --row number: 9251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3101797 , [Content] ='7/20/2018'
 WHERE id=193079215


   --row number: 9252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101799 , [Content] ='9999 US - MRKT 1'
 WHERE id=193079371


   --row number: 9253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101799 , [Content] ='US - MRKT 1'
 WHERE id=193079372


   --row number: 9254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101799 , [Content] ='AMS'
 WHERE id=193079373


   --row number: 9255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101799 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193079374


   --row number: 9256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101799 , [Content] ='9999 - Intern'
 WHERE id=193079375


   --row number: 9257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3101799 , [Content] ='USD'
 WHERE id=193079376


   --row number: 9258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101799 , [Content] ='No'
 WHERE id=193079377


   --row number: 9259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101799 , [Content] ='NON-EXEMPT'
 WHERE id=193079378


   --row number: 9260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3101799 , [Content] ='7/20/2018'
 WHERE id=193079379


   --row number: 9261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102067 , [Content] ='3475 US - MRKT 1'
 WHERE id=193102276


   --row number: 9262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102067 , [Content] ='US - MRKT 1'
 WHERE id=193102277


   --row number: 9263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102067 , [Content] ='AMS'
 WHERE id=193102278


   --row number: 9264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102067 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193102279


   --row number: 9265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3102067 , [Content] ='Info Systems/Technology'
 WHERE id=193102280


   --row number: 9266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102067 , [Content] ='3475 - Dir, Enterprisewide Systems Mgmt M5'
 WHERE id=193102281


   --row number: 9267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3102067 , [Content] ='Enterprise Systems'
 WHERE id=193102282


   --row number: 9268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3102067 , [Content] ='M5'
 WHERE id=193102283


   --row number: 9269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102067 , [Content] ='USD'
 WHERE id=193102285


   --row number: 9270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3102067 , [Content] ='136,800 / 167,550 / 198,300 / 229,100 / 259,900'
 WHERE id=193102286


   --row number: 9271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3102067 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=193102287


   --row number: 9272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3102067 , [Content] ='25%'
 WHERE id=193102288


   --row number: 9273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102067 , [Content] ='Yes'
 WHERE id=193102289


   --row number: 9274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3102067 , [Content] ='EXEMPT'
 WHERE id=193102290


   --row number: 9275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3102067 , [Content] ='NO'
 WHERE id=193102291


   --row number: 9276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3102067 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=193102292


   --row number: 9277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3102067 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193102293


   --row number: 9278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3102067 , [Content] ='Technical'
 WHERE id=193102294


   --row number: 9279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102067 , [Content] ='7/20/2018'
 WHERE id=193102295


   --row number: 9280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3101947 , [Content] ='9999 US - MRKT 1'
 WHERE id=193093984


   --row number: 9281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3101947 , [Content] ='US - MRKT 1'
 WHERE id=193093985


   --row number: 9282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3101947 , [Content] ='AMS'
 WHERE id=193093986


   --row number: 9283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3101947 , [Content] ='United States of America'
 WHERE id=193093987


   --row number: 9284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3101947 , [Content] ='9999 - Intern'
 WHERE id=193093988


   --row number: 9285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3101947 , [Content] ='Intern'
 WHERE id=193093989


   --row number: 9286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3101947 , [Content] ='No'
 WHERE id=193093990


   --row number: 9287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3101947 , [Content] ='NON-EXEMPT'
 WHERE id=193093991


   --row number: 9288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3101947 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193093992


   --row number: 9289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102109 , [Content] ='9999 US - MRKT 1'
 WHERE id=193105707


   --row number: 9290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102109 , [Content] ='US - MRKT 1'
 WHERE id=193105708


   --row number: 9291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102109 , [Content] ='AMS'
 WHERE id=193105709


   --row number: 9292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102109 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193105710


   --row number: 9293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102109 , [Content] ='9999 - Intern'
 WHERE id=193105711


   --row number: 9294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102109 , [Content] ='USD'
 WHERE id=193105712


   --row number: 9295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102109 , [Content] ='No'
 WHERE id=193105713


   --row number: 9296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3102109 , [Content] ='NON-EXEMPT'
 WHERE id=193105714


   --row number: 9297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102109 , [Content] ='7/20/2018'
 WHERE id=193105715


   --row number: 9298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102134 , [Content] ='9999 US - MRKT 1'
 WHERE id=193107910


   --row number: 9299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102134 , [Content] ='US - MRKT 1'
 WHERE id=193107911


   --row number: 9300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102134 , [Content] ='AMS'
 WHERE id=193107912


   --row number: 9301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102134 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193107913


   --row number: 9302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102134 , [Content] ='9999 - Intern'
 WHERE id=193107914


   --row number: 9303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102134 , [Content] ='USD'
 WHERE id=193107915


   --row number: 9304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102134 , [Content] ='No'
 WHERE id=193107916


   --row number: 9305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3102134 , [Content] ='NON-EXEMPT'
 WHERE id=193107917


   --row number: 9306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102134 , [Content] ='7/20/2018'
 WHERE id=193107918


   --row number: 9307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102116 , [Content] ='9999 US - MRKT 1'
 WHERE id=193106546


   --row number: 9308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102116 , [Content] ='US - MRKT 1'
 WHERE id=193106547


   --row number: 9309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102116 , [Content] ='AMS'
 WHERE id=193106548


   --row number: 9310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102116 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193106549


   --row number: 9311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102116 , [Content] ='9999 - Intern'
 WHERE id=193106550


   --row number: 9312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3102116 , [Content] ='Intern'
 WHERE id=193106551


   --row number: 9313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102116 , [Content] ='No'
 WHERE id=193106554


   --row number: 9314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3102116 , [Content] ='NON-EXEMPT'
 WHERE id=193106558


   --row number: 9315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102479 , [Content] ='S665 US - MRKT 2'
 WHERE id=193136497


   --row number: 9316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102479 , [Content] ='US - MRKT 2'
 WHERE id=193136498


   --row number: 9317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102479 , [Content] ='AMS'
 WHERE id=193136499


   --row number: 9318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102479 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193136500


   --row number: 9319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3102479 , [Content] ='Sales'
 WHERE id=193136501


   --row number: 9320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102479 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=193136502


   --row number: 9321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3102479 , [Content] ='Product Line Sales'
 WHERE id=193136503


   --row number: 9322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3102479 , [Content] ='IC5'
 WHERE id=193136504


   --row number: 9323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102479 , [Content] ='USD'
 WHERE id=193136506


   --row number: 9324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3102479 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=193136507


   --row number: 9325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3102479 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=193136508


   --row number: 9326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3102479 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=193136509


   --row number: 9327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3102479 , [Content] ='60/40'
 WHERE id=193136510


   --row number: 9328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102479 , [Content] ='Yes'
 WHERE id=193136511


   --row number: 9329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3102479 , [Content] ='EXEMPT'
 WHERE id=193136512


   --row number: 9330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3102479 , [Content] ='NO'
 WHERE id=193136513


   --row number: 9331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3102479 , [Content] ='4 - Sales Workers'
 WHERE id=193136514


   --row number: 9332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3102479 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193136515


   --row number: 9333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3102479 , [Content] ='Technical'
 WHERE id=193136516


   --row number: 9334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102479 , [Content] ='7/20/2018'
 WHERE id=193136517


   --row number: 9335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102292 , [Content] ='9999 US - MRKT 1'
 WHERE id=193118473


   --row number: 9336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102292 , [Content] ='US - MRKT 1'
 WHERE id=193118474


   --row number: 9337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102292 , [Content] ='AMS'
 WHERE id=193118475


   --row number: 9338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102292 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193118476


   --row number: 9339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102292 , [Content] ='9999 - Intern'
 WHERE id=193118477


   --row number: 9340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102292 , [Content] ='USD'
 WHERE id=193118478


   --row number: 9341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102292 , [Content] ='No'
 WHERE id=193118479


   --row number: 9342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3102292 , [Content] ='NON-EXEMPT'
 WHERE id=193118480


   --row number: 9343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102292 , [Content] ='7/20/2018'
 WHERE id=193118481


   --row number: 9344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3102486 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193137448


   --row number: 9345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3102486 , [Content] ='Technical'
 WHERE id=193137449


   --row number: 9346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102486 , [Content] ='7/20/2018'
 WHERE id=193137450


   --row number: 9347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102486 , [Content] ='S1411 AUS'
 WHERE id=193137432


   --row number: 9348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102486 , [Content] ='AUS'
 WHERE id=193137433


   --row number: 9349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102486 , [Content] ='APAC'
 WHERE id=193137434


   --row number: 9350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102486 , [Content] ='AUSTRALIA'
 WHERE id=193137435


   --row number: 9351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3102486 , [Content] ='Solution Consulting'
 WHERE id=193137436


   --row number: 9352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102486 , [Content] ='S1411 - Assoc Solution Consultant IC1'
 WHERE id=193137437


   --row number: 9353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3102486 , [Content] ='Solution Consultant Core'
 WHERE id=193137438


   --row number: 9354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3102486 , [Content] ='IC1'
 WHERE id=193137439


   --row number: 9355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102486 , [Content] ='AUD'
 WHERE id=193137441


   --row number: 9356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3102486 , [Content] ='72,038 / 78,394 / 84,750 / 91,106 / 97,463'
 WHERE id=193137442


   --row number: 9357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3102486 , [Content] ='13,200 / 18,600 / 24,000 / 29,400 / 34,800'
 WHERE id=193137443


   --row number: 9358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3102486 , [Content] ='96,050 / 104,525 / 113,000 / 121,475 / 129,950'
 WHERE id=193137444


   --row number: 9359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3102486 , [Content] ='75/25'
 WHERE id=193137445


   --row number: 9360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102486 , [Content] ='Yes'
 WHERE id=193137446


   --row number: 9361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3102486 , [Content] ='4 - Sales Workers'
 WHERE id=193137447


   --row number: 9362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3102489 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193137679


   --row number: 9363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3102489 , [Content] ='Technical'
 WHERE id=193137680


   --row number: 9364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102489 , [Content] ='7/20/2018'
 WHERE id=193137681


   --row number: 9365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102489 , [Content] ='S1411 AUS'
 WHERE id=193137663


   --row number: 9366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102489 , [Content] ='AUS'
 WHERE id=193137664


   --row number: 9367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102489 , [Content] ='APAC'
 WHERE id=193137665


   --row number: 9368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102489 , [Content] ='AUSTRALIA'
 WHERE id=193137666


   --row number: 9369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3102489 , [Content] ='Solution Consulting'
 WHERE id=193137667


   --row number: 9370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102489 , [Content] ='S1411 - Assoc Solution Consultant IC1'
 WHERE id=193137668


   --row number: 9371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3102489 , [Content] ='Solution Consultant Core'
 WHERE id=193137669


   --row number: 9372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3102489 , [Content] ='IC1'
 WHERE id=193137670


   --row number: 9373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102489 , [Content] ='AUD'
 WHERE id=193137672


   --row number: 9374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3102489 , [Content] ='72,038 / 78,394 / 84,750 / 91,106 / 97,463'
 WHERE id=193137673


   --row number: 9375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3102489 , [Content] ='13,200 / 18,600 / 24,000 / 29,400 / 34,800'
 WHERE id=193137674


   --row number: 9376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3102489 , [Content] ='96,050 / 104,525 / 113,000 / 121,475 / 129,950'
 WHERE id=193137675


   --row number: 9377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3102489 , [Content] ='75/25'
 WHERE id=193137676


   --row number: 9378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102489 , [Content] ='Yes'
 WHERE id=193137677


   --row number: 9379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3102489 , [Content] ='4 - Sales Workers'
 WHERE id=193137678


   --row number: 9380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3102999 , [Content] ='Technical'
 WHERE id=193205683


   --row number: 9381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3102999 , [Content] ='7/20/2018'
 WHERE id=193205684


   --row number: 9382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3102999 , [Content] ='5233 IND'
 WHERE id=193205667


   --row number: 9383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3102999 , [Content] ='IND'
 WHERE id=193205668


   --row number: 9384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3102999 , [Content] ='APAC'
 WHERE id=193205669


   --row number: 9385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3102999 , [Content] ='INDIA'
 WHERE id=193205670


   --row number: 9386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3102999 , [Content] ='Engineering'
 WHERE id=193205671


   --row number: 9387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3102999 , [Content] ='5233 - Sr UI Engineer IC3'
 WHERE id=193205672


   --row number: 9388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3102999 , [Content] ='UI'
 WHERE id=193205673


   --row number: 9389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3102999 , [Content] ='IC3'
 WHERE id=193205674


   --row number: 9390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3102999 , [Content] ='INR'
 WHERE id=193205676


   --row number: 9391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3102999 , [Content] ='1,200,000 / 1,470,000 / 1,740,000 / 2,010,000 / 2,280,000'
 WHERE id=193205677


   --row number: 9392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3102999 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=193205678


   --row number: 9393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3102999 , [Content] ='15%'
 WHERE id=193205679


   --row number: 9394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3102999 , [Content] ='Yes'
 WHERE id=193205680


   --row number: 9395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3102999 , [Content] ='2 - Professionals'
 WHERE id=193205681


   --row number: 9396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3102999 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=193205682


   --row number: 9397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103010 , [Content] ='7/20/2018'
 WHERE id=193206659


   --row number: 9398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103010 , [Content] ='5232 IND'
 WHERE id=193206643


   --row number: 9399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103010 , [Content] ='IND'
 WHERE id=193206644


   --row number: 9400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103010 , [Content] ='APAC'
 WHERE id=193206645


   --row number: 9401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103010 , [Content] ='INDIA'
 WHERE id=193206646


   --row number: 9402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103010 , [Content] ='Engineering'
 WHERE id=193206647


   --row number: 9403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103010 , [Content] ='5232 - UI Engineer IC2'
 WHERE id=193206648


   --row number: 9404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103010 , [Content] ='UI'
 WHERE id=193206649


   --row number: 9405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103010 , [Content] ='IC2'
 WHERE id=193206650


   --row number: 9406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103010 , [Content] ='INR'
 WHERE id=193206652


   --row number: 9407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3103010 , [Content] ='862,100 / 1,056,050 / 1,250,000 / 1,444,000 / 1,638,000'
 WHERE id=193206653


   --row number: 9408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3103010 , [Content] ='10%'
 WHERE id=193206654


   --row number: 9409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103010 , [Content] ='No'
 WHERE id=193206655


   --row number: 9410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103010 , [Content] ='2 - Professionals'
 WHERE id=193206656


   --row number: 9411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103010 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=193206657


   --row number: 9412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103010 , [Content] ='Technical'
 WHERE id=193206658


   --row number: 9413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103022 , [Content] ='6393 IND'
 WHERE id=193207626


   --row number: 9414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103022 , [Content] ='IND'
 WHERE id=193207627


   --row number: 9415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103022 , [Content] ='APAC'
 WHERE id=193207628


   --row number: 9416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103022 , [Content] ='INDIA'
 WHERE id=193207629


   --row number: 9417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103022 , [Content] ='Legal'
 WHERE id=193207630


   --row number: 9418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103022 , [Content] ='6393 - Legal Counsel IC3'
 WHERE id=193207631


   --row number: 9419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103022 , [Content] ='Legal Counsel'
 WHERE id=193207632


   --row number: 9420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103022 , [Content] ='IC3'
 WHERE id=193207633


   --row number: 9421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103022 , [Content] ='INR'
 WHERE id=193207635


   --row number: 9422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3103022 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=193207636


   --row number: 9423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3103022 , [Content] ='20%'
 WHERE id=193207637


   --row number: 9424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103022 , [Content] ='Yes'
 WHERE id=193207638


   --row number: 9425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103022 , [Content] ='2 - Professionals'
 WHERE id=193207639


   --row number: 9426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103022 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193207640


   --row number: 9427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103022 , [Content] ='Non Technical'
 WHERE id=193207641


   --row number: 9428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103022 , [Content] ='7/20/2018'
 WHERE id=193207642


   --row number: 9429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103034 , [Content] ='6112 IND'
 WHERE id=193208504


   --row number: 9430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103034 , [Content] ='IND'
 WHERE id=193208505


   --row number: 9431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103034 , [Content] ='APAC'
 WHERE id=193208506


   --row number: 9432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103034 , [Content] ='INDIA'
 WHERE id=193208507


   --row number: 9433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103034 , [Content] ='Finance'
 WHERE id=193208508


   --row number: 9434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103034 , [Content] ='6112 - Payroll Analyst IC2'
 WHERE id=193208509


   --row number: 9435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103034 , [Content] ='Payroll'
 WHERE id=193208510


   --row number: 9436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103034 , [Content] ='IC2'
 WHERE id=193208511


   --row number: 9437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103034 , [Content] ='INR'
 WHERE id=193208513


   --row number: 9438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3103034 , [Content] ='593,100 / 726,550 / 860,000 / 993,450 / 1,126,900'
 WHERE id=193208514


   --row number: 9439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3103034 , [Content] ='10%'
 WHERE id=193208515


   --row number: 9440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103034 , [Content] ='No'
 WHERE id=193208516


   --row number: 9441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103034 , [Content] ='2 - Professionals'
 WHERE id=193208517


   --row number: 9442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103034 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193208518


   --row number: 9443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103034 , [Content] ='Non Technical'
 WHERE id=193208519


   --row number: 9444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103034 , [Content] ='7/20/2018'
 WHERE id=193208520


   --row number: 9445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3103445 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=193240920


   --row number: 9446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103445 , [Content] ='2 - Professionals'
 WHERE id=193240925


   --row number: 9447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103445 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=193240926


   --row number: 9448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103445 , [Content] ='Technical'
 WHERE id=193240927


   --row number: 9449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103445 , [Content] ='7/20/2018'
 WHERE id=193240928


   --row number: 9450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103445 , [Content] ='5374 US - MRKT 1'
 WHERE id=193240909


   --row number: 9451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103445 , [Content] ='US - MRKT 1'
 WHERE id=193240910


   --row number: 9452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103445 , [Content] ='AMS'
 WHERE id=193240911


   --row number: 9453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103445 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193240912


   --row number: 9454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103445 , [Content] ='Engineering'
 WHERE id=193240913


   --row number: 9455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103445 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=193240914


   --row number: 9456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103445 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=193240915


   --row number: 9457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103445 , [Content] ='IC4'
 WHERE id=193240916


   --row number: 9458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103445 , [Content] ='USD'
 WHERE id=193240918


   --row number: 9459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3103445 , [Content] ='115,200 / 139,350 / 163,500 / 187,600 / 211,700'
 WHERE id=193240919


   --row number: 9460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3103445 , [Content] ='20%'
 WHERE id=193240921


   --row number: 9461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103445 , [Content] ='Yes'
 WHERE id=193240922


   --row number: 9462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3103445 , [Content] ='EXEMPT'
 WHERE id=193240923


   --row number: 9463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3103445 , [Content] ='NO'
 WHERE id=193240924


   --row number: 9464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103458 , [Content] ='S635 US - MRKT 3'
 WHERE id=193241629


   --row number: 9465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103458 , [Content] ='US - MRKT 3'
 WHERE id=193241630


   --row number: 9466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103458 , [Content] ='AMS'
 WHERE id=193241631


   --row number: 9467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103458 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193241632


   --row number: 9468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103458 , [Content] ='Sales'
 WHERE id=193241633


   --row number: 9469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103458 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=193241634


   --row number: 9470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103458 , [Content] ='Enterprise Accounts'
 WHERE id=193241635


   --row number: 9471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103458 , [Content] ='IC5'
 WHERE id=193241636


   --row number: 9472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3103458 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=193241638


   --row number: 9473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3103458 , [Content] ='50/50'
 WHERE id=193241639


   --row number: 9474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103458 , [Content] ='Yes'
 WHERE id=193241640


   --row number: 9475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103458 , [Content] ='Technical'
 WHERE id=193241644


   --row number: 9476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3103458 , [Content] ='EXEMPT'
 WHERE id=193241641


   --row number: 9477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103458 , [Content] ='4 - Sales Workers'
 WHERE id=193241642


   --row number: 9478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103458 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193241643


   --row number: 9479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103458 , [Content] ='7/20/2018'
 WHERE id=193246156


   --row number: 9480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3103458 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=193246157


   --row number: 9481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3103458 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=193246158


   --row number: 9482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103458 , [Content] ='USD'
 WHERE id=193246159


   --row number: 9483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103708 , [Content] ='Information Systems'
 WHERE id=193265356


   --row number: 9484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103708 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=193265366


   --row number: 9485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103708 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193265367


   --row number: 9486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103708 , [Content] ='Technical'
 WHERE id=193265368


   --row number: 9487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103708 , [Content] ='7/20/2018'
 WHERE id=193265369


   --row number: 9488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103708 , [Content] ='M3'
 WHERE id=193265357


   --row number: 9489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3103708 , [Content] ='20%'
 WHERE id=193265362


   --row number: 9490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103708 , [Content] ='Yes'
 WHERE id=193265363


   --row number: 9491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3103708 , [Content] ='EXEMPT'
 WHERE id=193265364


   --row number: 9492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3103708 , [Content] ='NO'
 WHERE id=193265365


   --row number: 9493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103708 , [Content] ='3403 US - MRKT 1'
 WHERE id=193265350


   --row number: 9494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103708 , [Content] ='US - MRKT 1'
 WHERE id=193265351


   --row number: 9495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103708 , [Content] ='AMS'
 WHERE id=193265352


   --row number: 9496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103708 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193265353


   --row number: 9497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103708 , [Content] ='Info Systems/Technology'
 WHERE id=193265354


   --row number: 9498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103708 , [Content] ='3403 - Mgr, Information Systems Mgmt M3'
 WHERE id=193265355


   --row number: 9499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103708 , [Content] ='USD'
 WHERE id=193265359


   --row number: 9500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3103708 , [Content] ='111,600 / 135,000 / 158,400 / 181,750 / 205,100'
 WHERE id=193265360


   --row number: 9501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3103708 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=193265361


   --row number: 9502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3103718 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193266240


   --row number: 9503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3103718 , [Content] ='Technical'
 WHERE id=193266241


   --row number: 9504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3103718 , [Content] ='7/20/2018'
 WHERE id=193266242


   --row number: 9505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3103718 , [Content] ='3494 US - MRKT 1'
 WHERE id=193266223


   --row number: 9506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3103718 , [Content] ='US - MRKT 1'
 WHERE id=193266224


   --row number: 9507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3103718 , [Content] ='AMS'
 WHERE id=193266225


   --row number: 9508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3103718 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193266226


   --row number: 9509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3103718 , [Content] ='Info Systems/Technology'
 WHERE id=193266227


   --row number: 9510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3103718 , [Content] ='3494 - Sr Mgr, Applications Development Mgmt M4'
 WHERE id=193266228


   --row number: 9511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3103718 , [Content] ='Enterprise Applications'
 WHERE id=193266229


   --row number: 9512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3103718 , [Content] ='M4'
 WHERE id=193266230


   --row number: 9513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3103718 , [Content] ='USD'
 WHERE id=193266232


   --row number: 9514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3103718 , [Content] ='124,400 / 152,400 / 180,400 / 208,400 / 236,400'
 WHERE id=193266233


   --row number: 9515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3103718 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=193266234


   --row number: 9516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3103718 , [Content] ='25%'
 WHERE id=193266235


   --row number: 9517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3103718 , [Content] ='Yes'
 WHERE id=193266236


   --row number: 9518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3103718 , [Content] ='EXEMPT'
 WHERE id=193266237


   --row number: 9519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3103718 , [Content] ='NO'
 WHERE id=193266238


   --row number: 9520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3103718 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=193266239


   --row number: 9521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3104360 , [Content] ='5141 US - MRKT 2'
 WHERE id=193320744


   --row number: 9522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3104360 , [Content] ='US - MRKT 2'
 WHERE id=193320745


   --row number: 9523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3104360 , [Content] ='AMS'
 WHERE id=193320746


   --row number: 9524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3104360 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193320747


   --row number: 9525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3104360 , [Content] ='Technical'
 WHERE id=193320762


   --row number: 9526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3104360 , [Content] ='Engineering'
 WHERE id=193320748


   --row number: 9527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3104360 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=193320749


   --row number: 9528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3104360 , [Content] ='Software'
 WHERE id=193320750


   --row number: 9529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3104360 , [Content] ='IC1'
 WHERE id=193320751


   --row number: 9530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3104360 , [Content] ='USD'
 WHERE id=193320753


   --row number: 9531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3104360 , [Content] ='62,300 / 71,150 / 80,000 / 88,900 / 97,800'
 WHERE id=193320754


   --row number: 9532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3104360 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=193320755


   --row number: 9533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3104360 , [Content] ='10%'
 WHERE id=193320756


   --row number: 9534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3104360 , [Content] ='Yes'
 WHERE id=193320757


   --row number: 9535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3104360 , [Content] ='EXEMPT'
 WHERE id=193320758


   --row number: 9536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3104360 , [Content] ='NO'
 WHERE id=193320759


   --row number: 9537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3104360 , [Content] ='2 - Professionals'
 WHERE id=193320760


   --row number: 9538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3104360 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=193320761


   --row number: 9539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3104965 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=193427184


   --row number: 9540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3104965 , [Content] ='Technical Support'
 WHERE id=193427185


   --row number: 9541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3104965 , [Content] ='5823 UK'
 WHERE id=193427179


   --row number: 9542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3104965 , [Content] ='UK'
 WHERE id=193427180


   --row number: 9543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3104965 , [Content] ='EMEA'
 WHERE id=193427181


   --row number: 9544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3104965 , [Content] ='United Kingdom'
 WHERE id=193427182


   --row number: 9545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3104965 , [Content] ='Customer Support'
 WHERE id=193427183


   --row number: 9546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3104965 , [Content] ='IC3'
 WHERE id=193427186


   --row number: 9547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3104965 , [Content] ='33,300 / 45,300 / 57,300'
 WHERE id=193427188


   --row number: 9548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3104965 , [Content] ='500 / 1,000 / 1,500'
 WHERE id=193427189


   --row number: 9549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3104965 , [Content] ='15%'
 WHERE id=193427190


   --row number: 9550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3104965 , [Content] ='Yes'
 WHERE id=193427191


   --row number: 9551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3104965 , [Content] ='2 - Professionals'
 WHERE id=193427192


   --row number: 9552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3104965 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193427193


   --row number: 9553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3104978 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=193428271


   --row number: 9554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3104978 , [Content] ='75/25'
 WHERE id=193428272


   --row number: 9555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3104978 , [Content] ='No'
 WHERE id=193428273


   --row number: 9556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3104978 , [Content] ='4 - Sales Workers'
 WHERE id=193428274


   --row number: 9557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3104978 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193428275


   --row number: 9558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3104978 , [Content] ='Technical'
 WHERE id=193428276


   --row number: 9559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3104978 , [Content] ='7/20/2018'
 WHERE id=193428277


   --row number: 9560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3104965 , [Content] ='Technical'
 WHERE id=193427194


   --row number: 9561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3104978 , [Content] ='S1413 FRA'
 WHERE id=193428260


   --row number: 9562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3104978 , [Content] ='FRA'
 WHERE id=193428261


   --row number: 9563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3104978 , [Content] ='EMEA'
 WHERE id=193428262


   --row number: 9564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3104978 , [Content] ='FRANCE'
 WHERE id=193428263


   --row number: 9565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3104978 , [Content] ='Solution Consulting'
 WHERE id=193428264


   --row number: 9566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3104978 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=193428265


   --row number: 9567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3104978 , [Content] ='Solution Consultant Core'
 WHERE id=193428266


   --row number: 9568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3104978 , [Content] ='IC3'
 WHERE id=193428267


   --row number: 9569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3104978 , [Content] ='EUR'
 WHERE id=193428269


   --row number: 9570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3104978 , [Content] ='57,375 / 62,438 / 67,500 / 72,563 / 77,625'
 WHERE id=193428270


   --row number: 9571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3105328 , [Content] ='9999 US - MRKT 1'
 WHERE id=193462237


   --row number: 9572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3105328 , [Content] ='US - MRKT 1'
 WHERE id=193462238


   --row number: 9573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3105328 , [Content] ='AMS'
 WHERE id=193462239


   --row number: 9574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3105328 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193462240


   --row number: 9575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3105328 , [Content] ='9999 - Intern'
 WHERE id=193462241


   --row number: 9576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3105328 , [Content] ='USD'
 WHERE id=193462242


   --row number: 9577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3105328 , [Content] ='No'
 WHERE id=193462243


   --row number: 9578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3105328 , [Content] ='NON-EXEMPT'
 WHERE id=193462244


   --row number: 9579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3105328 , [Content] ='7/20/2018'
 WHERE id=193462245


   --row number: 9580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3105726 , [Content] ='9999 US - MRKT 1'
 WHERE id=193494853


   --row number: 9581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3105726 , [Content] ='US - MRKT 1'
 WHERE id=193494854


   --row number: 9582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3105726 , [Content] ='AMS'
 WHERE id=193494855


   --row number: 9583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3105726 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193494856


   --row number: 9584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3105726 , [Content] ='9999 - Intern'
 WHERE id=193494857


   --row number: 9585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3105726 , [Content] ='USD'
 WHERE id=193494858


   --row number: 9586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3105726 , [Content] ='No'
 WHERE id=193494859


   --row number: 9587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3105726 , [Content] ='NON-EXEMPT'
 WHERE id=193494860


   --row number: 9588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3105726 , [Content] ='7/20/2018'
 WHERE id=193494861


   --row number: 9589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3106348 , [Content] ='9999 US - MRKT 1'
 WHERE id=193547931


   --row number: 9590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3106348 , [Content] ='US - MRKT 1'
 WHERE id=193547932


   --row number: 9591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3106348 , [Content] ='AMS'
 WHERE id=193547933


   --row number: 9592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3106348 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193547934


   --row number: 9593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3106348 , [Content] ='9999 - Intern'
 WHERE id=193547935


   --row number: 9594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3106348 , [Content] ='USD'
 WHERE id=193547936


   --row number: 9595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3106348 , [Content] ='No'
 WHERE id=193547937


   --row number: 9596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3106348 , [Content] ='NON-EXEMPT'
 WHERE id=193547938


   --row number: 9597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3106348 , [Content] ='7/20/2018'
 WHERE id=193547939


   --row number: 9598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3107613 , [Content] ='S1413 NLD'
 WHERE id=193663368


   --row number: 9599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3107613 , [Content] ='NLD'
 WHERE id=193663369


   --row number: 9600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3107613 , [Content] ='EMEA'
 WHERE id=193663370


   --row number: 9601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3107613 , [Content] ='NETHERLANDS'
 WHERE id=193663371


   --row number: 9602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3107613 , [Content] ='Solution Consulting'
 WHERE id=193663372


   --row number: 9603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3107613 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=193663373


   --row number: 9604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3107613 , [Content] ='Solution Consultant Core'
 WHERE id=193663374


   --row number: 9605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3107613 , [Content] ='IC3'
 WHERE id=193663377


   --row number: 9606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3107613 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=193663379


   --row number: 9607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3107613 , [Content] ='75/25'
 WHERE id=193663382


   --row number: 9608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3107613 , [Content] ='Yes'
 WHERE id=193663383


   --row number: 9609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3107613 , [Content] ='4 - Sales Workers'
 WHERE id=193663384


   --row number: 9610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3107613 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193663385


   --row number: 9611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3107613 , [Content] ='Technical'
 WHERE id=193663386


   --row number: 9612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3108644 , [Content] ='Technical'
 WHERE id=193760962


   --row number: 9613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3108644 , [Content] ='09/05/18'
 WHERE id=193760963


   --row number: 9614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3108644 , [Content] ='5143 US - MRKT 2'
 WHERE id=193760944


   --row number: 9615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3108644 , [Content] ='US - MRKT 2'
 WHERE id=193760945


   --row number: 9616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3108644 , [Content] ='AMS'
 WHERE id=193760946


   --row number: 9617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3108644 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193760947


   --row number: 9618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3108644 , [Content] ='Engineering'
 WHERE id=193760948


   --row number: 9619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3108644 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=193760949


   --row number: 9620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3108644 , [Content] ='Software'
 WHERE id=193760950


   --row number: 9621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3108644 , [Content] ='IC3'
 WHERE id=193760951


   --row number: 9622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3108644 , [Content] ='USD'
 WHERE id=193760953


   --row number: 9623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3108644 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=193760954


   --row number: 9624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3108644 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=193760955


   --row number: 9625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3108644 , [Content] ='15%'
 WHERE id=193760956


   --row number: 9626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3108644 , [Content] ='Yes'
 WHERE id=193760957


   --row number: 9627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3108644 , [Content] ='EXEMPT'
 WHERE id=193760958


   --row number: 9628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3108644 , [Content] ='NO'
 WHERE id=193760959


   --row number: 9629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3108644 , [Content] ='2 - Professionals'
 WHERE id=193760960


   --row number: 9630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3108644 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=193760961


   --row number: 9631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3108703 , [Content] ='NO'
 WHERE id=193764333


   --row number: 9632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3108703 , [Content] ='2 - Professionals'
 WHERE id=193764334


   --row number: 9633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3108703 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=193764335


   --row number: 9634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3108703 , [Content] ='Technical'
 WHERE id=193764336


   --row number: 9635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3108703 , [Content] ='7/20/2018'
 WHERE id=193764337


   --row number: 9636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3108703 , [Content] ='5193 US - MRKT 1'
 WHERE id=193764318


   --row number: 9637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3108703 , [Content] ='US - MRKT 1'
 WHERE id=193764319


   --row number: 9638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3108703 , [Content] ='AMS'
 WHERE id=193764320


   --row number: 9639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3108703 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193764321


   --row number: 9640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3108703 , [Content] ='Engineering'
 WHERE id=193764322


   --row number: 9641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3108703 , [Content] ='5193 - Sr Configuration/Release Engineer IC3'
 WHERE id=193764323


   --row number: 9642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3108703 , [Content] ='Configuration/Release'
 WHERE id=193764324


   --row number: 9643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3108703 , [Content] ='IC3'
 WHERE id=193764325


   --row number: 9644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3108703 , [Content] ='USD'
 WHERE id=193764327


   --row number: 9645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3108703 , [Content] ='106,500 / 125,650 / 144,800 / 164,000 / 183,200'
 WHERE id=193764328


   --row number: 9646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3108703 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=193764329


   --row number: 9647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3108703 , [Content] ='15%'
 WHERE id=193764330


   --row number: 9648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3108703 , [Content] ='Yes'
 WHERE id=193764331


   --row number: 9649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3108703 , [Content] ='EXEMPT'
 WHERE id=193764332


   --row number: 9650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3108898 , [Content] ='S634 AUS'
 WHERE id=193796500


   --row number: 9651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3108898 , [Content] ='AUS'
 WHERE id=193796501


   --row number: 9652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3108898 , [Content] ='APAC'
 WHERE id=193796502


   --row number: 9653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3108898 , [Content] ='AUSTRALIA'
 WHERE id=193796503


   --row number: 9654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3108898 , [Content] ='Sales'
 WHERE id=193796504


   --row number: 9655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3108898 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=193796505


   --row number: 9656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3108898 , [Content] ='Enterprise Accounts'
 WHERE id=193796506


   --row number: 9657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3108898 , [Content] ='IC4'
 WHERE id=193796507


   --row number: 9658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3108898 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=193796509


   --row number: 9659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3108898 , [Content] ='50/50'
 WHERE id=193796510


   --row number: 9660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3108898 , [Content] ='Yes'
 WHERE id=193796511


   --row number: 9661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3108898 , [Content] ='4 - Sales Workers'
 WHERE id=193796512


   --row number: 9662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3108898 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193796513


   --row number: 9663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3108898 , [Content] ='Technical'
 WHERE id=193796514


   --row number: 9664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3108898 , [Content] ='7/20/2018'
 WHERE id=193796628


   --row number: 9665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3108898 , [Content] ='276,250 / 300,625 / 325,000 / 349,375 / 373,750'
 WHERE id=193796629


   --row number: 9666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3108898 , [Content] ='138,125 / 150,313 / 162,500 / 174,688 / 186,875'
 WHERE id=193796630


   --row number: 9667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3108898 , [Content] ='AUD'
 WHERE id=193796631


   --row number: 9668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3109158 , [Content] ='25%'
 WHERE id=193810604


   --row number: 9669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3109158 , [Content] ='Technical'
 WHERE id=193810608


   --row number: 9670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3109158 , [Content] ='7/20/2018'
 WHERE id=193810609


   --row number: 9671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3109158 , [Content] ='Yes'
 WHERE id=193810605


   --row number: 9672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3109158 , [Content] ='2 - Professionals'
 WHERE id=193810606


   --row number: 9673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3109158 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193810607


   --row number: 9674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3109158 , [Content] ='5705 SGP'
 WHERE id=193810592


   --row number: 9675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3109158 , [Content] ='SGP'
 WHERE id=193810593


   --row number: 9676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3109158 , [Content] ='APAC'
 WHERE id=193810594


   --row number: 9677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3109158 , [Content] ='SINGAPORE'
 WHERE id=193810595


   --row number: 9678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3109158 , [Content] ='Professional Services'
 WHERE id=193810596


   --row number: 9679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3109158 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=193810597


   --row number: 9680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3109158 , [Content] ='Partner Support'
 WHERE id=193810598


   --row number: 9681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3109158 , [Content] ='IC5'
 WHERE id=193810599


   --row number: 9682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3109158 , [Content] ='SGD'
 WHERE id=193810601


   --row number: 9683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3109158 , [Content] ='131,000 / 160,500 / 190,000 / 219,450 / 248,900'
 WHERE id=193810602


   --row number: 9684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3109158 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=193810603


   --row number: 9685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3109585 , [Content] ='S1415 DEU'
 WHERE id=193830450


   --row number: 9686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3109585 , [Content] ='DEU'
 WHERE id=193830451


   --row number: 9687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3109585 , [Content] ='EMEA'
 WHERE id=193830452


   --row number: 9688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3109585 , [Content] ='GERMANY'
 WHERE id=193830453


   --row number: 9689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3109585 , [Content] ='Solution Consulting'
 WHERE id=193830454


   --row number: 9690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3109585 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=193830455


   --row number: 9691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3109585 , [Content] ='Solution Consultant Core'
 WHERE id=193830456


   --row number: 9692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3109585 , [Content] ='IC5'
 WHERE id=193830457


   --row number: 9693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3109585 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193830466


   --row number: 9694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3109585 , [Content] ='Technical'
 WHERE id=193830467


   --row number: 9695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3109585 , [Content] ='7/20/2018'
 WHERE id=193830468


   --row number: 9696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3109585 , [Content] ='EUR'
 WHERE id=193830459


   --row number: 9697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3109585 , [Content] ='86,063 / 93,656 / 101,250 / 108,844 / 116,438'
 WHERE id=193830460


   --row number: 9698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3109585 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=193830461


   --row number: 9699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3109585 , [Content] ='114,750 / 124,875 / 135,000 / 145,125 / 155,250'
 WHERE id=193830462


   --row number: 9700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3109585 , [Content] ='75/25'
 WHERE id=193830463


   --row number: 9701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3109585 , [Content] ='Yes'
 WHERE id=193830464


   --row number: 9702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3109585 , [Content] ='4 - Sales Workers'
 WHERE id=193830465


   --row number: 9703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3109595 , [Content] ='EMEA'
 WHERE id=193831661


   --row number: 9704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3109595 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193831675


   --row number: 9705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3109595 , [Content] ='Technical'
 WHERE id=193831676


   --row number: 9706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3109595 , [Content] ='7/20/2018'
 WHERE id=193831677


   --row number: 9707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3109595 , [Content] ='GERMANY'
 WHERE id=193831662


   --row number: 9708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3109595 , [Content] ='Solution Consulting'
 WHERE id=193831663


   --row number: 9709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3109595 , [Content] ='S1403 - Mgr, Solution Consulting M3'
 WHERE id=193831664


   --row number: 9710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3109595 , [Content] ='Solution Consultant Core'
 WHERE id=193831665


   --row number: 9711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3109595 , [Content] ='M3'
 WHERE id=193831666


   --row number: 9712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3109595 , [Content] ='S1403 DEU'
 WHERE id=193831659


   --row number: 9713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3109595 , [Content] ='DEU'
 WHERE id=193831660


   --row number: 9714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3109595 , [Content] ='EUR'
 WHERE id=193831668


   --row number: 9715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3109595 , [Content] ='85,744 / 93,309 / 100,875 / 108,441 / 116,006'
 WHERE id=193831669


   --row number: 9716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3109595 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=193831670


   --row number: 9717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3109595 , [Content] ='114,325 / 124,413 / 134,500 / 144,588 / 154,675'
 WHERE id=193831671


   --row number: 9718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3109595 , [Content] ='75/25'
 WHERE id=193831672


   --row number: 9719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3109595 , [Content] ='Yes'
 WHERE id=193831673


   --row number: 9720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3109595 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=193831674


   --row number: 9721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3110535 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=193867726


   --row number: 9722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3110535 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193867727


   --row number: 9723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3110535 , [Content] ='Technical'
 WHERE id=193867728


   --row number: 9724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3110535 , [Content] ='7/20/2018'
 WHERE id=193867729


   --row number: 9725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3110535 , [Content] ='2754 US - MRKT 1'
 WHERE id=193867710


   --row number: 9726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3110535 , [Content] ='US - MRKT 1'
 WHERE id=193867711


   --row number: 9727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3110535 , [Content] ='AMS'
 WHERE id=193867712


   --row number: 9728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3110535 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193867713


   --row number: 9729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3110535 , [Content] ='Customer Support'
 WHERE id=193867714


   --row number: 9730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3110535 , [Content] ='2754 - Sr Mgr, Customer Success Mgmt M4'
 WHERE id=193867715


   --row number: 9731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3110535 , [Content] ='Customer Success'
 WHERE id=193867716


   --row number: 9732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3110535 , [Content] ='M4'
 WHERE id=193867717


   --row number: 9733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3110535 , [Content] ='USD'
 WHERE id=193867719


   --row number: 9734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3110535 , [Content] ='100,000 / 122,500 / 145,000 / 167,500 / 190,000'
 WHERE id=193867720


   --row number: 9735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3110535 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=193867721


   --row number: 9736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3110535 , [Content] ='25%'
 WHERE id=193867722


   --row number: 9737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3110535 , [Content] ='Yes'
 WHERE id=193867723


   --row number: 9738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3110535 , [Content] ='Exempt'
 WHERE id=193867724


   --row number: 9739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3110535 , [Content] ='NO'
 WHERE id=193867725


   --row number: 9740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3110565 , [Content] ='NO'
 WHERE id=193870447


   --row number: 9741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3110565 , [Content] ='2 - Professionals'
 WHERE id=193870448


   --row number: 9742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3110565 , [Content] ='8810-Clerical Office Employees'
 WHERE id=193870449


   --row number: 9743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3110565 , [Content] ='Non Technical'
 WHERE id=193870450


   --row number: 9744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3110565 , [Content] ='7/20/2018'
 WHERE id=193870451


   --row number: 9745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3110565 , [Content] ='6015 US - MRKT 1'
 WHERE id=193870432


   --row number: 9746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3110565 , [Content] ='US - MRKT 1'
 WHERE id=193870433


   --row number: 9747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3110565 , [Content] ='AMS'
 WHERE id=193870434


   --row number: 9748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3110565 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193870435


   --row number: 9749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3110565 , [Content] ='Business Strategy'
 WHERE id=193870436


   --row number: 9750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3110565 , [Content] ='6015 - Business Analytics IC5'
 WHERE id=193870437


   --row number: 9751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3110565 , [Content] ='Business Analytics'
 WHERE id=193870438


   --row number: 9752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3110565 , [Content] ='IC5'
 WHERE id=193870439


   --row number: 9753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3110565 , [Content] ='USD'
 WHERE id=193870441


   --row number: 9754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3110565 , [Content] ='116,100 / 140,450 / 164,800 / 189,100 / 213,400'
 WHERE id=193870442


   --row number: 9755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3110565 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=193870443


   --row number: 9756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3110565 , [Content] ='20%'
 WHERE id=193870444


   --row number: 9757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3110565 , [Content] ='Yes'
 WHERE id=193870445


   --row number: 9758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3110565 , [Content] ='EXEMPT'
 WHERE id=193870446


   --row number: 9759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3110627 , [Content] ='Technical'
 WHERE id=193873871


   --row number: 9760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3110627 , [Content] ='7/20/2018'
 WHERE id=193873872


   --row number: 9761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3110627 , [Content] ='S1415A US - MRKT 3'
 WHERE id=193873853


   --row number: 9762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3110627 , [Content] ='US - MRKT 3'
 WHERE id=193873854


   --row number: 9763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3110627 , [Content] ='AMS'
 WHERE id=193873855


   --row number: 9764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3110627 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=193873856


   --row number: 9765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3110627 , [Content] ='Solution Consulting'
 WHERE id=193873857


   --row number: 9766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3110627 , [Content] ='S1415A - Sr Advisory Solution Architect IC5'
 WHERE id=193873858


   --row number: 9767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3110627 , [Content] ='Solution Consultant Architect'
 WHERE id=193873859


   --row number: 9768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3110627 , [Content] ='IC5'
 WHERE id=193873860


   --row number: 9769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3110627 , [Content] ='USD'
 WHERE id=193873862


   --row number: 9770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3110627 , [Content] ='147,900 / 160,950 / 174,000 / 187,050 / 200,100'
 WHERE id=193873863


   --row number: 9771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3110627 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=193873864


   --row number: 9772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3110627 , [Content] ='197,200 / 214,600 / 232,000 / 249,400 / 266,800'
 WHERE id=193873865


   --row number: 9773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3110627 , [Content] ='75/25'
 WHERE id=193873866


   --row number: 9774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3110627 , [Content] ='Yes'
 WHERE id=193873867


   --row number: 9775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3110627 , [Content] ='EXEMPT'
 WHERE id=193873868


   --row number: 9776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3110627 , [Content] ='4 - Sales Workers'
 WHERE id=193873869


   --row number: 9777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3110627 , [Content] ='8742-Salespersons - Outside'
 WHERE id=193873870


   --row number: 9778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3111912 , [Content] ='10/05/18'
 WHERE id=194142320


   --row number: 9779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3111912 , [Content] ='5142 IND'
 WHERE id=194142303


   --row number: 9780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3111912 , [Content] ='IND'
 WHERE id=194142304


   --row number: 9781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3111912 , [Content] ='APAC'
 WHERE id=194142305


   --row number: 9782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3111912 , [Content] ='INDIA'
 WHERE id=194142306


   --row number: 9783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3111912 , [Content] ='Engineering'
 WHERE id=194142307


   --row number: 9784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3111912 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=194142308


   --row number: 9785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3111912 , [Content] ='Software'
 WHERE id=194142309


   --row number: 9786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3111912 , [Content] ='IC2'
 WHERE id=194142310


   --row number: 9787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3111912 , [Content] ='INR'
 WHERE id=194142312


   --row number: 9788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3111912 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=194142313


   --row number: 9789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3111912 , [Content] ='10%'
 WHERE id=194142315


   --row number: 9790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3111912 , [Content] ='No'
 WHERE id=194142316


   --row number: 9791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3111912 , [Content] ='2 - Professionals'
 WHERE id=194142317


   --row number: 9792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3111912 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194142318


   --row number: 9793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3111912 , [Content] ='Technical'
 WHERE id=194142319


   --row number: 9794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3111925 , [Content] ='Technical'
 WHERE id=194144108


   --row number: 9795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3111925 , [Content] ='7/20/2018'
 WHERE id=194144109


   --row number: 9796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3111925 , [Content] ='5143 IND'
 WHERE id=194144092


   --row number: 9797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3111925 , [Content] ='IND'
 WHERE id=194144093


   --row number: 9798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3111925 , [Content] ='APAC'
 WHERE id=194144094


   --row number: 9799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3111925 , [Content] ='INDIA'
 WHERE id=194144095


   --row number: 9800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3111925 , [Content] ='Engineering'
 WHERE id=194144096


   --row number: 9801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3111925 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194144097


   --row number: 9802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3111925 , [Content] ='Software'
 WHERE id=194144098


   --row number: 9803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3111925 , [Content] ='IC3'
 WHERE id=194144099


   --row number: 9804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3111925 , [Content] ='INR'
 WHERE id=194144101


   --row number: 9805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3111925 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=194144102


   --row number: 9806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3111925 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=194144103


   --row number: 9807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3111925 , [Content] ='15%'
 WHERE id=194144104


   --row number: 9808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3111925 , [Content] ='Yes'
 WHERE id=194144105


   --row number: 9809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3111925 , [Content] ='2 - Professionals'
 WHERE id=194144106


   --row number: 9810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3111925 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194144107


   --row number: 9811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3111977 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194149365


   --row number: 9812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3111977 , [Content] ='Technical'
 WHERE id=194149366


   --row number: 9813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3111977 , [Content] ='7/20/2018'
 WHERE id=194149367


   --row number: 9814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3111977 , [Content] ='5823 UK'
 WHERE id=194149350


   --row number: 9815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3111977 , [Content] ='UK'
 WHERE id=194149351


   --row number: 9816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3111977 , [Content] ='EMEA'
 WHERE id=194149352


   --row number: 9817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3111977 , [Content] ='UNITED KINGDOM'
 WHERE id=194149353


   --row number: 9818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3111977 , [Content] ='Customer Support'
 WHERE id=194149354


   --row number: 9819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3111977 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=194149355


   --row number: 9820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3111977 , [Content] ='Technical Support'
 WHERE id=194149356


   --row number: 9821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3111977 , [Content] ='IC3'
 WHERE id=194149357


   --row number: 9822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3111977 , [Content] ='GBP'
 WHERE id=194149359


   --row number: 9823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3111977 , [Content] ='35,100 / 41,400 / 47,700 / 54,050 / 60,400'
 WHERE id=194149360


   --row number: 9824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3111977 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=194149361


   --row number: 9825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3111977 , [Content] ='15%'
 WHERE id=194149362


   --row number: 9826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3111977 , [Content] ='Yes'
 WHERE id=194149363


   --row number: 9827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3111977 , [Content] ='2 - Professionals'
 WHERE id=194149364


   --row number: 9828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3113263 , [Content] ='2 - Professionals'
 WHERE id=194275372


   --row number: 9829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3113263 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194275373


   --row number: 9830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3113263 , [Content] ='Technical'
 WHERE id=194275374


   --row number: 9831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3113263 , [Content] ='7/20/2018'
 WHERE id=194275375


   --row number: 9832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3113263 , [Content] ='5145 US - MRKT 1'
 WHERE id=194275356


   --row number: 9833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3113263 , [Content] ='US - MRKT 1'
 WHERE id=194275357


   --row number: 9834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3113263 , [Content] ='AMS'
 WHERE id=194275358


   --row number: 9835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3113263 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194275359


   --row number: 9836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3113263 , [Content] ='Engineering'
 WHERE id=194275360


   --row number: 9837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3113263 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=194275361


   --row number: 9838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3113263 , [Content] ='Software'
 WHERE id=194275362


   --row number: 9839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3113263 , [Content] ='IC5'
 WHERE id=194275363


   --row number: 9840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3113263 , [Content] ='USD'
 WHERE id=194275365


   --row number: 9841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3113263 , [Content] ='143,000 / 175,200 / 207,400 / 239,550 / 271,700'
 WHERE id=194275366


   --row number: 9842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3113263 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=194275367


   --row number: 9843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3113263 , [Content] ='25%'
 WHERE id=194275368


   --row number: 9844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3113263 , [Content] ='Yes'
 WHERE id=194275369


   --row number: 9845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3113263 , [Content] ='EXEMPT'
 WHERE id=194275370


   --row number: 9846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3113263 , [Content] ='NO'
 WHERE id=194275371


   --row number: 9847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3113593 , [Content] ='Technical'
 WHERE id=194329087


   --row number: 9848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3113593 , [Content] ='7/20/18'
 WHERE id=194329088


   --row number: 9849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3113593 , [Content] ='5143 IND'
 WHERE id=194329071


   --row number: 9850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3113593 , [Content] ='IND'
 WHERE id=194329072


   --row number: 9851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3113593 , [Content] ='APAC'
 WHERE id=194329073


   --row number: 9852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3113593 , [Content] ='INDIA'
 WHERE id=194329074


   --row number: 9853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3113593 , [Content] ='Engineering'
 WHERE id=194329075


   --row number: 9854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3113593 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194329076


   --row number: 9855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3113593 , [Content] ='Software'
 WHERE id=194329077


   --row number: 9856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3113593 , [Content] ='IC3'
 WHERE id=194329078


   --row number: 9857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3113593 , [Content] ='INR'
 WHERE id=194329080


   --row number: 9858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3113593 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=194329081


   --row number: 9859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3113593 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=194329082


   --row number: 9860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3113593 , [Content] ='15%'
 WHERE id=194329083


   --row number: 9861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3113593 , [Content] ='Yes'
 WHERE id=194329084


   --row number: 9862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3113593 , [Content] ='2 - Professionals'
 WHERE id=194329085


   --row number: 9863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3113593 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194329086


   --row number: 9864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114361 , [Content] ='S625C DEU'
 WHERE id=194398101


   --row number: 9865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114361 , [Content] ='DEU'
 WHERE id=194398102


   --row number: 9866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114361 , [Content] ='EMEA'
 WHERE id=194398103


   --row number: 9867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114361 , [Content] ='GERMANY'
 WHERE id=194398104


   --row number: 9868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114361 , [Content] ='Sales'
 WHERE id=194398105


   --row number: 9869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114361 , [Content] ='S625C - Client Director IC5'
 WHERE id=194398106


   --row number: 9870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114361 , [Content] ='Strategic Accounts'
 WHERE id=194398107


   --row number: 9871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114361 , [Content] ='IC5'
 WHERE id=194398108


   --row number: 9872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114361 , [Content] ='EUR'
 WHERE id=194398110


   --row number: 9873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114361 , [Content] ='96,900 / 105,450 / 114,000 / 122,550 / 131,100'
 WHERE id=194398111


   --row number: 9874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114361 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=194398112


   --row number: 9875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3114361 , [Content] ='161,500 / 175,750 / 190,000 / 204,250 / 218,500'
 WHERE id=194398113


   --row number: 9876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3114361 , [Content] ='60/40'
 WHERE id=194398114


   --row number: 9877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114361 , [Content] ='Yes'
 WHERE id=194398115


   --row number: 9878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114361 , [Content] ='4 - Sales Workers'
 WHERE id=194398116


   --row number: 9879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114361 , [Content] ='8742-Salespersons - Outside'
 WHERE id=194398117


   --row number: 9880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114361 , [Content] ='Technical'
 WHERE id=194398118


   --row number: 9881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114361 , [Content] ='7/20/18'
 WHERE id=194398119


   --row number: 9882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114299 , [Content] ='9999 US - MRKT 1'
 WHERE id=194391538


   --row number: 9883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114299 , [Content] ='US - MRKT 1'
 WHERE id=194391539


   --row number: 9884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114299 , [Content] ='AMS'
 WHERE id=194391540


   --row number: 9885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114299 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194391541


   --row number: 9886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114299 , [Content] ='9999 - Intern'
 WHERE id=194391542


   --row number: 9887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114299 , [Content] ='USD'
 WHERE id=194391543


   --row number: 9888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114299 , [Content] ='No'
 WHERE id=194391544


   --row number: 9889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3114299 , [Content] ='NON-EXEMPT'
 WHERE id=194391545


   --row number: 9890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114299 , [Content] ='7/20/18'
 WHERE id=194391546


   --row number: 9891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114396 , [Content] ='8742-Salespersons - Outside'
 WHERE id=194400335


   --row number: 9892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114396 , [Content] ='Technical'
 WHERE id=194400336


   --row number: 9893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114396 , [Content] ='7/20/18'
 WHERE id=194400337


   --row number: 9894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114396 , [Content] ='S313 DEU'
 WHERE id=194400319


   --row number: 9895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114396 , [Content] ='DEU'
 WHERE id=194400320


   --row number: 9896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114396 , [Content] ='EMEA'
 WHERE id=194400321


   --row number: 9897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114396 , [Content] ='GERMANY'
 WHERE id=194400322


   --row number: 9898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114396 , [Content] ='Sales'
 WHERE id=194400323


   --row number: 9899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114396 , [Content] ='S313 - Mgr, Sales M3'
 WHERE id=194400324


   --row number: 9900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114396 , [Content] ='Sales Management'
 WHERE id=194400325


   --row number: 9901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114396 , [Content] ='M3'
 WHERE id=194400326


   --row number: 9902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114396 , [Content] ='EUR'
 WHERE id=194400328


   --row number: 9903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114396 , [Content] ='80,750 / 87,875 / 95,000 / 102,125 / 109,250'
 WHERE id=194400329


   --row number: 9904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114396 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=194400330


   --row number: 9905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3114396 , [Content] ='161,500 / 175,750 / 190,000 / 204,250 / 218,500'
 WHERE id=194400331


   --row number: 9906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3114396 , [Content] ='50/50'
 WHERE id=194400332


   --row number: 9907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114396 , [Content] ='Yes'
 WHERE id=194400333


   --row number: 9908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114396 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=194400334


   --row number: 9909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114448 , [Content] ='8742-Salespersons - Outside'
 WHERE id=194404438


   --row number: 9910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114448 , [Content] ='Technical'
 WHERE id=194404439


   --row number: 9911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114448 , [Content] ='7/20/18'
 WHERE id=194404440


   --row number: 9912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114448 , [Content] ='S635 DEU'
 WHERE id=194404422


   --row number: 9913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114448 , [Content] ='DEU'
 WHERE id=194404423


   --row number: 9914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114448 , [Content] ='EMEA'
 WHERE id=194404424


   --row number: 9915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114448 , [Content] ='GERMANY'
 WHERE id=194404425


   --row number: 9916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114448 , [Content] ='Sales'
 WHERE id=194404426


   --row number: 9917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114448 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=194404427


   --row number: 9918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114448 , [Content] ='Enterprise Accounts'
 WHERE id=194404428


   --row number: 9919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114448 , [Content] ='IC5'
 WHERE id=194404429


   --row number: 9920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114448 , [Content] ='EUR'
 WHERE id=194404431


   --row number: 9921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114448 , [Content] ='78,625 / 85,563 / 92,500 / 99,438 / 106,375'
 WHERE id=194404432


   --row number: 9922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114448 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=194404433


   --row number: 9923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3114448 , [Content] ='157,250 / 171,125 / 185,000 / 198,875 / 212,750'
 WHERE id=194404434


   --row number: 9924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3114448 , [Content] ='50/50'
 WHERE id=194404435


   --row number: 9925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114448 , [Content] ='Yes'
 WHERE id=194404436


   --row number: 9926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114448 , [Content] ='4 - Sales Workers'
 WHERE id=194404437


   --row number: 9927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3114688 , [Content] ='NO'
 WHERE id=194426089


   --row number: 9928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114688 , [Content] ='2 - Professionals'
 WHERE id=194426090


   --row number: 9929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114688 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194426091


   --row number: 9930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114688 , [Content] ='Technical'
 WHERE id=194426092


   --row number: 9931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114688 , [Content] ='7/20/18'
 WHERE id=194426093


   --row number: 9932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114688 , [Content] ='6404 US - MRKT 2'
 WHERE id=194426074


   --row number: 9933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114688 , [Content] ='US - MRKT 2'
 WHERE id=194426075


   --row number: 9934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114688 , [Content] ='AMS'
 WHERE id=194426076


   --row number: 9935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114688 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194426077


   --row number: 9936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114688 , [Content] ='Info Systems/Technology'
 WHERE id=194426078


   --row number: 9937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114688 , [Content] ='6404 - Staff Information Systems Engineer IC4'
 WHERE id=194426079


   --row number: 9938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114688 , [Content] ='Information Systems'
 WHERE id=194426080


   --row number: 9939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114688 , [Content] ='IC4'
 WHERE id=194426081


   --row number: 9940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114688 , [Content] ='USD'
 WHERE id=194426083


   --row number: 9941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114688 , [Content] ='93,600 / 113,200 / 132,800 / 152,400 / 172,000'
 WHERE id=194426084


   --row number: 9942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114688 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=194426085


   --row number: 9943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3114688 , [Content] ='20%'
 WHERE id=194426086


   --row number: 9944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114688 , [Content] ='Yes'
 WHERE id=194426087


   --row number: 9945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3114688 , [Content] ='EXEMPT'
 WHERE id=194426088


   --row number: 9946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3114698 , [Content] ='NO'
 WHERE id=194426733


   --row number: 9947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114698 , [Content] ='2 - Professionals'
 WHERE id=194426734


   --row number: 9948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114698 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194426735


   --row number: 9949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114698 , [Content] ='Technical'
 WHERE id=194426736


   --row number: 9950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114698 , [Content] ='7/20/2018'
 WHERE id=194426737


   --row number: 9951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114698 , [Content] ='5144 US - MRKT 2'
 WHERE id=194426718


   --row number: 9952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114698 , [Content] ='US - MRKT 2'
 WHERE id=194426719


   --row number: 9953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114698 , [Content] ='AMS'
 WHERE id=194426720


   --row number: 9954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114698 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194426721


   --row number: 9955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114698 , [Content] ='Engineering'
 WHERE id=194426722


   --row number: 9956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114698 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=194426723


   --row number: 9957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114698 , [Content] ='Software'
 WHERE id=194426724


   --row number: 9958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114698 , [Content] ='IC4'
 WHERE id=194426725


   --row number: 9959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114698 , [Content] ='USD'
 WHERE id=194426727


   --row number: 9960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114698 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=194426728


   --row number: 9961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114698 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=194426729


   --row number: 9962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3114698 , [Content] ='20%'
 WHERE id=194426730


   --row number: 9963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114698 , [Content] ='Yes'
 WHERE id=194426731


   --row number: 9964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3114698 , [Content] ='EXEMPT'
 WHERE id=194426732


   --row number: 9965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114734 , [Content] ='2 - Professionals'
 WHERE id=194430144


   --row number: 9966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114734 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194430145


   --row number: 9967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114734 , [Content] ='Technical'
 WHERE id=194430146


   --row number: 9968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114734 , [Content] ='7/20/18'
 WHERE id=194430147


   --row number: 9969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114734 , [Content] ='5774 US - MRKT 2'
 WHERE id=194430128


   --row number: 9970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114734 , [Content] ='US - MRKT 2'
 WHERE id=194430129


   --row number: 9971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114734 , [Content] ='AMS'
 WHERE id=194430130


   --row number: 9972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114734 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194430131


   --row number: 9973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114734 , [Content] ='Professional Services'
 WHERE id=194430132


   --row number: 9974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114734 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=194430133


   --row number: 9975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114734 , [Content] ='Business Process Consulting'
 WHERE id=194430134


   --row number: 9976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114734 , [Content] ='IC4'
 WHERE id=194430135


   --row number: 9977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114734 , [Content] ='USD'
 WHERE id=194430137


   --row number: 9978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114734 , [Content] ='93,600 / 110,450 / 127,300 / 144,150 / 161,000'
 WHERE id=194430138


   --row number: 9979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114734 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=194430139


   --row number: 9980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3114734 , [Content] ='15%'
 WHERE id=194430140


   --row number: 9981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114734 , [Content] ='Yes'
 WHERE id=194430141


   --row number: 9982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3114734 , [Content] ='EXEMPT'
 WHERE id=194430142


   --row number: 9983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3114734 , [Content] ='NO'
 WHERE id=194430143


   --row number: 9984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114860 , [Content] ='2 - Professionals'
 WHERE id=194440825


   --row number: 9985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114860 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194440826


   --row number: 9986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114860 , [Content] ='Technical'
 WHERE id=194440827


   --row number: 9987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114860 , [Content] ='10/05/18'
 WHERE id=194440828


   --row number: 9988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114860 , [Content] ='5763 US - MRKT 2'
 WHERE id=194440809


   --row number: 9989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114860 , [Content] ='US - MRKT 2'
 WHERE id=194440810


   --row number: 9990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114860 , [Content] ='AMS'
 WHERE id=194440811


   --row number: 9991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114860 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194440812


   --row number: 9992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114860 , [Content] ='Professional Services'
 WHERE id=194440813


   --row number: 9993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114860 , [Content] ='5763 - Technology Consultant IC3'
 WHERE id=194440814


   --row number: 9994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114860 , [Content] ='Technology Consultant'
 WHERE id=194440815


   --row number: 9995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114860 , [Content] ='IC3'
 WHERE id=194440816


   --row number: 9996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114860 , [Content] ='USD'
 WHERE id=194440818


   --row number: 9997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114860 , [Content] ='74,700 / 88,150 / 101,600 / 115,050 / 128,500'
 WHERE id=194440819


   --row number: 9998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114860 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=194440820


   --row number: 9999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3114860 , [Content] ='15%'
 WHERE id=194440821


   --row number: 10000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114860 , [Content] ='Yes'
 WHERE id=194440822


   --row number: 10001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3114860 , [Content] ='EXEMPT'
 WHERE id=194440823


   --row number: 10002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3114860 , [Content] ='YES'
 WHERE id=194440824


   --row number: 10003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3114879 , [Content] ='5764 US - MRKT 2'
 WHERE id=194441539


   --row number: 10004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3114879 , [Content] ='US - MRKT 2'
 WHERE id=194441540


   --row number: 10005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3114879 , [Content] ='AMS'
 WHERE id=194441541


   --row number: 10006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3114879 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194441542


   --row number: 10007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3114879 , [Content] ='Professional Services'
 WHERE id=194441543


   --row number: 10008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3114879 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=194441544


   --row number: 10009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3114879 , [Content] ='Technology Consultant'
 WHERE id=194441545


   --row number: 10010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3114879 , [Content] ='IC4'
 WHERE id=194441546


   --row number: 10011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3114879 , [Content] ='USD'
 WHERE id=194441548


   --row number: 10012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3114879 , [Content] ='88,800 / 107,400 / 126,000 / 144,600 / 163,200'
 WHERE id=194441549


   --row number: 10013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3114879 , [Content] ='2 - Professionals'
 WHERE id=194441555


   --row number: 10014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3114879 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194441556


   --row number: 10015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3114879 , [Content] ='Technical'
 WHERE id=194441557


   --row number: 10016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3114879 , [Content] ='7/20/18'
 WHERE id=194441558


   --row number: 10017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3114879 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=194441550


   --row number: 10018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3114879 , [Content] ='20%'
 WHERE id=194441551


   --row number: 10019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3114879 , [Content] ='Yes'
 WHERE id=194441552


   --row number: 10020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3114879 , [Content] ='EXEMPT'
 WHERE id=194441553


   --row number: 10021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3114879 , [Content] ='NO'
 WHERE id=194441554


   --row number: 10022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115000 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=194451386


   --row number: 10023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115000 , [Content] ='2 - Professionals'
 WHERE id=194451397


   --row number: 10024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115000 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194451398


   --row number: 10025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115000 , [Content] ='Technical'
 WHERE id=194451399


   --row number: 10026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115000 , [Content] ='7/20/18'
 WHERE id=194451400


   --row number: 10027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115078 , [Content] ='6433 US - MRKT 1'
 WHERE id=194457664


   --row number: 10028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115078 , [Content] ='US - MRKT 1'
 WHERE id=194457665


   --row number: 10029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115078 , [Content] ='AMS'
 WHERE id=194457666


   --row number: 10030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115078 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194457667


   --row number: 10031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115078 , [Content] ='Info Systems/Technology'
 WHERE id=194457668


   --row number: 10032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115078 , [Content] ='6433 - Sr Unified Communications Engineer IC3'
 WHERE id=194457669


   --row number: 10033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115078 , [Content] ='Unified Communications'
 WHERE id=194457670


   --row number: 10034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115078 , [Content] ='IC3'
 WHERE id=194457671


   --row number: 10035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115078 , [Content] ='USD'
 WHERE id=194457673


   --row number: 10036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115078 , [Content] ='81,300 / 95,950 / 110,600 / 125,200 / 139,800'
 WHERE id=194457674


   --row number: 10037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115078 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=194457675


   --row number: 10038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115078 , [Content] ='15%'
 WHERE id=194457676


   --row number: 10039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3115078 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=194457677


   --row number: 10040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115078 , [Content] ='Yes'
 WHERE id=194457678


   --row number: 10041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3115078 , [Content] ='EXEMPT'
 WHERE id=194457679


   --row number: 10042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3115078 , [Content] ='YES'
 WHERE id=194457680


   --row number: 10043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115078 , [Content] ='2 - Professionals'
 WHERE id=194457681


   --row number: 10044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115000 , [Content] ='Product Mgmt Mgr'
 WHERE id=194451387


   --row number: 10045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115000 , [Content] ='IC4'
 WHERE id=194451388


   --row number: 10046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115000 , [Content] ='USD'
 WHERE id=194451390


   --row number: 10047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115000 , [Content] ='101,800 / 123,150 / 144,500 / 165,800 / 187,100'
 WHERE id=194451391


   --row number: 10048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115000 , [Content] ='5224 US - MRKT 2'
 WHERE id=194451381


   --row number: 10049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115000 , [Content] ='US - MRKT 2'
 WHERE id=194451382


   --row number: 10050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115000 , [Content] ='AMS'
 WHERE id=194451383


   --row number: 10051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115000 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194451384


   --row number: 10052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115000 , [Content] ='Engineering'
 WHERE id=194451385


   --row number: 10053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115000 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=194451392


   --row number: 10054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115000 , [Content] ='20%'
 WHERE id=194451393


   --row number: 10055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115000 , [Content] ='Yes'
 WHERE id=194451394


   --row number: 10056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3115000 , [Content] ='EXEMPT'
 WHERE id=194451395


   --row number: 10057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3115000 , [Content] ='NO'
 WHERE id=194451396


   --row number: 10058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115078 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194457682


   --row number: 10059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115078 , [Content] ='Non Technical'
 WHERE id=194457683


   --row number: 10060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115078 , [Content] ='7/20/18'
 WHERE id=194457684


   --row number: 10061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115222 , [Content] ='5143 US - MRKT 2'
 WHERE id=194474213


   --row number: 10062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115222 , [Content] ='US - MRKT 2'
 WHERE id=194474214


   --row number: 10063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115222 , [Content] ='AMS'
 WHERE id=194474215


   --row number: 10064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115222 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194474216


   --row number: 10065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115222 , [Content] ='Engineering'
 WHERE id=194474217


   --row number: 10066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115222 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194474218


   --row number: 10067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115222 , [Content] ='Software'
 WHERE id=194474219


   --row number: 10068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115222 , [Content] ='IC3'
 WHERE id=194474220


   --row number: 10069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115222 , [Content] ='USD'
 WHERE id=194474222


   --row number: 10070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115222 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194474223


   --row number: 10071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115222 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194474224


   --row number: 10072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115222 , [Content] ='15%'
 WHERE id=194474225


   --row number: 10073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115222 , [Content] ='Yes'
 WHERE id=194474226


   --row number: 10074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3115222 , [Content] ='EXEMPT'
 WHERE id=194474227


   --row number: 10075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3115222 , [Content] ='NO'
 WHERE id=194474228


   --row number: 10076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115222 , [Content] ='2 - Professionals'
 WHERE id=194474229


   --row number: 10077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115222 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194474230


   --row number: 10078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115222 , [Content] ='Technical'
 WHERE id=194474231


   --row number: 10079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115222 , [Content] ='7/20/18'
 WHERE id=194474232


   --row number: 10080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115262 , [Content] ='6634 US - MRKT 1'
 WHERE id=194478148


   --row number: 10081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115262 , [Content] ='US - MRKT 1'
 WHERE id=194478149


   --row number: 10082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115262 , [Content] ='AMS'
 WHERE id=194478150


   --row number: 10083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115262 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194478151


   --row number: 10084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115262 , [Content] ='Administration'
 WHERE id=194478152


   --row number: 10085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115262 , [Content] ='6634 - Project/Program Manager IC4'
 WHERE id=194478153


   --row number: 10086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115262 , [Content] ='Project/Program Mgrs'
 WHERE id=194478154


   --row number: 10087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115262 , [Content] ='IC4'
 WHERE id=194478155


   --row number: 10088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115262 , [Content] ='USD'
 WHERE id=194478157


   --row number: 10089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115262 , [Content] ='104,600 / 123,450 / 142,300 / 161,100 / 179,900'
 WHERE id=194478158


   --row number: 10090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115262 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=194478159


   --row number: 10091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115262 , [Content] ='15%'
 WHERE id=194478160


   --row number: 10092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115262 , [Content] ='Yes'
 WHERE id=194478161


   --row number: 10093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3115262 , [Content] ='EXEMPT'
 WHERE id=194478162


   --row number: 10094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3115262 , [Content] ='NO'
 WHERE id=194478163


   --row number: 10095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115262 , [Content] ='2 - Professionals'
 WHERE id=194478164


   --row number: 10096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115262 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194478165


   --row number: 10097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115262 , [Content] ='Non Technical'
 WHERE id=194478166


   --row number: 10098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115262 , [Content] ='7/20/18'
 WHERE id=194478167


   --row number: 10099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115584 , [Content] ='5823 UK'
 WHERE id=194533625


   --row number: 10100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115584 , [Content] ='UK'
 WHERE id=194533626


   --row number: 10101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115584 , [Content] ='EMEA'
 WHERE id=194533627


   --row number: 10102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115584 , [Content] ='United Kingdom'
 WHERE id=194533628


   --row number: 10103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115584 , [Content] ='Customer Support'
 WHERE id=194533629


   --row number: 10104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115584 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=194533630


   --row number: 10105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115584 , [Content] ='Technical Support'
 WHERE id=194533631


   --row number: 10106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115584 , [Content] ='IC3'
 WHERE id=194533632


   --row number: 10107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115584 , [Content] ='33,300 / 45,300 / 57,300'
 WHERE id=194533634


   --row number: 10108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115584 , [Content] ='500 / 1,000 / 1,500'
 WHERE id=194533635


   --row number: 10109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115584 , [Content] ='15%'
 WHERE id=194533636


   --row number: 10110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115584 , [Content] ='Yes'
 WHERE id=194533637


   --row number: 10111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115584 , [Content] ='2 - Professionals'
 WHERE id=194533638


   --row number: 10112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115584 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194533639


   --row number: 10113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115584 , [Content] ='Technical'
 WHERE id=194533640


   --row number: 10114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115587 , [Content] ='5823 NLD'
 WHERE id=194533756


   --row number: 10115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115587 , [Content] ='NLD'
 WHERE id=194533757


   --row number: 10116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115587 , [Content] ='EMEA'
 WHERE id=194533758


   --row number: 10117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115587 , [Content] ='NETHERLANDS'
 WHERE id=194533759


   --row number: 10118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115587 , [Content] ='Customer Support'
 WHERE id=194533760


   --row number: 10119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115587 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=194533761


   --row number: 10120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115587 , [Content] ='Technical Support'
 WHERE id=194533762


   --row number: 10121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115587 , [Content] ='IC3'
 WHERE id=194533763


   --row number: 10122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115587 , [Content] ='EUR'
 WHERE id=194533765


   --row number: 10123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115587 , [Content] ='45,500 / 53,700 / 61,900 / 70,100 / 78,300'
 WHERE id=194533766


   --row number: 10124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115587 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=194533767


   --row number: 10125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115587 , [Content] ='15%'
 WHERE id=194533768


   --row number: 10126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115587 , [Content] ='Yes'
 WHERE id=194533769


   --row number: 10127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115587 , [Content] ='2 - Professionals'
 WHERE id=194533770


   --row number: 10128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115587 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194533771


   --row number: 10129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115587 , [Content] ='Technical'
 WHERE id=194533772


   --row number: 10130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115587 , [Content] ='7/20/18'
 WHERE id=194533773


   --row number: 10131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115593 , [Content] ='6484 UK'
 WHERE id=194534320


   --row number: 10132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115593 , [Content] ='UK'
 WHERE id=194534321


   --row number: 10133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115593 , [Content] ='EMEA'
 WHERE id=194534322


   --row number: 10134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115593 , [Content] ='UNITED KINGDOM'
 WHERE id=194534323


   --row number: 10135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115593 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=194534324


   --row number: 10136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115593 , [Content] ='6484 - Staff Production Service Engineer IC4'
 WHERE id=194534325


   --row number: 10137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115593 , [Content] ='Production service'
 WHERE id=194534326


   --row number: 10138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115593 , [Content] ='IC4'
 WHERE id=194534327


   --row number: 10139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115593 , [Content] ='GBP'
 WHERE id=194534329


   --row number: 10140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115593 , [Content] ='52,200 / 63,150 / 74,100 / 85,000 / 95,900'
 WHERE id=194534330


   --row number: 10141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115593 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=194534331


   --row number: 10142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115593 , [Content] ='20%'
 WHERE id=194534332


   --row number: 10143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115593 , [Content] ='Yes'
 WHERE id=194534333


   --row number: 10144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115593 , [Content] ='2 - Professionals'
 WHERE id=194534334


   --row number: 10145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115593 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194534335


   --row number: 10146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115593 , [Content] ='Technical'
 WHERE id=194534336


   --row number: 10147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115593 , [Content] ='7/20/18'
 WHERE id=194534337


   --row number: 10148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115798 , [Content] ='6295 NLD'
 WHERE id=194555281


   --row number: 10149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115798 , [Content] ='NLD'
 WHERE id=194555282


   --row number: 10150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115798 , [Content] ='EMEA'
 WHERE id=194555283


   --row number: 10151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115798 , [Content] ='NETHERLANDS'
 WHERE id=194555284


   --row number: 10152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115798 , [Content] ='Human Resources'
 WHERE id=194555285


   --row number: 10153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115798 , [Content] ='6295 - HRBP IC5'
 WHERE id=194555286


   --row number: 10154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115798 , [Content] ='Business Partners'
 WHERE id=194555287


   --row number: 10155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115798 , [Content] ='IC5'
 WHERE id=194555288


   --row number: 10156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115798 , [Content] ='EUR'
 WHERE id=194555290


   --row number: 10157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115798 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=194555291


   --row number: 10158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115798 , [Content] ='20%'
 WHERE id=194555292


   --row number: 10159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115798 , [Content] ='Yes'
 WHERE id=194555293


   --row number: 10160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115798 , [Content] ='2 - Professionals'
 WHERE id=194555294


   --row number: 10161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115798 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194555295


   --row number: 10162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115798 , [Content] ='Non Technical'
 WHERE id=194555296


   --row number: 10163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115798 , [Content] ='7/20/18'
 WHERE id=194555297


   --row number: 10164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115917 , [Content] ='5144 US - MRKT 2'
 WHERE id=194564946


   --row number: 10165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115917 , [Content] ='US - MRKT 2'
 WHERE id=194564947


   --row number: 10166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115917 , [Content] ='AMS'
 WHERE id=194564948


   --row number: 10167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115917 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194564949


   --row number: 10168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115917 , [Content] ='Engineering'
 WHERE id=194564950


   --row number: 10169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115917 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=194564951


   --row number: 10170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115917 , [Content] ='Software'
 WHERE id=194564952


   --row number: 10171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115917 , [Content] ='IC4'
 WHERE id=194564953


   --row number: 10172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115917 , [Content] ='USD'
 WHERE id=194564955


   --row number: 10173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115917 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=194564956


   --row number: 10174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115917 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=194564957


   --row number: 10175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115917 , [Content] ='20%'
 WHERE id=194564958


   --row number: 10176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115917 , [Content] ='Yes'
 WHERE id=194564959


   --row number: 10177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3115917 , [Content] ='EXEMPT'
 WHERE id=194564960


   --row number: 10178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3115917 , [Content] ='NO'
 WHERE id=194564961


   --row number: 10179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115917 , [Content] ='2 - Professionals'
 WHERE id=194564962


   --row number: 10180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115917 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194564963


   --row number: 10181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115917 , [Content] ='Technical'
 WHERE id=194564964


   --row number: 10182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115917 , [Content] ='7/20/2018'
 WHERE id=194564965


   --row number: 10183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3115962 , [Content] ='5145 ISR'
 WHERE id=194568847


   --row number: 10184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3115962 , [Content] ='ISR'
 WHERE id=194568848


   --row number: 10185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3115962 , [Content] ='EMEA'
 WHERE id=194568849


   --row number: 10186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3115962 , [Content] ='ISRAEL'
 WHERE id=194568850


   --row number: 10187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3115962 , [Content] ='Engineering'
 WHERE id=194568851


   --row number: 10188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3115962 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=194568852


   --row number: 10189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3115962 , [Content] ='Software'
 WHERE id=194568853


   --row number: 10190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3115962 , [Content] ='IC5'
 WHERE id=194568854


   --row number: 10191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3115962 , [Content] ='ILS'
 WHERE id=194568856


   --row number: 10192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3115962 , [Content] ='328,100 / 401,900 / 475,700 / 549,550 / 623,400'
 WHERE id=194568857


   --row number: 10193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3115962 , [Content] ='186,000 / 261,000 / 336,000 / 411,000 / 486,000'
 WHERE id=194568858


   --row number: 10194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3115962 , [Content] ='25%'
 WHERE id=194568859


   --row number: 10195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3115962 , [Content] ='Yes'
 WHERE id=194568860


   --row number: 10196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3115962 , [Content] ='2 - Professionals'
 WHERE id=194568861


   --row number: 10197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3115962 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194568862


   --row number: 10198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3115962 , [Content] ='Technical'
 WHERE id=194568863


   --row number: 10199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3115962 , [Content] ='7/20/18'
 WHERE id=194568864


   --row number: 10200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3116092 , [Content] ='9999 US - MRKT 1'
 WHERE id=194578493


   --row number: 10201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3116092 , [Content] ='US - MRKT 1'
 WHERE id=194578494


   --row number: 10202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3116092 , [Content] ='AMS'
 WHERE id=194578495


   --row number: 10203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3116092 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194578496


   --row number: 10204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3116092 , [Content] ='9999 - Intern'
 WHERE id=194578497


   --row number: 10205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3116092 , [Content] ='USD'
 WHERE id=194578498


   --row number: 10206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3116092 , [Content] ='No'
 WHERE id=194578499


   --row number: 10207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3116092 , [Content] ='NON-EXEMPT'
 WHERE id=194578500


   --row number: 10208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3116092 , [Content] ='7/20/18'
 WHERE id=194578501


   --row number: 10209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3116476 , [Content] ='NO'
 WHERE id=194610931


   --row number: 10210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3116476 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=194610932


   --row number: 10211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3116476 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194610933


   --row number: 10212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3116476 , [Content] ='Non Technical'
 WHERE id=194610934


   --row number: 10213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3116476 , [Content] ='10/05/18'
 WHERE id=194610935


   --row number: 10214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3116476 , [Content] ='EXEMPT'
 WHERE id=194610930


   --row number: 10215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3116476 , [Content] ='Yes'
 WHERE id=194610929


   --row number: 10216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3116476 , [Content] ='20%'
 WHERE id=194610928


   --row number: 10217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3116476 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=194610927


   --row number: 10218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3116476 , [Content] ='95,500 / 115,500 / 135,500 / 155,500 / 175,500'
 WHERE id=194610926


   --row number: 10219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3116476 , [Content] ='USD'
 WHERE id=194610925


   --row number: 10220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3116476 , [Content] ='M3'
 WHERE id=194610923


   --row number: 10221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3116476 , [Content] ='Tax'
 WHERE id=194610922


   --row number: 10222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3116476 , [Content] ='3083 - Mgr, Tax Mgmt M3'
 WHERE id=194610921


   --row number: 10223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3116476 , [Content] ='Finance'
 WHERE id=194610920


   --row number: 10224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3116476 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194610919


   --row number: 10225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3116476 , [Content] ='AMS'
 WHERE id=194610918


   --row number: 10226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3116476 , [Content] ='US - MRKT 2'
 WHERE id=194610917


   --row number: 10227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3116476 , [Content] ='3083 US - MRKT 2'
 WHERE id=194610916


   --row number: 10228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3117093 , [Content] ='EXEMPT'
 WHERE id=194662981


   --row number: 10229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3117093 , [Content] ='NO'
 WHERE id=194662982


   --row number: 10230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3117093 , [Content] ='4 - Sales Workers'
 WHERE id=194662983


   --row number: 10231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3117093 , [Content] ='8742-Salespersons - Outside'
 WHERE id=194662984


   --row number: 10232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3117093 , [Content] ='S635 US - MRKT 1'
 WHERE id=194662966


   --row number: 10233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3117093 , [Content] ='US - MRKT 1'
 WHERE id=194662967


   --row number: 10234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3117093 , [Content] ='AMS'
 WHERE id=194662968


   --row number: 10235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3117093 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194662969


   --row number: 10236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3117093 , [Content] ='Sales'
 WHERE id=194662970


   --row number: 10237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3117093 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=194662971


   --row number: 10238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3117093 , [Content] ='Enterprise Accounts'
 WHERE id=194662972


   --row number: 10239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3117093 , [Content] ='IC5'
 WHERE id=194662973


   --row number: 10240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3117093 , [Content] ='USD'
 WHERE id=194662975


   --row number: 10241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3117093 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=194662976


   --row number: 10242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3117093 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=194662977


   --row number: 10243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3117093 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=194662978


   --row number: 10244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3117093 , [Content] ='50/50'
 WHERE id=194662979


   --row number: 10245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3117093 , [Content] ='Yes'
 WHERE id=194662980


   --row number: 10246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3117093 , [Content] ='Technical'
 WHERE id=194662985


   --row number: 10247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3117093 , [Content] ='7/20/18'
 WHERE id=194662986


   --row number: 10248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3117231 , [Content] ='Exempt'
 WHERE id=194685237


   --row number: 10249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3117231 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=194685238


   --row number: 10250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3117231 , [Content] ='2756 US - MRKT 3'
 WHERE id=194685224


   --row number: 10251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3117231 , [Content] ='US - MRKT 3'
 WHERE id=194685225


   --row number: 10252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3117231 , [Content] ='AMS'
 WHERE id=194685226


   --row number: 10253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3117231 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194685227


   --row number: 10254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3117231 , [Content] ='Customer Support'
 WHERE id=194685228


   --row number: 10255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3117231 , [Content] ='2756 - Sr Dir, Customer Success Mgmt M6'
 WHERE id=194685229


   --row number: 10256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3117231 , [Content] ='Customer Success'
 WHERE id=194685230


   --row number: 10257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3117231 , [Content] ='M6'
 WHERE id=194685231


   --row number: 10258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3117231 , [Content] ='USD'
 WHERE id=194685233


   --row number: 10259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3117231 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=194685234


   --row number: 10260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3117231 , [Content] ='30%'
 WHERE id=194685235


   --row number: 10261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3117231 , [Content] ='Yes'
 WHERE id=194685236


   --row number: 10262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3117231 , [Content] ='7/20/18'
 WHERE id=194685241


   --row number: 10263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3117231 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194685239


   --row number: 10264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3117231 , [Content] ='Technical'
 WHERE id=194685240


   --row number: 10265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3117300 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=194704341


   --row number: 10266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3117300 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194704342


   --row number: 10267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3117300 , [Content] ='Non Technical'
 WHERE id=194704343


   --row number: 10268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3117300 , [Content] ='09/05/18'
 WHERE id=194704344


   --row number: 10269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3117300 , [Content] ='3263 IND'
 WHERE id=194704327


   --row number: 10270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3117300 , [Content] ='IND'
 WHERE id=194704328


   --row number: 10271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3117300 , [Content] ='APAC'
 WHERE id=194704329


   --row number: 10272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3117300 , [Content] ='INDIA'
 WHERE id=194704330


   --row number: 10273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3117300 , [Content] ='Human Resources'
 WHERE id=194704331


   --row number: 10274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3117300 , [Content] ='3263 - Mgr, Shared Services Mgmt M3'
 WHERE id=194704332


   --row number: 10275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3117300 , [Content] ='HR Shared Srvcs'
 WHERE id=194704333


   --row number: 10276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3117300 , [Content] ='M3'
 WHERE id=194704334


   --row number: 10277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3117300 , [Content] ='INR'
 WHERE id=194704336


   --row number: 10278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3117300 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=194704338


   --row number: 10279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3117300 , [Content] ='20%'
 WHERE id=194704339


   --row number: 10280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3117300 , [Content] ='Yes'
 WHERE id=194704340


   --row number: 10281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3117834 , [Content] ='Technical'
 WHERE id=194748986


   --row number: 10282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3117834 , [Content] ='7/20/18'
 WHERE id=194748987


   --row number: 10283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3117834 , [Content] ='5145 ISR'
 WHERE id=194748970


   --row number: 10284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3117834 , [Content] ='ISR'
 WHERE id=194748971


   --row number: 10285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3117834 , [Content] ='EMEA'
 WHERE id=194748972


   --row number: 10286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3117834 , [Content] ='ISRAEL'
 WHERE id=194748973


   --row number: 10287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3117834 , [Content] ='Engineering'
 WHERE id=194748974


   --row number: 10288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3117834 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=194748975


   --row number: 10289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3117834 , [Content] ='Software'
 WHERE id=194748976


   --row number: 10290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3117834 , [Content] ='IC5'
 WHERE id=194748977


   --row number: 10291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3117834 , [Content] ='ILS'
 WHERE id=194748979


   --row number: 10292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3117834 , [Content] ='328,100 / 401,900 / 475,700 / 549,550 / 623,400'
 WHERE id=194748980


   --row number: 10293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3117834 , [Content] ='186,000 / 261,000 / 336,000 / 411,000 / 486,000'
 WHERE id=194748981


   --row number: 10294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3117834 , [Content] ='25%'
 WHERE id=194748982


   --row number: 10295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3117834 , [Content] ='Yes'
 WHERE id=194748983


   --row number: 10296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3117834 , [Content] ='2 - Professionals'
 WHERE id=194748984


   --row number: 10297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3117834 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194748985


   --row number: 10298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3117841 , [Content] ='Technical'
 WHERE id=194749887


   --row number: 10299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3117841 , [Content] ='7/20/18'
 WHERE id=194749888


   --row number: 10300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3117841 , [Content] ='5143 ISR'
 WHERE id=194749871


   --row number: 10301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3117841 , [Content] ='ISR'
 WHERE id=194749872


   --row number: 10302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3117841 , [Content] ='EMEA'
 WHERE id=194749873


   --row number: 10303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3117841 , [Content] ='ISRAEL'
 WHERE id=194749874


   --row number: 10304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3117841 , [Content] ='Engineering'
 WHERE id=194749875


   --row number: 10305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3117841 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194749876


   --row number: 10306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3117841 , [Content] ='Software'
 WHERE id=194749877


   --row number: 10307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3117841 , [Content] ='IC3'
 WHERE id=194749878


   --row number: 10308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3117841 , [Content] ='ILS'
 WHERE id=194749880


   --row number: 10309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3117841 , [Content] ='261,700 / 308,800 / 355,900 / 403,000 / 450,100'
 WHERE id=194749881


   --row number: 10310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3117841 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=194749882


   --row number: 10311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3117841 , [Content] ='15%'
 WHERE id=194749883


   --row number: 10312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3117841 , [Content] ='Yes'
 WHERE id=194749884


   --row number: 10313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3117841 , [Content] ='2 - Professionals'
 WHERE id=194749885


   --row number: 10314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3117841 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194749886


   --row number: 10315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3118145 , [Content] ='EXEMPT'
 WHERE id=194775573


   --row number: 10316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3118145 , [Content] ='NO'
 WHERE id=194775574


   --row number: 10317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3118145 , [Content] ='2 - Professionals'
 WHERE id=194775575


   --row number: 10318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3118145 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194775576


   --row number: 10319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3118145 , [Content] ='Technical'
 WHERE id=194775577


   --row number: 10320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3118145 , [Content] ='04/05/18'
 WHERE id=194775578


   --row number: 10321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3118145 , [Content] ='5142 US - MRKT 2'
 WHERE id=194775559


   --row number: 10322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3118145 , [Content] ='US - MRKT 2'
 WHERE id=194775560


   --row number: 10323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3118145 , [Content] ='AMS'
 WHERE id=194775561


   --row number: 10324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3118145 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194775562


   --row number: 10325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3118145 , [Content] ='Engineering'
 WHERE id=194775563


   --row number: 10326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3118145 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=194775564


   --row number: 10327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3118145 , [Content] ='Software'
 WHERE id=194775565


   --row number: 10328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3118145 , [Content] ='IC2'
 WHERE id=194775566


   --row number: 10329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3118145 , [Content] ='USD'
 WHERE id=194775568


   --row number: 10330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3118145 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=194775569


   --row number: 10331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3118145 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=194775570


   --row number: 10332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3118145 , [Content] ='10%'
 WHERE id=194775571


   --row number: 10333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3118145 , [Content] ='Yes'
 WHERE id=194775572


   --row number: 10334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3118348 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194790987


   --row number: 10335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3118348 , [Content] ='Non Technical'
 WHERE id=194790988


   --row number: 10336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3118348 , [Content] ='7/20/18'
 WHERE id=194790989


   --row number: 10337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3118348 , [Content] ='5545 US - MRKT 1'
 WHERE id=194790970


   --row number: 10338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3118348 , [Content] ='US - MRKT 1'
 WHERE id=194790971


   --row number: 10339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3118348 , [Content] ='AMS'
 WHERE id=194790972


   --row number: 10340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3118348 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194790973


   --row number: 10341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3118348 , [Content] ='Marketing'
 WHERE id=194790974


   --row number: 10342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3118348 , [Content] ='5545 - Events Coordinator IC5'
 WHERE id=194790975


   --row number: 10343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3118348 , [Content] ='Events'
 WHERE id=194790976


   --row number: 10344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3118348 , [Content] ='IC5'
 WHERE id=194790977


   --row number: 10345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3118348 , [Content] ='USD'
 WHERE id=194790979


   --row number: 10346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3118348 , [Content] ='103,400 / 125,100 / 146,800 / 168,450 / 190,100'
 WHERE id=194790980


   --row number: 10347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3118348 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=194790981


   --row number: 10348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3118348 , [Content] ='20%'
 WHERE id=194790982


   --row number: 10349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3118348 , [Content] ='Yes'
 WHERE id=194790983


   --row number: 10350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3118348 , [Content] ='EXEMPT'
 WHERE id=194790984


   --row number: 10351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3118348 , [Content] ='NO'
 WHERE id=194790985


   --row number: 10352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3118348 , [Content] ='2 - Professionals'
 WHERE id=194790986


   --row number: 10353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3118606 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=194809487


   --row number: 10354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3118606 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194809488


   --row number: 10355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3118606 , [Content] ='Non Technical'
 WHERE id=194809489


   --row number: 10356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3118606 , [Content] ='7/20/18'
 WHERE id=194809490


   --row number: 10357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3118606 , [Content] ='3396 US - MRKT 1'
 WHERE id=194809471


   --row number: 10358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3118606 , [Content] ='US - MRKT 1'
 WHERE id=194809472


   --row number: 10359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3118606 , [Content] ='AMS'
 WHERE id=194809473


   --row number: 10360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3118606 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194809474


   --row number: 10361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3118606 , [Content] ='Legal'
 WHERE id=194809475


   --row number: 10362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3118606 , [Content] ='3396 - Sr Dir, Corporate Counsel Mgmt M6'
 WHERE id=194809476


   --row number: 10363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3118606 , [Content] ='Legal Counsel'
 WHERE id=194809477


   --row number: 10364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3118606 , [Content] ='M6'
 WHERE id=194809478


   --row number: 10365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3118606 , [Content] ='USD'
 WHERE id=194809480


   --row number: 10366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3118606 , [Content] ='188,600 / 231,000 / 273,400 / 315,850 / 358,300'
 WHERE id=194809481


   --row number: 10367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3118606 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=194809482


   --row number: 10368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3118606 , [Content] ='30%'
 WHERE id=194809483


   --row number: 10369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3118606 , [Content] ='Yes'
 WHERE id=194809484


   --row number: 10370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3118606 , [Content] ='EXEMPT'
 WHERE id=194809485


   --row number: 10371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3118606 , [Content] ='NO'
 WHERE id=194809486


   --row number: 10372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119020 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194837551


   --row number: 10373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119020 , [Content] ='Non Technical'
 WHERE id=194837552


   --row number: 10374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119020 , [Content] ='7/20/18'
 WHERE id=194837553


   --row number: 10375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119020 , [Content] ='2655 US - MRKT 1'
 WHERE id=194837534


   --row number: 10376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119020 , [Content] ='US - MRKT 1'
 WHERE id=194837535


   --row number: 10377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119020 , [Content] ='AMS'
 WHERE id=194837536


   --row number: 10378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119020 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194837537


   --row number: 10379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119020 , [Content] ='Marketing'
 WHERE id=194837538


   --row number: 10380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119020 , [Content] ='2655 - Dir, Trade Show/Events Mgmt M5'
 WHERE id=194837539


   --row number: 10381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119020 , [Content] ='Events'
 WHERE id=194837540


   --row number: 10382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119020 , [Content] ='M5'
 WHERE id=194837541


   --row number: 10383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119020 , [Content] ='USD'
 WHERE id=194837543


   --row number: 10384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119020 , [Content] ='125,200 / 153,400 / 181,600 / 209,750 / 237,900'
 WHERE id=194837544


   --row number: 10385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3119020 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=194837545


   --row number: 10386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3119020 , [Content] ='25%'
 WHERE id=194837546


   --row number: 10387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119020 , [Content] ='Yes'
 WHERE id=194837547


   --row number: 10388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3119020 , [Content] ='EXEMPT'
 WHERE id=194837548


   --row number: 10389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3119020 , [Content] ='NO'
 WHERE id=194837549


   --row number: 10390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119020 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=194837550


   --row number: 10391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119181 , [Content] ='2 - Professionals'
 WHERE id=194851195


   --row number: 10392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119181 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194851196


   --row number: 10393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119181 , [Content] ='Technical'
 WHERE id=194851197


   --row number: 10394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119181 , [Content] ='7/20/18'
 WHERE id=194851198


   --row number: 10395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119181 , [Content] ='5894 US - MRKT 2'
 WHERE id=194851179


   --row number: 10396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119181 , [Content] ='US - MRKT 2'
 WHERE id=194851180


   --row number: 10397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119181 , [Content] ='AMS'
 WHERE id=194851181


   --row number: 10398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119181 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194851182


   --row number: 10399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119181 , [Content] ='Professional Services'
 WHERE id=194851183


   --row number: 10400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119181 , [Content] ='5894 - Technical Curriculum Developer IC4'
 WHERE id=194851184


   --row number: 10401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119181 , [Content] ='Technical Curriculum'
 WHERE id=194851185


   --row number: 10402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119181 , [Content] ='IC4'
 WHERE id=194851186


   --row number: 10403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119181 , [Content] ='USD'
 WHERE id=194851188


   --row number: 10404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119181 , [Content] ='82,400 / 97,250 / 112,100 / 126,900 / 141,700'
 WHERE id=194851189


   --row number: 10405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3119181 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=194851190


   --row number: 10406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3119181 , [Content] ='15%'
 WHERE id=194851191


   --row number: 10407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119181 , [Content] ='Yes'
 WHERE id=194851192


   --row number: 10408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3119181 , [Content] ='EXEMPT'
 WHERE id=194851193


   --row number: 10409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3119181 , [Content] ='NO'
 WHERE id=194851194


   --row number: 10410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3119199 , [Content] ='NO'
 WHERE id=194852034


   --row number: 10411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119199 , [Content] ='2 - Professionals'
 WHERE id=194852035


   --row number: 10412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119199 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194852036


   --row number: 10413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119199 , [Content] ='Technical'
 WHERE id=194852037


   --row number: 10414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119199 , [Content] ='7/20/18'
 WHERE id=194852038


   --row number: 10415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119199 , [Content] ='5894 US - MRKT 2'
 WHERE id=194852019


   --row number: 10416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119199 , [Content] ='US - MRKT 2'
 WHERE id=194852020


   --row number: 10417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119199 , [Content] ='AMS'
 WHERE id=194852021


   --row number: 10418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119199 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194852022


   --row number: 10419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119199 , [Content] ='Professional Services'
 WHERE id=194852023


   --row number: 10420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119199 , [Content] ='5894 - Technical Curriculum Developer IC4'
 WHERE id=194852024


   --row number: 10421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119199 , [Content] ='Technical Curriculum'
 WHERE id=194852025


   --row number: 10422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119199 , [Content] ='IC4'
 WHERE id=194852026


   --row number: 10423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119199 , [Content] ='USD'
 WHERE id=194852028


   --row number: 10424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119199 , [Content] ='82,400 / 97,250 / 112,100 / 126,900 / 141,700'
 WHERE id=194852029


   --row number: 10425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3119199 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=194852030


   --row number: 10426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3119199 , [Content] ='15%'
 WHERE id=194852031


   --row number: 10427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119199 , [Content] ='Yes'
 WHERE id=194852032


   --row number: 10428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3119199 , [Content] ='EXEMPT'
 WHERE id=194852033


   --row number: 10429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119451 , [Content] ='8742-Salespersons - Outside'
 WHERE id=194885559


   --row number: 10430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119451 , [Content] ='Technical'
 WHERE id=194885560


   --row number: 10431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119451 , [Content] ='7/20/18'
 WHERE id=194885561


   --row number: 10432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119451 , [Content] ='S1615 JPN'
 WHERE id=194885543


   --row number: 10433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119451 , [Content] ='JPN'
 WHERE id=194885544


   --row number: 10434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119451 , [Content] ='APAC'
 WHERE id=194885545


   --row number: 10435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119451 , [Content] ='JAPAN'
 WHERE id=194885546


   --row number: 10436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119451 , [Content] ='Sales'
 WHERE id=194885547


   --row number: 10437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119451 , [Content] ='S1615 - Regional Partner Mgr IC5'
 WHERE id=194885548


   --row number: 10438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119451 , [Content] ='Partner Sales'
 WHERE id=194885549


   --row number: 10439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119451 , [Content] ='IC5'
 WHERE id=194885550


   --row number: 10440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119451 , [Content] ='JPY'
 WHERE id=194885552


   --row number: 10441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119451 , [Content] ='10,098,000 / 10,989,000 / 11,880,000 / 12,771,000 / 13,662,000'
 WHERE id=194885553


   --row number: 10442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3119451 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=194885554


   --row number: 10443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3119451 , [Content] ='16,830,000 / 18,315,000 / 19,800,000 / 21,285,000 / 22,770,000'
 WHERE id=194885555


   --row number: 10444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3119451 , [Content] ='60/40'
 WHERE id=194885556


   --row number: 10445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119451 , [Content] ='Yes'
 WHERE id=194885557


   --row number: 10446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119451 , [Content] ='4 - Sales Workers'
 WHERE id=194885558


   --row number: 10447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119456 , [Content] ='4 - Sales Workers'
 WHERE id=194886464


   --row number: 10448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119456 , [Content] ='8742-Salespersons - Outside'
 WHERE id=194886465


   --row number: 10449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119456 , [Content] ='Technical'
 WHERE id=194886466


   --row number: 10450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119456 , [Content] ='7/20/18'
 WHERE id=194886467


   --row number: 10451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119456 , [Content] ='S634 SGP'
 WHERE id=194886449


   --row number: 10452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119456 , [Content] ='SGP'
 WHERE id=194886450


   --row number: 10453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119456 , [Content] ='APAC'
 WHERE id=194886451


   --row number: 10454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119456 , [Content] ='SINGAPORE'
 WHERE id=194886452


   --row number: 10455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119456 , [Content] ='Sales'
 WHERE id=194886453


   --row number: 10456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119456 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=194886454


   --row number: 10457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119456 , [Content] ='Enterprise Accounts'
 WHERE id=194886455


   --row number: 10458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119456 , [Content] ='IC4'
 WHERE id=194886456


   --row number: 10459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119456 , [Content] ='SGD'
 WHERE id=194886458


   --row number: 10460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119456 , [Content] ='119,000 / 129,500 / 140,000 / 150,500 / 161,000'
 WHERE id=194886459


   --row number: 10461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3119456 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=194886460


   --row number: 10462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3119456 , [Content] ='238,000 / 259,000 / 280,000 / 301,000 / 322,000'
 WHERE id=194886461


   --row number: 10463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3119456 , [Content] ='50/50'
 WHERE id=194886462


   --row number: 10464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119456 , [Content] ='Yes'
 WHERE id=194886463


   --row number: 10465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119501 , [Content] ='5142 IND'
 WHERE id=194894347


   --row number: 10466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119501 , [Content] ='IND'
 WHERE id=194894348


   --row number: 10467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119501 , [Content] ='APAC'
 WHERE id=194894349


   --row number: 10468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119501 , [Content] ='INDIA'
 WHERE id=194894350


   --row number: 10469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119501 , [Content] ='Engineering'
 WHERE id=194894351


   --row number: 10470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119501 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=194894352


   --row number: 10471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119501 , [Content] ='Software'
 WHERE id=194894353


   --row number: 10472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119501 , [Content] ='IC2'
 WHERE id=194894354


   --row number: 10473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119501 , [Content] ='INR'
 WHERE id=194894356


   --row number: 10474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119501 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=194894357


   --row number: 10475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3119501 , [Content] ='10%'
 WHERE id=194894358


   --row number: 10476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119501 , [Content] ='No'
 WHERE id=194894359


   --row number: 10477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119501 , [Content] ='2 - Professionals'
 WHERE id=194894360


   --row number: 10478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119501 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194894361


   --row number: 10479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119501 , [Content] ='Technical'
 WHERE id=194894362


   --row number: 10480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119501 , [Content] ='7/20/18'
 WHERE id=194894363


   --row number: 10481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3119676 , [Content] ='Technical'
 WHERE id=194909764


   --row number: 10482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3119676 , [Content] ='7/20/2018'
 WHERE id=194909765


   --row number: 10483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3119676 , [Content] ='6483 IRL'
 WHERE id=194909748


   --row number: 10484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3119676 , [Content] ='IRL'
 WHERE id=194909749


   --row number: 10485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3119676 , [Content] ='EMEA'
 WHERE id=194909750


   --row number: 10486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3119676 , [Content] ='IRELAND'
 WHERE id=194909751


   --row number: 10487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3119676 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=194909752


   --row number: 10488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3119676 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=194909753


   --row number: 10489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3119676 , [Content] ='Production service'
 WHERE id=194909754


   --row number: 10490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3119676 , [Content] ='IC3'
 WHERE id=194909755


   --row number: 10491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3119676 , [Content] ='EUR'
 WHERE id=194909757


   --row number: 10492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3119676 , [Content] ='53,700 / 63,350 / 73,000 / 82,700 / 92,400'
 WHERE id=194909758


   --row number: 10493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3119676 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=194909759


   --row number: 10494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3119676 , [Content] ='15%'
 WHERE id=194909760


   --row number: 10495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3119676 , [Content] ='Yes'
 WHERE id=194909761


   --row number: 10496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3119676 , [Content] ='2 - Professionals'
 WHERE id=194909762


   --row number: 10497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3119676 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194909763


   --row number: 10498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120374 , [Content] ='8810-Clerical Office Employees'
 WHERE id=194962286


   --row number: 10499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120374 , [Content] ='Non Technical'
 WHERE id=194962287


   --row number: 10500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120374 , [Content] ='7/20/18'
 WHERE id=194962288


   --row number: 10501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120374 , [Content] ='6005 US - MRKT 1'
 WHERE id=194962269


   --row number: 10502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120374 , [Content] ='US - MRKT 1'
 WHERE id=194962270


   --row number: 10503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120374 , [Content] ='AMS'
 WHERE id=194962271


   --row number: 10504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120374 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194962272


   --row number: 10505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120374 , [Content] ='Finance'
 WHERE id=194962273


   --row number: 10506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120374 , [Content] ='6005 - Sr. FP&A Analyst IC5'
 WHERE id=194962274


   --row number: 10507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120374 , [Content] ='FP&A'
 WHERE id=194962275


   --row number: 10508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120374 , [Content] ='IC5'
 WHERE id=194962276


   --row number: 10509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120374 , [Content] ='USD'
 WHERE id=194962278


   --row number: 10510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120374 , [Content] ='110,800 / 134,050 / 157,300 / 180,500 / 203,700'
 WHERE id=194962279


   --row number: 10511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120374 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=194962280


   --row number: 10512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120374 , [Content] ='20%'
 WHERE id=194962281


   --row number: 10513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120374 , [Content] ='Yes'
 WHERE id=194962282


   --row number: 10514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120374 , [Content] ='EXEMPT'
 WHERE id=194962283


   --row number: 10515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120374 , [Content] ='NO'
 WHERE id=194962284


   --row number: 10516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120374 , [Content] ='2 - Professionals'
 WHERE id=194962285


   --row number: 10517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120385 , [Content] ='2 - Professionals'
 WHERE id=194963023


   --row number: 10518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120385 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963024


   --row number: 10519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120385 , [Content] ='Technical'
 WHERE id=194963025


   --row number: 10520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120385 , [Content] ='7/20/18'
 WHERE id=194963026


   --row number: 10521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120385 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963007


   --row number: 10522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120385 , [Content] ='US - MRKT 2'
 WHERE id=194963008


   --row number: 10523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120385 , [Content] ='AMS'
 WHERE id=194963009


   --row number: 10524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120385 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963010


   --row number: 10525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120385 , [Content] ='Engineering'
 WHERE id=194963011


   --row number: 10526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120385 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963012


   --row number: 10527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120385 , [Content] ='Software'
 WHERE id=194963013


   --row number: 10528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120385 , [Content] ='IC3'
 WHERE id=194963014


   --row number: 10529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120385 , [Content] ='USD'
 WHERE id=194963016


   --row number: 10530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120385 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963017


   --row number: 10531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120385 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963018


   --row number: 10532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120385 , [Content] ='15%'
 WHERE id=194963019


   --row number: 10533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120385 , [Content] ='Yes'
 WHERE id=194963020


   --row number: 10534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120385 , [Content] ='EXEMPT'
 WHERE id=194963021


   --row number: 10535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120385 , [Content] ='NO'
 WHERE id=194963022


   --row number: 10536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120386 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963127


   --row number: 10537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120386 , [Content] ='US - MRKT 2'
 WHERE id=194963128


   --row number: 10538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120386 , [Content] ='AMS'
 WHERE id=194963129


   --row number: 10539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120386 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963130


   --row number: 10540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120386 , [Content] ='Engineering'
 WHERE id=194963131


   --row number: 10541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120386 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963132


   --row number: 10542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120386 , [Content] ='Software'
 WHERE id=194963133


   --row number: 10543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120386 , [Content] ='IC3'
 WHERE id=194963134


   --row number: 10544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120386 , [Content] ='USD'
 WHERE id=194963136


   --row number: 10545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120386 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963137


   --row number: 10546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120386 , [Content] ='2 - Professionals'
 WHERE id=194963143


   --row number: 10547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120396 , [Content] ='Software'
 WHERE id=194963218


   --row number: 10548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120396 , [Content] ='IC3'
 WHERE id=194963219


   --row number: 10549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120396 , [Content] ='USD'
 WHERE id=194963221


   --row number: 10550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120396 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963222


   --row number: 10551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120396 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963223


   --row number: 10552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120396 , [Content] ='15%'
 WHERE id=194963224


   --row number: 10553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120396 , [Content] ='Yes'
 WHERE id=194963225


   --row number: 10554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120396 , [Content] ='EXEMPT'
 WHERE id=194963226


   --row number: 10555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120396 , [Content] ='NO'
 WHERE id=194963227


   --row number: 10556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120396 , [Content] ='2 - Professionals'
 WHERE id=194963228


   --row number: 10557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120396 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963229


   --row number: 10558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120396 , [Content] ='Technical'
 WHERE id=194963230


   --row number: 10559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120396 , [Content] ='7/20/18'
 WHERE id=194963231


   --row number: 10560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120386 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963144


   --row number: 10561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120386 , [Content] ='Technical'
 WHERE id=194963145


   --row number: 10562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120386 , [Content] ='7/20/18'
 WHERE id=194963146


   --row number: 10563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120396 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963212


   --row number: 10564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120396 , [Content] ='US - MRKT 2'
 WHERE id=194963213


   --row number: 10565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120396 , [Content] ='AMS'
 WHERE id=194963214


   --row number: 10566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120396 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963215


   --row number: 10567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120396 , [Content] ='Engineering'
 WHERE id=194963216


   --row number: 10568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120396 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963217


   --row number: 10569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120386 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963138


   --row number: 10570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120386 , [Content] ='15%'
 WHERE id=194963139


   --row number: 10571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120386 , [Content] ='Yes'
 WHERE id=194963140


   --row number: 10572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120386 , [Content] ='EXEMPT'
 WHERE id=194963141


   --row number: 10573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120386 , [Content] ='NO'
 WHERE id=194963142


   --row number: 10574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120397 , [Content] ='2 - Professionals'
 WHERE id=194963339


   --row number: 10575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120397 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963340


   --row number: 10576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120397 , [Content] ='Technical'
 WHERE id=194963341


   --row number: 10577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120397 , [Content] ='7/20/18'
 WHERE id=194963342


   --row number: 10578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120397 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963323


   --row number: 10579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120397 , [Content] ='US - MRKT 2'
 WHERE id=194963324


   --row number: 10580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120397 , [Content] ='AMS'
 WHERE id=194963325


   --row number: 10581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120397 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963326


   --row number: 10582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120397 , [Content] ='Engineering'
 WHERE id=194963327


   --row number: 10583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120397 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963328


   --row number: 10584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120397 , [Content] ='Software'
 WHERE id=194963329


   --row number: 10585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120397 , [Content] ='IC3'
 WHERE id=194963330


   --row number: 10586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120397 , [Content] ='USD'
 WHERE id=194963332


   --row number: 10587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120397 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963333


   --row number: 10588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120397 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963334


   --row number: 10589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120397 , [Content] ='15%'
 WHERE id=194963335


   --row number: 10590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120397 , [Content] ='Yes'
 WHERE id=194963336


   --row number: 10591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120397 , [Content] ='EXEMPT'
 WHERE id=194963337


   --row number: 10592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120397 , [Content] ='NO'
 WHERE id=194963338


   --row number: 10593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120398 , [Content] ='2 - Professionals'
 WHERE id=194963412


   --row number: 10594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120398 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963413


   --row number: 10595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120398 , [Content] ='Technical'
 WHERE id=194963414


   --row number: 10596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120398 , [Content] ='7/20/18'
 WHERE id=194963415


   --row number: 10597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120398 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963396


   --row number: 10598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120398 , [Content] ='US - MRKT 2'
 WHERE id=194963397


   --row number: 10599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120398 , [Content] ='AMS'
 WHERE id=194963398


   --row number: 10600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120398 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963399


   --row number: 10601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120398 , [Content] ='Engineering'
 WHERE id=194963400


   --row number: 10602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120398 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963401


   --row number: 10603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120398 , [Content] ='Software'
 WHERE id=194963402


   --row number: 10604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120398 , [Content] ='IC3'
 WHERE id=194963403


   --row number: 10605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120398 , [Content] ='USD'
 WHERE id=194963405


   --row number: 10606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120398 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963406


   --row number: 10607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120398 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963407


   --row number: 10608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120398 , [Content] ='15%'
 WHERE id=194963408


   --row number: 10609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120398 , [Content] ='Yes'
 WHERE id=194963409


   --row number: 10610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120398 , [Content] ='EXEMPT'
 WHERE id=194963410


   --row number: 10611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120398 , [Content] ='NO'
 WHERE id=194963411


   --row number: 10612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120399 , [Content] ='2 - Professionals'
 WHERE id=194963486


   --row number: 10613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120399 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963487


   --row number: 10614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120399 , [Content] ='Technical'
 WHERE id=194963488


   --row number: 10615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120399 , [Content] ='7/20/18'
 WHERE id=194963489


   --row number: 10616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120400 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963531


   --row number: 10617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120400 , [Content] ='US - MRKT 2'
 WHERE id=194963532


   --row number: 10618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120400 , [Content] ='AMS'
 WHERE id=194963533


   --row number: 10619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120400 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963534


   --row number: 10620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120400 , [Content] ='Engineering'
 WHERE id=194963535


   --row number: 10621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120400 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963536


   --row number: 10622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120400 , [Content] ='Software'
 WHERE id=194963537


   --row number: 10623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120400 , [Content] ='IC3'
 WHERE id=194963538


   --row number: 10624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120400 , [Content] ='USD'
 WHERE id=194963540


   --row number: 10625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120400 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963541


   --row number: 10626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120400 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963542


   --row number: 10627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120400 , [Content] ='15%'
 WHERE id=194963543


   --row number: 10628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120400 , [Content] ='Yes'
 WHERE id=194963544


   --row number: 10629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120400 , [Content] ='EXEMPT'
 WHERE id=194963545


   --row number: 10630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120400 , [Content] ='NO'
 WHERE id=194963546


   --row number: 10631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120400 , [Content] ='2 - Professionals'
 WHERE id=194963547


   --row number: 10632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120400 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963548


   --row number: 10633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120399 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963470


   --row number: 10634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120399 , [Content] ='US - MRKT 2'
 WHERE id=194963471


   --row number: 10635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120399 , [Content] ='AMS'
 WHERE id=194963472


   --row number: 10636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120399 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963473


   --row number: 10637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120399 , [Content] ='Engineering'
 WHERE id=194963474


   --row number: 10638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120399 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963475


   --row number: 10639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120399 , [Content] ='Software'
 WHERE id=194963476


   --row number: 10640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120399 , [Content] ='IC3'
 WHERE id=194963477


   --row number: 10641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120399 , [Content] ='USD'
 WHERE id=194963479


   --row number: 10642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120399 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963480


   --row number: 10643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120399 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963481


   --row number: 10644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120399 , [Content] ='15%'
 WHERE id=194963482


   --row number: 10645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120399 , [Content] ='Yes'
 WHERE id=194963483


   --row number: 10646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120399 , [Content] ='EXEMPT'
 WHERE id=194963484


   --row number: 10647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120399 , [Content] ='NO'
 WHERE id=194963485


   --row number: 10648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120400 , [Content] ='Technical'
 WHERE id=194963549


   --row number: 10649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120400 , [Content] ='7/20/18'
 WHERE id=194963550


   --row number: 10650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120401 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963615


   --row number: 10651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120401 , [Content] ='US - MRKT 2'
 WHERE id=194963616


   --row number: 10652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120401 , [Content] ='AMS'
 WHERE id=194963617


   --row number: 10653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120401 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963618


   --row number: 10654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120401 , [Content] ='Engineering'
 WHERE id=194963619


   --row number: 10655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120401 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963620


   --row number: 10656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120401 , [Content] ='Software'
 WHERE id=194963621


   --row number: 10657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120401 , [Content] ='IC3'
 WHERE id=194963622


   --row number: 10658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120401 , [Content] ='USD'
 WHERE id=194963624


   --row number: 10659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120401 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963625


   --row number: 10660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120401 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963626


   --row number: 10661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120401 , [Content] ='15%'
 WHERE id=194963627


   --row number: 10662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120401 , [Content] ='Yes'
 WHERE id=194963628


   --row number: 10663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120401 , [Content] ='EXEMPT'
 WHERE id=194963629


   --row number: 10664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120401 , [Content] ='NO'
 WHERE id=194963630


   --row number: 10665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120401 , [Content] ='2 - Professionals'
 WHERE id=194963631


   --row number: 10666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120401 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963632


   --row number: 10667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120401 , [Content] ='Technical'
 WHERE id=194963633


   --row number: 10668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120401 , [Content] ='7/20/18'
 WHERE id=194963634


   --row number: 10669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120403 , [Content] ='5143 US - MRKT 2'
 WHERE id=194963710


   --row number: 10670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120403 , [Content] ='US - MRKT 2'
 WHERE id=194963711


   --row number: 10671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120403 , [Content] ='AMS'
 WHERE id=194963712


   --row number: 10672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120403 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194963713


   --row number: 10673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120403 , [Content] ='Engineering'
 WHERE id=194963714


   --row number: 10674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120403 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=194963715


   --row number: 10675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120403 , [Content] ='Software'
 WHERE id=194963716


   --row number: 10676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120403 , [Content] ='IC3'
 WHERE id=194963717


   --row number: 10677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120403 , [Content] ='USD'
 WHERE id=194963719


   --row number: 10678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120403 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=194963720


   --row number: 10679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120403 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=194963721


   --row number: 10680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120403 , [Content] ='15%'
 WHERE id=194963722


   --row number: 10681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120403 , [Content] ='Yes'
 WHERE id=194963723


   --row number: 10682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120403 , [Content] ='EXEMPT'
 WHERE id=194963724


   --row number: 10683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120403 , [Content] ='NO'
 WHERE id=194963725


   --row number: 10684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120403 , [Content] ='2 - Professionals'
 WHERE id=194963726


   --row number: 10685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120403 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194963727


   --row number: 10686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120403 , [Content] ='Technical'
 WHERE id=194963728


   --row number: 10687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120403 , [Content] ='7/20/18'
 WHERE id=194963729


   --row number: 10688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3120406 , [Content] ='NO'
 WHERE id=194964060


   --row number: 10689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3120406 , [Content] ='2 - Professionals'
 WHERE id=194964061


   --row number: 10690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3120406 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=194964062


   --row number: 10691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3120406 , [Content] ='Technical'
 WHERE id=194964063


   --row number: 10692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120406 , [Content] ='10/05/18'
 WHERE id=194964064


   --row number: 10693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120406 , [Content] ='EXEMPT'
 WHERE id=194964059


   --row number: 10694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120406 , [Content] ='Yes'
 WHERE id=194964058


   --row number: 10695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3120406 , [Content] ='20%'
 WHERE id=194964057


   --row number: 10696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3120406 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=194964056


   --row number: 10697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3120406 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=194964055


   --row number: 10698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120406 , [Content] ='USD'
 WHERE id=194964054


   --row number: 10699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3120406 , [Content] ='IC4'
 WHERE id=194964052


   --row number: 10700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3120406 , [Content] ='Software'
 WHERE id=194964051


   --row number: 10701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120406 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=194964050


   --row number: 10702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3120406 , [Content] ='Engineering'
 WHERE id=194964049


   --row number: 10703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120406 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194964048


   --row number: 10704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120406 , [Content] ='AMS'
 WHERE id=194964047


   --row number: 10705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120406 , [Content] ='US - MRKT 1'
 WHERE id=194964046


   --row number: 10706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120406 , [Content] ='5144 US - MRKT 1'
 WHERE id=194964045


   --row number: 10707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120435 , [Content] ='9999 US - MRKT 1'
 WHERE id=194966555


   --row number: 10708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120435 , [Content] ='US - MRKT 1'
 WHERE id=194966556


   --row number: 10709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120435 , [Content] ='AMS'
 WHERE id=194966557


   --row number: 10710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120435 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194966558


   --row number: 10711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120435 , [Content] ='9999 - Intern'
 WHERE id=194966559


   --row number: 10712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120435 , [Content] ='USD'
 WHERE id=194966560


   --row number: 10713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120435 , [Content] ='No'
 WHERE id=194966561


   --row number: 10714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120435 , [Content] ='NON-EXEMPT'
 WHERE id=194966562


   --row number: 10715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120435 , [Content] ='7/20/18'
 WHERE id=194966563


   --row number: 10716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3120791 , [Content] ='9999 US - MRKT 1'
 WHERE id=194995208


   --row number: 10717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3120791 , [Content] ='US - MRKT 1'
 WHERE id=194995209


   --row number: 10718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3120791 , [Content] ='AMS'
 WHERE id=194995210


   --row number: 10719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3120791 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=194995211


   --row number: 10720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3120791 , [Content] ='9999 - Intern'
 WHERE id=194995212


   --row number: 10721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3120791 , [Content] ='USD'
 WHERE id=194995213


   --row number: 10722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3120791 , [Content] ='No'
 WHERE id=194995214


   --row number: 10723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3120791 , [Content] ='NON-EXEMPT'
 WHERE id=194995215


   --row number: 10724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3120791 , [Content] ='7/20/18'
 WHERE id=194995216


   --row number: 10725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121099 , [Content] ='5312 US - MRKT 1'
 WHERE id=195017984


   --row number: 10726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121099 , [Content] ='US - MRKT 1'
 WHERE id=195017985


   --row number: 10727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121099 , [Content] ='7/20/18'
 WHERE id=195018003


   --row number: 10728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121099 , [Content] ='AMS'
 WHERE id=195017986


   --row number: 10729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121099 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195017987


   --row number: 10730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121099 , [Content] ='Engineering Operations'
 WHERE id=195017988


   --row number: 10731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121099 , [Content] ='5312 - Technical Writer IC2'
 WHERE id=195017989


   --row number: 10732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121099 , [Content] ='Technical Writer'
 WHERE id=195017990


   --row number: 10733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121099 , [Content] ='IC2'
 WHERE id=195017991


   --row number: 10734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121099 , [Content] ='USD'
 WHERE id=195017993


   --row number: 10735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121099 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195018001


   --row number: 10736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121099 , [Content] ='Technical'
 WHERE id=195018002


   --row number: 10737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121099 , [Content] ='74,300 / 84,900 / 95,500 / 106,100 / 116,700'
 WHERE id=195017994


   --row number: 10738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3121099 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=195017995


   --row number: 10739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121099 , [Content] ='10%'
 WHERE id=195017996


   --row number: 10740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121099 , [Content] ='Yes'
 WHERE id=195017997


   --row number: 10741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3121099 , [Content] ='EXEMPT'
 WHERE id=195017998


   --row number: 10742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3121099 , [Content] ='NO'
 WHERE id=195017999


   --row number: 10743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121099 , [Content] ='2 - Professionals'
 WHERE id=195018000


   --row number: 10744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121101 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195018156


   --row number: 10745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121101 , [Content] ='Technical'
 WHERE id=195018157


   --row number: 10746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121101 , [Content] ='7/20/18'
 WHERE id=195018158


   --row number: 10747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121101 , [Content] ='USD'
 WHERE id=195018148


   --row number: 10748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121101 , [Content] ='5313 US - MRKT 2'
 WHERE id=195018139


   --row number: 10749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121101 , [Content] ='US - MRKT 2'
 WHERE id=195018140


   --row number: 10750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121101 , [Content] ='AMS'
 WHERE id=195018141


   --row number: 10751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121101 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195018142


   --row number: 10752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121101 , [Content] ='Engineering Operations'
 WHERE id=195018143


   --row number: 10753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121101 , [Content] ='5313 - Technical Writer IC3'
 WHERE id=195018144


   --row number: 10754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121101 , [Content] ='Technical Writer'
 WHERE id=195018145


   --row number: 10755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121101 , [Content] ='IC3'
 WHERE id=195018146


   --row number: 10756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121101 , [Content] ='67,700 / 78,850 / 90,000 / 101,200 / 112,400'
 WHERE id=195018149


   --row number: 10757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3121101 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=195018150


   --row number: 10758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121101 , [Content] ='10%'
 WHERE id=195018151


   --row number: 10759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121101 , [Content] ='Yes'
 WHERE id=195018152


   --row number: 10760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3121101 , [Content] ='EXEMPT'
 WHERE id=195018153


   --row number: 10761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3121101 , [Content] ='NO'
 WHERE id=195018154


   --row number: 10762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121101 , [Content] ='2 - Professionals'
 WHERE id=195018155


   --row number: 10763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121106 , [Content] ='2 - Professionals'
 WHERE id=195018580


   --row number: 10764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121106 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195018581


   --row number: 10765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121106 , [Content] ='Technical'
 WHERE id=195018582


   --row number: 10766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121106 , [Content] ='7/20/18'
 WHERE id=195018583


   --row number: 10767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121106 , [Content] ='5141 US - MRKT 1'
 WHERE id=195018564


   --row number: 10768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121106 , [Content] ='US - MRKT 1'
 WHERE id=195018565


   --row number: 10769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121106 , [Content] ='AMS'
 WHERE id=195018566


   --row number: 10770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121106 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195018567


   --row number: 10771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121106 , [Content] ='Engineering'
 WHERE id=195018568


   --row number: 10772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121106 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=195018569


   --row number: 10773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121106 , [Content] ='Software'
 WHERE id=195018570


   --row number: 10774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121106 , [Content] ='IC1'
 WHERE id=195018571


   --row number: 10775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121106 , [Content] ='USD'
 WHERE id=195018573


   --row number: 10776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121106 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=195018574


   --row number: 10777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3121106 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=195018575


   --row number: 10778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121106 , [Content] ='10%'
 WHERE id=195018576


   --row number: 10779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121106 , [Content] ='Yes'
 WHERE id=195018577


   --row number: 10780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3121106 , [Content] ='EXEMPT'
 WHERE id=195018578


   --row number: 10781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3121106 , [Content] ='NO'
 WHERE id=195018579


   --row number: 10782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121114 , [Content] ='9999 US - MRKT 1'
 WHERE id=195019230


   --row number: 10783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121114 , [Content] ='US - MRKT 1'
 WHERE id=195019231


   --row number: 10784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121114 , [Content] ='AMS'
 WHERE id=195019232


   --row number: 10785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121114 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195019233


   --row number: 10786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121114 , [Content] ='9999 - Intern'
 WHERE id=195019234


   --row number: 10787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121114 , [Content] ='USD'
 WHERE id=195019235


   --row number: 10788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121114 , [Content] ='No'
 WHERE id=195019236


   --row number: 10789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3121114 , [Content] ='NON-EXEMPT'
 WHERE id=195019237


   --row number: 10790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121114 , [Content] ='7/20/18'
 WHERE id=195019238


   --row number: 10791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121368 , [Content] ='6552 IND'
 WHERE id=195051684


   --row number: 10792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121368 , [Content] ='IND'
 WHERE id=195051685


   --row number: 10793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121368 , [Content] ='APAC'
 WHERE id=195051686


   --row number: 10794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121368 , [Content] ='INDIA'
 WHERE id=195051687


   --row number: 10795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121368 , [Content] ='Info Systems/Technology'
 WHERE id=195051688


   --row number: 10796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121368 , [Content] ='6552 - Enterprisewide Apps/Sys Developer IC2'
 WHERE id=195051689


   --row number: 10797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121368 , [Content] ='Enterprise Apps/Systems'
 WHERE id=195051690


   --row number: 10798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121368 , [Content] ='IC2'
 WHERE id=195051691


   --row number: 10799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121368 , [Content] ='INR'
 WHERE id=195051693


   --row number: 10800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121368 , [Content] ='675,900 / 827,950 / 980,000 / 1,132,100 / 1,284,200'
 WHERE id=195051694


   --row number: 10801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121368 , [Content] ='10%'
 WHERE id=195051695


   --row number: 10802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121368 , [Content] ='No'
 WHERE id=195051696


   --row number: 10803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121368 , [Content] ='2 - Professionals'
 WHERE id=195051697


   --row number: 10804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121368 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195051698


   --row number: 10805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121368 , [Content] ='Technical'
 WHERE id=195051699


   --row number: 10806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121368 , [Content] ='7/20/18'
 WHERE id=195051700


   --row number: 10807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121719 , [Content] ='9999 SGP'
 WHERE id=195176334


   --row number: 10808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121719 , [Content] ='SGP'
 WHERE id=195176335


   --row number: 10809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121719 , [Content] ='APAC'
 WHERE id=195176336


   --row number: 10810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121719 , [Content] ='Singapore'
 WHERE id=195176337


   --row number: 10811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121719 , [Content] ='9999 - Intern'
 WHERE id=195176339


   --row number: 10812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121719 , [Content] ='SGD'
 WHERE id=195176343


   --row number: 10813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121719 , [Content] ='No'
 WHERE id=195176347


   --row number: 10814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121719 , [Content] ='09/05/18'
 WHERE id=195176351


   --row number: 10815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121757 , [Content] ='S1415 SGP'
 WHERE id=195187609


   --row number: 10816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121811 , [Content] ='2314 IND'
 WHERE id=195205110


   --row number: 10817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121811 , [Content] ='IND'
 WHERE id=195205111


   --row number: 10818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121811 , [Content] ='APAC'
 WHERE id=195205112


   --row number: 10819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121811 , [Content] ='INDIA'
 WHERE id=195205113


   --row number: 10820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121811 , [Content] ='Engineering Operations'
 WHERE id=195205114


   --row number: 10821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121811 , [Content] ='2314 - Sr Mgr, Technical Writing Mgmt M4'
 WHERE id=195205115


   --row number: 10822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121811 , [Content] ='Technical Writer'
 WHERE id=195205116


   --row number: 10823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121811 , [Content] ='M4'
 WHERE id=195205117


   --row number: 10824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121811 , [Content] ='INR'
 WHERE id=195205119


   --row number: 10825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121811 , [Content] ='2,069,000 / 2,534,500 / 3,000,000 / 3,465,550 / 3,931,100'
 WHERE id=195205120


   --row number: 10826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3121811 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=195205121


   --row number: 10827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121811 , [Content] ='25%'
 WHERE id=195205122


   --row number: 10828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121811 , [Content] ='Yes'
 WHERE id=195205123


   --row number: 10829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121811 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=195205124


   --row number: 10830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121811 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195205125


   --row number: 10831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121811 , [Content] ='Technical'
 WHERE id=195205126


   --row number: 10832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121811 , [Content] ='7/20/18'
 WHERE id=195205127


   --row number: 10833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121757 , [Content] ='SGP'
 WHERE id=195187610


   --row number: 10834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121757 , [Content] ='APAC'
 WHERE id=195187611


   --row number: 10835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121757 , [Content] ='SINGAPORE'
 WHERE id=195187612


   --row number: 10836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121757 , [Content] ='Solution Consulting'
 WHERE id=195187613


   --row number: 10837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121757 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=195187614


   --row number: 10838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121757 , [Content] ='Solution Consultant Core'
 WHERE id=195187615


   --row number: 10839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121757 , [Content] ='IC5'
 WHERE id=195187616


   --row number: 10840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3121757 , [Content] ='800 / 1,600 / 2,400'
 WHERE id=195187618


   --row number: 10841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3121757 , [Content] ='75/25'
 WHERE id=195187619


   --row number: 10842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121757 , [Content] ='Yes'
 WHERE id=195187620


   --row number: 10843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121757 , [Content] ='4 - Sales Workers'
 WHERE id=195187621


   --row number: 10844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121757 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195187622


   --row number: 10845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121757 , [Content] ='Technical'
 WHERE id=195187623


   --row number: 10846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121821 , [Content] ='Technical'
 WHERE id=195206884


   --row number: 10847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121821 , [Content] ='04/05/18'
 WHERE id=195206885


   --row number: 10848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121821 , [Content] ='5143 IND'
 WHERE id=195206868


   --row number: 10849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121821 , [Content] ='IND'
 WHERE id=195206869


   --row number: 10850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121821 , [Content] ='APAC'
 WHERE id=195206870


   --row number: 10851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121821 , [Content] ='INDIA'
 WHERE id=195206871


   --row number: 10852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121821 , [Content] ='Engineering'
 WHERE id=195206872


   --row number: 10853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121821 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=195206873


   --row number: 10854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121821 , [Content] ='Software'
 WHERE id=195206874


   --row number: 10855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121821 , [Content] ='IC3'
 WHERE id=195206875


   --row number: 10856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121821 , [Content] ='INR'
 WHERE id=195206877


   --row number: 10857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121821 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=195206878


   --row number: 10858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3121821 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=195206879


   --row number: 10859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121821 , [Content] ='15%'
 WHERE id=195206880


   --row number: 10860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121821 , [Content] ='Yes'
 WHERE id=195206881


   --row number: 10861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121821 , [Content] ='2 - Professionals'
 WHERE id=195206882


   --row number: 10862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121821 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195206883


   --row number: 10863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3121822 , [Content] ='10/24/2018'
 WHERE id=195207003


   --row number: 10864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3121822 , [Content] ='5142 IND'
 WHERE id=195206986


   --row number: 10865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3121822 , [Content] ='IND'
 WHERE id=195206987


   --row number: 10866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3121822 , [Content] ='APAC'
 WHERE id=195206988


   --row number: 10867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3121822 , [Content] ='INDIA'
 WHERE id=195206989


   --row number: 10868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3121822 , [Content] ='Engineering'
 WHERE id=195206990


   --row number: 10869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3121822 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=195206991


   --row number: 10870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3121822 , [Content] ='Software'
 WHERE id=195206992


   --row number: 10871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3121822 , [Content] ='IC2'
 WHERE id=195206993


   --row number: 10872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3121822 , [Content] ='INR'
 WHERE id=195206995


   --row number: 10873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3121822 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=195206996


   --row number: 10874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3121822 , [Content] ='10%'
 WHERE id=195206998


   --row number: 10875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3121822 , [Content] ='No'
 WHERE id=195206999


   --row number: 10876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3121822 , [Content] ='2 - Professionals'
 WHERE id=195207000


   --row number: 10877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3121822 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195207001


   --row number: 10878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3121822 , [Content] ='Technical'
 WHERE id=195207002


   --row number: 10879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3122217 , [Content] ='6001 US - MRKT 1'
 WHERE id=195252226


   --row number: 10880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3122217 , [Content] ='US - MRKT 1'
 WHERE id=195252227


   --row number: 10881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3122217 , [Content] ='AMS'
 WHERE id=195252228


   --row number: 10882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3122217 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195252229


   --row number: 10883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3122217 , [Content] ='Finance'
 WHERE id=195252230


   --row number: 10884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3122217 , [Content] ='6001 - FP&A Analyst IC1'
 WHERE id=195252231


   --row number: 10885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3122217 , [Content] ='FP&A'
 WHERE id=195252232


   --row number: 10886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3122217 , [Content] ='IC1'
 WHERE id=195252233


   --row number: 10887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3122217 , [Content] ='USD'
 WHERE id=195252235


   --row number: 10888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3122217 , [Content] ='56,600 / 64,300 / 72,000 / 79,650 / 87,300'
 WHERE id=195252236


   --row number: 10889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3122217 , [Content] ='10%'
 WHERE id=195252237


   --row number: 10890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3122217 , [Content] ='No'
 WHERE id=195252238


   --row number: 10891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3122217 , [Content] ='NON-EXEMPT'
 WHERE id=195252239


   --row number: 10892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3122217 , [Content] ='NO'
 WHERE id=195252240


   --row number: 10893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3122217 , [Content] ='2 - Professionals'
 WHERE id=195252241


   --row number: 10894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3122217 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195252242


   --row number: 10895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3122217 , [Content] ='Non Technical'
 WHERE id=195252243


   --row number: 10896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3122217 , [Content] ='7/20/18'
 WHERE id=195252245


   --row number: 10897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3122980 , [Content] ='6001 US - MRKT 1'
 WHERE id=195316859


   --row number: 10898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3122980 , [Content] ='US - MRKT 1'
 WHERE id=195316860


   --row number: 10899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3122980 , [Content] ='AMS'
 WHERE id=195316861


   --row number: 10900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3122980 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195316862


   --row number: 10901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3122980 , [Content] ='Finance'
 WHERE id=195316863


   --row number: 10902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3122980 , [Content] ='6001 - FP&A Analyst IC1'
 WHERE id=195316864


   --row number: 10903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3122980 , [Content] ='FP&A'
 WHERE id=195316865


   --row number: 10904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3122980 , [Content] ='IC1'
 WHERE id=195316866


   --row number: 10905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3122980 , [Content] ='USD'
 WHERE id=195316868


   --row number: 10906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3122980 , [Content] ='56,600 / 64,300 / 72,000 / 79,650 / 87,300'
 WHERE id=195316869


   --row number: 10907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3122980 , [Content] ='10%'
 WHERE id=195316870


   --row number: 10908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3122980 , [Content] ='No'
 WHERE id=195316871


   --row number: 10909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3122980 , [Content] ='NON-EXEMPT'
 WHERE id=195316872


   --row number: 10910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3122980 , [Content] ='NO'
 WHERE id=195316873


   --row number: 10911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3122980 , [Content] ='2 - Professionals'
 WHERE id=195316874


   --row number: 10912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3122980 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195316875


   --row number: 10913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3122980 , [Content] ='Non Technical'
 WHERE id=195316876


   --row number: 10914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3122980 , [Content] ='7/20/18'
 WHERE id=195316878


   --row number: 10915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3123239 , [Content] ='NO'
 WHERE id=195339619


   --row number: 10916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123239 , [Content] ='4 - Sales Workers'
 WHERE id=195339620


   --row number: 10917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123239 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195339621


   --row number: 10918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123239 , [Content] ='Technical'
 WHERE id=195339622


   --row number: 10919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123239 , [Content] ='7/20/18'
 WHERE id=195339623


   --row number: 10920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123239 , [Content] ='S635 US - MRKT 2'
 WHERE id=195339603


   --row number: 10921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123239 , [Content] ='US - MRKT 2'
 WHERE id=195339604


   --row number: 10922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123239 , [Content] ='AMS'
 WHERE id=195339605


   --row number: 10923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123239 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195339606


   --row number: 10924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123239 , [Content] ='Sales'
 WHERE id=195339607


   --row number: 10925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123239 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=195339608


   --row number: 10926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123239 , [Content] ='Enterprise Accounts'
 WHERE id=195339609


   --row number: 10927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123239 , [Content] ='IC5'
 WHERE id=195339610


   --row number: 10928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123239 , [Content] ='USD'
 WHERE id=195339612


   --row number: 10929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123239 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=195339613


   --row number: 10930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123239 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=195339614


   --row number: 10931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3123239 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=195339615


   --row number: 10932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3123239 , [Content] ='50/50'
 WHERE id=195339616


   --row number: 10933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123239 , [Content] ='Yes'
 WHERE id=195339617


   --row number: 10934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3123239 , [Content] ='EXEMPT'
 WHERE id=195339618


   --row number: 10935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123349 , [Content] ='2 - Professionals'
 WHERE id=195349698


   --row number: 10936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123349 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195349699


   --row number: 10937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123349 , [Content] ='Non Technical'
 WHERE id=195349700


   --row number: 10938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123349 , [Content] ='7/20/18'
 WHERE id=195349701


   --row number: 10939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123349 , [Content] ='6002 US - MRKT 1'
 WHERE id=195349682


   --row number: 10940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123349 , [Content] ='US - MRKT 1'
 WHERE id=195349683


   --row number: 10941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123349 , [Content] ='AMS'
 WHERE id=195349684


   --row number: 10942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123349 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195349685


   --row number: 10943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123349 , [Content] ='Finance'
 WHERE id=195349686


   --row number: 10944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123349 , [Content] ='6002 - FP&A Analyst IC2'
 WHERE id=195349687


   --row number: 10945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123349 , [Content] ='FP&A'
 WHERE id=195349688


   --row number: 10946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123349 , [Content] ='IC2'
 WHERE id=195349689


   --row number: 10947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123349 , [Content] ='USD'
 WHERE id=195349691


   --row number: 10948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123349 , [Content] ='69,900 / 79,850 / 89,800 / 99,750 / 109,700'
 WHERE id=195349692


   --row number: 10949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123349 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=195349693


   --row number: 10950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3123349 , [Content] ='10%'
 WHERE id=195349694


   --row number: 10951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123349 , [Content] ='Yes'
 WHERE id=195349695


   --row number: 10952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3123349 , [Content] ='EXEMPT'
 WHERE id=195349696


   --row number: 10953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3123349 , [Content] ='NO'
 WHERE id=195349697


   --row number: 10954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123368 , [Content] ='2 - Professionals'
 WHERE id=195351147


   --row number: 10955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123368 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195351148


   --row number: 10956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123368 , [Content] ='Technical'
 WHERE id=195351149


   --row number: 10957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123368 , [Content] ='09/05/18'
 WHERE id=195351150


   --row number: 10958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123368 , [Content] ='5142 US - MRKT 2'
 WHERE id=195351131


   --row number: 10959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123368 , [Content] ='US - MRKT 2'
 WHERE id=195351132


   --row number: 10960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123368 , [Content] ='AMS'
 WHERE id=195351133


   --row number: 10961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123368 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195351134


   --row number: 10962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123368 , [Content] ='Engineering'
 WHERE id=195351135


   --row number: 10963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123368 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=195351136


   --row number: 10964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123368 , [Content] ='Software'
 WHERE id=195351137


   --row number: 10965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123368 , [Content] ='IC2'
 WHERE id=195351138


   --row number: 10966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123368 , [Content] ='USD'
 WHERE id=195351140


   --row number: 10967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123368 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=195351141


   --row number: 10968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123368 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=195351142


   --row number: 10969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3123368 , [Content] ='10%'
 WHERE id=195351143


   --row number: 10970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123368 , [Content] ='Yes'
 WHERE id=195351144


   --row number: 10971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3123368 , [Content] ='EXEMPT'
 WHERE id=195351145


   --row number: 10972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3123368 , [Content] ='NO'
 WHERE id=195351146


   --row number: 10973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123566 , [Content] ='USD'
 WHERE id=195370148


   --row number: 10974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123566 , [Content] ='81,855 / 89,078 / 96,300 / 103,523 / 110,745'
 WHERE id=195370149


   --row number: 10975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123566 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=195370150


   --row number: 10976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3123566 , [Content] ='136,425 / 148,463 / 160,500 / 172,538 / 184,575'
 WHERE id=195370151


   --row number: 10977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3123566 , [Content] ='60/40'
 WHERE id=195370152


   --row number: 10978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123566 , [Content] ='Yes'
 WHERE id=195370153


   --row number: 10979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3123566 , [Content] ='EXEMPT'
 WHERE id=195370154


   --row number: 10980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3123566 , [Content] ='NO'
 WHERE id=195370155


   --row number: 10981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123566 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=195370156


   --row number: 10982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123566 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195370157


   --row number: 10983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123566 , [Content] ='Non Technical'
 WHERE id=195370158


   --row number: 10984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123566 , [Content] ='7/20/18'
 WHERE id=195370159


   --row number: 10985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123566 , [Content] ='S1203 US - MRKT 2'
 WHERE id=195370139


   --row number: 10986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123566 , [Content] ='US - MRKT 2'
 WHERE id=195370140


   --row number: 10987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123566 , [Content] ='AMS'
 WHERE id=195370141


   --row number: 10988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123566 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195370142


   --row number: 10989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123566 , [Content] ='Sales'
 WHERE id=195370143


   --row number: 10990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123566 , [Content] ='S1203 - Mgr, Inside Sales M3'
 WHERE id=195370144


   --row number: 10991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123566 , [Content] ='Inside Sales'
 WHERE id=195370145


   --row number: 10992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123566 , [Content] ='M3'
 WHERE id=195370146


   --row number: 10993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3123576 , [Content] ='EXEMPT'
 WHERE id=195371979


   --row number: 10994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123576 , [Content] ='S713 US - MRKT 1'
 WHERE id=195371964


   --row number: 10995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123576 , [Content] ='US - MRKT 1'
 WHERE id=195371965


   --row number: 10996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123576 , [Content] ='AMS'
 WHERE id=195371966


   --row number: 10997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123576 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195371967


   --row number: 10998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123576 , [Content] ='Sales - MSP'
 WHERE id=195371968


   --row number: 10999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123576 , [Content] ='S713 - Enterprise Account Exec - MSP IC3'
 WHERE id=195371969


   --row number: 11000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123576 , [Content] ='Enterprise Accounts - MSP'
 WHERE id=195371970


   --row number: 11001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123576 , [Content] ='IC3'
 WHERE id=195371971


   --row number: 11002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123576 , [Content] ='USD'
 WHERE id=195371973


   --row number: 11003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123576 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=195371974


   --row number: 11004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123576 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=195371975


   --row number: 11005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3123576 , [Content] ='212,500 / 231,250 / 250,000 / 268,750 / 287,500'
 WHERE id=195371976


   --row number: 11006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3123576 , [Content] ='60/40'
 WHERE id=195371977


   --row number: 11007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123576 , [Content] ='Yes'
 WHERE id=195371978


   --row number: 11008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3123576 , [Content] ='NO'
 WHERE id=195371980


   --row number: 11009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123576 , [Content] ='4 - Sales Workers'
 WHERE id=195371981


   --row number: 11010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123576 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195371982


   --row number: 11011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123576 , [Content] ='Technical'
 WHERE id=195371983


   --row number: 11012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123576 , [Content] ='7/20/18'
 WHERE id=195371984


   --row number: 11013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123938 , [Content] ='INR'
 WHERE id=195428310


   --row number: 11014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123938 , [Content] ='Technical'
 WHERE id=195428317


   --row number: 11015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123938 , [Content] ='7/20/18'
 WHERE id=195428318


   --row number: 11016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123938 , [Content] ='1,851,700 / 2,268,350 / 2,685,000 / 3,101,600 / 3,518,200'
 WHERE id=195428311


   --row number: 11017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123938 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=195428312


   --row number: 11018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3123938 , [Content] ='20%'
 WHERE id=195428313


   --row number: 11019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123938 , [Content] ='Yes'
 WHERE id=195428314


   --row number: 11020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123938 , [Content] ='2 - Professionals'
 WHERE id=195428315


   --row number: 11021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123938 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195428316


   --row number: 11022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123938 , [Content] ='5184 IND'
 WHERE id=195428301


   --row number: 11023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123938 , [Content] ='IND'
 WHERE id=195428302


   --row number: 11024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123938 , [Content] ='APAC'
 WHERE id=195428303


   --row number: 11025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123938 , [Content] ='INDIA'
 WHERE id=195428304


   --row number: 11026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123938 , [Content] ='Engineering'
 WHERE id=195428305


   --row number: 11027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123938 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=195428306


   --row number: 11028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123938 , [Content] ='Quality'
 WHERE id=195428307


   --row number: 11029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123938 , [Content] ='IC4'
 WHERE id=195428308


   --row number: 11030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123987 , [Content] ='7/20/18'
 WHERE id=195432889


   --row number: 11031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123987 , [Content] ='5142 IND'
 WHERE id=195432873


   --row number: 11032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123987 , [Content] ='IND'
 WHERE id=195432874


   --row number: 11033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123987 , [Content] ='APAC'
 WHERE id=195432875


   --row number: 11034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123987 , [Content] ='INDIA'
 WHERE id=195432876


   --row number: 11035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123987 , [Content] ='Engineering'
 WHERE id=195432877


   --row number: 11036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123987 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=195432878


   --row number: 11037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123987 , [Content] ='Software'
 WHERE id=195432879


   --row number: 11038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123987 , [Content] ='IC2'
 WHERE id=195432880


   --row number: 11039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123987 , [Content] ='INR'
 WHERE id=195432882


   --row number: 11040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123987 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=195432883


   --row number: 11041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3123987 , [Content] ='10%'
 WHERE id=195432884


   --row number: 11042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123987 , [Content] ='No'
 WHERE id=195432885


   --row number: 11043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123987 , [Content] ='2 - Professionals'
 WHERE id=195432886


   --row number: 11044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123987 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195432887


   --row number: 11045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123987 , [Content] ='Technical'
 WHERE id=195432888


   --row number: 11046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3123992 , [Content] ='7/20/18'
 WHERE id=195433322


   --row number: 11047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3123992 , [Content] ='5144 IND'
 WHERE id=195433306


   --row number: 11048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3123992 , [Content] ='IND'
 WHERE id=195433307


   --row number: 11049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3123992 , [Content] ='APAC'
 WHERE id=195433308


   --row number: 11050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3123992 , [Content] ='INDIA'
 WHERE id=195433309


   --row number: 11051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3123992 , [Content] ='Engineering'
 WHERE id=195433310


   --row number: 11052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3123992 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=195433311


   --row number: 11053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3123992 , [Content] ='Software'
 WHERE id=195433312


   --row number: 11054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3123992 , [Content] ='IC4'
 WHERE id=195433313


   --row number: 11055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3123992 , [Content] ='INR'
 WHERE id=195433315


   --row number: 11056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3123992 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=195433316


   --row number: 11057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3123992 , [Content] ='20%'
 WHERE id=195433317


   --row number: 11058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3123992 , [Content] ='Yes'
 WHERE id=195433318


   --row number: 11059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3123992 , [Content] ='2 - Professionals'
 WHERE id=195433319


   --row number: 11060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3123992 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195433320


   --row number: 11061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3123992 , [Content] ='Technical'
 WHERE id=195433321


   --row number: 11062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3124000 , [Content] ='7/20/18'
 WHERE id=195434046


   --row number: 11063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3124000 , [Content] ='5182 IND'
 WHERE id=195434030


   --row number: 11064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3124000 , [Content] ='IND'
 WHERE id=195434031


   --row number: 11065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3124000 , [Content] ='APAC'
 WHERE id=195434032


   --row number: 11066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3124000 , [Content] ='INDIA'
 WHERE id=195434033


   --row number: 11067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3124000 , [Content] ='Engineering'
 WHERE id=195434034


   --row number: 11068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3124000 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=195434035


   --row number: 11069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3124000 , [Content] ='Quality'
 WHERE id=195434036


   --row number: 11070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3124000 , [Content] ='IC2'
 WHERE id=195434037


   --row number: 11071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3124000 , [Content] ='INR'
 WHERE id=195434039


   --row number: 11072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3124000 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=195434040


   --row number: 11073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3124000 , [Content] ='10%'
 WHERE id=195434041


   --row number: 11074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3124000 , [Content] ='No'
 WHERE id=195434042


   --row number: 11075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3124000 , [Content] ='2 - Professionals'
 WHERE id=195434043


   --row number: 11076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3124000 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195434044


   --row number: 11077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3124000 , [Content] ='Technical'
 WHERE id=195434045


   --row number: 11078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3124018 , [Content] ='Technical'
 WHERE id=195435934


   --row number: 11079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3124018 , [Content] ='7/20/18'
 WHERE id=195435935


   --row number: 11080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3124018 , [Content] ='5143 IND'
 WHERE id=195435918


   --row number: 11081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3124018 , [Content] ='IND'
 WHERE id=195435919


   --row number: 11082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3124018 , [Content] ='APAC'
 WHERE id=195435920


   --row number: 11083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3124018 , [Content] ='INDIA'
 WHERE id=195435921


   --row number: 11084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3124018 , [Content] ='Engineering'
 WHERE id=195435922


   --row number: 11085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3124018 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=195435923


   --row number: 11086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3124018 , [Content] ='Software'
 WHERE id=195435924


   --row number: 11087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3124018 , [Content] ='IC3'
 WHERE id=195435925


   --row number: 11088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3124018 , [Content] ='INR'
 WHERE id=195435927


   --row number: 11089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3124018 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=195435928


   --row number: 11090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3124018 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=195435929


   --row number: 11091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3124018 , [Content] ='15%'
 WHERE id=195435930


   --row number: 11092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3124018 , [Content] ='Yes'
 WHERE id=195435931


   --row number: 11093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3124018 , [Content] ='2 - Professionals'
 WHERE id=195435932


   --row number: 11094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3124018 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195435933


   --row number: 11095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3124021 , [Content] ='Technical'
 WHERE id=195436274


   --row number: 11096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3124021 , [Content] ='7/20/18'
 WHERE id=195436275


   --row number: 11097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3124021 , [Content] ='5143 IND'
 WHERE id=195436258


   --row number: 11098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3124021 , [Content] ='IND'
 WHERE id=195436259


   --row number: 11099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3124021 , [Content] ='APAC'
 WHERE id=195436260


   --row number: 11100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3124021 , [Content] ='INDIA'
 WHERE id=195436261


   --row number: 11101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3124021 , [Content] ='Engineering'
 WHERE id=195436262


   --row number: 11102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3124021 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=195436263


   --row number: 11103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3124021 , [Content] ='Software'
 WHERE id=195436264


   --row number: 11104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3124021 , [Content] ='IC3'
 WHERE id=195436265


   --row number: 11105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3124021 , [Content] ='INR'
 WHERE id=195436267


   --row number: 11106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3124021 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=195436268


   --row number: 11107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3124021 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=195436269


   --row number: 11108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3124021 , [Content] ='15%'
 WHERE id=195436270


   --row number: 11109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3124021 , [Content] ='Yes'
 WHERE id=195436271


   --row number: 11110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3124021 , [Content] ='2 - Professionals'
 WHERE id=195436272


   --row number: 11111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3124021 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195436273


   --row number: 11112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3124640 , [Content] ='2 - Professionals'
 WHERE id=195488012


   --row number: 11113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3124640 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195488013


   --row number: 11114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3124640 , [Content] ='Non Technical'
 WHERE id=195488014


   --row number: 11115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3124640 , [Content] ='7/20/18'
 WHERE id=195488015


   --row number: 11116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3124640 , [Content] ='5674 US - MRKT 1'
 WHERE id=195487996


   --row number: 11117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3124640 , [Content] ='US - MRKT 1'
 WHERE id=195487997


   --row number: 11118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3124640 , [Content] ='AMS'
 WHERE id=195487998


   --row number: 11119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3124640 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195487999


   --row number: 11120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3124640 , [Content] ='Business Strategy'
 WHERE id=195488000


   --row number: 11121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3124640 , [Content] ='5674 - Business Strategy Mgr IC4'
 WHERE id=195488001


   --row number: 11122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3124640 , [Content] ='Business Strategy'
 WHERE id=195488002


   --row number: 11123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3124640 , [Content] ='IC4'
 WHERE id=195488003


   --row number: 11124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3124640 , [Content] ='USD'
 WHERE id=195488005


   --row number: 11125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3124640 , [Content] ='109,000 / 131,850 / 154,700 / 177,550 / 200,400'
 WHERE id=195488006


   --row number: 11126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3124640 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=195488007


   --row number: 11127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3124640 , [Content] ='20%'
 WHERE id=195488008


   --row number: 11128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3124640 , [Content] ='Yes'
 WHERE id=195488009


   --row number: 11129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3124640 , [Content] ='EXEMPT'
 WHERE id=195488010


   --row number: 11130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3124640 , [Content] ='NO'
 WHERE id=195488011


   --row number: 11131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125248 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195543325


   --row number: 11132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125248 , [Content] ='Technical'
 WHERE id=195543326


   --row number: 11133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125248 , [Content] ='10/05/18'
 WHERE id=195543327


   --row number: 11134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125248 , [Content] ='5875 US - MRKT 1'
 WHERE id=195543308


   --row number: 11135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125248 , [Content] ='US - MRKT 1'
 WHERE id=195543309


   --row number: 11136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125248 , [Content] ='AMS'
 WHERE id=195543310


   --row number: 11137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125248 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195543311


   --row number: 11138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125248 , [Content] ='Professional Services'
 WHERE id=195543312


   --row number: 11139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125248 , [Content] ='5875 - Engagement Mgr IC5'
 WHERE id=195543313


   --row number: 11140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125248 , [Content] ='Engagement Mgrs'
 WHERE id=195543314


   --row number: 11141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125248 , [Content] ='IC5'
 WHERE id=195543315


   --row number: 11142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125248 , [Content] ='USD'
 WHERE id=195543317


   --row number: 11143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125248 , [Content] ='110,900 / 135,850 / 160,800 / 185,750 / 210,700'
 WHERE id=195543318


   --row number: 11144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125248 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=195543319


   --row number: 11145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125248 , [Content] ='25%'
 WHERE id=195543320


   --row number: 11146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125248 , [Content] ='Yes'
 WHERE id=195543321


   --row number: 11147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125248 , [Content] ='EXEMPT'
 WHERE id=195543322


   --row number: 11148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125248 , [Content] ='NO'
 WHERE id=195543323


   --row number: 11149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125248 , [Content] ='2 - Professionals'
 WHERE id=195543324


   --row number: 11150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125314 , [Content] ='EXEMPT'
 WHERE id=195549752


   --row number: 11151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125314 , [Content] ='NO'
 WHERE id=195549753


   --row number: 11152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125314 , [Content] ='4 - Sales Workers'
 WHERE id=195549754


   --row number: 11153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125314 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195549755


   --row number: 11154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125314 , [Content] ='Technical'
 WHERE id=195549756


   --row number: 11155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125314 , [Content] ='7/20/18'
 WHERE id=195549757


   --row number: 11156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125314 , [Content] ='S1413 US - MRKT 1'
 WHERE id=195549737


   --row number: 11157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125314 , [Content] ='US - MRKT 1'
 WHERE id=195549738


   --row number: 11158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125314 , [Content] ='AMS'
 WHERE id=195549739


   --row number: 11159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125314 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195549740


   --row number: 11160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125314 , [Content] ='Solution Consulting'
 WHERE id=195549741


   --row number: 11161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125314 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=195549742


   --row number: 11162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125314 , [Content] ='Solution Consultant Core'
 WHERE id=195549743


   --row number: 11163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125314 , [Content] ='IC3'
 WHERE id=195549744


   --row number: 11164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125314 , [Content] ='USD'
 WHERE id=195549746


   --row number: 11165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125314 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=195549747


   --row number: 11166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125314 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=195549748


   --row number: 11167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3125314 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=195549749


   --row number: 11168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3125314 , [Content] ='75/25'
 WHERE id=195549750


   --row number: 11169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125314 , [Content] ='Yes'
 WHERE id=195549751


   --row number: 11170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125331 , [Content] ='NO'
 WHERE id=195550884


   --row number: 11171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125331 , [Content] ='4 - Sales Workers'
 WHERE id=195550885


   --row number: 11172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125331 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195550886


   --row number: 11173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125331 , [Content] ='Technical'
 WHERE id=195550887


   --row number: 11174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125331 , [Content] ='7/20/18'
 WHERE id=195550888


   --row number: 11175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125331 , [Content] ='S665 US - MRKT 2'
 WHERE id=195550868


   --row number: 11176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125331 , [Content] ='US - MRKT 2'
 WHERE id=195550869


   --row number: 11177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125331 , [Content] ='AMS'
 WHERE id=195550870


   --row number: 11178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125331 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195550871


   --row number: 11179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125331 , [Content] ='Sales'
 WHERE id=195550872


   --row number: 11180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125331 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=195550873


   --row number: 11181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125331 , [Content] ='Product Line Sales'
 WHERE id=195550874


   --row number: 11182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125331 , [Content] ='IC5'
 WHERE id=195550875


   --row number: 11183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125331 , [Content] ='USD'
 WHERE id=195550877


   --row number: 11184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125331 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=195550878


   --row number: 11185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125331 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=195550879


   --row number: 11186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3125331 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=195550880


   --row number: 11187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3125331 , [Content] ='60/40'
 WHERE id=195550881


   --row number: 11188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125331 , [Content] ='Yes'
 WHERE id=195550882


   --row number: 11189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125331 , [Content] ='EXEMPT'
 WHERE id=195550883


   --row number: 11190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125394 , [Content] ='2 - Professionals'
 WHERE id=195558661


   --row number: 11191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125394 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195558662


   --row number: 11192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125394 , [Content] ='Technical'
 WHERE id=195558663


   --row number: 11193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125394 , [Content] ='7/20/18'
 WHERE id=195558664


   --row number: 11194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125394 , [Content] ='5895 US - MRKT 1'
 WHERE id=195558645


   --row number: 11195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125394 , [Content] ='US - MRKT 1'
 WHERE id=195558646


   --row number: 11196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125394 , [Content] ='AMS'
 WHERE id=195558647


   --row number: 11197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125394 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195558648


   --row number: 11198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125394 , [Content] ='Professional Services'
 WHERE id=195558649


   --row number: 11199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125394 , [Content] ='5895 - Technical Curriculum Developer IC5'
 WHERE id=195558650


   --row number: 11200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125394 , [Content] ='Technical Curriculum'
 WHERE id=195558651


   --row number: 11201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125394 , [Content] ='IC5'
 WHERE id=195558652


   --row number: 11202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125394 , [Content] ='USD'
 WHERE id=195558654


   --row number: 11203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125394 , [Content] ='97,200 / 117,550 / 137,900 / 158,300 / 178,700'
 WHERE id=195558655


   --row number: 11204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125394 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=195558656


   --row number: 11205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125394 , [Content] ='20%'
 WHERE id=195558657


   --row number: 11206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125394 , [Content] ='Yes'
 WHERE id=195558658


   --row number: 11207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125394 , [Content] ='EXEMPT'
 WHERE id=195558659


   --row number: 11208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125394 , [Content] ='NO'
 WHERE id=195558660


   --row number: 11209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125414 , [Content] ='2 - Professionals'
 WHERE id=195560423


   --row number: 11210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125414 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195560424


   --row number: 11211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125414 , [Content] ='Technical'
 WHERE id=195560425


   --row number: 11212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125414 , [Content] ='7/20/18'
 WHERE id=195560426


   --row number: 11213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125414 , [Content] ='5775 US - MRKT 1'
 WHERE id=195560407


   --row number: 11214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125414 , [Content] ='US - MRKT 1'
 WHERE id=195560408


   --row number: 11215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125414 , [Content] ='AMS'
 WHERE id=195560409


   --row number: 11216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125414 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195560410


   --row number: 11217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125414 , [Content] ='Professional Services'
 WHERE id=195560411


   --row number: 11218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125414 , [Content] ='5775 - Business Process Consultant IC5'
 WHERE id=195560412


   --row number: 11219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125414 , [Content] ='Business Process Consulting'
 WHERE id=195560413


   --row number: 11220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125414 , [Content] ='IC5'
 WHERE id=195560414


   --row number: 11221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125414 , [Content] ='USD'
 WHERE id=195560416


   --row number: 11222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125414 , [Content] ='116,600 / 141,050 / 165,500 / 189,900 / 214,300'
 WHERE id=195560417


   --row number: 11223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125414 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=195560418


   --row number: 11224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125414 , [Content] ='20%'
 WHERE id=195560419


   --row number: 11225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125414 , [Content] ='Yes'
 WHERE id=195560420


   --row number: 11226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125414 , [Content] ='EXEMPT'
 WHERE id=195560421


   --row number: 11227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125414 , [Content] ='NO'
 WHERE id=195560422


   --row number: 11228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125424 , [Content] ='2 - Professionals'
 WHERE id=195560956


   --row number: 11229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125424 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195560957


   --row number: 11230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125424 , [Content] ='Technical'
 WHERE id=195560958


   --row number: 11231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125424 , [Content] ='7/20/18'
 WHERE id=195560959


   --row number: 11232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125424 , [Content] ='5875 US - MRKT 1'
 WHERE id=195560940


   --row number: 11233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125424 , [Content] ='US - MRKT 1'
 WHERE id=195560941


   --row number: 11234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125424 , [Content] ='AMS'
 WHERE id=195560942


   --row number: 11235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125424 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195560943


   --row number: 11236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125424 , [Content] ='Professional Services'
 WHERE id=195560944


   --row number: 11237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125424 , [Content] ='5875 - Engagement Mgr IC5'
 WHERE id=195560945


   --row number: 11238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125424 , [Content] ='Engagement Mgrs'
 WHERE id=195560946


   --row number: 11239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125424 , [Content] ='IC5'
 WHERE id=195560947


   --row number: 11240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125424 , [Content] ='USD'
 WHERE id=195560949


   --row number: 11241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125424 , [Content] ='110,900 / 135,850 / 160,800 / 185,750 / 210,700'
 WHERE id=195560950


   --row number: 11242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125424 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=195560951


   --row number: 11243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125424 , [Content] ='25%'
 WHERE id=195560952


   --row number: 11244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125424 , [Content] ='Yes'
 WHERE id=195560953


   --row number: 11245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125424 , [Content] ='EXEMPT'
 WHERE id=195560954


   --row number: 11246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125424 , [Content] ='NO'
 WHERE id=195560955


   --row number: 11247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125477 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195566218


   --row number: 11248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125477 , [Content] ='Technical'
 WHERE id=195566219


   --row number: 11249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125477 , [Content] ='7/20/18'
 WHERE id=195566220


   --row number: 11250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125477 , [Content] ='6624 US - MRKT 1'
 WHERE id=195566201


   --row number: 11251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125477 , [Content] ='US - MRKT 1'
 WHERE id=195566202


   --row number: 11252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125477 , [Content] ='AMS'
 WHERE id=195566203


   --row number: 11253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125477 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195566204


   --row number: 11254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125477 , [Content] ='Info Systems/Technology'
 WHERE id=195566205


   --row number: 11255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125477 , [Content] ='6624 - Project (Information Systems) Mgr IC4'
 WHERE id=195566206


   --row number: 11256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125477 , [Content] ='IT Project/Program Mgrs'
 WHERE id=195566207


   --row number: 11257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125477 , [Content] ='IC4'
 WHERE id=195566208


   --row number: 11258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125477 , [Content] ='USD'
 WHERE id=195566210


   --row number: 11259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125477 , [Content] ='103,200 / 124,800 / 146,400 / 168,050 / 189,700'
 WHERE id=195566211


   --row number: 11260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125477 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=195566212


   --row number: 11261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125477 , [Content] ='20%'
 WHERE id=195566213


   --row number: 11262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125477 , [Content] ='Yes'
 WHERE id=195566214


   --row number: 11263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125477 , [Content] ='EXEMPT'
 WHERE id=195566215


   --row number: 11264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125477 , [Content] ='NO'
 WHERE id=195566216


   --row number: 11265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125477 , [Content] ='2 - Professionals'
 WHERE id=195566217


   --row number: 11266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3125605 , [Content] ='NO'
 WHERE id=195590254


   --row number: 11267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125605 , [Content] ='4 - Sales Workers'
 WHERE id=195590255


   --row number: 11268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125605 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195590256


   --row number: 11269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125605 , [Content] ='Technical'
 WHERE id=195590257


   --row number: 11270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125605 , [Content] ='10/05/18'
 WHERE id=195590258


   --row number: 11271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125605 , [Content] ='S665 US - MRKT 2'
 WHERE id=195590238


   --row number: 11272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125605 , [Content] ='US - MRKT 2'
 WHERE id=195590239


   --row number: 11273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125605 , [Content] ='AMS'
 WHERE id=195590240


   --row number: 11274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125605 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195590241


   --row number: 11275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125605 , [Content] ='Sales'
 WHERE id=195590242


   --row number: 11276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125605 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=195590243


   --row number: 11277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125605 , [Content] ='Product Line Sales'
 WHERE id=195590244


   --row number: 11278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125605 , [Content] ='IC5'
 WHERE id=195590245


   --row number: 11279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125605 , [Content] ='USD'
 WHERE id=195590247


   --row number: 11280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125605 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=195590248


   --row number: 11281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125605 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=195590249


   --row number: 11282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3125605 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=195590250


   --row number: 11283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3125605 , [Content] ='60/40'
 WHERE id=195590251


   --row number: 11284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125605 , [Content] ='Yes'
 WHERE id=195590252


   --row number: 11285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3125605 , [Content] ='EXEMPT'
 WHERE id=195590253


   --row number: 11286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125896 , [Content] ='Technical'
 WHERE id=195658421


   --row number: 11287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125896 , [Content] ='7/20/18'
 WHERE id=195658422


   --row number: 11288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125896 , [Content] ='5183 IND'
 WHERE id=195658405


   --row number: 11289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125896 , [Content] ='IND'
 WHERE id=195658406


   --row number: 11290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125896 , [Content] ='APAC'
 WHERE id=195658407


   --row number: 11291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125896 , [Content] ='INDIA'
 WHERE id=195658408


   --row number: 11292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125896 , [Content] ='Engineering'
 WHERE id=195658409


   --row number: 11293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125896 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=195658410


   --row number: 11294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125896 , [Content] ='Quality'
 WHERE id=195658411


   --row number: 11295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125896 , [Content] ='IC3'
 WHERE id=195658412


   --row number: 11296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125896 , [Content] ='INR'
 WHERE id=195658414


   --row number: 11297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125896 , [Content] ='1,344,800 / 1,647,400 / 1,950,000 / 2,252,550 / 2,555,100'
 WHERE id=195658415


   --row number: 11298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125896 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=195658416


   --row number: 11299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125896 , [Content] ='15%'
 WHERE id=195658417


   --row number: 11300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125896 , [Content] ='Yes'
 WHERE id=195658418


   --row number: 11301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125896 , [Content] ='2 - Professionals'
 WHERE id=195658419


   --row number: 11302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125896 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195658420


   --row number: 11303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125932 , [Content] ='Technical'
 WHERE id=195663421


   --row number: 11304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125932 , [Content] ='7/20/18'
 WHERE id=195663422


   --row number: 11305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125932 , [Content] ='5143 ISR'
 WHERE id=195663405


   --row number: 11306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125932 , [Content] ='ISR'
 WHERE id=195663406


   --row number: 11307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125932 , [Content] ='EMEA'
 WHERE id=195663407


   --row number: 11308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125932 , [Content] ='ISRAEL'
 WHERE id=195663408


   --row number: 11309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125932 , [Content] ='Engineering'
 WHERE id=195663409


   --row number: 11310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125932 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=195663410


   --row number: 11311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125932 , [Content] ='Software'
 WHERE id=195663411


   --row number: 11312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125932 , [Content] ='IC3'
 WHERE id=195663412


   --row number: 11313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125932 , [Content] ='ILS'
 WHERE id=195663414


   --row number: 11314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125932 , [Content] ='261,700 / 308,800 / 355,900 / 403,000 / 450,100'
 WHERE id=195663415


   --row number: 11315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125932 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=195663416


   --row number: 11316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3125932 , [Content] ='15%'
 WHERE id=195663417


   --row number: 11317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125932 , [Content] ='Yes'
 WHERE id=195663418


   --row number: 11318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125932 , [Content] ='2 - Professionals'
 WHERE id=195663419


   --row number: 11319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125932 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195663420


   --row number: 11320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3125935 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195663608


   --row number: 11321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3125935 , [Content] ='Technical'
 WHERE id=195663609


   --row number: 11322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3125935 , [Content] ='10/26/2018'
 WHERE id=195663610


   --row number: 11323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3125935 , [Content] ='S634 SWE'
 WHERE id=195663592


   --row number: 11324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3125935 , [Content] ='SWE'
 WHERE id=195663593


   --row number: 11325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3125935 , [Content] ='EMEA'
 WHERE id=195663594


   --row number: 11326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3125935 , [Content] ='SWEDEN'
 WHERE id=195663595


   --row number: 11327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3125935 , [Content] ='Sales'
 WHERE id=195663596


   --row number: 11328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3125935 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=195663597


   --row number: 11329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3125935 , [Content] ='Enterprise Accounts'
 WHERE id=195663598


   --row number: 11330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3125935 , [Content] ='IC4'
 WHERE id=195663599


   --row number: 11331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3125935 , [Content] ='SEK'
 WHERE id=195663601


   --row number: 11332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3125935 , [Content] ='680,000 / 740,000 / 800,000 / 860,000 / 920,000'
 WHERE id=195663602


   --row number: 11333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3125935 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=195663603


   --row number: 11334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3125935 , [Content] ='1,360,000 / 1,480,000 / 1,600,000 / 1,720,000 / 1,840,000'
 WHERE id=195663604


   --row number: 11335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3125935 , [Content] ='50/50'
 WHERE id=195663605


   --row number: 11336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3125935 , [Content] ='Yes'
 WHERE id=195663606


   --row number: 11337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3125935 , [Content] ='4 - Sales Workers'
 WHERE id=195663607


   --row number: 11338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3126471 , [Content] ='NO'
 WHERE id=195721863


   --row number: 11339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3126471 , [Content] ='4 - Sales Workers'
 WHERE id=195721864


   --row number: 11340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3126471 , [Content] ='8742-Salespersons - Outside'
 WHERE id=195721865


   --row number: 11341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3126471 , [Content] ='Technical'
 WHERE id=195721866


   --row number: 11342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3126471 , [Content] ='10/05/18'
 WHERE id=195721867


   --row number: 11343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3126471 , [Content] ='S635 US - MRKT 1'
 WHERE id=195721847


   --row number: 11344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3126471 , [Content] ='US - MRKT 1'
 WHERE id=195721848


   --row number: 11345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3126471 , [Content] ='AMS'
 WHERE id=195721849


   --row number: 11346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3126471 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195721850


   --row number: 11347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3126471 , [Content] ='Sales'
 WHERE id=195721851


   --row number: 11348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3126471 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=195721852


   --row number: 11349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3126471 , [Content] ='Enterprise Accounts'
 WHERE id=195721853


   --row number: 11350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3126471 , [Content] ='IC5'
 WHERE id=195721854


   --row number: 11351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3126471 , [Content] ='USD'
 WHERE id=195721856


   --row number: 11352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3126471 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=195721857


   --row number: 11353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3126471 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=195721858


   --row number: 11354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3126471 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=195721859


   --row number: 11355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3126471 , [Content] ='50/50'
 WHERE id=195721860


   --row number: 11356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3126471 , [Content] ='Yes'
 WHERE id=195721861


   --row number: 11357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3126471 , [Content] ='EXEMPT'
 WHERE id=195721862


   --row number: 11358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3126866 , [Content] ='9999 US - MRKT 2'
 WHERE id=195765800


   --row number: 11359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3126866 , [Content] ='US - MRKT 2'
 WHERE id=195765801


   --row number: 11360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3126866 , [Content] ='AMS'
 WHERE id=195765802


   --row number: 11361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3126866 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195765803


   --row number: 11362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3126873 , [Content] ='7/20/18'
 WHERE id=195770541


   --row number: 11363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3126866 , [Content] ='9999 - Intern'
 WHERE id=195765804


   --row number: 11364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3126866 , [Content] ='USD'
 WHERE id=195765805


   --row number: 11365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3126866 , [Content] ='No'
 WHERE id=195765806


   --row number: 11366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3126866 , [Content] ='NON-EXEMPT'
 WHERE id=195765807


   --row number: 11367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3126866 , [Content] ='7/20/18'
 WHERE id=195765808


   --row number: 11368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3126873 , [Content] ='9999 US - MRKT 2'
 WHERE id=195770533


   --row number: 11369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3126873 , [Content] ='US - MRKT 2'
 WHERE id=195770534


   --row number: 11370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3126873 , [Content] ='AMS'
 WHERE id=195770535


   --row number: 11371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3126873 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195770536


   --row number: 11372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3126873 , [Content] ='9999 - Intern'
 WHERE id=195770537


   --row number: 11373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3126873 , [Content] ='USD'
 WHERE id=195770538


   --row number: 11374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3126873 , [Content] ='No'
 WHERE id=195770539


   --row number: 11375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3126873 , [Content] ='NON-EXEMPT'
 WHERE id=195770540


   --row number: 11376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3127281 , [Content] ='4903 US - MRKT 2'
 WHERE id=195941951


   --row number: 11377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3127281 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=195941968


   --row number: 11378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3127281 , [Content] ='Technical'
 WHERE id=195941969


   --row number: 11379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3127281 , [Content] ='7/20/18'
 WHERE id=195941970


   --row number: 11380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3127281 , [Content] ='US - MRKT 2'
 WHERE id=195941952


   --row number: 11381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3127281 , [Content] ='AMS'
 WHERE id=195941953


   --row number: 11382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3127281 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195941954


   --row number: 11383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3127281 , [Content] ='Engineering'
 WHERE id=195941955


   --row number: 11384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3127281 , [Content] ='4903 - Product Security Engineer IC3'
 WHERE id=195941956


   --row number: 11385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3127281 , [Content] ='Product Security'
 WHERE id=195941957


   --row number: 11386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3127281 , [Content] ='IC3'
 WHERE id=195941958


   --row number: 11387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3127281 , [Content] ='USD'
 WHERE id=195941960


   --row number: 11388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3127281 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=195941961


   --row number: 11389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3127281 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=195941962


   --row number: 11390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3127281 , [Content] ='15%'
 WHERE id=195941963


   --row number: 11391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3127281 , [Content] ='Yes'
 WHERE id=195941964


   --row number: 11392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3127281 , [Content] ='EXEMPT'
 WHERE id=195941965


   --row number: 11393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3127281 , [Content] ='NO'
 WHERE id=195941966


   --row number: 11394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3127281 , [Content] ='2 - Professionals'
 WHERE id=195941967


   --row number: 11395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3127465 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195962840


   --row number: 11396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3127465 , [Content] ='Technical'
 WHERE id=195962841


   --row number: 11397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3127465 , [Content] ='7/20/18'
 WHERE id=195962842


   --row number: 11398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3127465 , [Content] ='5465 US - MRKT 1'
 WHERE id=195962823


   --row number: 11399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3127465 , [Content] ='US - MRKT 1'
 WHERE id=195962824


   --row number: 11400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3127465 , [Content] ='AMS'
 WHERE id=195962825


   --row number: 11401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3127465 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=195962826


   --row number: 11402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3127465 , [Content] ='Marketing'
 WHERE id=195962827


   --row number: 11403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3127465 , [Content] ='5465 - Product Portfolio Mgr IC5'
 WHERE id=195962828


   --row number: 11404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3127465 , [Content] ='Product Mgrs'
 WHERE id=195962829


   --row number: 11405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3127465 , [Content] ='IC5'
 WHERE id=195962830


   --row number: 11406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3127465 , [Content] ='USD'
 WHERE id=195962832


   --row number: 11407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3127465 , [Content] ='130,700 / 160,100 / 189,500 / 218,900 / 248,300'
 WHERE id=195962833


   --row number: 11408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3127465 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=195962834


   --row number: 11409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3127465 , [Content] ='25%'
 WHERE id=195962835


   --row number: 11410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3127465 , [Content] ='Yes'
 WHERE id=195962836


   --row number: 11411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3127465 , [Content] ='EXEMPT'
 WHERE id=195962837


   --row number: 11412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3127465 , [Content] ='NO'
 WHERE id=195962838


   --row number: 11413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3127465 , [Content] ='2 - Professionals'
 WHERE id=195962839


   --row number: 11414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3127630 , [Content] ='7/20/18'
 WHERE id=195999533


   --row number: 11415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3127630 , [Content] ='6224 AUS'
 WHERE id=195999516


   --row number: 11416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3127630 , [Content] ='AUS'
 WHERE id=195999517


   --row number: 11417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3127630 , [Content] ='APAC'
 WHERE id=195999518


   --row number: 11418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3127630 , [Content] ='AUSTRALIA'
 WHERE id=195999519


   --row number: 11419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3127630 , [Content] ='Human Resources'
 WHERE id=195999520


   --row number: 11420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3127630 , [Content] ='6224 - Recruiter/Staffing Representative IC4'
 WHERE id=195999521


   --row number: 11421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3127630 , [Content] ='Staffing'
 WHERE id=195999522


   --row number: 11422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3127630 , [Content] ='IC4'
 WHERE id=195999523


   --row number: 11423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3127630 , [Content] ='AUD'
 WHERE id=195999525


   --row number: 11424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3127630 , [Content] ='99,200 / 117,050 / 134,900 / 152,750 / 170,600'
 WHERE id=195999526


   --row number: 11425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3127630 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=195999527


   --row number: 11426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3127630 , [Content] ='15%'
 WHERE id=195999528


   --row number: 11427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3127630 , [Content] ='Yes'
 WHERE id=195999529


   --row number: 11428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3127630 , [Content] ='2 - Professionals'
 WHERE id=195999530


   --row number: 11429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3127630 , [Content] ='8810-Clerical Office Employees'
 WHERE id=195999531


   --row number: 11430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3127630 , [Content] ='Non Technical'
 WHERE id=195999532


   --row number: 11431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3123992 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=196005711


   --row number: 11432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3128081 , [Content] ='2 - Professionals'
 WHERE id=196040820


   --row number: 11433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3128081 , [Content] ='Technical'
 WHERE id=196040822


   --row number: 11434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3128081 , [Content] ='7/20/18'
 WHERE id=196040823


   --row number: 11435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3128081 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196040821


   --row number: 11436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3128081 , [Content] ='5595 NLD'
 WHERE id=196040807


   --row number: 11437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3128081 , [Content] ='NLD'
 WHERE id=196040808


   --row number: 11438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3128081 , [Content] ='EMEA'
 WHERE id=196040809


   --row number: 11439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3128081 , [Content] ='NETHERLANDS'
 WHERE id=196040810


   --row number: 11440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3128081 , [Content] ='Marketing'
 WHERE id=196040811


   --row number: 11441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3128081 , [Content] ='5595 - Product Marketing Mgr IC5'
 WHERE id=196040812


   --row number: 11442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3128081 , [Content] ='Product Marketing'
 WHERE id=196040813


   --row number: 11443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3128081 , [Content] ='IC5'
 WHERE id=196040814


   --row number: 11444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3128081 , [Content] ='EUR'
 WHERE id=196040816


   --row number: 11445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3128081 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=196040817


   --row number: 11446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3128081 , [Content] ='25%'
 WHERE id=196040818


   --row number: 11447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3128081 , [Content] ='Yes'
 WHERE id=196040819


   --row number: 11448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3128180 , [Content] ='7/20/18'
 WHERE id=196050431


   --row number: 11449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3128180 , [Content] ='Technical'
 WHERE id=196050430


   --row number: 11450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3128180 , [Content] ='5142 IND'
 WHERE id=196050415


   --row number: 11451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3128180 , [Content] ='IND'
 WHERE id=196050416


   --row number: 11452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3128180 , [Content] ='APAC'
 WHERE id=196050417


   --row number: 11453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3128180 , [Content] ='INDIA'
 WHERE id=196050418


   --row number: 11454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3128180 , [Content] ='Engineering'
 WHERE id=196050419


   --row number: 11455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3128180 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196050420


   --row number: 11456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3128180 , [Content] ='Software'
 WHERE id=196050421


   --row number: 11457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3128180 , [Content] ='IC2'
 WHERE id=196050422


   --row number: 11458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3128180 , [Content] ='INR'
 WHERE id=196050424


   --row number: 11459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3128180 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=196050425


   --row number: 11460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3128180 , [Content] ='10%'
 WHERE id=196050426


   --row number: 11461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3128180 , [Content] ='No'
 WHERE id=196050427


   --row number: 11462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3128180 , [Content] ='2 - Professionals'
 WHERE id=196050428


   --row number: 11463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3128180 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196050429


   --row number: 11464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3128213 , [Content] ='7/20/18'
 WHERE id=196053324


   --row number: 11465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3128213 , [Content] ='5142 IND'
 WHERE id=196053308


   --row number: 11466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3128213 , [Content] ='IND'
 WHERE id=196053309


   --row number: 11467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3128213 , [Content] ='APAC'
 WHERE id=196053310


   --row number: 11468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3128213 , [Content] ='INDIA'
 WHERE id=196053311


   --row number: 11469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3128213 , [Content] ='Engineering'
 WHERE id=196053312


   --row number: 11470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3128213 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196053313


   --row number: 11471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3128213 , [Content] ='Software'
 WHERE id=196053314


   --row number: 11472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3128213 , [Content] ='IC2'
 WHERE id=196053315


   --row number: 11473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3128213 , [Content] ='INR'
 WHERE id=196053317


   --row number: 11474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3128213 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=196053318


   --row number: 11475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3128213 , [Content] ='10%'
 WHERE id=196053319


   --row number: 11476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3128213 , [Content] ='No'
 WHERE id=196053320


   --row number: 11477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3128213 , [Content] ='2 - Professionals'
 WHERE id=196053321


   --row number: 11478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3128213 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196053322


   --row number: 11479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3128213 , [Content] ='Technical'
 WHERE id=196053323


   --row number: 11480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3128475 , [Content] ='Non Technical'
 WHERE id=196075543


   --row number: 11481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3128475 , [Content] ='4/25/2018'
 WHERE id=196075544


   --row number: 11482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3128475 , [Content] ='6394 US - MRKT 1'
 WHERE id=196075525


   --row number: 11483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3128475 , [Content] ='US - MRKT 1'
 WHERE id=196075526


   --row number: 11484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3128475 , [Content] ='AMS'
 WHERE id=196075527


   --row number: 11485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3128475 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196075528


   --row number: 11486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3128475 , [Content] ='Legal'
 WHERE id=196075529


   --row number: 11487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3128475 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=196075530


   --row number: 11488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3128475 , [Content] ='Legal Counsel'
 WHERE id=196075531


   --row number: 11489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3128475 , [Content] ='IC4'
 WHERE id=196075532


   --row number: 11490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3128475 , [Content] ='USD'
 WHERE id=196075534


   --row number: 11491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3128475 , [Content] ='134,800 / 165,100 / 195,400 / 225,750 / 256,100'
 WHERE id=196075535


   --row number: 11492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3128475 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=196075536


   --row number: 11493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3128475 , [Content] ='25%'
 WHERE id=196075537


   --row number: 11494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3128475 , [Content] ='Yes'
 WHERE id=196075538


   --row number: 11495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3128475 , [Content] ='EXEMPT'
 WHERE id=196075539


   --row number: 11496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3128475 , [Content] ='NO'
 WHERE id=196075540


   --row number: 11497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3128475 , [Content] ='2 - Professionals'
 WHERE id=196075541


   --row number: 11498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3128475 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196075542


   --row number: 11499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129310 , [Content] ='4 - Sales Workers'
 WHERE id=196148357


   --row number: 11500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129310 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196148358


   --row number: 11501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129310 , [Content] ='Technical'
 WHERE id=196148359


   --row number: 11502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129310 , [Content] ='7/20/18'
 WHERE id=196148360


   --row number: 11503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129310 , [Content] ='S1515 US - MRKT 1'
 WHERE id=196148341


   --row number: 11504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129310 , [Content] ='US - MRKT 1'
 WHERE id=196148342


   --row number: 11505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129310 , [Content] ='AMS'
 WHERE id=196148343


   --row number: 11506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129310 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196148344


   --row number: 11507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129310 , [Content] ='Professional Services'
 WHERE id=196148345


   --row number: 11508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129310 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=196148346


   --row number: 11509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129310 , [Content] ='Solution Architect'
 WHERE id=196148347


   --row number: 11510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129310 , [Content] ='IC5'
 WHERE id=196148348


   --row number: 11511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129310 , [Content] ='USD'
 WHERE id=196148350


   --row number: 11512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129310 , [Content] ='113,800 / 139,400 / 165,000 / 190,600 / 216,200'
 WHERE id=196148351


   --row number: 11513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3129310 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=196148352


   --row number: 11514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129310 , [Content] ='25%'
 WHERE id=196148353


   --row number: 11515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129310 , [Content] ='Yes'
 WHERE id=196148354


   --row number: 11516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3129310 , [Content] ='EXEMPT'
 WHERE id=196148355


   --row number: 11517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3129310 , [Content] ='NO'
 WHERE id=196148356


   --row number: 11518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3129313 , [Content] ='NO'
 WHERE id=196148756


   --row number: 11519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129313 , [Content] ='4 - Sales Workers'
 WHERE id=196148757


   --row number: 11520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129313 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196148758


   --row number: 11521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129313 , [Content] ='Technical'
 WHERE id=196148759


   --row number: 11522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129313 , [Content] ='7/20/18'
 WHERE id=196148760


   --row number: 11523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129313 , [Content] ='S1515 US - MRKT 1'
 WHERE id=196148741


   --row number: 11524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129313 , [Content] ='US - MRKT 1'
 WHERE id=196148742


   --row number: 11525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129313 , [Content] ='AMS'
 WHERE id=196148743


   --row number: 11526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129313 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196148744


   --row number: 11527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129313 , [Content] ='Professional Services'
 WHERE id=196148745


   --row number: 11528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129313 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=196148746


   --row number: 11529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129313 , [Content] ='Solution Architect'
 WHERE id=196148747


   --row number: 11530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129313 , [Content] ='IC5'
 WHERE id=196148748


   --row number: 11531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129313 , [Content] ='USD'
 WHERE id=196148750


   --row number: 11532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129313 , [Content] ='113,800 / 139,400 / 165,000 / 190,600 / 216,200'
 WHERE id=196148751


   --row number: 11533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3129313 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=196148752


   --row number: 11534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129313 , [Content] ='25%'
 WHERE id=196148753


   --row number: 11535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129313 , [Content] ='Yes'
 WHERE id=196148754


   --row number: 11536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3129313 , [Content] ='EXEMPT'
 WHERE id=196148755


   --row number: 11537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3129399 , [Content] ='NO'
 WHERE id=196158301


   --row number: 11538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129399 , [Content] ='2 - Professionals'
 WHERE id=196158302


   --row number: 11539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129399 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196158303


   --row number: 11540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129399 , [Content] ='Technical'
 WHERE id=196158304


   --row number: 11541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129399 , [Content] ='7/20/18'
 WHERE id=196158305


   --row number: 11542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129399 , [Content] ='5143 US - MRKT 2'
 WHERE id=196158286


   --row number: 11543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129399 , [Content] ='US - MRKT 2'
 WHERE id=196158287


   --row number: 11544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129399 , [Content] ='AMS'
 WHERE id=196158288


   --row number: 11545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129399 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196158289


   --row number: 11546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129399 , [Content] ='Engineering'
 WHERE id=196158290


   --row number: 11547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129399 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=196158291


   --row number: 11548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129399 , [Content] ='Software'
 WHERE id=196158292


   --row number: 11549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129399 , [Content] ='IC3'
 WHERE id=196158293


   --row number: 11550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129399 , [Content] ='USD'
 WHERE id=196158295


   --row number: 11551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129399 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=196158296


   --row number: 11552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3129399 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=196158297


   --row number: 11553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129399 , [Content] ='15%'
 WHERE id=196158298


   --row number: 11554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129399 , [Content] ='Yes'
 WHERE id=196158299


   --row number: 11555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3129399 , [Content] ='EXEMPT'
 WHERE id=196158300


   --row number: 11556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129406 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196159316


   --row number: 11557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129406 , [Content] ='Technical'
 WHERE id=196159317


   --row number: 11558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129406 , [Content] ='7/20/18'
 WHERE id=196159318


   --row number: 11559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129406 , [Content] ='5224 US - MRKT 2'
 WHERE id=196159299


   --row number: 11560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129406 , [Content] ='US - MRKT 2'
 WHERE id=196159300


   --row number: 11561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129406 , [Content] ='AMS'
 WHERE id=196159301


   --row number: 11562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129406 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196159302


   --row number: 11563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129406 , [Content] ='Engineering'
 WHERE id=196159303


   --row number: 11564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129406 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=196159304


   --row number: 11565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129406 , [Content] ='Product Mgmt Mgr'
 WHERE id=196159305


   --row number: 11566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129406 , [Content] ='IC4'
 WHERE id=196159306


   --row number: 11567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129406 , [Content] ='USD'
 WHERE id=196159308


   --row number: 11568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129406 , [Content] ='101,800 / 123,150 / 144,500 / 165,800 / 187,100'
 WHERE id=196159309


   --row number: 11569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3129406 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=196159310


   --row number: 11570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129406 , [Content] ='20%'
 WHERE id=196159311


   --row number: 11571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129406 , [Content] ='Yes'
 WHERE id=196159312


   --row number: 11572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3129406 , [Content] ='EXEMPT'
 WHERE id=196159313


   --row number: 11573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3129406 , [Content] ='NO'
 WHERE id=196159314


   --row number: 11574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129406 , [Content] ='2 - Professionals'
 WHERE id=196159315


   --row number: 11575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129687 , [Content] ='9912 SGP'
 WHERE id=196192715


   --row number: 11576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129687 , [Content] ='SGP'
 WHERE id=196192716


   --row number: 11577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129687 , [Content] ='APAC'
 WHERE id=196192717


   --row number: 11578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129687 , [Content] ='SINGAPORE'
 WHERE id=196192718


   --row number: 11579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129687 , [Content] ='Administration'
 WHERE id=196192719


   --row number: 11580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129687 , [Content] ='9912 - Administrative Assistant A2'
 WHERE id=196192720


   --row number: 11581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129687 , [Content] ='Administrative Assistant'
 WHERE id=196192721


   --row number: 11582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129687 , [Content] ='A2'
 WHERE id=196192722


   --row number: 11583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129687 , [Content] ='SGD'
 WHERE id=196192724


   --row number: 11584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129687 , [Content] ='35,700 / 40,350 / 45,000 / 49,650 / 54,300'
 WHERE id=196192725


   --row number: 11585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129687 , [Content] ='8%'
 WHERE id=196192726


   --row number: 11586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129687 , [Content] ='No'
 WHERE id=196192727


   --row number: 11587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129687 , [Content] ='5 - Administrative Support Workers'
 WHERE id=196192728


   --row number: 11588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129687 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196192729


   --row number: 11589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129687 , [Content] ='Non Technical'
 WHERE id=196192730


   --row number: 11590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129687 , [Content] ='7/20/18'
 WHERE id=196192731


   --row number: 11591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129707 , [Content] ='6504 SGP'
 WHERE id=196193588


   --row number: 11592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129707 , [Content] ='SGP'
 WHERE id=196193589


   --row number: 11593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129707 , [Content] ='APAC'
 WHERE id=196193590


   --row number: 11594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129707 , [Content] ='SINGAPORE'
 WHERE id=196193591


   --row number: 11595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129707 , [Content] ='Administration'
 WHERE id=196193592


   --row number: 11596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129707 , [Content] ='6504 - Executive Assistant IC4'
 WHERE id=196193593


   --row number: 11597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129707 , [Content] ='Executive Assistant'
 WHERE id=196193594


   --row number: 11598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129707 , [Content] ='IC4'
 WHERE id=196193595


   --row number: 11599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129707 , [Content] ='SGD'
 WHERE id=196193597


   --row number: 11600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129707 , [Content] ='77,100 / 91,000 / 104,900 / 118,750 / 132,600'
 WHERE id=196193598


   --row number: 11601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129707 , [Content] ='15%'
 WHERE id=196193599


   --row number: 11602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129707 , [Content] ='Yes'
 WHERE id=196193600


   --row number: 11603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129707 , [Content] ='5 - Administrative Support Workers'
 WHERE id=196193601


   --row number: 11604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129707 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196193602


   --row number: 11605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129707 , [Content] ='Non Technical'
 WHERE id=196193603


   --row number: 11606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129707 , [Content] ='10/05/18'
 WHERE id=196193604


   --row number: 11607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129870 , [Content] ='7/20/18'
 WHERE id=196206491


   --row number: 11608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129870 , [Content] ='5142 IND'
 WHERE id=196206475


   --row number: 11609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129870 , [Content] ='IND'
 WHERE id=196206476


   --row number: 11610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129870 , [Content] ='APAC'
 WHERE id=196206477


   --row number: 11611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129870 , [Content] ='INDIA'
 WHERE id=196206478


   --row number: 11612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129870 , [Content] ='Engineering'
 WHERE id=196206479


   --row number: 11613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129870 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196206480


   --row number: 11614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129870 , [Content] ='Software'
 WHERE id=196206481


   --row number: 11615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129870 , [Content] ='IC2'
 WHERE id=196206482


   --row number: 11616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129870 , [Content] ='INR'
 WHERE id=196206484


   --row number: 11617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129870 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=196206485


   --row number: 11618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129870 , [Content] ='10%'
 WHERE id=196206486


   --row number: 11619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129870 , [Content] ='No'
 WHERE id=196206487


   --row number: 11620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129870 , [Content] ='2 - Professionals'
 WHERE id=196206488


   --row number: 11621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129870 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196206489


   --row number: 11622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129870 , [Content] ='Technical'
 WHERE id=196206490


   --row number: 11623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3129990 , [Content] ='7/20/18'
 WHERE id=196218583


   --row number: 11624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3129990 , [Content] ='6394 NLD'
 WHERE id=196218566


   --row number: 11625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3129990 , [Content] ='NLD'
 WHERE id=196218567


   --row number: 11626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3129990 , [Content] ='EMEA'
 WHERE id=196218568


   --row number: 11627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3129990 , [Content] ='NETHERLANDS'
 WHERE id=196218569


   --row number: 11628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3129990 , [Content] ='Legal'
 WHERE id=196218570


   --row number: 11629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3129990 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=196218571


   --row number: 11630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3129990 , [Content] ='Legal Counsel'
 WHERE id=196218572


   --row number: 11631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3129990 , [Content] ='IC4'
 WHERE id=196218573


   --row number: 11632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3129990 , [Content] ='EUR'
 WHERE id=196218575


   --row number: 11633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3129990 , [Content] ='89,500 / 109,650 / 129,800 / 149,950 / 170,100'
 WHERE id=196218576


   --row number: 11634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3129990 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=196218577


   --row number: 11635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3129990 , [Content] ='25%'
 WHERE id=196218578


   --row number: 11636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3129990 , [Content] ='Yes'
 WHERE id=196218579


   --row number: 11637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3129990 , [Content] ='2 - Professionals'
 WHERE id=196218580


   --row number: 11638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3129990 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196218581


   --row number: 11639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3129990 , [Content] ='Non Technical'
 WHERE id=196218582


   --row number: 11640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3130053 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196224519


   --row number: 11641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3130053 , [Content] ='Non Technical'
 WHERE id=196224520


   --row number: 11642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3130053 , [Content] ='7/20/18'
 WHERE id=196224521


   --row number: 11643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3130053 , [Content] ='S1223-CE UK'
 WHERE id=196224504


   --row number: 11644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3130053 , [Content] ='UK'
 WHERE id=196224505


   --row number: 11645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3130053 , [Content] ='EMEA'
 WHERE id=196224506


   --row number: 11646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3130053 , [Content] ='UNITED KINGDOM'
 WHERE id=196224507


   --row number: 11647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3130053 , [Content] ='Sales'
 WHERE id=196224508


   --row number: 11648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3130053 , [Content] ='S1223-CE - Customer Education Inside Sales Rep IC3'
 WHERE id=196224509


   --row number: 11649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3130053 , [Content] ='Inside Sales'
 WHERE id=196224510


   --row number: 11650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3130053 , [Content] ='IC3'
 WHERE id=196224511


   --row number: 11651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3130053 , [Content] ='GBP'
 WHERE id=196224513


   --row number: 11652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3130053 , [Content] ='41,565 / 45,233 / 48,900 / 52,568 / 56,235'
 WHERE id=196224514


   --row number: 11653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3130053 , [Content] ='69,275 / 75,388 / 81,500 / 87,613 / 93,725'
 WHERE id=196224515


   --row number: 11654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3130053 , [Content] ='60/40'
 WHERE id=196224516


   --row number: 11655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3130053 , [Content] ='No'
 WHERE id=196224517


   --row number: 11656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3130053 , [Content] ='4 - Sales Workers'
 WHERE id=196224518


   --row number: 11657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3130277 , [Content] ='Technical'
 WHERE id=196238871


   --row number: 11658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3130277 , [Content] ='7/20/2018'
 WHERE id=196238872


   --row number: 11659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3130277 , [Content] ='6483 IRL'
 WHERE id=196238855


   --row number: 11660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3130277 , [Content] ='IRL'
 WHERE id=196238856


   --row number: 11661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3130277 , [Content] ='EMEA'
 WHERE id=196238857


   --row number: 11662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3130277 , [Content] ='IRELAND'
 WHERE id=196238858


   --row number: 11663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3130277 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=196238859


   --row number: 11664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3130277 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=196238860


   --row number: 11665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3130277 , [Content] ='Production service'
 WHERE id=196238861


   --row number: 11666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3130277 , [Content] ='IC3'
 WHERE id=196238862


   --row number: 11667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3130277 , [Content] ='EUR'
 WHERE id=196238864


   --row number: 11668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3130277 , [Content] ='53,700 / 63,350 / 73,000 / 82,700 / 92,400'
 WHERE id=196238865


   --row number: 11669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3130277 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=196238866


   --row number: 11670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3130277 , [Content] ='15%'
 WHERE id=196238867


   --row number: 11671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3130277 , [Content] ='Yes'
 WHERE id=196238868


   --row number: 11672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3130277 , [Content] ='2 - Professionals'
 WHERE id=196238869


   --row number: 11673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3130277 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196238870


   --row number: 11674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3130733 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196276191


   --row number: 11675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3130733 , [Content] ='Technical'
 WHERE id=196276192


   --row number: 11676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3130733 , [Content] ='10/05/18'
 WHERE id=196276193


   --row number: 11677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3130733 , [Content] ='5373 US - MRKT 2'
 WHERE id=196276174


   --row number: 11678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3130733 , [Content] ='US - MRKT 2'
 WHERE id=196276175


   --row number: 11679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3130733 , [Content] ='AMS'
 WHERE id=196276176


   --row number: 11680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3130733 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196276177


   --row number: 11681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3130733 , [Content] ='Engineering'
 WHERE id=196276178


   --row number: 11682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3130733 , [Content] ='5373 - Project (Design) Manager IC3'
 WHERE id=196276179


   --row number: 11683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3130733 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=196276180


   --row number: 11684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3130733 , [Content] ='IC3'
 WHERE id=196276181


   --row number: 11685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3130733 , [Content] ='USD'
 WHERE id=196276183


   --row number: 11686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3130733 , [Content] ='81,900 / 96,650 / 111,400 / 126,150 / 140,900'
 WHERE id=196276184


   --row number: 11687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3130733 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=196276185


   --row number: 11688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3130733 , [Content] ='15%'
 WHERE id=196276186


   --row number: 11689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3130733 , [Content] ='Yes'
 WHERE id=196276187


   --row number: 11690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3130733 , [Content] ='EXEMPT'
 WHERE id=196276188


   --row number: 11691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3130733 , [Content] ='NO'
 WHERE id=196276189


   --row number: 11692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3130733 , [Content] ='2 - Professionals'
 WHERE id=196276190


   --row number: 11693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131026 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=196299721


   --row number: 11694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131026 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196299722


   --row number: 11695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131026 , [Content] ='Technical'
 WHERE id=196299723


   --row number: 11696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131026 , [Content] ='7/20/18'
 WHERE id=196299724


   --row number: 11697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131026 , [Content] ='3593 US - MRKT 1'
 WHERE id=196299705


   --row number: 11698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131026 , [Content] ='US - MRKT 1'
 WHERE id=196299706


   --row number: 11699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131026 , [Content] ='AMS'
 WHERE id=196299707


   --row number: 11700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131026 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196299708


   --row number: 11701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131026 , [Content] ='Info Systems/Technology'
 WHERE id=196299709


   --row number: 11702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131026 , [Content] ='3593 - Mgr, Data Informatics Mgmt M3'
 WHERE id=196299710


   --row number: 11703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131026 , [Content] ='Data Informatics'
 WHERE id=196299711


   --row number: 11704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131026 , [Content] ='M3'
 WHERE id=196299712


   --row number: 11705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131026 , [Content] ='USD'
 WHERE id=196299714


   --row number: 11706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131026 , [Content] ='110,300 / 133,400 / 156,500 / 179,600 / 202,700'
 WHERE id=196299715


   --row number: 11707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131026 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=196299716


   --row number: 11708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131026 , [Content] ='20%'
 WHERE id=196299717


   --row number: 11709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131026 , [Content] ='Yes'
 WHERE id=196299718


   --row number: 11710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3131026 , [Content] ='EXEMPT'
 WHERE id=196299719


   --row number: 11711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3131026 , [Content] ='NO'
 WHERE id=196299720


   --row number: 11712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3131053 , [Content] ='NO'
 WHERE id=196302536


   --row number: 11713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131053 , [Content] ='2 - Professionals'
 WHERE id=196302537


   --row number: 11714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131053 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196302538


   --row number: 11715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131053 , [Content] ='Technical'
 WHERE id=196302539


   --row number: 11716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131053 , [Content] ='7/20/18'
 WHERE id=196302540


   --row number: 11717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131053 , [Content] ='5143 US - MRKT 1'
 WHERE id=196302521


   --row number: 11718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131053 , [Content] ='US - MRKT 1'
 WHERE id=196302522


   --row number: 11719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131053 , [Content] ='AMS'
 WHERE id=196302523


   --row number: 11720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131053 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196302524


   --row number: 11721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131053 , [Content] ='Engineering'
 WHERE id=196302525


   --row number: 11722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131053 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=196302526


   --row number: 11723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131053 , [Content] ='Software'
 WHERE id=196302527


   --row number: 11724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131053 , [Content] ='IC3'
 WHERE id=196302528


   --row number: 11725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131053 , [Content] ='USD'
 WHERE id=196302530


   --row number: 11726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131053 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=196302531


   --row number: 11727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131053 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=196302532


   --row number: 11728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131053 , [Content] ='15%'
 WHERE id=196302533


   --row number: 11729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131053 , [Content] ='Yes'
 WHERE id=196302534


   --row number: 11730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3131053 , [Content] ='EXEMPT'
 WHERE id=196302535


   --row number: 11731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131608 , [Content] ='Technical'
 WHERE id=196481338


   --row number: 11732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131608 , [Content] ='02/09/18'
 WHERE id=196481339


   --row number: 11733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131609 , [Content] ='6483 IND'
 WHERE id=196481373


   --row number: 11734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131609 , [Content] ='IND'
 WHERE id=196481374


   --row number: 11735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131609 , [Content] ='APAC'
 WHERE id=196481375


   --row number: 11736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131609 , [Content] ='INDIA'
 WHERE id=196481376


   --row number: 11737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131609 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=196481377


   --row number: 11738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131609 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=196481378


   --row number: 11739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131609 , [Content] ='Production service'
 WHERE id=196481379


   --row number: 11740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131609 , [Content] ='IC3'
 WHERE id=196481380


   --row number: 11741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131609 , [Content] ='INR'
 WHERE id=196481382


   --row number: 11742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131609 , [Content] ='1,206,900 / 1,478,450 / 1,750,000 / 2,021,550 / 2,293,100'
 WHERE id=196481383


   --row number: 11743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131609 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=196481384


   --row number: 11744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131609 , [Content] ='15%'
 WHERE id=196481385


   --row number: 11745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131609 , [Content] ='Yes'
 WHERE id=196481386


   --row number: 11746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131609 , [Content] ='2 - Professionals'
 WHERE id=196481387


   --row number: 11747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131609 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196481388


   --row number: 11748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131609 , [Content] ='Technical'
 WHERE id=196481389


   --row number: 11749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131609 , [Content] ='02/09/18'
 WHERE id=196481390


   --row number: 11750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131608 , [Content] ='6483 IND'
 WHERE id=196481322


   --row number: 11751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131608 , [Content] ='IND'
 WHERE id=196481323


   --row number: 11752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131608 , [Content] ='APAC'
 WHERE id=196481324


   --row number: 11753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131608 , [Content] ='INDIA'
 WHERE id=196481325


   --row number: 11754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131608 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=196481326


   --row number: 11755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131608 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=196481327


   --row number: 11756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131608 , [Content] ='Production service'
 WHERE id=196481328


   --row number: 11757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131608 , [Content] ='IC3'
 WHERE id=196481329


   --row number: 11758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131608 , [Content] ='INR'
 WHERE id=196481331


   --row number: 11759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131608 , [Content] ='1,206,900 / 1,478,450 / 1,750,000 / 2,021,550 / 2,293,100'
 WHERE id=196481332


   --row number: 11760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131608 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=196481333


   --row number: 11761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131608 , [Content] ='15%'
 WHERE id=196481334


   --row number: 11762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131608 , [Content] ='Yes'
 WHERE id=196481335


   --row number: 11763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131608 , [Content] ='2 - Professionals'
 WHERE id=196481336


   --row number: 11764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131608 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196481337


   --row number: 11765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131610 , [Content] ='6483 IND'
 WHERE id=196481540


   --row number: 11766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131610 , [Content] ='IND'
 WHERE id=196481541


   --row number: 11767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131610 , [Content] ='APAC'
 WHERE id=196481542


   --row number: 11768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131610 , [Content] ='INDIA'
 WHERE id=196481543


   --row number: 11769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131610 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=196481544


   --row number: 11770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131610 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=196481545


   --row number: 11771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131610 , [Content] ='Production service'
 WHERE id=196481546


   --row number: 11772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131610 , [Content] ='IC3'
 WHERE id=196481547


   --row number: 11773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131610 , [Content] ='INR'
 WHERE id=196481549


   --row number: 11774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131610 , [Content] ='1,206,900 / 1,478,450 / 1,750,000 / 2,021,550 / 2,293,100'
 WHERE id=196481550


   --row number: 11775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131610 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=196481551


   --row number: 11776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131610 , [Content] ='15%'
 WHERE id=196481552


   --row number: 11777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131610 , [Content] ='Yes'
 WHERE id=196481553


   --row number: 11778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131610 , [Content] ='2 - Professionals'
 WHERE id=196481554


   --row number: 11779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131610 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196481555


   --row number: 11780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131610 , [Content] ='Technical'
 WHERE id=196481556


   --row number: 11781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131610 , [Content] ='02/09/18'
 WHERE id=196481557


   --row number: 11782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131612 , [Content] ='5143 IND'
 WHERE id=196481823


   --row number: 11783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131612 , [Content] ='IND'
 WHERE id=196481824


   --row number: 11784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131612 , [Content] ='APAC'
 WHERE id=196481825


   --row number: 11785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131612 , [Content] ='INDIA'
 WHERE id=196481826


   --row number: 11786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131612 , [Content] ='Engineering'
 WHERE id=196481827


   --row number: 11787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131612 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=196481828


   --row number: 11788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131612 , [Content] ='Software'
 WHERE id=196481829


   --row number: 11789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131612 , [Content] ='IC3'
 WHERE id=196481830


   --row number: 11790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131612 , [Content] ='INR'
 WHERE id=196481832


   --row number: 11791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131612 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=196481833


   --row number: 11792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131612 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=196481834


   --row number: 11793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131612 , [Content] ='15%'
 WHERE id=196481835


   --row number: 11794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131612 , [Content] ='Yes'
 WHERE id=196481836


   --row number: 11795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131612 , [Content] ='2 - Professionals'
 WHERE id=196481837


   --row number: 11796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131612 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196481838


   --row number: 11797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131612 , [Content] ='Technical'
 WHERE id=196481839


   --row number: 11798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131612 , [Content] ='7/20/18'
 WHERE id=196481840


   --row number: 11799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131621 , [Content] ='5142 IND'
 WHERE id=196482502


   --row number: 11800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131621 , [Content] ='IND'
 WHERE id=196482503


   --row number: 11801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131621 , [Content] ='APAC'
 WHERE id=196482504


   --row number: 11802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131621 , [Content] ='INDIA'
 WHERE id=196482505


   --row number: 11803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131621 , [Content] ='Engineering'
 WHERE id=196482506


   --row number: 11804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131621 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196482507


   --row number: 11805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131621 , [Content] ='Software'
 WHERE id=196482508


   --row number: 11806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131621 , [Content] ='IC2'
 WHERE id=196482509


   --row number: 11807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131621 , [Content] ='INR'
 WHERE id=196482511


   --row number: 11808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131621 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=196482512


   --row number: 11809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131621 , [Content] ='10%'
 WHERE id=196482514


   --row number: 11810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131621 , [Content] ='No'
 WHERE id=196482515


   --row number: 11811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131621 , [Content] ='2 - Professionals'
 WHERE id=196482516


   --row number: 11812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131621 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196482517


   --row number: 11813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131621 , [Content] ='Technical'
 WHERE id=196482518


   --row number: 11814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131621 , [Content] ='10/05/18'
 WHERE id=196482519


   --row number: 11815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131672 , [Content] ='5144 IND'
 WHERE id=196483841


   --row number: 11816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131672 , [Content] ='IND'
 WHERE id=196483842


   --row number: 11817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131672 , [Content] ='APAC'
 WHERE id=196483843


   --row number: 11818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131672 , [Content] ='INDIA'
 WHERE id=196483844


   --row number: 11819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131672 , [Content] ='Engineering'
 WHERE id=196483845


   --row number: 11820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131672 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=196483846


   --row number: 11821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131672 , [Content] ='Software'
 WHERE id=196483847


   --row number: 11822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131672 , [Content] ='IC4'
 WHERE id=196483848


   --row number: 11823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131672 , [Content] ='INR'
 WHERE id=196483850


   --row number: 11824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131672 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=196483851


   --row number: 11825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3131672 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=196483852


   --row number: 11826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131672 , [Content] ='20%'
 WHERE id=196483853


   --row number: 11827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131672 , [Content] ='Yes'
 WHERE id=196483854


   --row number: 11828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131672 , [Content] ='2 - Professionals'
 WHERE id=196483855


   --row number: 11829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131672 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196483856


   --row number: 11830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131672 , [Content] ='Technical'
 WHERE id=196483857


   --row number: 11831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131672 , [Content] ='7/20/18'
 WHERE id=196483858


   --row number: 11832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131699 , [Content] ='5142 IND'
 WHERE id=196484041


   --row number: 11833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131699 , [Content] ='IND'
 WHERE id=196484042


   --row number: 11834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131699 , [Content] ='APAC'
 WHERE id=196484043


   --row number: 11835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131699 , [Content] ='INDIA'
 WHERE id=196484044


   --row number: 11836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131699 , [Content] ='Engineering'
 WHERE id=196484045


   --row number: 11837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131699 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196484046


   --row number: 11838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131699 , [Content] ='Software'
 WHERE id=196484047


   --row number: 11839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131699 , [Content] ='IC2'
 WHERE id=196484048


   --row number: 11840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131699 , [Content] ='INR'
 WHERE id=196484050


   --row number: 11841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131699 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=196484051


   --row number: 11842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131699 , [Content] ='10%'
 WHERE id=196484052


   --row number: 11843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131699 , [Content] ='No'
 WHERE id=196484053


   --row number: 11844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131699 , [Content] ='2 - Professionals'
 WHERE id=196484054


   --row number: 11845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131699 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196484055


   --row number: 11846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131699 , [Content] ='Technical'
 WHERE id=196484056


   --row number: 11847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131699 , [Content] ='7/20/18'
 WHERE id=196484057


   --row number: 11848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131724 , [Content] ='5142 IND'
 WHERE id=196484238


   --row number: 11849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131724 , [Content] ='IND'
 WHERE id=196484239


   --row number: 11850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131724 , [Content] ='APAC'
 WHERE id=196484240


   --row number: 11851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131724 , [Content] ='INDIA'
 WHERE id=196484241


   --row number: 11852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131724 , [Content] ='Engineering'
 WHERE id=196484242


   --row number: 11853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131724 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196484243


   --row number: 11854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131724 , [Content] ='Software'
 WHERE id=196484244


   --row number: 11855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131724 , [Content] ='IC2'
 WHERE id=196484245


   --row number: 11856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131724 , [Content] ='INR'
 WHERE id=196484247


   --row number: 11857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3131724 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=196484248


   --row number: 11858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131724 , [Content] ='10%'
 WHERE id=196484249


   --row number: 11859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131724 , [Content] ='No'
 WHERE id=196484250


   --row number: 11860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131724 , [Content] ='2 - Professionals'
 WHERE id=196484251


   --row number: 11861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131724 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196484252


   --row number: 11862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3129707 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=196486505


   --row number: 11863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131724 , [Content] ='7/20/18'
 WHERE id=196484254


   --row number: 11864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131724 , [Content] ='Technical'
 WHERE id=196484253


   --row number: 11865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3131862 , [Content] ='2 - Professionals'
 WHERE id=196499365


   --row number: 11866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3131862 , [Content] ='No'
 WHERE id=196499364


   --row number: 11867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3131862 , [Content] ='10%'
 WHERE id=196499363


   --row number: 11868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3131862 , [Content] ='INR'
 WHERE id=196499362


   --row number: 11869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3131862 , [Content] ='IC2'
 WHERE id=196499360


   --row number: 11870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3131862 , [Content] ='Sales Operations'
 WHERE id=196499359


   --row number: 11871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3131862 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=196499358


   --row number: 11872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3131862 , [Content] ='Sales Operations'
 WHERE id=196499357


   --row number: 11873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3131862 , [Content] ='INDIA'
 WHERE id=196499356


   --row number: 11874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3131862 , [Content] ='APAC'
 WHERE id=196499355


   --row number: 11875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3131862 , [Content] ='IND'
 WHERE id=196499354


   --row number: 11876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3131862 , [Content] ='S1832 IND'
 WHERE id=196499353


   --row number: 11877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3131862 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196499366


   --row number: 11878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3131862 , [Content] ='Technical'
 WHERE id=196499367


   --row number: 11879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3131862 , [Content] ='7/20/18'
 WHERE id=196499368


   --row number: 11880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3132198 , [Content] ='9999 US - MRKT 1'
 WHERE id=196538713


   --row number: 11881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3132198 , [Content] ='US - MRKT 1'
 WHERE id=196538714


   --row number: 11882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3132198 , [Content] ='AMS'
 WHERE id=196538715


   --row number: 11883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3132198 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196538716


   --row number: 11884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3132198 , [Content] ='9999 - Intern'
 WHERE id=196538717


   --row number: 11885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3132198 , [Content] ='USD'
 WHERE id=196538718


   --row number: 11886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3132198 , [Content] ='No'
 WHERE id=196538719


   --row number: 11887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3132198 , [Content] ='NON-EXEMPT'
 WHERE id=196538720


   --row number: 11888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3132198 , [Content] ='7/20/18'
 WHERE id=196538721


   --row number: 11889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133282 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=196629191


   --row number: 11890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133282 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196629192


   --row number: 11891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133282 , [Content] ='Non Technical'
 WHERE id=196629193


   --row number: 11892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133282 , [Content] ='7/20/18'
 WHERE id=196629194


   --row number: 11893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133282 , [Content] ='2656 US - MRKT 1'
 WHERE id=196629175


   --row number: 11894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133282 , [Content] ='US - MRKT 1'
 WHERE id=196629176


   --row number: 11895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133282 , [Content] ='AMS'
 WHERE id=196629177


   --row number: 11896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133282 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196629178


   --row number: 11897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133282 , [Content] ='Marketing'
 WHERE id=196629179


   --row number: 11898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133282 , [Content] ='2656 - Sr Dir, Trade Show/Events Mgmt M6'
 WHERE id=196629180


   --row number: 11899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133282 , [Content] ='Events'
 WHERE id=196629181


   --row number: 11900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133282 , [Content] ='M6'
 WHERE id=196629182


   --row number: 11901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133282 , [Content] ='USD'
 WHERE id=196629184


   --row number: 11902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133282 , [Content] ='143,100 / 175,300 / 207,500 / 239,700 / 271,900'
 WHERE id=196629185


   --row number: 11903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133282 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=196629186


   --row number: 11904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133282 , [Content] ='30%'
 WHERE id=196629187


   --row number: 11905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133282 , [Content] ='Yes'
 WHERE id=196629188


   --row number: 11906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133282 , [Content] ='EXEMPT'
 WHERE id=196629189


   --row number: 11907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133282 , [Content] ='NO'
 WHERE id=196629190


   --row number: 11908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133419 , [Content] ='2 - Professionals'
 WHERE id=196643119


   --row number: 11909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133419 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196643120


   --row number: 11910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133419 , [Content] ='Technical'
 WHERE id=196643121


   --row number: 11911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133419 , [Content] ='7/20/18'
 WHERE id=196643122


   --row number: 11912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133419 , [Content] ='6554 US - MRKT 1'
 WHERE id=196643103


   --row number: 11913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133419 , [Content] ='US - MRKT 1'
 WHERE id=196643104


   --row number: 11914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133419 , [Content] ='AMS'
 WHERE id=196643105


   --row number: 11915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133419 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196643106


   --row number: 11916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133419 , [Content] ='Info Systems/Technology'
 WHERE id=196643107


   --row number: 11917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133419 , [Content] ='6554 - Enterprisewide Apps/Sys Developer IC4'
 WHERE id=196643108


   --row number: 11918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133419 , [Content] ='Enterprise Apps/Systems'
 WHERE id=196643109


   --row number: 11919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133419 , [Content] ='IC4'
 WHERE id=196643110


   --row number: 11920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133419 , [Content] ='USD'
 WHERE id=196643112


   --row number: 11921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133419 , [Content] ='100,700 / 121,800 / 142,900 / 164,000 / 185,100'
 WHERE id=196643113


   --row number: 11922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133419 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=196643114


   --row number: 11923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133419 , [Content] ='20%'
 WHERE id=196643115


   --row number: 11924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133419 , [Content] ='Yes'
 WHERE id=196643116


   --row number: 11925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133419 , [Content] ='EXEMPT'
 WHERE id=196643117


   --row number: 11926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133419 , [Content] ='NO'
 WHERE id=196643118


   --row number: 11927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133492 , [Content] ='NO'
 WHERE id=196652486


   --row number: 11928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133492 , [Content] ='4 - Sales Workers'
 WHERE id=196652487


   --row number: 11929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133492 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196652488


   --row number: 11930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133492 , [Content] ='Technical'
 WHERE id=196652489


   --row number: 11931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133492 , [Content] ='7/20/18'
 WHERE id=196652490


   --row number: 11932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133492 , [Content] ='S1414 US - MRKT 2'
 WHERE id=196652470


   --row number: 11933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133492 , [Content] ='US - MRKT 2'
 WHERE id=196652471


   --row number: 11934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133492 , [Content] ='AMS'
 WHERE id=196652472


   --row number: 11935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133492 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196652473


   --row number: 11936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133492 , [Content] ='Solution Consulting'
 WHERE id=196652474


   --row number: 11937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133492 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=196652475


   --row number: 11938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133492 , [Content] ='Solution Consultant Core'
 WHERE id=196652476


   --row number: 11939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133492 , [Content] ='IC4'
 WHERE id=196652477


   --row number: 11940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133492 , [Content] ='USD'
 WHERE id=196652479


   --row number: 11941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133492 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=196652480


   --row number: 11942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133492 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=196652481


   --row number: 11943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3133492 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=196652482


   --row number: 11944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3133492 , [Content] ='75/25'
 WHERE id=196652483


   --row number: 11945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133492 , [Content] ='Yes'
 WHERE id=196652484


   --row number: 11946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133492 , [Content] ='EXEMPT'
 WHERE id=196652485


   --row number: 11947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133512 , [Content] ='S665 US - MRKT 3'
 WHERE id=196654169


   --row number: 11948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133512 , [Content] ='US - MRKT 3'
 WHERE id=196654170


   --row number: 11949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133512 , [Content] ='AMS'
 WHERE id=196654171


   --row number: 11950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133512 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196654172


   --row number: 11951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133512 , [Content] ='Sales'
 WHERE id=196654173


   --row number: 11952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133512 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=196654174


   --row number: 11953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133512 , [Content] ='Product Line Sales'
 WHERE id=196654175


   --row number: 11954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133512 , [Content] ='IC5'
 WHERE id=196654176


   --row number: 11955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133512 , [Content] ='USD'
 WHERE id=196654178


   --row number: 11956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133512 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=196654179


   --row number: 11957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133512 , [Content] ='4 - Sales Workers'
 WHERE id=196654186


   --row number: 11958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133512 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196654187


   --row number: 11959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133512 , [Content] ='Technical'
 WHERE id=196654188


   --row number: 11960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133512 , [Content] ='7/20/18'
 WHERE id=196654189


   --row number: 11961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133512 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=196654180


   --row number: 11962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3133512 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=196654181


   --row number: 11963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3133512 , [Content] ='60/40'
 WHERE id=196654182


   --row number: 11964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133512 , [Content] ='Yes'
 WHERE id=196654183


   --row number: 11965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133512 , [Content] ='EXEMPT'
 WHERE id=196654184


   --row number: 11966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133534 , [Content] ='Product Line Sales'
 WHERE id=196657239


   --row number: 11967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133534 , [Content] ='4 - Sales Workers'
 WHERE id=196657250


   --row number: 11968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133534 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196657251


   --row number: 11969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133534 , [Content] ='Technical'
 WHERE id=196657252


   --row number: 11970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133534 , [Content] ='10/05/18'
 WHERE id=196657253


   --row number: 11971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133534 , [Content] ='IC5'
 WHERE id=196657240


   --row number: 11972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133534 , [Content] ='USD'
 WHERE id=196657242


   --row number: 11973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133534 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=196657243


   --row number: 11974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133534 , [Content] ='S665 US - MRKT 3'
 WHERE id=196657233


   --row number: 11975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133534 , [Content] ='US - MRKT 3'
 WHERE id=196657234


   --row number: 11976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133534 , [Content] ='AMS'
 WHERE id=196657235


   --row number: 11977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133534 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196657236


   --row number: 11978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133534 , [Content] ='Sales'
 WHERE id=196657237


   --row number: 11979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133534 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=196657238


   --row number: 11980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133534 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=196657244


   --row number: 11981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3133534 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=196657245


   --row number: 11982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3133534 , [Content] ='60/40'
 WHERE id=196657246


   --row number: 11983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133534 , [Content] ='Yes'
 WHERE id=196657247


   --row number: 11984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133534 , [Content] ='EXEMPT'
 WHERE id=196657248


   --row number: 11985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133560 , [Content] ='NO'
 WHERE id=196659176


   --row number: 11986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133560 , [Content] ='4 - Sales Workers'
 WHERE id=196659177


   --row number: 11987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133560 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196659178


   --row number: 11988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133560 , [Content] ='Technical'
 WHERE id=196659179


   --row number: 11989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133560 , [Content] ='S665 US - MRKT 1'
 WHERE id=196659160


   --row number: 11990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133560 , [Content] ='US - MRKT 1'
 WHERE id=196659161


   --row number: 11991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133560 , [Content] ='AMS'
 WHERE id=196659162


   --row number: 11992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133560 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196659163


   --row number: 11993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133560 , [Content] ='Sales'
 WHERE id=196659164


   --row number: 11994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133560 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=196659165


   --row number: 11995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133560 , [Content] ='Product Line Sales'
 WHERE id=196659166


   --row number: 11996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133560 , [Content] ='IC5'
 WHERE id=196659167


   --row number: 11997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133560 , [Content] ='USD'
 WHERE id=196659169


   --row number: 11998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133560 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=196659170


   --row number: 11999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133560 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=196659171


   --row number: 12000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3133560 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=196659172

