
--Total 3000

   --row number: 18001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3191070 , [Content] ='164,475 / 178,988 / 193,500 / 208,013 / 222,525'
 WHERE id=201987526


   --row number: 18002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3191070 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=201987527


   --row number: 18003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3191070 , [Content] ='219,300 / 238,650 / 258,000 / 277,350 / 296,700'
 WHERE id=201987528


   --row number: 18004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3191070 , [Content] ='75/25'
 WHERE id=201987529


   --row number: 18005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3191125 , [Content] ='Yes'
 WHERE id=201999659


   --row number: 18006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3191125 , [Content] ='4 - Sales Workers'
 WHERE id=201999660


   --row number: 18007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3191125 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201999661


   --row number: 18008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3191125 , [Content] ='Technical'
 WHERE id=201999662


   --row number: 18009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3191125 , [Content] ='09/05/18'
 WHERE id=201999663


   --row number: 18010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3191125 , [Content] ='S1414 HKG'
 WHERE id=201999645


   --row number: 18011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3191125 , [Content] ='HKG'
 WHERE id=201999646


   --row number: 18012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3191125 , [Content] ='APAC'
 WHERE id=201999647


   --row number: 18013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3191125 , [Content] ='HONG KONG'
 WHERE id=201999648


   --row number: 18014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3191125 , [Content] ='Solution Consulting'
 WHERE id=201999649


   --row number: 18015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3191125 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=201999650


   --row number: 18016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3191125 , [Content] ='Solution Consultant Core'
 WHERE id=201999651


   --row number: 18017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3191125 , [Content] ='IC4'
 WHERE id=201999652


   --row number: 18018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3191125 , [Content] ='HKD'
 WHERE id=201999654


   --row number: 18019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3191125 , [Content] ='829,069 / 902,222 / 975,375 / 1,048,528 / 1,121,681'
 WHERE id=201999655


   --row number: 18020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3191125 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=201999656


   --row number: 18021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3191125 , [Content] ='1,105,425 / 1,202,963 / 1,300,500 / 1,398,038 / 1,495,575'
 WHERE id=201999657


   --row number: 18022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3191125 , [Content] ='75/25'
 WHERE id=201999658


   --row number: 18023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3191174 , [Content] ='20%'
 WHERE id=202014230


   --row number: 18024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3191174 , [Content] ='Yes'
 WHERE id=202014231


   --row number: 18025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3191174 , [Content] ='EXEMPT'
 WHERE id=202014232


   --row number: 18026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3191174 , [Content] ='NO'
 WHERE id=202014233


   --row number: 18027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3191174 , [Content] ='2 - Professionals'
 WHERE id=202014234


   --row number: 18028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3191174 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202014235


   --row number: 18029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3191174 , [Content] ='Technical'
 WHERE id=202014236


   --row number: 18030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3191174 , [Content] ='09/05/18'
 WHERE id=202014237


   --row number: 18031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3191174 , [Content] ='5764 US - MRKT 2'
 WHERE id=202014217


   --row number: 18032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3191174 , [Content] ='US - MRKT 2'
 WHERE id=202014218


   --row number: 18033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3191174 , [Content] ='AMS'
 WHERE id=202014219


   --row number: 18034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3191174 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202014220


   --row number: 18035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3191174 , [Content] ='Professional Services'
 WHERE id=202014221


   --row number: 18036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3191174 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=202014222


   --row number: 18037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3191174 , [Content] ='Technology Consultant'
 WHERE id=202014223


   --row number: 18038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3191174 , [Content] ='IC4'
 WHERE id=202014224


   --row number: 18039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3191174 , [Content] ='USD'
 WHERE id=202014226


   --row number: 18040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3191174 , [Content] ='88,800 / 107,400 / 126,000 / 144,600 / 163,200'
 WHERE id=202014227


   --row number: 18041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3191174 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=202014228


   --row number: 18042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3191174 , [Content] ='106,600 / 128,900 / 151,200 / 173,500 / 195,800'
 WHERE id=202014229


   --row number: 18043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192345 , [Content] ='Technical'
 WHERE id=202043528


   --row number: 18044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192345 , [Content] ='09/05/18'
 WHERE id=202043529


   --row number: 18045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192345 , [Content] ='S1413 FRA'
 WHERE id=202043512


   --row number: 18046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192345 , [Content] ='FRA'
 WHERE id=202043513


   --row number: 18047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192345 , [Content] ='EMEA'
 WHERE id=202043514


   --row number: 18048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192345 , [Content] ='FRANCE'
 WHERE id=202043515


   --row number: 18049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192345 , [Content] ='Solution Consulting'
 WHERE id=202043516


   --row number: 18050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192345 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=202043517


   --row number: 18051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192345 , [Content] ='Solution Consultant Core'
 WHERE id=202043518


   --row number: 18052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192345 , [Content] ='IC3'
 WHERE id=202043519


   --row number: 18053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192345 , [Content] ='EUR'
 WHERE id=202043521


   --row number: 18054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192345 , [Content] ='57,375 / 62,438 / 67,500 / 72,563 / 77,625'
 WHERE id=202043522


   --row number: 18055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192345 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=202043523


   --row number: 18056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3192345 , [Content] ='75/25'
 WHERE id=202043524


   --row number: 18057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192345 , [Content] ='No'
 WHERE id=202043525


   --row number: 18058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192345 , [Content] ='4 - Sales Workers'
 WHERE id=202043526


   --row number: 18059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192345 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202043527


   --row number: 18060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192371 , [Content] ='5 - Administrative Support Workers'
 WHERE id=202045902


   --row number: 18061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192371 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202045903


   --row number: 18062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192371 , [Content] ='Non Technical'
 WHERE id=202045904


   --row number: 18063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192371 , [Content] ='09/05/18'
 WHERE id=202045905


   --row number: 18064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192371 , [Content] ='6503 JPN'
 WHERE id=202045887


   --row number: 18065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192371 , [Content] ='JPN'
 WHERE id=202045888


   --row number: 18066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192371 , [Content] ='APAC'
 WHERE id=202045889


   --row number: 18067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192371 , [Content] ='JAPAN'
 WHERE id=202045890


   --row number: 18068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192371 , [Content] ='Administration'
 WHERE id=202045891


   --row number: 18069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192371 , [Content] ='6503 - Executive Assistant IC3'
 WHERE id=202045892


   --row number: 18070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192371 , [Content] ='Executive Assistant'
 WHERE id=202045893


   --row number: 18071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192371 , [Content] ='IC3'
 WHERE id=202045894


   --row number: 18072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192371 , [Content] ='JPY'
 WHERE id=202045896


   --row number: 18073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192371 , [Content] ='6,090,200 / 7,095,100 / 8,100,000 / 9,104,850 / 10,109,700'
 WHERE id=202045897


   --row number: 18074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192371 , [Content] ='27,000 / 37,500 / 48,000 / 58,800 / 69,600'
 WHERE id=202045898


   --row number: 18075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192371 , [Content] ='6,699,200 / 7,804,600 / 8,910,000 / 10,015,350 / 11,120,700'
 WHERE id=202045899


   --row number: 18076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192371 , [Content] ='10%'
 WHERE id=202045900


   --row number: 18077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192371 , [Content] ='Yes'
 WHERE id=202045901


   --row number: 18078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192379 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202046424


   --row number: 18079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192379 , [Content] ='Technical'
 WHERE id=202046425


   --row number: 18080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192379 , [Content] ='09/05/18'
 WHERE id=202046426


   --row number: 18081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192379 , [Content] ='S1864 IND'
 WHERE id=202046409


   --row number: 18082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192379 , [Content] ='IND'
 WHERE id=202046410


   --row number: 18083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192379 , [Content] ='APAC'
 WHERE id=202046411


   --row number: 18084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192379 , [Content] ='INDIA'
 WHERE id=202046412


   --row number: 18085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192379 , [Content] ='Sales Operations'
 WHERE id=202046413


   --row number: 18086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192379 , [Content] ='S1864 - Sales Operations Specialist A4'
 WHERE id=202046414


   --row number: 18087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192379 , [Content] ='Sales Operations'
 WHERE id=202046415


   --row number: 18088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192379 , [Content] ='A4'
 WHERE id=202046416


   --row number: 18089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192379 , [Content] ='INR'
 WHERE id=202046418


   --row number: 18090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192379 , [Content] ='586,200 / 718,100 / 850,000 / 981,900 / 1,113,800'
 WHERE id=202046419


   --row number: 18091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192379 , [Content] ='633,100 / 775,550 / 918,000 / 1,060,450 / 1,202,900'
 WHERE id=202046420


   --row number: 18092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192379 , [Content] ='8%'
 WHERE id=202046421


   --row number: 18093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192379 , [Content] ='No'
 WHERE id=202046422


   --row number: 18094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192379 , [Content] ='5 - Administrative Support Workers'
 WHERE id=202046423


   --row number: 18095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192382 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202046511


   --row number: 18096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192382 , [Content] ='Technical'
 WHERE id=202046512


   --row number: 18097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192382 , [Content] ='09/05/18'
 WHERE id=202046513


   --row number: 18098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192382 , [Content] ='S1864 IND'
 WHERE id=202046496


   --row number: 18099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192382 , [Content] ='IND'
 WHERE id=202046497


   --row number: 18100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192382 , [Content] ='APAC'
 WHERE id=202046498


   --row number: 18101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192382 , [Content] ='INDIA'
 WHERE id=202046499


   --row number: 18102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192382 , [Content] ='Sales Operations'
 WHERE id=202046500


   --row number: 18103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192382 , [Content] ='S1864 - Sales Operations Specialist A4'
 WHERE id=202046501


   --row number: 18104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192382 , [Content] ='Sales Operations'
 WHERE id=202046502


   --row number: 18105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192382 , [Content] ='A4'
 WHERE id=202046503


   --row number: 18106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192382 , [Content] ='INR'
 WHERE id=202046505


   --row number: 18107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192382 , [Content] ='586,200 / 718,100 / 850,000 / 981,900 / 1,113,800'
 WHERE id=202046506


   --row number: 18108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192382 , [Content] ='633,100 / 775,550 / 918,000 / 1,060,450 / 1,202,900'
 WHERE id=202046507


   --row number: 18109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192382 , [Content] ='8%'
 WHERE id=202046508


   --row number: 18110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192382 , [Content] ='No'
 WHERE id=202046509


   --row number: 18111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192382 , [Content] ='5 - Administrative Support Workers'
 WHERE id=202046510


   --row number: 18112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192417 , [Content] ='3104 IND'
 WHERE id=202050996


   --row number: 18113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192417 , [Content] ='IND'
 WHERE id=202050997


   --row number: 18114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192417 , [Content] ='APAC'
 WHERE id=202050998


   --row number: 18115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192417 , [Content] ='INDIA'
 WHERE id=202050999


   --row number: 18116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192417 , [Content] ='Finance'
 WHERE id=202051000


   --row number: 18117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192417 , [Content] ='3104 - Sr Mgr, Accounting Mgmt M4'
 WHERE id=202051001


   --row number: 18118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192417 , [Content] ='Accounting'
 WHERE id=202051002


   --row number: 18119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192417 , [Content] ='M4'
 WHERE id=202051003


   --row number: 18120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192417 , [Content] ='INR'
 WHERE id=202051005


   --row number: 18121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192417 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202051011


   --row number: 18122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192417 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202051012


   --row number: 18123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192417 , [Content] ='Non Technical'
 WHERE id=202051013


   --row number: 18124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192417 , [Content] ='09/05/18'
 WHERE id=202051014


   --row number: 18125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192417 , [Content] ='2,379,300 / 2,914,650 / 3,450,000 / 3,985,350 / 4,520,700'
 WHERE id=202051006


   --row number: 18126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192417 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=202051007


   --row number: 18127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192417 , [Content] ='2,974,100 / 3,643,300 / 4,312,500 / 4,981,700 / 5,650,900'
 WHERE id=202051008


   --row number: 18128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192417 , [Content] ='25%'
 WHERE id=202051009


   --row number: 18129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192417 , [Content] ='Yes'
 WHERE id=202051010


   --row number: 18130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192913 , [Content] ='Engineering'
 WHERE id=202088910


   --row number: 18131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192913 , [Content] ='Yes'
 WHERE id=202088920


   --row number: 18132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192913 , [Content] ='EXEMPT'
 WHERE id=202088921


   --row number: 18133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192913 , [Content] ='NO'
 WHERE id=202088922


   --row number: 18134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192913 , [Content] ='2 - Professionals'
 WHERE id=202088923


   --row number: 18135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192913 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202088924


   --row number: 18136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192913 , [Content] ='Technical'
 WHERE id=202088925


   --row number: 18137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192913 , [Content] ='09/05/18'
 WHERE id=202088926


   --row number: 18138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192913 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202088911


   --row number: 18139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192913 , [Content] ='Software'
 WHERE id=202088912


   --row number: 18140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192913 , [Content] ='IC3'
 WHERE id=202088913


   --row number: 18141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192913 , [Content] ='5143 US - MRKT 2'
 WHERE id=202088906


   --row number: 18142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192913 , [Content] ='US - MRKT 2'
 WHERE id=202088907


   --row number: 18143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192913 , [Content] ='AMS'
 WHERE id=202088908


   --row number: 18144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192913 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202088909


   --row number: 18145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192913 , [Content] ='USD'
 WHERE id=202088915


   --row number: 18146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192913 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202088916


   --row number: 18147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192913 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202088917


   --row number: 18148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192913 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202088918


   --row number: 18149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192913 , [Content] ='15%'
 WHERE id=202088919


   --row number: 18150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192914 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202088985


   --row number: 18151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192914 , [Content] ='Technical'
 WHERE id=202088986


   --row number: 18152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192914 , [Content] ='10/05/18'
 WHERE id=202088987


   --row number: 18153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192914 , [Content] ='5144 US - MRKT 2'
 WHERE id=202088967


   --row number: 18154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192914 , [Content] ='US - MRKT 2'
 WHERE id=202088968


   --row number: 18155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192914 , [Content] ='AMS'
 WHERE id=202088969


   --row number: 18156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192914 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202088970


   --row number: 18157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192914 , [Content] ='Engineering'
 WHERE id=202088971


   --row number: 18158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192914 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202088972


   --row number: 18159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192914 , [Content] ='Software'
 WHERE id=202088973


   --row number: 18160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192914 , [Content] ='IC4'
 WHERE id=202088974


   --row number: 18161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192914 , [Content] ='USD'
 WHERE id=202088976


   --row number: 18162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192914 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202088977


   --row number: 18163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192914 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202088978


   --row number: 18164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192914 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202088979


   --row number: 18165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192914 , [Content] ='20%'
 WHERE id=202088980


   --row number: 18166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192914 , [Content] ='Yes'
 WHERE id=202088981


   --row number: 18167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192914 , [Content] ='EXEMPT'
 WHERE id=202088982


   --row number: 18168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192914 , [Content] ='NO'
 WHERE id=202088983


   --row number: 18169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192914 , [Content] ='2 - Professionals'
 WHERE id=202088984


   --row number: 18170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192921 , [Content] ='5143 US - MRKT 2'
 WHERE id=202089405


   --row number: 18171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192921 , [Content] ='US - MRKT 2'
 WHERE id=202089406


   --row number: 18172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192921 , [Content] ='AMS'
 WHERE id=202089407


   --row number: 18173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192921 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202089408


   --row number: 18174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192921 , [Content] ='Engineering'
 WHERE id=202089409


   --row number: 18175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192921 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202089410


   --row number: 18176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192921 , [Content] ='Yes'
 WHERE id=202089419


   --row number: 18177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192924 , [Content] ='5143 US - MRKT 2'
 WHERE id=202089518


   --row number: 18178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192924 , [Content] ='US - MRKT 2'
 WHERE id=202089519


   --row number: 18179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192924 , [Content] ='AMS'
 WHERE id=202089520


   --row number: 18180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192924 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202089521


   --row number: 18181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192924 , [Content] ='Engineering'
 WHERE id=202089522


   --row number: 18182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192921 , [Content] ='EXEMPT'
 WHERE id=202089420


   --row number: 18183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192921 , [Content] ='NO'
 WHERE id=202089421


   --row number: 18184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192921 , [Content] ='2 - Professionals'
 WHERE id=202089422


   --row number: 18185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192921 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202089423


   --row number: 18186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192921 , [Content] ='Technical'
 WHERE id=202089424


   --row number: 18187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192921 , [Content] ='09/05/18'
 WHERE id=202089425


   --row number: 18188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192921 , [Content] ='Software'
 WHERE id=202089411


   --row number: 18189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192921 , [Content] ='IC3'
 WHERE id=202089412


   --row number: 18190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192921 , [Content] ='USD'
 WHERE id=202089414


   --row number: 18191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192921 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202089415


   --row number: 18192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192921 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202089416


   --row number: 18193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192921 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202089417


   --row number: 18194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192921 , [Content] ='15%'
 WHERE id=202089418


   --row number: 18195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192924 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202089523


   --row number: 18196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192924 , [Content] ='Software'
 WHERE id=202089524


   --row number: 18197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192924 , [Content] ='IC3'
 WHERE id=202089525


   --row number: 18198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192924 , [Content] ='USD'
 WHERE id=202089527


   --row number: 18199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192924 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202089528


   --row number: 18200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192924 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202089529


   --row number: 18201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192924 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202089530


   --row number: 18202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192924 , [Content] ='15%'
 WHERE id=202089531


   --row number: 18203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192924 , [Content] ='Yes'
 WHERE id=202089532


   --row number: 18204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192924 , [Content] ='EXEMPT'
 WHERE id=202089533


   --row number: 18205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192924 , [Content] ='NO'
 WHERE id=202089534


   --row number: 18206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192924 , [Content] ='2 - Professionals'
 WHERE id=202089535


   --row number: 18207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192924 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202089536


   --row number: 18208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192924 , [Content] ='Technical'
 WHERE id=202089537


   --row number: 18209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192924 , [Content] ='09/05/18'
 WHERE id=202089538


   --row number: 18210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192939 , [Content] ='Yes'
 WHERE id=202091075


   --row number: 18211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192939 , [Content] ='EXEMPT'
 WHERE id=202091076


   --row number: 18212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192939 , [Content] ='NO'
 WHERE id=202091077


   --row number: 18213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192939 , [Content] ='2 - Professionals'
 WHERE id=202091078


   --row number: 18214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192939 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202091079


   --row number: 18215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192939 , [Content] ='Technical'
 WHERE id=202091080


   --row number: 18216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192939 , [Content] ='09/05/18'
 WHERE id=202091081


   --row number: 18217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192939 , [Content] ='5143 US - MRKT 1'
 WHERE id=202091061


   --row number: 18218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192939 , [Content] ='US - MRKT 1'
 WHERE id=202091062


   --row number: 18219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192939 , [Content] ='AMS'
 WHERE id=202091063


   --row number: 18220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192939 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202091064


   --row number: 18221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192939 , [Content] ='Engineering'
 WHERE id=202091065


   --row number: 18222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192939 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202091066


   --row number: 18223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192939 , [Content] ='Software'
 WHERE id=202091067


   --row number: 18224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192939 , [Content] ='IC3'
 WHERE id=202091068


   --row number: 18225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192939 , [Content] ='USD'
 WHERE id=202091070


   --row number: 18226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192939 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=202091071


   --row number: 18227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192939 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202091072


   --row number: 18228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192939 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=202091073


   --row number: 18229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192939 , [Content] ='15%'
 WHERE id=202091074


   --row number: 18230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192947 , [Content] ='Yes'
 WHERE id=202091605


   --row number: 18231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192947 , [Content] ='EXEMPT'
 WHERE id=202091606


   --row number: 18232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192947 , [Content] ='NO'
 WHERE id=202091607


   --row number: 18233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192947 , [Content] ='2 - Professionals'
 WHERE id=202091608


   --row number: 18234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192947 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202091609


   --row number: 18235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192947 , [Content] ='Technical'
 WHERE id=202091610


   --row number: 18236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192947 , [Content] ='09/05/18'
 WHERE id=202091611


   --row number: 18237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192947 , [Content] ='5143 US - MRKT 2'
 WHERE id=202091591


   --row number: 18238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192947 , [Content] ='US - MRKT 2'
 WHERE id=202091592


   --row number: 18239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192947 , [Content] ='AMS'
 WHERE id=202091593


   --row number: 18240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192947 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202091594


   --row number: 18241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192947 , [Content] ='Engineering'
 WHERE id=202091595


   --row number: 18242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192947 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202091596


   --row number: 18243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192947 , [Content] ='Software'
 WHERE id=202091597


   --row number: 18244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192947 , [Content] ='IC3'
 WHERE id=202091598


   --row number: 18245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192947 , [Content] ='USD'
 WHERE id=202091600


   --row number: 18246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192947 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202091601


   --row number: 18247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192947 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202091602


   --row number: 18248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192947 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202091603


   --row number: 18249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192947 , [Content] ='15%'
 WHERE id=202091604


   --row number: 18250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192949 , [Content] ='Yes'
 WHERE id=202091717


   --row number: 18251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192949 , [Content] ='EXEMPT'
 WHERE id=202091718


   --row number: 18252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192949 , [Content] ='NO'
 WHERE id=202091719


   --row number: 18253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192949 , [Content] ='2 - Professionals'
 WHERE id=202091720


   --row number: 18254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192949 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202091721


   --row number: 18255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192949 , [Content] ='Technical'
 WHERE id=202091722


   --row number: 18256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192949 , [Content] ='09/05/18'
 WHERE id=202091723


   --row number: 18257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192949 , [Content] ='5143 US - MRKT 2'
 WHERE id=202091703


   --row number: 18258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192949 , [Content] ='US - MRKT 2'
 WHERE id=202091704


   --row number: 18259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192949 , [Content] ='AMS'
 WHERE id=202091705


   --row number: 18260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192949 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202091706


   --row number: 18261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192949 , [Content] ='Engineering'
 WHERE id=202091707


   --row number: 18262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192949 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202091708


   --row number: 18263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192949 , [Content] ='Software'
 WHERE id=202091709


   --row number: 18264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192949 , [Content] ='IC3'
 WHERE id=202091710


   --row number: 18265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192949 , [Content] ='USD'
 WHERE id=202091712


   --row number: 18266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192949 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202091713


   --row number: 18267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192949 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202091714


   --row number: 18268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192949 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202091715


   --row number: 18269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192949 , [Content] ='15%'
 WHERE id=202091716


   --row number: 18270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3192955 , [Content] ='20%'
 WHERE id=202092217


   --row number: 18271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3192955 , [Content] ='Yes'
 WHERE id=202092218


   --row number: 18272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3192955 , [Content] ='EXEMPT'
 WHERE id=202092219


   --row number: 18273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3192955 , [Content] ='NO'
 WHERE id=202092220


   --row number: 18274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3192955 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202092221


   --row number: 18275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3192955 , [Content] ='2143 US - MRKT 2'
 WHERE id=202092204


   --row number: 18276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3192955 , [Content] ='US - MRKT 2'
 WHERE id=202092205


   --row number: 18277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3192955 , [Content] ='AMS'
 WHERE id=202092206


   --row number: 18278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3192955 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202092207


   --row number: 18279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3192955 , [Content] ='Engineering'
 WHERE id=202092208


   --row number: 18280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3192955 , [Content] ='2143 - Mgr, Software Engrg Mgmt M3'
 WHERE id=202092209


   --row number: 18281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3192955 , [Content] ='Software'
 WHERE id=202092210


   --row number: 18282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3192955 , [Content] ='M3'
 WHERE id=202092211


   --row number: 18283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3192955 , [Content] ='USD'
 WHERE id=202092213


   --row number: 18284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3192955 , [Content] ='111,000 / 134,250 / 157,500 / 180,750 / 204,000'
 WHERE id=202092214


   --row number: 18285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3192955 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202092215


   --row number: 18286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3192955 , [Content] ='133,200 / 161,100 / 189,000 / 216,900 / 244,800'
 WHERE id=202092216


   --row number: 18287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3192955 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202092222


   --row number: 18288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3192955 , [Content] ='Technical'
 WHERE id=202092223


   --row number: 18289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3192955 , [Content] ='09/05/18'
 WHERE id=202092224


   --row number: 18290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3193079 , [Content] ='87,300 / 103,000 / 118,700 / 134,450 / 150,200'
 WHERE id=202102069


   --row number: 18291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3193079 , [Content] ='Yes'
 WHERE id=202102073


   --row number: 18292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3193079 , [Content] ='EXEMPT'
 WHERE id=202102074


   --row number: 18293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3193079 , [Content] ='NO'
 WHERE id=202102075


   --row number: 18294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3193079 , [Content] ='2 - Professionals'
 WHERE id=202102076


   --row number: 18295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3193079 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202102077


   --row number: 18296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3193079 , [Content] ='Technical'
 WHERE id=202102078


   --row number: 18297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3193079 , [Content] ='09/05/18'
 WHERE id=202102079


   --row number: 18298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3193079 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=202102070


   --row number: 18299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3193079 , [Content] ='100,400 / 118,450 / 136,500 / 154,600 / 172,700'
 WHERE id=202102071


   --row number: 18300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3193079 , [Content] ='15%'
 WHERE id=202102072


   --row number: 18301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3193079 , [Content] ='4684 US - MRKT 2'
 WHERE id=202102057


   --row number: 18302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3193079 , [Content] ='US - MRKT 2'
 WHERE id=202102060


   --row number: 18303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3193079 , [Content] ='AMS'
 WHERE id=202102061


   --row number: 18304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3193079 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202102062


   --row number: 18305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3193079 , [Content] ='Business Strategy'
 WHERE id=202102063


   --row number: 18306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3193079 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=202102064


   --row number: 18307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3193079 , [Content] ='Business Process'
 WHERE id=202102065


   --row number: 18308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3193079 , [Content] ='IC4'
 WHERE id=202102066


   --row number: 18309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3193079 , [Content] ='USD'
 WHERE id=202102068


   --row number: 18310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3193328 , [Content] ='133,200 / 161,100 / 189,000 / 216,900 / 244,800'
 WHERE id=202121574


   --row number: 18311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3193328 , [Content] ='20%'
 WHERE id=202121575


   --row number: 18312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3193328 , [Content] ='Yes'
 WHERE id=202121576


   --row number: 18313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3193328 , [Content] ='EXEMPT'
 WHERE id=202121577


   --row number: 18314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3193328 , [Content] ='NO'
 WHERE id=202121578


   --row number: 18315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3193328 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202121579


   --row number: 18316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3193328 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202121580


   --row number: 18317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3193328 , [Content] ='Technical'
 WHERE id=202121581


   --row number: 18318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3193328 , [Content] ='09/05/18'
 WHERE id=202121582


   --row number: 18319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3193328 , [Content] ='2143 US - MRKT 2'
 WHERE id=202121562


   --row number: 18320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3193328 , [Content] ='US - MRKT 2'
 WHERE id=202121563


   --row number: 18321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3193328 , [Content] ='AMS'
 WHERE id=202121564


   --row number: 18322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3193328 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202121565


   --row number: 18323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3193328 , [Content] ='Engineering'
 WHERE id=202121566


   --row number: 18324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3193328 , [Content] ='2143 - Mgr, Software Engrg Mgmt M3'
 WHERE id=202121567


   --row number: 18325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3193328 , [Content] ='Software'
 WHERE id=202121568


   --row number: 18326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3193328 , [Content] ='M3'
 WHERE id=202121569


   --row number: 18327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3193328 , [Content] ='USD'
 WHERE id=202121571


   --row number: 18328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3193328 , [Content] ='111,000 / 134,250 / 157,500 / 180,750 / 204,000'
 WHERE id=202121572


   --row number: 18329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3193328 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202121573


   --row number: 18330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3193633 , [Content] ='Yes'
 WHERE id=202143964


   --row number: 18331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3193633 , [Content] ='EXEMPT'
 WHERE id=202143965


   --row number: 18332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3193633 , [Content] ='NO'
 WHERE id=202143966


   --row number: 18333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3193633 , [Content] ='S1414A US - MRKT 1'
 WHERE id=202143950


   --row number: 18334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3193633 , [Content] ='US - MRKT 1'
 WHERE id=202143951


   --row number: 18335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3193633 , [Content] ='AMS'
 WHERE id=202143952


   --row number: 18336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3193633 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202143953


   --row number: 18337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3193633 , [Content] ='Solution Consulting'
 WHERE id=202143954


   --row number: 18338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3193633 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=202143955


   --row number: 18339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3193633 , [Content] ='Solution Consultant Architect'
 WHERE id=202143956


   --row number: 18340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3193633 , [Content] ='IC4'
 WHERE id=202143957


   --row number: 18341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3193633 , [Content] ='USD'
 WHERE id=202143959


   --row number: 18342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3193633 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=202143960


   --row number: 18343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3193633 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=202143961


   --row number: 18344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3193633 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=202143962


   --row number: 18345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3193633 , [Content] ='75/25'
 WHERE id=202143963


   --row number: 18346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3193633 , [Content] ='4 - Sales Workers'
 WHERE id=202143967


   --row number: 18347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3193633 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202143968


   --row number: 18348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3193633 , [Content] ='Technical'
 WHERE id=202143969


   --row number: 18349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3193633 , [Content] ='09/05/18'
 WHERE id=202143970


   --row number: 18350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3193664 , [Content] ='M5'
 WHERE id=202146133


   --row number: 18351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3193664 , [Content] ='Yes'
 WHERE id=202146140


   --row number: 18352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3193664 , [Content] ='EXEMPT'
 WHERE id=202146141


   --row number: 18353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3193664 , [Content] ='NO'
 WHERE id=202146142


   --row number: 18354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3193664 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202146143


   --row number: 18355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3193664 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202146144


   --row number: 18356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3193664 , [Content] ='Technical'
 WHERE id=202146145


   --row number: 18357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3193664 , [Content] ='09/05/18'
 WHERE id=202146146


   --row number: 18358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3193749 , [Content] ='6583 US - MRKT 1'
 WHERE id=202152190


   --row number: 18359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3193749 , [Content] ='US - MRKT 1'
 WHERE id=202152191


   --row number: 18360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3193749 , [Content] ='AMS'
 WHERE id=202152192


   --row number: 18361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3193749 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202152193


   --row number: 18362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3193749 , [Content] ='Info Systems/Technology'
 WHERE id=202152194


   --row number: 18363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3193749 , [Content] ='6583 - Sr Information Security Engineer IC3'
 WHERE id=202152195


   --row number: 18364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3193749 , [Content] ='Security'
 WHERE id=202152196


   --row number: 18365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3193749 , [Content] ='IC3'
 WHERE id=202152197


   --row number: 18366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3193749 , [Content] ='USD'
 WHERE id=202152199


   --row number: 18367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3193749 , [Content] ='101,500 / 119,750 / 138,000 / 156,300 / 174,600'
 WHERE id=202152200


   --row number: 18368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3193749 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202152201


   --row number: 18369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3193664 , [Content] ='USD'
 WHERE id=202146135


   --row number: 18370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3193664 , [Content] ='137,200 / 168,100 / 199,000 / 229,850 / 260,700'
 WHERE id=202146136


   --row number: 18371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3193664 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=202146137


   --row number: 18372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3193664 , [Content] ='171,500 / 210,150 / 248,800 / 287,350 / 325,900'
 WHERE id=202146138


   --row number: 18373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3193664 , [Content] ='25%'
 WHERE id=202146139


   --row number: 18374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3193664 , [Content] ='2555 US - MRKT 1'
 WHERE id=202146126


   --row number: 18375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3193664 , [Content] ='US - MRKT 1'
 WHERE id=202146127


   --row number: 18376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3193664 , [Content] ='AMS'
 WHERE id=202146128


   --row number: 18377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3193664 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202146129


   --row number: 18378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3193664 , [Content] ='Professional Services'
 WHERE id=202146130


   --row number: 18379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3193664 , [Content] ='2555 - Dir, Professional Services Mgmt M5'
 WHERE id=202146131


   --row number: 18380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3193664 , [Content] ='Professional Services'
 WHERE id=202146132


   --row number: 18381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3193749 , [Content] ='116,700 / 137,700 / 158,700 / 179,750 / 200,800'
 WHERE id=202152202


   --row number: 18382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3193749 , [Content] ='15%'
 WHERE id=202152203


   --row number: 18383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3193749 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=202152204


   --row number: 18384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3193749 , [Content] ='Yes'
 WHERE id=202152205


   --row number: 18385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3193749 , [Content] ='EXEMPT'
 WHERE id=202152206


   --row number: 18386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3193749 , [Content] ='YES'
 WHERE id=202152207


   --row number: 18387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3193749 , [Content] ='2 - Professionals'
 WHERE id=202152208


   --row number: 18388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3193749 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202152209


   --row number: 18389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3193749 , [Content] ='Technical'
 WHERE id=202152210


   --row number: 18390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3193749 , [Content] ='09/05/18'
 WHERE id=202152211


   --row number: 18391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195606 , [Content] ='S315 US - MRKT 1'
 WHERE id=202170168


   --row number: 18392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195606 , [Content] ='US - MRKT 1'
 WHERE id=202170169


   --row number: 18393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195606 , [Content] ='AMS'
 WHERE id=202170170


   --row number: 18394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195606 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202170171


   --row number: 18395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195606 , [Content] ='Sales'
 WHERE id=202170172


   --row number: 18396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195606 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=202170173


   --row number: 18397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195606 , [Content] ='Sales Management'
 WHERE id=202170174


   --row number: 18398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195606 , [Content] ='M5'
 WHERE id=202170175


   --row number: 18399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195606 , [Content] ='USD'
 WHERE id=202170177


   --row number: 18400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195606 , [Content] ='159,375 / 173,438 / 187,500 / 201,563 / 215,625'
 WHERE id=202170178


   --row number: 18401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195606 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=202170179


   --row number: 18402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195606 , [Content] ='318,750 / 346,875 / 375,000 / 403,125 / 431,250'
 WHERE id=202170180


   --row number: 18403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3195606 , [Content] ='50/50'
 WHERE id=202170181


   --row number: 18404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195606 , [Content] ='Yes'
 WHERE id=202170182


   --row number: 18405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195606 , [Content] ='EXEMPT'
 WHERE id=202170183


   --row number: 18406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3195606 , [Content] ='NO'
 WHERE id=202170184


   --row number: 18407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195606 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202170185


   --row number: 18408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195606 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202170186


   --row number: 18409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195606 , [Content] ='Technical'
 WHERE id=202170187


   --row number: 18410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195606 , [Content] ='09/05/18'
 WHERE id=202170188


   --row number: 18411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195610 , [Content] ='5184 US - MRKT 1'
 WHERE id=202170873


   --row number: 18412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195610 , [Content] ='US - MRKT 1'
 WHERE id=202170874


   --row number: 18413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195610 , [Content] ='AMS'
 WHERE id=202170875


   --row number: 18414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195610 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202170876


   --row number: 18415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195610 , [Content] ='Engineering'
 WHERE id=202170877


   --row number: 18416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195610 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=202170878


   --row number: 18417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195610 , [Content] ='Quality'
 WHERE id=202170879


   --row number: 18418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195610 , [Content] ='IC4'
 WHERE id=202170880


   --row number: 18419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195610 , [Content] ='USD'
 WHERE id=202170882


   --row number: 18420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195610 , [Content] ='103,300 / 124,950 / 146,600 / 168,250 / 189,900'
 WHERE id=202170883


   --row number: 18421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195610 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=202170884


   --row number: 18422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195610 , [Content] ='124,000 / 149,950 / 175,900 / 201,900 / 227,900'
 WHERE id=202170885


   --row number: 18423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3195610 , [Content] ='20%'
 WHERE id=202170886


   --row number: 18424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195610 , [Content] ='Yes'
 WHERE id=202170887


   --row number: 18425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195610 , [Content] ='EXEMPT'
 WHERE id=202170888


   --row number: 18426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3195610 , [Content] ='NO'
 WHERE id=202170889


   --row number: 18427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195610 , [Content] ='2 - Professionals'
 WHERE id=202170890


   --row number: 18428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195610 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202170891


   --row number: 18429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195610 , [Content] ='Technical'
 WHERE id=202170892


   --row number: 18430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195610 , [Content] ='10/05/18'
 WHERE id=202170893


   --row number: 18431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195616 , [Content] ='S1375 US - MRKT 1'
 WHERE id=202171363


   --row number: 18432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195616 , [Content] ='US - MRKT 1'
 WHERE id=202171364


   --row number: 18433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195616 , [Content] ='AMS'
 WHERE id=202171365


   --row number: 18434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195616 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202171366


   --row number: 18435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195616 , [Content] ='Sales'
 WHERE id=202171367


   --row number: 18436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195616 , [Content] ='S1375 - Inside/Contract Renewal Sales Rep IC5'
 WHERE id=202171368


   --row number: 18437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195616 , [Content] ='Inside/Contract Renewal'
 WHERE id=202171369


   --row number: 18438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195616 , [Content] ='IC5'
 WHERE id=202171370


   --row number: 18439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195616 , [Content] ='USD'
 WHERE id=202171372


   --row number: 18440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195616 , [Content] ='82,100 / 89,350 / 96,600 / 103,850 / 111,100'
 WHERE id=202171373


   --row number: 18441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195616 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=202171374


   --row number: 18442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195616 , [Content] ='117,300 / 127,650 / 138,000 / 148,350 / 158,700'
 WHERE id=202171375


   --row number: 18443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3195616 , [Content] ='70/30'
 WHERE id=202171376


   --row number: 18444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195616 , [Content] ='Yes'
 WHERE id=202171377


   --row number: 18445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195616 , [Content] ='EXEMPT'
 WHERE id=202171378


   --row number: 18446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3195616 , [Content] ='NO'
 WHERE id=202171379


   --row number: 18447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195616 , [Content] ='4 - Sales Workers'
 WHERE id=202171380


   --row number: 18448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195616 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202171381


   --row number: 18449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195616 , [Content] ='Non Technical'
 WHERE id=202171382


   --row number: 18450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195616 , [Content] ='10/26/2018'
 WHERE id=202171383


   --row number: 18451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195643 , [Content] ='S1833 US - MRKT 2'
 WHERE id=202173262


   --row number: 18452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195643 , [Content] ='US - MRKT 2'
 WHERE id=202173263


   --row number: 18453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195643 , [Content] ='AMS'
 WHERE id=202173264


   --row number: 18454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195643 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202173265


   --row number: 18455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195643 , [Content] ='Sales Operations'
 WHERE id=202173266


   --row number: 18456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195643 , [Content] ='S1833 - Sales Operations Analyst IC3'
 WHERE id=202173267


   --row number: 18457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195643 , [Content] ='Sales Operations'
 WHERE id=202173268


   --row number: 18458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195643 , [Content] ='IC3'
 WHERE id=202173269


   --row number: 18459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195643 , [Content] ='USD'
 WHERE id=202173271


   --row number: 18460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195643 , [Content] ='60,200 / 70,100 / 80,000 / 89,950 / 99,900'
 WHERE id=202173272


   --row number: 18461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195643 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=202173273


   --row number: 18462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195643 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=202173274


   --row number: 18463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3195643 , [Content] ='10%'
 WHERE id=202173275


   --row number: 18464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195643 , [Content] ='Yes'
 WHERE id=202173276


   --row number: 18465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195643 , [Content] ='EXEMPT'
 WHERE id=202173277


   --row number: 18466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3195643 , [Content] ='NO'
 WHERE id=202173278


   --row number: 18467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195643 , [Content] ='2 - Professionals'
 WHERE id=202173279


   --row number: 18468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195643 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202173280


   --row number: 18469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195643 , [Content] ='Technical'
 WHERE id=202173281


   --row number: 18470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195643 , [Content] ='09/05/18'
 WHERE id=202173282


   --row number: 18471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195664 , [Content] ='S1414A US - MRKT 3'
 WHERE id=202175329


   --row number: 18472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195664 , [Content] ='US - MRKT 3'
 WHERE id=202175330


   --row number: 18473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195664 , [Content] ='AMS'
 WHERE id=202175331


   --row number: 18474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195664 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202175332


   --row number: 18475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195664 , [Content] ='Solution Consulting'
 WHERE id=202175333


   --row number: 18476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195664 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=202175334


   --row number: 18477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195664 , [Content] ='Solution Consultant Architect'
 WHERE id=202175335


   --row number: 18478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195664 , [Content] ='IC4'
 WHERE id=202175336


   --row number: 18479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195664 , [Content] ='USD'
 WHERE id=202175338


   --row number: 18480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195664 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=202175339


   --row number: 18481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195664 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=202175340


   --row number: 18482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195664 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=202175341


   --row number: 18483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3195664 , [Content] ='75/25'
 WHERE id=202175342


   --row number: 18484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195664 , [Content] ='Yes'
 WHERE id=202175343


   --row number: 18485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195664 , [Content] ='EXEMPT'
 WHERE id=202175344


   --row number: 18486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195664 , [Content] ='4 - Sales Workers'
 WHERE id=202175345


   --row number: 18487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195664 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202175346


   --row number: 18488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195664 , [Content] ='Technical'
 WHERE id=202175347


   --row number: 18489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195664 , [Content] ='09/05/18'
 WHERE id=202175348


   --row number: 18490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195682 , [Content] ='S1414 US - MRKT 3'
 WHERE id=202177593


   --row number: 18491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195682 , [Content] ='US - MRKT 3'
 WHERE id=202177594


   --row number: 18492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195682 , [Content] ='AMS'
 WHERE id=202177595


   --row number: 18493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195682 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202177596


   --row number: 18494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195682 , [Content] ='Solution Consulting'
 WHERE id=202177597


   --row number: 18495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195682 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=202177598


   --row number: 18496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195682 , [Content] ='Solution Consultant Core'
 WHERE id=202177599


   --row number: 18497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195682 , [Content] ='IC4'
 WHERE id=202177600


   --row number: 18498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195682 , [Content] ='USD'
 WHERE id=202177602


   --row number: 18499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195682 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=202177603


   --row number: 18500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195682 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=202177604


   --row number: 18501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195682 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=202177605


   --row number: 18502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3195682 , [Content] ='75/25'
 WHERE id=202177606


   --row number: 18503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195682 , [Content] ='Yes'
 WHERE id=202177607


   --row number: 18504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195682 , [Content] ='EXEMPT'
 WHERE id=202177608


   --row number: 18505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195682 , [Content] ='4 - Sales Workers'
 WHERE id=202177609


   --row number: 18506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195682 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202177610


   --row number: 18507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195682 , [Content] ='Technical'
 WHERE id=202177611


   --row number: 18508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195682 , [Content] ='09/05/18'
 WHERE id=202177612


   --row number: 18509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3195726 , [Content] ='5875 US - MRKT 2'
 WHERE id=202179444


   --row number: 18510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3195726 , [Content] ='US - MRKT 2'
 WHERE id=202179445


   --row number: 18511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3195726 , [Content] ='AMS'
 WHERE id=202179446


   --row number: 18512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3195726 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202179447


   --row number: 18513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3195726 , [Content] ='Professional Services'
 WHERE id=202179448


   --row number: 18514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3195726 , [Content] ='5875 - Engagement Mgr IC5'
 WHERE id=202179449


   --row number: 18515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3195726 , [Content] ='Engagement Mgrs'
 WHERE id=202179450


   --row number: 18516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3195726 , [Content] ='IC5'
 WHERE id=202179451


   --row number: 18517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3195726 , [Content] ='USD'
 WHERE id=202179453


   --row number: 18518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3195726 , [Content] ='104,600 / 128,150 / 151,700 / 175,200 / 198,700'
 WHERE id=202179454


   --row number: 18519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3195726 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=202179455


   --row number: 18520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3195726 , [Content] ='130,800 / 160,200 / 189,600 / 219,000 / 248,400'
 WHERE id=202179456


   --row number: 18521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3195726 , [Content] ='25%'
 WHERE id=202179457


   --row number: 18522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3195726 , [Content] ='Yes'
 WHERE id=202179458


   --row number: 18523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3195726 , [Content] ='EXEMPT'
 WHERE id=202179459


   --row number: 18524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3195726 , [Content] ='NO'
 WHERE id=202179460


   --row number: 18525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3195726 , [Content] ='2 - Professionals'
 WHERE id=202179461


   --row number: 18526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3195726 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202179462


   --row number: 18527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3195726 , [Content] ='Technical'
 WHERE id=202179463


   --row number: 18528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3195726 , [Content] ='09/05/18'
 WHERE id=202179464


   --row number: 18529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3196686 , [Content] ='5143 US - MRKT 2'
 WHERE id=202432987


   --row number: 18530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3196686 , [Content] ='US - MRKT 2'
 WHERE id=202432988


   --row number: 18531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3196686 , [Content] ='AMS'
 WHERE id=202432989


   --row number: 18532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3196686 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202432990


   --row number: 18533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3196686 , [Content] ='Engineering'
 WHERE id=202432991


   --row number: 18534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3196686 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202432992


   --row number: 18535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3196686 , [Content] ='Software'
 WHERE id=202432993


   --row number: 18536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3196686 , [Content] ='IC3'
 WHERE id=202432994


   --row number: 18537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3196686 , [Content] ='USD'
 WHERE id=202432996


   --row number: 18538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3196686 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202432997


   --row number: 18539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3196686 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202432998


   --row number: 18540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3196686 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202432999


   --row number: 18541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3196686 , [Content] ='15%'
 WHERE id=202433000


   --row number: 18542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3196686 , [Content] ='Yes'
 WHERE id=202433001


   --row number: 18543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3196686 , [Content] ='EXEMPT'
 WHERE id=202433002


   --row number: 18544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3196686 , [Content] ='NO'
 WHERE id=202433003


   --row number: 18545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3196686 , [Content] ='2 - Professionals'
 WHERE id=202433004


   --row number: 18546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3196686 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202433005


   --row number: 18547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3196686 , [Content] ='Technical'
 WHERE id=202433006


   --row number: 18548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3196686 , [Content] ='09/05/18'
 WHERE id=202433007


   --row number: 18549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3196994 , [Content] ='6365 IRL'
 WHERE id=202459298


   --row number: 18550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3196994 , [Content] ='IRL'
 WHERE id=202459299


   --row number: 18551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3196994 , [Content] ='EMEA'
 WHERE id=202459300


   --row number: 18552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3196994 , [Content] ='IRELAND'
 WHERE id=202459301


   --row number: 18553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3196994 , [Content] ='Legal'
 WHERE id=202459302


   --row number: 18554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3196994 , [Content] ='6365 - Paralegal IC5'
 WHERE id=202459303


   --row number: 18555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3196994 , [Content] ='Paralegal'
 WHERE id=202459304


   --row number: 18556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3196994 , [Content] ='IC5'
 WHERE id=202459305


   --row number: 18557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3196994 , [Content] ='EUR'
 WHERE id=202459307


   --row number: 18558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3196994 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=202459308


   --row number: 18559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3196994 , [Content] ='20%'
 WHERE id=202459309


   --row number: 18560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3196994 , [Content] ='Yes'
 WHERE id=202459310


   --row number: 18561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3196994 , [Content] ='2 - Professionals'
 WHERE id=202459311


   --row number: 18562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3196994 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202459312


   --row number: 18563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3196994 , [Content] ='Non Technical'
 WHERE id=202459313


   --row number: 18564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3196994 , [Content] ='09/05/18'
 WHERE id=202459314


   --row number: 18565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3196998 , [Content] ='S315 DEU'
 WHERE id=202459880


   --row number: 18566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3196998 , [Content] ='DEU'
 WHERE id=202459881


   --row number: 18567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3196998 , [Content] ='EMEA'
 WHERE id=202459882


   --row number: 18568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3196998 , [Content] ='GERMANY'
 WHERE id=202459883


   --row number: 18569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3196998 , [Content] ='Sales'
 WHERE id=202459884


   --row number: 18570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3196998 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=202459885


   --row number: 18571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3196998 , [Content] ='Sales Management'
 WHERE id=202459886


   --row number: 18572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3196998 , [Content] ='M5'
 WHERE id=202459887


   --row number: 18573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3196998 , [Content] ='EUR'
 WHERE id=202459889


   --row number: 18574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3196998 , [Content] ='102,850 / 111,925 / 121,000 / 130,075 / 139,150'
 WHERE id=202459890


   --row number: 18575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3196998 , [Content] ='114,000 / 171,000 / 228,000 / 285,000 / 342,000'
 WHERE id=202459891


   --row number: 18576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3196998 , [Content] ='205,700 / 223,850 / 242,000 / 260,150 / 278,300'
 WHERE id=202459892


   --row number: 18577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3196998 , [Content] ='50/50'
 WHERE id=202459893


   --row number: 18578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3196998 , [Content] ='Yes'
 WHERE id=202459894


   --row number: 18579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3196998 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202459895


   --row number: 18580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3196998 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202459896


   --row number: 18581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3196998 , [Content] ='Technical'
 WHERE id=202459897


   --row number: 18582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3196998 , [Content] ='09/05/18'
 WHERE id=202459898


   --row number: 18583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3197011 , [Content] ='5143 NLD'
 WHERE id=202461654


   --row number: 18584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3197011 , [Content] ='NLD'
 WHERE id=202461655


   --row number: 18585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3197011 , [Content] ='EMEA'
 WHERE id=202461656


   --row number: 18586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3197011 , [Content] ='NETHERLANDS'
 WHERE id=202461657


   --row number: 18587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3197011 , [Content] ='Engineering'
 WHERE id=202461658


   --row number: 18588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3197011 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202461659


   --row number: 18589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3197011 , [Content] ='Software'
 WHERE id=202461660


   --row number: 18590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3197011 , [Content] ='IC3'
 WHERE id=202461661


   --row number: 18591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3197011 , [Content] ='EUR'
 WHERE id=202461663


   --row number: 18592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3197011 , [Content] ='56,600 / 66,800 / 77,000 / 87,200 / 97,400'
 WHERE id=202461664


   --row number: 18593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3197011 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=202461665


   --row number: 18594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3197011 , [Content] ='65,100 / 76,850 / 88,600 / 100,300 / 112,000'
 WHERE id=202461666


   --row number: 18595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3197011 , [Content] ='15%'
 WHERE id=202461667


   --row number: 18596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3197011 , [Content] ='Yes'
 WHERE id=202461668


   --row number: 18597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3197011 , [Content] ='2 - Professionals'
 WHERE id=202461669


   --row number: 18598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3197011 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202461670


   --row number: 18599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3197011 , [Content] ='Technical'
 WHERE id=202461671


   --row number: 18600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3197011 , [Content] ='09/05/18'
 WHERE id=202461672


   --row number: 18601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3197058 , [Content] ='5874 NLD'
 WHERE id=202466748


   --row number: 18602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3197058 , [Content] ='NLD'
 WHERE id=202466749


   --row number: 18603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3197058 , [Content] ='EMEA'
 WHERE id=202466750


   --row number: 18604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3197058 , [Content] ='NETHERLANDS'
 WHERE id=202466751


   --row number: 18605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3197058 , [Content] ='Professional Services'
 WHERE id=202466752


   --row number: 18606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3197058 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=202466753


   --row number: 18607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3197058 , [Content] ='Engagement Mgrs'
 WHERE id=202466754


   --row number: 18608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3197058 , [Content] ='IC4'
 WHERE id=202466755


   --row number: 18609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3197058 , [Content] ='EUR'
 WHERE id=202466757


   --row number: 18610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3197058 , [Content] ='64,100 / 77,550 / 91,000 / 104,400 / 117,800'
 WHERE id=202466758


   --row number: 18611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3197058 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=202466759


   --row number: 18612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3197058 , [Content] ='76,900 / 93,050 / 109,200 / 125,300 / 141,400'
 WHERE id=202466760


   --row number: 18613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3197058 , [Content] ='20%'
 WHERE id=202466761


   --row number: 18614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3197058 , [Content] ='Yes'
 WHERE id=202466762


   --row number: 18615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3197058 , [Content] ='2 - Professionals'
 WHERE id=202466763


   --row number: 18616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3197058 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202466764


   --row number: 18617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3197058 , [Content] ='Technical'
 WHERE id=202466765


   --row number: 18618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3197058 , [Content] ='09/05/18'
 WHERE id=202466766


   --row number: 18619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3197105 , [Content] ='6503 US - MRKT 1'
 WHERE id=202472069


   --row number: 18620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3197105 , [Content] ='US - MRKT 1'
 WHERE id=202472070


   --row number: 18621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3197105 , [Content] ='AMS'
 WHERE id=202472071


   --row number: 18622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3197105 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202472072


   --row number: 18623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3197105 , [Content] ='Administration'
 WHERE id=202472073


   --row number: 18624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3197105 , [Content] ='6503 - Executive Assistant IC3'
 WHERE id=202472074


   --row number: 18625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3197105 , [Content] ='Executive Assistant'
 WHERE id=202472075


   --row number: 18626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3197105 , [Content] ='IC3'
 WHERE id=202472076


   --row number: 18627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3197105 , [Content] ='USD'
 WHERE id=202472078


   --row number: 18628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3197105 , [Content] ='83,700 / 97,500 / 111,300 / 125,100 / 138,900'
 WHERE id=202472079


   --row number: 18629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3197105 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=202472080


   --row number: 18630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3197105 , [Content] ='92,100 / 107,250 / 122,400 / 137,600 / 152,800'
 WHERE id=202472081


   --row number: 18631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3197105 , [Content] ='10%'
 WHERE id=202472082


   --row number: 18632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3197105 , [Content] ='Yes'
 WHERE id=202472083


   --row number: 18633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3197105 , [Content] ='NON-EXEMPT'
 WHERE id=202472084


   --row number: 18634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3197105 , [Content] ='NO'
 WHERE id=202472085


   --row number: 18635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3197105 , [Content] ='5 - Administrative Support Workers'
 WHERE id=202472086


   --row number: 18636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3197105 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202472087


   --row number: 18637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3197105 , [Content] ='Non Technical'
 WHERE id=202472088


   --row number: 18638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3197105 , [Content] ='09/05/18'
 WHERE id=202472089


   --row number: 18639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3197469 , [Content] ='2545 US - MRKT 1'
 WHERE id=202505048


   --row number: 18640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3197469 , [Content] ='US - MRKT 1'
 WHERE id=202505049


   --row number: 18641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3197469 , [Content] ='AMS'
 WHERE id=202505050


   --row number: 18642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3197469 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202505051


   --row number: 18643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3197469 , [Content] ='Marketing'
 WHERE id=202505052


   --row number: 18644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3197469 , [Content] ='2545 - Dir, Product Marketing Mgmt M5'
 WHERE id=202505053


   --row number: 18645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3197469 , [Content] ='Product Marketing'
 WHERE id=202505054


   --row number: 18646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3197469 , [Content] ='M5'
 WHERE id=202505055


   --row number: 18647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3197469 , [Content] ='USD'
 WHERE id=202505057


   --row number: 18648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3197469 , [Content] ='158,000 / 193,550 / 229,100 / 264,650 / 300,200'
 WHERE id=202505058


   --row number: 18649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3197469 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=202505059


   --row number: 18650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3197469 , [Content] ='197,500 / 241,950 / 286,400 / 330,850 / 375,300'
 WHERE id=202505060


   --row number: 18651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3197469 , [Content] ='25%'
 WHERE id=202505061


   --row number: 18652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3197469 , [Content] ='Yes'
 WHERE id=202505062


   --row number: 18653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3197469 , [Content] ='EXEMPT'
 WHERE id=202505063


   --row number: 18654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3197469 , [Content] ='NO'
 WHERE id=202505064


   --row number: 18655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3197469 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202505065


   --row number: 18656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3197469 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202505066


   --row number: 18657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3197469 , [Content] ='Technical'
 WHERE id=202505067


   --row number: 18658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3197469 , [Content] ='09/05/18'
 WHERE id=202505068


   --row number: 18659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3197624 , [Content] ='5225 US - MRKT 1'
 WHERE id=202519427


   --row number: 18660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3197624 , [Content] ='US - MRKT 1'
 WHERE id=202519428


   --row number: 18661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3197624 , [Content] ='AMS'
 WHERE id=202519429


   --row number: 18662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3197624 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202519430


   --row number: 18663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3197624 , [Content] ='Engineering'
 WHERE id=202519431


   --row number: 18664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3197624 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=202519432


   --row number: 18665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3197624 , [Content] ='Product Mgmt Mgr'
 WHERE id=202519433


   --row number: 18666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3197624 , [Content] ='IC5'
 WHERE id=202519434


   --row number: 18667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3197624 , [Content] ='USD'
 WHERE id=202519436


   --row number: 18668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3197624 , [Content] ='123,800 / 151,650 / 179,500 / 207,350 / 235,200'
 WHERE id=202519437


   --row number: 18669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3197624 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=202519438


   --row number: 18670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3197624 , [Content] ='154,800 / 189,600 / 224,400 / 259,200 / 294,000'
 WHERE id=202519439


   --row number: 18671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3197624 , [Content] ='25%'
 WHERE id=202519440


   --row number: 18672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3197624 , [Content] ='Yes'
 WHERE id=202519441


   --row number: 18673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3197624 , [Content] ='EXEMPT'
 WHERE id=202519442


   --row number: 18674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3197624 , [Content] ='NO'
 WHERE id=202519443


   --row number: 18675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3197624 , [Content] ='2 - Professionals'
 WHERE id=202519444


   --row number: 18676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3197624 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202519445


   --row number: 18677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3197624 , [Content] ='Technical'
 WHERE id=202519446


   --row number: 18678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3197624 , [Content] ='09/05/18'
 WHERE id=202519447


   --row number: 18679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3197840 , [Content] ='2536 US - MRKT 1'
 WHERE id=202538297


   --row number: 18680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3197840 , [Content] ='US - MRKT 1'
 WHERE id=202538298


   --row number: 18681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3197840 , [Content] ='AMS'
 WHERE id=202538299


   --row number: 18682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3197840 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202538300


   --row number: 18683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3197840 , [Content] ='Marketing'
 WHERE id=202538301


   --row number: 18684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3197840 , [Content] ='2536 - Sr Dir, Public/Analyst Relations Mgmt M6'
 WHERE id=202538302


   --row number: 18685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3197840 , [Content] ='Public Relations'
 WHERE id=202538303


   --row number: 18686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3197840 , [Content] ='M6'
 WHERE id=202538304


   --row number: 18687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3197840 , [Content] ='USD'
 WHERE id=202538306


   --row number: 18688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3197840 , [Content] ='155,000 / 189,900 / 224,800 / 259,650 / 294,500'
 WHERE id=202538307


   --row number: 18689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3197840 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=202538308


   --row number: 18690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3197840 , [Content] ='201,500 / 246,850 / 292,200 / 337,550 / 382,900'
 WHERE id=202538309


   --row number: 18691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3197840 , [Content] ='30%'
 WHERE id=202538310


   --row number: 18692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3197840 , [Content] ='Yes'
 WHERE id=202538311


   --row number: 18693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3197840 , [Content] ='EXEMPT'
 WHERE id=202538312


   --row number: 18694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3197840 , [Content] ='NO'
 WHERE id=202538313


   --row number: 18695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3197840 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202538314


   --row number: 18696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3197840 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202538315


   --row number: 18697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3197840 , [Content] ='Non Technical'
 WHERE id=202538316


   --row number: 18698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3197840 , [Content] ='09/05/18'
 WHERE id=202538317


   --row number: 18699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3198719 , [Content] ='S1403 NLD'
 WHERE id=202640749


   --row number: 18700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3198719 , [Content] ='NLD'
 WHERE id=202640750


   --row number: 18701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3198719 , [Content] ='EMEA'
 WHERE id=202640751


   --row number: 18702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3198719 , [Content] ='NETHERLANDS'
 WHERE id=202640752


   --row number: 18703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3198719 , [Content] ='Solution Consulting'
 WHERE id=202640753


   --row number: 18704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3198719 , [Content] ='S1403 - Mgr, Solution Consulting M3'
 WHERE id=202640754


   --row number: 18705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3198719 , [Content] ='Solution Consultant Core'
 WHERE id=202640755


   --row number: 18706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3198719 , [Content] ='M3'
 WHERE id=202640756


   --row number: 18707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3198719 , [Content] ='EUR'
 WHERE id=202640758


   --row number: 18708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3198719 , [Content] ='89,569 / 97,472 / 105,375 / 113,278 / 121,181'
 WHERE id=202640759


   --row number: 18709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3198719 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=202640760


   --row number: 18710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3198719 , [Content] ='119,425 / 129,963 / 140,500 / 151,038 / 161,575'
 WHERE id=202640761


   --row number: 18711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3198719 , [Content] ='75/25'
 WHERE id=202640762


   --row number: 18712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3198719 , [Content] ='Yes'
 WHERE id=202640763


   --row number: 18713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3198719 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202640764


   --row number: 18714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3198719 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202640765


   --row number: 18715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3198719 , [Content] ='Technical'
 WHERE id=202640766


   --row number: 18716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3198719 , [Content] ='09/05/18'
 WHERE id=202640767


   --row number: 18717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3199312 , [Content] ='5223 US - MRKT 2'
 WHERE id=202697494


   --row number: 18718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3199312 , [Content] ='US - MRKT 2'
 WHERE id=202697495


   --row number: 18719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3199312 , [Content] ='AMS'
 WHERE id=202697496


   --row number: 18720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3199312 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202697497


   --row number: 18721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3199312 , [Content] ='Engineering'
 WHERE id=202697498


   --row number: 18722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3199312 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=202697499


   --row number: 18723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3199312 , [Content] ='Product Mgmt Mgr'
 WHERE id=202697500


   --row number: 18724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3199312 , [Content] ='IC3'
 WHERE id=202697501


   --row number: 18725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3199312 , [Content] ='USD'
 WHERE id=202697503


   --row number: 18726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3199312 , [Content] ='89,000 / 105,000 / 121,000 / 137,050 / 153,100'
 WHERE id=202697504


   --row number: 18727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3199312 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202697505


   --row number: 18728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3199312 , [Content] ='102,400 / 120,800 / 139,200 / 157,650 / 176,100'
 WHERE id=202697506


   --row number: 18729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3199312 , [Content] ='15%'
 WHERE id=202697507


   --row number: 18730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3199312 , [Content] ='Yes'
 WHERE id=202697508


   --row number: 18731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3199312 , [Content] ='EXEMPT'
 WHERE id=202697509


   --row number: 18732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3199312 , [Content] ='NO'
 WHERE id=202697510


   --row number: 18733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3199312 , [Content] ='2 - Professionals'
 WHERE id=202697511


   --row number: 18734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3199312 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202697512


   --row number: 18735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3199312 , [Content] ='Technical'
 WHERE id=202697513


   --row number: 18736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3199312 , [Content] ='09/05/18'
 WHERE id=202697514


   --row number: 18737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3199324 , [Content] ='5222 US - MRKT 2'
 WHERE id=202698225


   --row number: 18738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3199324 , [Content] ='US - MRKT 2'
 WHERE id=202698226


   --row number: 18739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3199324 , [Content] ='AMS'
 WHERE id=202698227


   --row number: 18740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3199324 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202698228


   --row number: 18741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3199324 , [Content] ='Engineering'
 WHERE id=202698229


   --row number: 18742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3199324 , [Content] ='5222 - Product Mgmt Mgr IC2'
 WHERE id=202698230


   --row number: 18743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3199324 , [Content] ='Product Mgmt Mgr'
 WHERE id=202698231


   --row number: 18744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3199324 , [Content] ='IC2'
 WHERE id=202698232


   --row number: 18745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3199324 , [Content] ='USD'
 WHERE id=202698234


   --row number: 18746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3199324 , [Content] ='76,600 / 89,250 / 101,900 / 114,550 / 127,200'
 WHERE id=202698235


   --row number: 18747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3199324 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=202698236


   --row number: 18748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3199324 , [Content] ='84,300 / 98,200 / 112,100 / 126,000 / 139,900'
 WHERE id=202698237


   --row number: 18749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3199331 , [Content] ='Engineering'
 WHERE id=202698727


   --row number: 18750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3199331 , [Content] ='5222 - Product Mgmt Mgr IC2'
 WHERE id=202698728


   --row number: 18751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3199331 , [Content] ='Product Mgmt Mgr'
 WHERE id=202698729


   --row number: 18752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3199331 , [Content] ='IC2'
 WHERE id=202698730


   --row number: 18753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3199331 , [Content] ='USD'
 WHERE id=202698732


   --row number: 18754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3199331 , [Content] ='76,600 / 89,250 / 101,900 / 114,550 / 127,200'
 WHERE id=202698733


   --row number: 18755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3199331 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=202698734


   --row number: 18756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3199331 , [Content] ='84,300 / 98,200 / 112,100 / 126,000 / 139,900'
 WHERE id=202698735


   --row number: 18757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3199331 , [Content] ='10%'
 WHERE id=202698736


   --row number: 18758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3199331 , [Content] ='Yes'
 WHERE id=202698737


   --row number: 18759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3199331 , [Content] ='EXEMPT'
 WHERE id=202698738


   --row number: 18760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3199331 , [Content] ='NO'
 WHERE id=202698739


   --row number: 18761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3199331 , [Content] ='2 - Professionals'
 WHERE id=202698740


   --row number: 18762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3199331 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202698741


   --row number: 18763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3199331 , [Content] ='Technical'
 WHERE id=202698742


   --row number: 18764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3199331 , [Content] ='09/05/18'
 WHERE id=202698743


   --row number: 18765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3199331 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202698726


   --row number: 18766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3199331 , [Content] ='AMS'
 WHERE id=202698725


   --row number: 18767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3199331 , [Content] ='US - MRKT 2'
 WHERE id=202698724


   --row number: 18768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3199331 , [Content] ='5222 US - MRKT 2'
 WHERE id=202698723


   --row number: 18769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3199324 , [Content] ='09/05/18'
 WHERE id=202698245


   --row number: 18770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3199324 , [Content] ='Technical'
 WHERE id=202698244


   --row number: 18771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3199324 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202698243


   --row number: 18772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3199324 , [Content] ='2 - Professionals'
 WHERE id=202698242


   --row number: 18773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3199324 , [Content] ='NO'
 WHERE id=202698241


   --row number: 18774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3199324 , [Content] ='EXEMPT'
 WHERE id=202698240


   --row number: 18775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3199324 , [Content] ='Yes'
 WHERE id=202698239


   --row number: 18776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3199324 , [Content] ='10%'
 WHERE id=202698238


   --row number: 18777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3199554 , [Content] ='Yes'
 WHERE id=202719398


   --row number: 18778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3199554 , [Content] ='EXEMPT'
 WHERE id=202719399


   --row number: 18779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3199554 , [Content] ='2 - Professionals'
 WHERE id=202719400


   --row number: 18780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3199554 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202719401


   --row number: 18781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3199554 , [Content] ='Technical'
 WHERE id=202719402


   --row number: 18782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3199554 , [Content] ='09/05/18'
 WHERE id=202719403


   --row number: 18783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3199554 , [Content] ='4684 US - MRKT 3'
 WHERE id=202719384


   --row number: 18784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3199554 , [Content] ='US - MRKT 3'
 WHERE id=202719385


   --row number: 18785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3199554 , [Content] ='AMS'
 WHERE id=202719386


   --row number: 18786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3199554 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202719387


   --row number: 18787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3199554 , [Content] ='Business Strategy'
 WHERE id=202719388


   --row number: 18788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3199554 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=202719389


   --row number: 18789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3199554 , [Content] ='Business Process'
 WHERE id=202719390


   --row number: 18790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3199554 , [Content] ='IC4'
 WHERE id=202719391


   --row number: 18791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3199554 , [Content] ='USD'
 WHERE id=202719393


   --row number: 18792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3199554 , [Content] ='80,300 / 94,750 / 109,200 / 123,650 / 138,100'
 WHERE id=202719394


   --row number: 18793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3199554 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=202719395


   --row number: 18794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3199554 , [Content] ='92,300 / 108,950 / 125,600 / 142,200 / 158,800'
 WHERE id=202719396


   --row number: 18795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3199554 , [Content] ='15%'
 WHERE id=202719397


   --row number: 18796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3199627 , [Content] ='NO'
 WHERE id=202725140


   --row number: 18797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3199627 , [Content] ='4 - Sales Workers'
 WHERE id=202725141


   --row number: 18798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3199627 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202725142


   --row number: 18799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3199627 , [Content] ='Technical'
 WHERE id=202725143


   --row number: 18800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3199627 , [Content] ='09/05/18'
 WHERE id=202725144


   --row number: 18801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3199627 , [Content] ='S1332-SC US - MRKT 2'
 WHERE id=202725125


   --row number: 18802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3199627 , [Content] ='US - MRKT 2'
 WHERE id=202725126


   --row number: 18803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3199627 , [Content] ='AMS'
 WHERE id=202725127


   --row number: 18804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3199627 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202725128


   --row number: 18805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3199627 , [Content] ='Solution Consulting'
 WHERE id=202725129


   --row number: 18806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3199627 , [Content] ='S1332-SC - Associate Solution Consultant A2'
 WHERE id=202725130


   --row number: 18807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3199627 , [Content] ='Solution Consultant Core'
 WHERE id=202725131


   --row number: 18808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3199627 , [Content] ='A2'
 WHERE id=202725132


   --row number: 18809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3199627 , [Content] ='USD'
 WHERE id=202725134


   --row number: 18810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3199627 , [Content] ='49,406 / 53,766 / 58,125 / 62,484 / 66,844'
 WHERE id=202725135


   --row number: 18811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3199627 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=202725136


   --row number: 18812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3199627 , [Content] ='75/25'
 WHERE id=202725137


   --row number: 18813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3199627 , [Content] ='No'
 WHERE id=202725138


   --row number: 18814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3199627 , [Content] ='NON-EXEMPT'
 WHERE id=202725139


   --row number: 18815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200009 , [Content] ='Yes'
 WHERE id=202757148


   --row number: 18816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200009 , [Content] ='EXEMPT'
 WHERE id=202757149


   --row number: 18817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200009 , [Content] ='NO'
 WHERE id=202757150


   --row number: 18818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200009 , [Content] ='2 - Professionals'
 WHERE id=202757151


   --row number: 18819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200009 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202757152


   --row number: 18820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200009 , [Content] ='Technical'
 WHERE id=202757153


   --row number: 18821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200009 , [Content] ='09/05/18'
 WHERE id=202757154


   --row number: 18822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200009 , [Content] ='5141 US - MRKT 1'
 WHERE id=202757134


   --row number: 18823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200009 , [Content] ='US - MRKT 1'
 WHERE id=202757135


   --row number: 18824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200009 , [Content] ='AMS'
 WHERE id=202757136


   --row number: 18825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200009 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202757137


   --row number: 18826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200009 , [Content] ='Engineering'
 WHERE id=202757138


   --row number: 18827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200009 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=202757139


   --row number: 18828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200009 , [Content] ='Software'
 WHERE id=202757140


   --row number: 18829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200009 , [Content] ='IC1'
 WHERE id=202757141


   --row number: 18830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200009 , [Content] ='USD'
 WHERE id=202757143


   --row number: 18831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200009 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=202757144


   --row number: 18832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200009 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=202757145


   --row number: 18833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200009 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=202757146


   --row number: 18834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200009 , [Content] ='10%'
 WHERE id=202757147


   --row number: 18835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200031 , [Content] ='6296 US - MRKT 1'
 WHERE id=202758895


   --row number: 18836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200031 , [Content] ='US - MRKT 1'
 WHERE id=202758896


   --row number: 18837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200031 , [Content] ='AMS'
 WHERE id=202758897


   --row number: 18838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200031 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202758898


   --row number: 18839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200031 , [Content] ='Human Resources'
 WHERE id=202758899


   --row number: 18840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200031 , [Content] ='6296 - HRBP IC6'
 WHERE id=202758900


   --row number: 18841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200031 , [Content] ='Business Partners'
 WHERE id=202758901


   --row number: 18842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200031 , [Content] ='IC6'
 WHERE id=202758902


   --row number: 18843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200031 , [Content] ='Yes'
 WHERE id=202758909


   --row number: 18844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200031 , [Content] ='EXEMPT'
 WHERE id=202758910


   --row number: 18845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200031 , [Content] ='NO'
 WHERE id=202758911


   --row number: 18846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200031 , [Content] ='2 - Professionals'
 WHERE id=202758912


   --row number: 18847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200031 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202758913


   --row number: 18848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200031 , [Content] ='Non Technical'
 WHERE id=202758914


   --row number: 18849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200031 , [Content] ='09/05/18'
 WHERE id=202758915


   --row number: 18850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200031 , [Content] ='USD'
 WHERE id=202758904


   --row number: 18851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200031 , [Content] ='143,400 / 175,700 / 208,000 / 240,250 / 272,500'
 WHERE id=202758905


   --row number: 18852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200031 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=202758906


   --row number: 18853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200031 , [Content] ='179,300 / 219,650 / 260,000 / 300,300 / 340,600'
 WHERE id=202758907


   --row number: 18854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200031 , [Content] ='25%'
 WHERE id=202758908


   --row number: 18855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200039 , [Content] ='5141 US - MRKT 1'
 WHERE id=202759783


   --row number: 18856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200039 , [Content] ='Yes'
 WHERE id=202759797


   --row number: 18857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200039 , [Content] ='EXEMPT'
 WHERE id=202759798


   --row number: 18858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200039 , [Content] ='NO'
 WHERE id=202759799


   --row number: 18859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200039 , [Content] ='2 - Professionals'
 WHERE id=202759800


   --row number: 18860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200039 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202759801


   --row number: 18861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200039 , [Content] ='Technical'
 WHERE id=202759802


   --row number: 18862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200039 , [Content] ='09/05/18'
 WHERE id=202759803


   --row number: 18863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200039 , [Content] ='US - MRKT 1'
 WHERE id=202759784


   --row number: 18864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200039 , [Content] ='AMS'
 WHERE id=202759785


   --row number: 18865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200039 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202759786


   --row number: 18866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200039 , [Content] ='Engineering'
 WHERE id=202759787


   --row number: 18867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200039 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=202759788


   --row number: 18868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200039 , [Content] ='Software'
 WHERE id=202759789


   --row number: 18869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200039 , [Content] ='IC1'
 WHERE id=202759790


   --row number: 18870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200039 , [Content] ='USD'
 WHERE id=202759792


   --row number: 18871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200039 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=202759793


   --row number: 18872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200039 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=202759794


   --row number: 18873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200039 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=202759795


   --row number: 18874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200039 , [Content] ='10%'
 WHERE id=202759796


   --row number: 18875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200402 , [Content] ='5174 US - MRKT 1'
 WHERE id=202792044


   --row number: 18876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200402 , [Content] ='US - MRKT 1'
 WHERE id=202792045


   --row number: 18877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200402 , [Content] ='AMS'
 WHERE id=202792046


   --row number: 18878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200402 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202792047


   --row number: 18879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200402 , [Content] ='Engineering'
 WHERE id=202792048


   --row number: 18880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200402 , [Content] ='5174 - Machine Learning Engineer IC4'
 WHERE id=202792049


   --row number: 18881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200402 , [Content] ='Machine Learning'
 WHERE id=202792050


   --row number: 18882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200402 , [Content] ='IC4'
 WHERE id=202792051


   --row number: 18883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200402 , [Content] ='USD'
 WHERE id=202792053


   --row number: 18884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200402 , [Content] ='126,800 / 153,400 / 180,000 / 206,550 / 233,100'
 WHERE id=202792054


   --row number: 18885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200402 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202792055


   --row number: 18886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200401 , [Content] ='9999 US - MRKT 2'
 WHERE id=202792011


   --row number: 18887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200401 , [Content] ='US - MRKT 2'
 WHERE id=202792012


   --row number: 18888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200401 , [Content] ='AMS'
 WHERE id=202792013


   --row number: 18889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200401 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202792014


   --row number: 18890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200401 , [Content] ='9999 - Intern'
 WHERE id=202792015


   --row number: 18891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200401 , [Content] ='Intern'
 WHERE id=202792016


   --row number: 18892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200401 , [Content] ='No'
 WHERE id=202792017


   --row number: 18893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200401 , [Content] ='NON-EXEMPT'
 WHERE id=202792018


   --row number: 18894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200402 , [Content] ='152,200 / 184,100 / 216,000 / 247,850 / 279,700'
 WHERE id=202792056


   --row number: 18895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200402 , [Content] ='20%'
 WHERE id=202792057


   --row number: 18896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200402 , [Content] ='Yes'
 WHERE id=202792058


   --row number: 18897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200402 , [Content] ='EXEMPT'
 WHERE id=202792059


   --row number: 18898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200402 , [Content] ='NO'
 WHERE id=202792060


   --row number: 18899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200402 , [Content] ='2 - Professionals'
 WHERE id=202792061


   --row number: 18900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200402 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202792062


   --row number: 18901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200402 , [Content] ='Technical'
 WHERE id=202792063


   --row number: 18902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200402 , [Content] ='09/05/18'
 WHERE id=202792064


   --row number: 18903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200428 , [Content] ='Professional Services'
 WHERE id=202801466


   --row number: 18904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200428 , [Content] ='EXEMPT'
 WHERE id=202801477


   --row number: 18905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200428 , [Content] ='NO'
 WHERE id=202801478


   --row number: 18906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200428 , [Content] ='2 - Professionals'
 WHERE id=202801479


   --row number: 18907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200428 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202801480


   --row number: 18908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200428 , [Content] ='Technical'
 WHERE id=202801481


   --row number: 18909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200428 , [Content] ='09/05/18'
 WHERE id=202801482


   --row number: 18910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200428 , [Content] ='5873 - Engagement Mgr IC3'
 WHERE id=202801467


   --row number: 18911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200428 , [Content] ='Engagement Mgrs'
 WHERE id=202801468


   --row number: 18912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200428 , [Content] ='IC3'
 WHERE id=202801469


   --row number: 18913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200428 , [Content] ='USD'
 WHERE id=202801471


   --row number: 18914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200428 , [Content] ='80,300 / 94,750 / 109,200 / 123,650 / 138,100'
 WHERE id=202801472


   --row number: 18915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200428 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=202801473


   --row number: 18916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200428 , [Content] ='92,300 / 108,950 / 125,600 / 142,200 / 158,800'
 WHERE id=202801474


   --row number: 18917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200428 , [Content] ='15%'
 WHERE id=202801475


   --row number: 18918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200428 , [Content] ='Yes'
 WHERE id=202801476


   --row number: 18919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200428 , [Content] ='5873 US - MRKT 2'
 WHERE id=202801462


   --row number: 18920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200428 , [Content] ='US - MRKT 2'
 WHERE id=202801463


   --row number: 18921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200428 , [Content] ='AMS'
 WHERE id=202801464


   --row number: 18922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200428 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202801465


   --row number: 18923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200508 , [Content] ='Yes'
 WHERE id=202815423


   --row number: 18924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200508 , [Content] ='4 - Sales Workers'
 WHERE id=202815424


   --row number: 18925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200508 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202815425


   --row number: 18926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200508 , [Content] ='Technical'
 WHERE id=202815426


   --row number: 18927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200508 , [Content] ='09/05/18'
 WHERE id=202815427


   --row number: 18928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200508 , [Content] ='S1414 AUS'
 WHERE id=202815409


   --row number: 18929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200508 , [Content] ='AUS'
 WHERE id=202815410


   --row number: 18930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200508 , [Content] ='APAC'
 WHERE id=202815411


   --row number: 18931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200508 , [Content] ='AUSTRALIA'
 WHERE id=202815412


   --row number: 18932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200508 , [Content] ='Solution Consulting'
 WHERE id=202815413


   --row number: 18933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200508 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=202815414


   --row number: 18934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200508 , [Content] ='Solution Consultant Core'
 WHERE id=202815415


   --row number: 18935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200508 , [Content] ='IC4'
 WHERE id=202815416


   --row number: 18936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200508 , [Content] ='AUD'
 WHERE id=202815418


   --row number: 18937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200508 , [Content] ='146,625 / 159,563 / 172,500 / 185,438 / 198,375'
 WHERE id=202815419


   --row number: 18938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200508 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=202815420


   --row number: 18939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200508 , [Content] ='195,500 / 212,750 / 230,000 / 247,250 / 264,500'
 WHERE id=202815421


   --row number: 18940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200508 , [Content] ='75/25'
 WHERE id=202815422


   --row number: 18941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200563 , [Content] ='2 - Professionals'
 WHERE id=202824832


   --row number: 18942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200563 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202824833


   --row number: 18943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200563 , [Content] ='Non Technical'
 WHERE id=202824834


   --row number: 18944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200563 , [Content] ='09/05/18'
 WHERE id=202824835


   --row number: 18945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200563 , [Content] ='6722 SGP'
 WHERE id=202824817


   --row number: 18946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200563 , [Content] ='SGP'
 WHERE id=202824818


   --row number: 18947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200563 , [Content] ='APAC'
 WHERE id=202824819


   --row number: 18948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200563 , [Content] ='SINGAPORE'
 WHERE id=202824820


   --row number: 18949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200563 , [Content] ='Administration'
 WHERE id=202824821


   --row number: 18950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200563 , [Content] ='6722 - Purchasing Analyst IC2'
 WHERE id=202824822


   --row number: 18951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200563 , [Content] ='Procurement'
 WHERE id=202824823


   --row number: 18952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200563 , [Content] ='IC2'
 WHERE id=202824824


   --row number: 18953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200563 , [Content] ='SGD'
 WHERE id=202824826


   --row number: 18954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200563 , [Content] ='47,000 / 53,700 / 60,400 / 67,100 / 73,800'
 WHERE id=202824827


   --row number: 18955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200563 , [Content] ='19,200 / 26,400 / 33,600 / 40,800 / 48,000'
 WHERE id=202824828


   --row number: 18956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200563 , [Content] ='51,700 / 59,050 / 66,400 / 73,800 / 81,200'
 WHERE id=202824829


   --row number: 18957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200563 , [Content] ='10%'
 WHERE id=202824830


   --row number: 18958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200563 , [Content] ='Yes'
 WHERE id=202824831


   --row number: 18959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200584 , [Content] ='259,250 / 282,125 / 305,000 / 327,875 / 350,750'
 WHERE id=202832961


   --row number: 18960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200584 , [Content] ='Yes'
 WHERE id=202832963


   --row number: 18961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200584 , [Content] ='EXEMPT'
 WHERE id=202832964


   --row number: 18962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200584 , [Content] ='NO'
 WHERE id=202832965


   --row number: 18963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200584 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202832966


   --row number: 18964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200584 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202832967


   --row number: 18965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200584 , [Content] ='Technical'
 WHERE id=202832968


   --row number: 18966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200584 , [Content] ='09/05/18'
 WHERE id=202832969


   --row number: 18967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200584 , [Content] ='50/50'
 WHERE id=202832962


   --row number: 18968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200584 , [Content] ='S313 US - MRKT 1'
 WHERE id=202832949


   --row number: 18969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200584 , [Content] ='US - MRKT 1'
 WHERE id=202832950


   --row number: 18970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200584 , [Content] ='AMS'
 WHERE id=202832951


   --row number: 18971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200584 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202832952


   --row number: 18972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200584 , [Content] ='Sales'
 WHERE id=202832953


   --row number: 18973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200584 , [Content] ='S313 - Mgr, Sales M3'
 WHERE id=202832954


   --row number: 18974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200584 , [Content] ='Sales Management'
 WHERE id=202832955


   --row number: 18975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200584 , [Content] ='M3'
 WHERE id=202832956


   --row number: 18976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200584 , [Content] ='USD'
 WHERE id=202832958


   --row number: 18977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200584 , [Content] ='129,625 / 141,063 / 152,500 / 163,938 / 175,375'
 WHERE id=202832959


   --row number: 18978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200584 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=202832960


   --row number: 18979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200587 , [Content] ='NO'
 WHERE id=202834030


   --row number: 18980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200587 , [Content] ='2 - Professionals'
 WHERE id=202834031


   --row number: 18981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200587 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202834032


   --row number: 18982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200587 , [Content] ='Technical'
 WHERE id=202834033


   --row number: 18983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200587 , [Content] ='09/05/18'
 WHERE id=202834034


   --row number: 18984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200587 , [Content] ='Yes'
 WHERE id=202834028


   --row number: 18985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200587 , [Content] ='EXEMPT'
 WHERE id=202834029


   --row number: 18986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200587 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=202834025


   --row number: 18987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200587 , [Content] ='116,600 / 141,100 / 165,600 / 190,000 / 214,400'
 WHERE id=202834026


   --row number: 18988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200587 , [Content] ='20%'
 WHERE id=202834027


   --row number: 18989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200587 , [Content] ='5874 US - MRKT 1'
 WHERE id=202834014


   --row number: 18990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200587 , [Content] ='US - MRKT 1'
 WHERE id=202834015


   --row number: 18991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200587 , [Content] ='AMS'
 WHERE id=202834016


   --row number: 18992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200587 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202834017


   --row number: 18993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200587 , [Content] ='Professional Services'
 WHERE id=202834018


   --row number: 18994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200587 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=202834019


   --row number: 18995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200587 , [Content] ='Engagement Mgrs'
 WHERE id=202834020


   --row number: 18996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200587 , [Content] ='IC4'
 WHERE id=202834021


   --row number: 18997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200587 , [Content] ='USD'
 WHERE id=202834023


   --row number: 18998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200587 , [Content] ='97,200 / 117,600 / 138,000 / 158,350 / 178,700'
 WHERE id=202834024


   --row number: 18999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200591 , [Content] ='Yes'
 WHERE id=202834832


   --row number: 19000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200591 , [Content] ='EXEMPT'
 WHERE id=202834833


   --row number: 19001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200591 , [Content] ='NO'
 WHERE id=202834834


   --row number: 19002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200591 , [Content] ='4 - Sales Workers'
 WHERE id=202834835


   --row number: 19003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200591 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202834836


   --row number: 19004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200591 , [Content] ='Technical'
 WHERE id=202834837


   --row number: 19005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200591 , [Content] ='09/05/18'
 WHERE id=202834838


   --row number: 19006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200591 , [Content] ='S665 US - MRKT 1'
 WHERE id=202834818


   --row number: 19007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200591 , [Content] ='US - MRKT 1'
 WHERE id=202834819


   --row number: 19008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200591 , [Content] ='AMS'
 WHERE id=202834820


   --row number: 19009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200591 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202834821


   --row number: 19010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200591 , [Content] ='Sales'
 WHERE id=202834822


   --row number: 19011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200591 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=202834823


   --row number: 19012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200591 , [Content] ='Product Line Sales'
 WHERE id=202834824


   --row number: 19013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200591 , [Content] ='IC5'
 WHERE id=202834825


   --row number: 19014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200591 , [Content] ='USD'
 WHERE id=202834827


   --row number: 19015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200591 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=202834828


   --row number: 19016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200591 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=202834829


   --row number: 19017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200591 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=202834830


   --row number: 19018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200591 , [Content] ='60/40'
 WHERE id=202834831


   --row number: 19019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200594 , [Content] ='Yes'
 WHERE id=202837798


   --row number: 19020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200594 , [Content] ='EXEMPT'
 WHERE id=202837799


   --row number: 19021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200594 , [Content] ='NO'
 WHERE id=202837800


   --row number: 19022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200594 , [Content] ='2 - Professionals'
 WHERE id=202837801


   --row number: 19023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200594 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202837802


   --row number: 19024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200594 , [Content] ='Technical'
 WHERE id=202837803


   --row number: 19025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200594 , [Content] ='09/05/18'
 WHERE id=202837804


   --row number: 19026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200594 , [Content] ='5874 US - MRKT 1'
 WHERE id=202837784


   --row number: 19027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200594 , [Content] ='US - MRKT 1'
 WHERE id=202837785


   --row number: 19028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200594 , [Content] ='AMS'
 WHERE id=202837786


   --row number: 19029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200594 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202837787


   --row number: 19030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200594 , [Content] ='Professional Services'
 WHERE id=202837788


   --row number: 19031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200594 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=202837789


   --row number: 19032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200594 , [Content] ='Engagement Mgrs'
 WHERE id=202837790


   --row number: 19033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200594 , [Content] ='IC4'
 WHERE id=202837791


   --row number: 19034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200594 , [Content] ='USD'
 WHERE id=202837793


   --row number: 19035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200594 , [Content] ='97,200 / 117,600 / 138,000 / 158,350 / 178,700'
 WHERE id=202837794


   --row number: 19036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200594 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=202837795


   --row number: 19037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200594 , [Content] ='116,600 / 141,100 / 165,600 / 190,000 / 214,400'
 WHERE id=202837796


   --row number: 19038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3200594 , [Content] ='20%'
 WHERE id=202837797


   --row number: 19039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3200596 , [Content] ='EXEMPT'
 WHERE id=202838130


   --row number: 19040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3200596 , [Content] ='NO'
 WHERE id=202838131


   --row number: 19041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200596 , [Content] ='4 - Sales Workers'
 WHERE id=202838132


   --row number: 19042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200596 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202838133


   --row number: 19043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200596 , [Content] ='Technical'
 WHERE id=202838134


   --row number: 19044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200596 , [Content] ='09/05/18'
 WHERE id=202838135


   --row number: 19045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200596 , [Content] ='50/50'
 WHERE id=202838128


   --row number: 19046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200596 , [Content] ='Yes'
 WHERE id=202838129


   --row number: 19047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200596 , [Content] ='S635 US - MRKT 1'
 WHERE id=202838115


   --row number: 19048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200596 , [Content] ='US - MRKT 1'
 WHERE id=202838116


   --row number: 19049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200596 , [Content] ='AMS'
 WHERE id=202838117


   --row number: 19050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200596 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202838118


   --row number: 19051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200596 , [Content] ='Sales'
 WHERE id=202838119


   --row number: 19052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200596 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=202838120


   --row number: 19053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200596 , [Content] ='Enterprise Accounts'
 WHERE id=202838121


   --row number: 19054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200596 , [Content] ='IC5'
 WHERE id=202838122


   --row number: 19055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200596 , [Content] ='USD'
 WHERE id=202838124


   --row number: 19056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200596 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=202838125


   --row number: 19057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200596 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=202838126


   --row number: 19058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200596 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=202838127


   --row number: 19059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200774 , [Content] ='4 - Sales Workers'
 WHERE id=202861998


   --row number: 19060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200774 , [Content] ='S665 DNK'
 WHERE id=202861984


   --row number: 19061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200774 , [Content] ='DNK'
 WHERE id=202861985


   --row number: 19062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200774 , [Content] ='EMEA'
 WHERE id=202861986


   --row number: 19063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200774 , [Content] ='DENMARK'
 WHERE id=202861987


   --row number: 19064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200774 , [Content] ='Sales'
 WHERE id=202861988


   --row number: 19065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200774 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=202861989


   --row number: 19066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200774 , [Content] ='Product Line Sales'
 WHERE id=202861990


   --row number: 19067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200774 , [Content] ='IC5'
 WHERE id=202861991


   --row number: 19068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200774 , [Content] ='DKK'
 WHERE id=202861993


   --row number: 19069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200774 , [Content] ='765,000 / 832,500 / 900,000 / 967,500 / 1,035,000'
 WHERE id=202861994


   --row number: 19070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200774 , [Content] ='1,275,000 / 1,387,500 / 1,500,000 / 1,612,500 / 1,725,000'
 WHERE id=202861995


   --row number: 19071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200774 , [Content] ='60/40'
 WHERE id=202861996


   --row number: 19072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200774 , [Content] ='No'
 WHERE id=202861997


   --row number: 19073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200774 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202861999


   --row number: 19074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200774 , [Content] ='Technical'
 WHERE id=202862000


   --row number: 19075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200774 , [Content] ='09/05/18'
 WHERE id=202862001


   --row number: 19076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200775 , [Content] ='S665 FRA'
 WHERE id=202862050


   --row number: 19077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200775 , [Content] ='FRA'
 WHERE id=202862051


   --row number: 19078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200775 , [Content] ='EMEA'
 WHERE id=202862052


   --row number: 19079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200775 , [Content] ='FRANCE'
 WHERE id=202862053


   --row number: 19080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200775 , [Content] ='Sales'
 WHERE id=202862054


   --row number: 19081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200775 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=202862055


   --row number: 19082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200775 , [Content] ='91,800 / 99,900 / 108,000 / 116,100 / 124,200'
 WHERE id=202862060


   --row number: 19083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200775 , [Content] ='153,000 / 166,500 / 180,000 / 193,500 / 207,000'
 WHERE id=202862061


   --row number: 19084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200775 , [Content] ='60/40'
 WHERE id=202862062


   --row number: 19085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200775 , [Content] ='No'
 WHERE id=202862063


   --row number: 19086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200775 , [Content] ='4 - Sales Workers'
 WHERE id=202862064


   --row number: 19087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200775 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202862065


   --row number: 19088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200775 , [Content] ='Technical'
 WHERE id=202862066


   --row number: 19089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200775 , [Content] ='09/05/18'
 WHERE id=202862067


   --row number: 19090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200775 , [Content] ='Product Line Sales'
 WHERE id=202862056


   --row number: 19091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200775 , [Content] ='IC5'
 WHERE id=202862057


   --row number: 19092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200775 , [Content] ='EUR'
 WHERE id=202862059


   --row number: 19093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200781 , [Content] ='CHE'
 WHERE id=202862557


   --row number: 19094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200781 , [Content] ='Yes'
 WHERE id=202862570


   --row number: 19095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200781 , [Content] ='4 - Sales Workers'
 WHERE id=202862571


   --row number: 19096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200781 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202862572


   --row number: 19097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200781 , [Content] ='Technical'
 WHERE id=202862573


   --row number: 19098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200781 , [Content] ='09/05/18'
 WHERE id=202862574


   --row number: 19099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200781 , [Content] ='EMEA'
 WHERE id=202862558


   --row number: 19100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200781 , [Content] ='SWITZERLAND'
 WHERE id=202862559


   --row number: 19101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200781 , [Content] ='Sales'
 WHERE id=202862560


   --row number: 19102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200781 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=202862561


   --row number: 19103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200781 , [Content] ='Product Line Sales'
 WHERE id=202862562


   --row number: 19104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200781 , [Content] ='IC5'
 WHERE id=202862563


   --row number: 19105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200781 , [Content] ='CHF'
 WHERE id=202862565


   --row number: 19106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200781 , [Content] ='S665 CHE'
 WHERE id=202862556


   --row number: 19107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200781 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=202862566


   --row number: 19108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200781 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=202862567


   --row number: 19109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200781 , [Content] ='233,750 / 254,375 / 275,000 / 295,625 / 316,250'
 WHERE id=202862568


   --row number: 19110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200781 , [Content] ='60/40'
 WHERE id=202862569


   --row number: 19111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200783 , [Content] ='Yes'
 WHERE id=202862742


   --row number: 19112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200783 , [Content] ='4 - Sales Workers'
 WHERE id=202862743


   --row number: 19113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200783 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202862744


   --row number: 19114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200783 , [Content] ='Technical'
 WHERE id=202862745


   --row number: 19115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200783 , [Content] ='09/05/18'
 WHERE id=202862746


   --row number: 19116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200783 , [Content] ='S665 UK'
 WHERE id=202862728


   --row number: 19117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200783 , [Content] ='UK'
 WHERE id=202862729


   --row number: 19118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200783 , [Content] ='EMEA'
 WHERE id=202862730


   --row number: 19119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200783 , [Content] ='UNITED KINGDOM'
 WHERE id=202862731


   --row number: 19120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200783 , [Content] ='Sales'
 WHERE id=202862732


   --row number: 19121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200783 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=202862733


   --row number: 19122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200783 , [Content] ='Product Line Sales'
 WHERE id=202862734


   --row number: 19123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200783 , [Content] ='IC5'
 WHERE id=202862735


   --row number: 19124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200783 , [Content] ='GBP'
 WHERE id=202862737


   --row number: 19125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200783 , [Content] ='94,350 / 102,675 / 111,000 / 119,325 / 127,650'
 WHERE id=202862738


   --row number: 19126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200783 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=202862739


   --row number: 19127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200783 , [Content] ='157,250 / 171,125 / 185,000 / 198,875 / 212,750'
 WHERE id=202862740


   --row number: 19128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200783 , [Content] ='60/40'
 WHERE id=202862741


   --row number: 19129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200784 , [Content] ='Yes'
 WHERE id=202862833


   --row number: 19130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200784 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202862834


   --row number: 19131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200784 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202862835


   --row number: 19132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200784 , [Content] ='Technical'
 WHERE id=202862836


   --row number: 19133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200784 , [Content] ='10/05/18'
 WHERE id=202862837


   --row number: 19134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200784 , [Content] ='S314 DEU'
 WHERE id=202862819


   --row number: 19135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200784 , [Content] ='DEU'
 WHERE id=202862820


   --row number: 19136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200784 , [Content] ='EMEA'
 WHERE id=202862821


   --row number: 19137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200784 , [Content] ='GERMANY'
 WHERE id=202862822


   --row number: 19138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200784 , [Content] ='Sales'
 WHERE id=202862823


   --row number: 19139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200784 , [Content] ='S314 - Sr Mgr, Sales M4'
 WHERE id=202862824


   --row number: 19140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200784 , [Content] ='Sales Management'
 WHERE id=202862825


   --row number: 19141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200784 , [Content] ='M4'
 WHERE id=202862826


   --row number: 19142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200784 , [Content] ='EUR'
 WHERE id=202862828


   --row number: 19143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200784 , [Content] ='89,463 / 97,356 / 105,250 / 113,144 / 121,038'
 WHERE id=202862829


   --row number: 19144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3200784 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=202862830


   --row number: 19145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200784 , [Content] ='178,925 / 194,713 / 210,500 / 226,288 / 242,075'
 WHERE id=202862831


   --row number: 19146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200784 , [Content] ='50/50'
 WHERE id=202862832


   --row number: 19147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3200791 , [Content] ='No'
 WHERE id=202863514


   --row number: 19148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3200791 , [Content] ='4 - Sales Workers'
 WHERE id=202863515


   --row number: 19149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3200791 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202863516


   --row number: 19150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3200791 , [Content] ='Technical'
 WHERE id=202863517


   --row number: 19151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3200791 , [Content] ='10/05/18'
 WHERE id=202863518


   --row number: 19152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3200791 , [Content] ='R3613B FRA'
 WHERE id=202863501


   --row number: 19153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3200791 , [Content] ='FRA'
 WHERE id=202863502


   --row number: 19154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3200791 , [Content] ='EMEA'
 WHERE id=202863503


   --row number: 19155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3200791 , [Content] ='FRANCE'
 WHERE id=202863504


   --row number: 19156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3200791 , [Content] ='Sales'
 WHERE id=202863505


   --row number: 19157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3200791 , [Content] ='R3613B - Commercial Account Exec IC3'
 WHERE id=202863506


   --row number: 19158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3200791 , [Content] ='Commercial Accounts'
 WHERE id=202863507


   --row number: 19159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3200791 , [Content] ='IC3'
 WHERE id=202863508


   --row number: 19160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3200791 , [Content] ='EUR'
 WHERE id=202863510


   --row number: 19161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3200791 , [Content] ='58,013 / 63,131 / 68,250 / 73,369 / 78,488'
 WHERE id=202863511


   --row number: 19162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3200791 , [Content] ='116,025 / 126,263 / 136,500 / 146,738 / 156,975'
 WHERE id=202863512


   --row number: 19163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3200791 , [Content] ='50/50'
 WHERE id=202863513


   --row number: 19164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201173 , [Content] ='5462 IND'
 WHERE id=202902727


   --row number: 19165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201173 , [Content] ='IND'
 WHERE id=202902728


   --row number: 19166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201173 , [Content] ='APAC'
 WHERE id=202902729


   --row number: 19167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201173 , [Content] ='INDIA'
 WHERE id=202902730


   --row number: 19168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201173 , [Content] ='Marketing'
 WHERE id=202902731


   --row number: 19169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201173 , [Content] ='5462 - Product Portfolio Mgr IC2'
 WHERE id=202902732


   --row number: 19170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201173 , [Content] ='Product Mgrs'
 WHERE id=202902733


   --row number: 19171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201173 , [Content] ='IC2'
 WHERE id=202902734


   --row number: 19172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201173 , [Content] ='INR'
 WHERE id=202902736


   --row number: 19173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201173 , [Content] ='1,213,800 / 1,486,900 / 1,760,000 / 2,033,100 / 2,306,200'
 WHERE id=202902737


   --row number: 19174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201173 , [Content] ='Technical'
 WHERE id=202902744


   --row number: 19175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201173 , [Content] ='10/05/18'
 WHERE id=202902745


   --row number: 19176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201173 , [Content] ='10%'
 WHERE id=202902740


   --row number: 19177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201173 , [Content] ='No'
 WHERE id=202902741


   --row number: 19178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201173 , [Content] ='2 - Professionals'
 WHERE id=202902742


   --row number: 19179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201173 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202902743


   --row number: 19180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201183 , [Content] ='2 - Professionals'
 WHERE id=202903451


   --row number: 19181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201183 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202903452


   --row number: 19182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201183 , [Content] ='Technical'
 WHERE id=202903453


   --row number: 19183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201183 , [Content] ='09/05/18'
 WHERE id=202903454


   --row number: 19184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201183 , [Content] ='INR'
 WHERE id=202903445


   --row number: 19185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201183 , [Content] ='1,520,700 / 1,862,850 / 2,205,000 / 2,547,150 / 2,889,300'
 WHERE id=202903446


   --row number: 19186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201183 , [Content] ='5463 IND'
 WHERE id=202903436


   --row number: 19187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201183 , [Content] ='IND'
 WHERE id=202903437


   --row number: 19188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201183 , [Content] ='APAC'
 WHERE id=202903438


   --row number: 19189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201183 , [Content] ='INDIA'
 WHERE id=202903439


   --row number: 19190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201183 , [Content] ='Marketing'
 WHERE id=202903440


   --row number: 19191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201183 , [Content] ='5463 - Product Portfolio Mgr IC3'
 WHERE id=202903441


   --row number: 19192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201183 , [Content] ='Product Mgrs'
 WHERE id=202903442


   --row number: 19193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201183 , [Content] ='IC3'
 WHERE id=202903443


   --row number: 19194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201183 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=202903447


   --row number: 19195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201183 , [Content] ='1,748,800 / 2,142,300 / 2,535,800 / 2,929,250 / 3,322,700'
 WHERE id=202903448


   --row number: 19196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201183 , [Content] ='15%'
 WHERE id=202903449


   --row number: 19197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201183 , [Content] ='Yes'
 WHERE id=202903450


   --row number: 19198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201543 , [Content] ='Yes'
 WHERE id=202932452


   --row number: 19199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201543 , [Content] ='EXEMPT'
 WHERE id=202932453


   --row number: 19200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201543 , [Content] ='NO'
 WHERE id=202932454


   --row number: 19201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201543 , [Content] ='2 - Professionals'
 WHERE id=202932455


   --row number: 19202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201543 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202932456


   --row number: 19203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201543 , [Content] ='Technical'
 WHERE id=202932457


   --row number: 19204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201543 , [Content] ='09/05/18'
 WHERE id=202932458


   --row number: 19205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201543 , [Content] ='5144 US - MRKT 2'
 WHERE id=202932438


   --row number: 19206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201543 , [Content] ='US - MRKT 2'
 WHERE id=202932439


   --row number: 19207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201543 , [Content] ='AMS'
 WHERE id=202932440


   --row number: 19208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201543 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202932441


   --row number: 19209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201543 , [Content] ='Engineering'
 WHERE id=202932442


   --row number: 19210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201543 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202932443


   --row number: 19211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201543 , [Content] ='Software'
 WHERE id=202932444


   --row number: 19212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201543 , [Content] ='IC4'
 WHERE id=202932445


   --row number: 19213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201543 , [Content] ='USD'
 WHERE id=202932447


   --row number: 19214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201543 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202932448


   --row number: 19215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201543 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202932449


   --row number: 19216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201543 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202932450


   --row number: 19217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201543 , [Content] ='20%'
 WHERE id=202932451


   --row number: 19218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201549 , [Content] ='5143 US - MRKT 2'
 WHERE id=202932549


   --row number: 19219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201549 , [Content] ='US - MRKT 2'
 WHERE id=202932550


   --row number: 19220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201549 , [Content] ='EXEMPT'
 WHERE id=202932564


   --row number: 19221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201549 , [Content] ='NO'
 WHERE id=202932565


   --row number: 19222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201549 , [Content] ='2 - Professionals'
 WHERE id=202932566


   --row number: 19223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201549 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202932567


   --row number: 19224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201549 , [Content] ='Technical'
 WHERE id=202932568


   --row number: 19225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201549 , [Content] ='10/24/2018'
 WHERE id=202932569


   --row number: 19226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201549 , [Content] ='AMS'
 WHERE id=202932551


   --row number: 19227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201549 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202932552


   --row number: 19228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201549 , [Content] ='Engineering'
 WHERE id=202932553


   --row number: 19229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201549 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202932554


   --row number: 19230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201549 , [Content] ='Software'
 WHERE id=202932555


   --row number: 19231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201549 , [Content] ='IC3'
 WHERE id=202932556


   --row number: 19232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201549 , [Content] ='USD'
 WHERE id=202932558


   --row number: 19233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201549 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202932559


   --row number: 19234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201549 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202932560


   --row number: 19235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201549 , [Content] ='15%'
 WHERE id=202932562


   --row number: 19236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201549 , [Content] ='Yes'
 WHERE id=202932563


   --row number: 19237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201625 , [Content] ='5145 US - MRKT 1'
 WHERE id=202937346


   --row number: 19238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201625 , [Content] ='US - MRKT 1'
 WHERE id=202937347


   --row number: 19239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201625 , [Content] ='AMS'
 WHERE id=202937348


   --row number: 19240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201625 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202937349


   --row number: 19241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201625 , [Content] ='Engineering'
 WHERE id=202937350


   --row number: 19242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201625 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=202937351


   --row number: 19243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201625 , [Content] ='Software'
 WHERE id=202937352


   --row number: 19244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201625 , [Content] ='IC5'
 WHERE id=202937353


   --row number: 19245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201625 , [Content] ='USD'
 WHERE id=202937355


   --row number: 19246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201625 , [Content] ='25%'
 WHERE id=202937359


   --row number: 19247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201625 , [Content] ='Yes'
 WHERE id=202937360


   --row number: 19248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201625 , [Content] ='EXEMPT'
 WHERE id=202937361


   --row number: 19249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201625 , [Content] ='NO'
 WHERE id=202937362


   --row number: 19250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201625 , [Content] ='2 - Professionals'
 WHERE id=202937363


   --row number: 19251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201625 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202937364


   --row number: 19252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201625 , [Content] ='Technical'
 WHERE id=202937365


   --row number: 19253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201625 , [Content] ='09/05/18'
 WHERE id=202937366


   --row number: 19254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201625 , [Content] ='143,000 / 175,200 / 207,400 / 239,550 / 271,700'
 WHERE id=202937356


   --row number: 19255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201625 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=202937357


   --row number: 19256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201625 , [Content] ='178,800 / 219,050 / 259,300 / 299,450 / 339,600'
 WHERE id=202937358


   --row number: 19257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201627 , [Content] ='US - MRKT 1'
 WHERE id=202937629


   --row number: 19258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201627 , [Content] ='25%'
 WHERE id=202937641


   --row number: 19259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201627 , [Content] ='Yes'
 WHERE id=202937642


   --row number: 19260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201627 , [Content] ='EXEMPT'
 WHERE id=202937643


   --row number: 19261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201627 , [Content] ='AMS'
 WHERE id=202937630


   --row number: 19262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201627 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202937631


   --row number: 19263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201627 , [Content] ='Engineering'
 WHERE id=202937632


   --row number: 19264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201627 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=202937633


   --row number: 19265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201627 , [Content] ='Software'
 WHERE id=202937634


   --row number: 19266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201627 , [Content] ='IC5'
 WHERE id=202937635


   --row number: 19267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201627 , [Content] ='USD'
 WHERE id=202937637


   --row number: 19268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201627 , [Content] ='5145 US - MRKT 1'
 WHERE id=202937628


   --row number: 19269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201627 , [Content] ='143,000 / 175,200 / 207,400 / 239,550 / 271,700'
 WHERE id=202937638


   --row number: 19270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201627 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=202937639


   --row number: 19271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201627 , [Content] ='178,800 / 219,050 / 259,300 / 299,450 / 339,600'
 WHERE id=202937640


   --row number: 19272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201627 , [Content] ='NO'
 WHERE id=202937644


   --row number: 19273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201657 , [Content] ='USD'
 WHERE id=202940965


   --row number: 19274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201657 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202940966


   --row number: 19275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201657 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202940967


   --row number: 19276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201657 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202940968


   --row number: 19277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201657 , [Content] ='20%'
 WHERE id=202940969


   --row number: 19278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201657 , [Content] ='Yes'
 WHERE id=202940970


   --row number: 19279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201657 , [Content] ='EXEMPT'
 WHERE id=202940971


   --row number: 19280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201657 , [Content] ='NO'
 WHERE id=202940972


   --row number: 19281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201657 , [Content] ='2 - Professionals'
 WHERE id=202940973


   --row number: 19282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201657 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202940974


   --row number: 19283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201627 , [Content] ='2 - Professionals'
 WHERE id=202937645


   --row number: 19284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201627 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202937646


   --row number: 19285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201627 , [Content] ='Technical'
 WHERE id=202937647


   --row number: 19286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201627 , [Content] ='09/05/18'
 WHERE id=202937648


   --row number: 19287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201657 , [Content] ='5144 US - MRKT 2'
 WHERE id=202940956


   --row number: 19288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201657 , [Content] ='US - MRKT 2'
 WHERE id=202940957


   --row number: 19289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201657 , [Content] ='AMS'
 WHERE id=202940958


   --row number: 19290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201657 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202940959


   --row number: 19291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201657 , [Content] ='Engineering'
 WHERE id=202940960


   --row number: 19292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201657 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202940961


   --row number: 19293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201657 , [Content] ='Software'
 WHERE id=202940962


   --row number: 19294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201657 , [Content] ='IC4'
 WHERE id=202940963


   --row number: 19295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201657 , [Content] ='Technical'
 WHERE id=202940975


   --row number: 19296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201657 , [Content] ='09/05/18'
 WHERE id=202940976


   --row number: 19297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201672 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=202942994


   --row number: 19298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201672 , [Content] ='EXEMPT'
 WHERE id=202942999


   --row number: 19299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201672 , [Content] ='NO'
 WHERE id=202943000


   --row number: 19300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201672 , [Content] ='2 - Professionals'
 WHERE id=202943001


   --row number: 19301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201672 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202943002


   --row number: 19302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201672 , [Content] ='Technical'
 WHERE id=202943003


   --row number: 19303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201672 , [Content] ='10/05/18'
 WHERE id=202943004


   --row number: 19304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201672 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202942995


   --row number: 19305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201672 , [Content] ='15%'
 WHERE id=202942997


   --row number: 19306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201672 , [Content] ='Yes'
 WHERE id=202942998


   --row number: 19307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201672 , [Content] ='5143 US - MRKT 2'
 WHERE id=202942984


   --row number: 19308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201672 , [Content] ='US - MRKT 2'
 WHERE id=202942985


   --row number: 19309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201672 , [Content] ='AMS'
 WHERE id=202942986


   --row number: 19310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201672 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202942987


   --row number: 19311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201672 , [Content] ='Engineering'
 WHERE id=202942988


   --row number: 19312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201672 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=202942989


   --row number: 19313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201672 , [Content] ='Software'
 WHERE id=202942990


   --row number: 19314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201672 , [Content] ='IC3'
 WHERE id=202942991


   --row number: 19315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201672 , [Content] ='USD'
 WHERE id=202942993


   --row number: 19316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201674 , [Content] ='Yes'
 WHERE id=202943106


   --row number: 19317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201674 , [Content] ='EXEMPT'
 WHERE id=202943107


   --row number: 19318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201674 , [Content] ='NO'
 WHERE id=202943108


   --row number: 19319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201674 , [Content] ='2 - Professionals'
 WHERE id=202943109


   --row number: 19320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201674 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202943110


   --row number: 19321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201674 , [Content] ='Technical'
 WHERE id=202943111


   --row number: 19322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201674 , [Content] ='09/05/18'
 WHERE id=202943112


   --row number: 19323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201674 , [Content] ='5144 US - MRKT 2'
 WHERE id=202943092


   --row number: 19324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201674 , [Content] ='US - MRKT 2'
 WHERE id=202943093


   --row number: 19325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201674 , [Content] ='AMS'
 WHERE id=202943094


   --row number: 19326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201674 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202943095


   --row number: 19327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201674 , [Content] ='Engineering'
 WHERE id=202943096


   --row number: 19328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201674 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202943097


   --row number: 19329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201674 , [Content] ='Software'
 WHERE id=202943098


   --row number: 19330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201674 , [Content] ='IC4'
 WHERE id=202943099


   --row number: 19331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201674 , [Content] ='USD'
 WHERE id=202943101


   --row number: 19332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201674 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202943102


   --row number: 19333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201674 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202943103


   --row number: 19334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201674 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202943104


   --row number: 19335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201674 , [Content] ='20%'
 WHERE id=202943105


   --row number: 19336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201676 , [Content] ='EXEMPT'
 WHERE id=202943237


   --row number: 19337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201676 , [Content] ='NO'
 WHERE id=202943238


   --row number: 19338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201676 , [Content] ='2 - Professionals'
 WHERE id=202943239


   --row number: 19339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201676 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202943240


   --row number: 19340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201676 , [Content] ='Technical'
 WHERE id=202943241


   --row number: 19341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201676 , [Content] ='10/24/2018'
 WHERE id=202943242


   --row number: 19342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201676 , [Content] ='5142 US - MRKT 2'
 WHERE id=202943222


   --row number: 19343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201676 , [Content] ='US - MRKT 2'
 WHERE id=202943223


   --row number: 19344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201676 , [Content] ='AMS'
 WHERE id=202943224


   --row number: 19345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201676 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202943225


   --row number: 19346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201676 , [Content] ='Engineering'
 WHERE id=202943226


   --row number: 19347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201676 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=202943227


   --row number: 19348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201676 , [Content] ='Software'
 WHERE id=202943228


   --row number: 19349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201676 , [Content] ='IC2'
 WHERE id=202943229


   --row number: 19350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201676 , [Content] ='USD'
 WHERE id=202943231


   --row number: 19351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201676 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=202943232


   --row number: 19352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201676 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=202943233


   --row number: 19353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201676 , [Content] ='10%'
 WHERE id=202943235


   --row number: 19354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201676 , [Content] ='Yes'
 WHERE id=202943236


   --row number: 19355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201678 , [Content] ='Yes'
 WHERE id=202943334


   --row number: 19356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201678 , [Content] ='EXEMPT'
 WHERE id=202943335


   --row number: 19357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201678 , [Content] ='NO'
 WHERE id=202943336


   --row number: 19358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201678 , [Content] ='2 - Professionals'
 WHERE id=202943337


   --row number: 19359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201678 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202943338


   --row number: 19360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201678 , [Content] ='Technical'
 WHERE id=202943339


   --row number: 19361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201678 , [Content] ='09/05/18'
 WHERE id=202943340


   --row number: 19362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201678 , [Content] ='5144 US - MRKT 2'
 WHERE id=202943320


   --row number: 19363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201678 , [Content] ='US - MRKT 2'
 WHERE id=202943321


   --row number: 19364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201678 , [Content] ='AMS'
 WHERE id=202943322


   --row number: 19365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201678 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202943323


   --row number: 19366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201678 , [Content] ='Engineering'
 WHERE id=202943324


   --row number: 19367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201678 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202943325


   --row number: 19368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201678 , [Content] ='Software'
 WHERE id=202943326


   --row number: 19369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201678 , [Content] ='IC4'
 WHERE id=202943327


   --row number: 19370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201678 , [Content] ='USD'
 WHERE id=202943329


   --row number: 19371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201678 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202943330


   --row number: 19372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201678 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202943331


   --row number: 19373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201678 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202943332


   --row number: 19374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201678 , [Content] ='20%'
 WHERE id=202943333


   --row number: 19375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201679 , [Content] ='5145 US - MRKT 1'
 WHERE id=202943399


   --row number: 19376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201679 , [Content] ='US - MRKT 1'
 WHERE id=202943400


   --row number: 19377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201679 , [Content] ='AMS'
 WHERE id=202943401


   --row number: 19378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201679 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202943402


   --row number: 19379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201679 , [Content] ='Engineering'
 WHERE id=202943403


   --row number: 19380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201679 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=202943404


   --row number: 19381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201679 , [Content] ='Software'
 WHERE id=202943405


   --row number: 19382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201679 , [Content] ='IC5'
 WHERE id=202943406


   --row number: 19383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201679 , [Content] ='USD'
 WHERE id=202943408


   --row number: 19384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201679 , [Content] ='143,000 / 175,200 / 207,400 / 239,550 / 271,700'
 WHERE id=202943409


   --row number: 19385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201679 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=202943410


   --row number: 19386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201679 , [Content] ='178,800 / 219,050 / 259,300 / 299,450 / 339,600'
 WHERE id=202943411


   --row number: 19387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201679 , [Content] ='25%'
 WHERE id=202943412


   --row number: 19388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201679 , [Content] ='Yes'
 WHERE id=202943413


   --row number: 19389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201679 , [Content] ='EXEMPT'
 WHERE id=202943414


   --row number: 19390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201679 , [Content] ='NO'
 WHERE id=202943415


   --row number: 19391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201679 , [Content] ='2 - Professionals'
 WHERE id=202943416


   --row number: 19392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201679 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202943417


   --row number: 19393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201679 , [Content] ='Technical'
 WHERE id=202943418


   --row number: 19394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201679 , [Content] ='10/05/18'
 WHERE id=202943419


   --row number: 19395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201725 , [Content] ='5144 US - MRKT 2'
 WHERE id=202947558


   --row number: 19396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201725 , [Content] ='US - MRKT 2'
 WHERE id=202947559


   --row number: 19397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201725 , [Content] ='AMS'
 WHERE id=202947560


   --row number: 19398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201725 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202947561


   --row number: 19399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201725 , [Content] ='Engineering'
 WHERE id=202947562


   --row number: 19400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201725 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202947563


   --row number: 19401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201725 , [Content] ='Software'
 WHERE id=202947564


   --row number: 19402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201725 , [Content] ='IC4'
 WHERE id=202947565


   --row number: 19403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201725 , [Content] ='Yes'
 WHERE id=202947572


   --row number: 19404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201725 , [Content] ='EXEMPT'
 WHERE id=202947573


   --row number: 19405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201725 , [Content] ='NO'
 WHERE id=202947574


   --row number: 19406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201725 , [Content] ='2 - Professionals'
 WHERE id=202947575


   --row number: 19407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201725 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202947576


   --row number: 19408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201725 , [Content] ='Technical'
 WHERE id=202947577


   --row number: 19409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201725 , [Content] ='09/05/18'
 WHERE id=202947578


   --row number: 19410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201725 , [Content] ='USD'
 WHERE id=202947567


   --row number: 19411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201725 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202947568


   --row number: 19412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201725 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202947569


   --row number: 19413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201725 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202947570


   --row number: 19414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201725 , [Content] ='20%'
 WHERE id=202947571


   --row number: 19415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201729 , [Content] ='Yes'
 WHERE id=202947753


   --row number: 19416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201729 , [Content] ='EXEMPT'
 WHERE id=202947754


   --row number: 19417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201729 , [Content] ='NO'
 WHERE id=202947755


   --row number: 19418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201729 , [Content] ='2 - Professionals'
 WHERE id=202947756


   --row number: 19419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201729 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202947758


   --row number: 19420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201729 , [Content] ='Technical'
 WHERE id=202947759


   --row number: 19421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201729 , [Content] ='09/05/18'
 WHERE id=202947760


   --row number: 19422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201729 , [Content] ='5144 US - MRKT 2'
 WHERE id=202947739


   --row number: 19423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201729 , [Content] ='US - MRKT 2'
 WHERE id=202947740


   --row number: 19424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201729 , [Content] ='AMS'
 WHERE id=202947741


   --row number: 19425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201729 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202947742


   --row number: 19426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201729 , [Content] ='Engineering'
 WHERE id=202947743


   --row number: 19427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201729 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202947744


   --row number: 19428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201729 , [Content] ='Software'
 WHERE id=202947745


   --row number: 19429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201729 , [Content] ='IC4'
 WHERE id=202947746


   --row number: 19430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201729 , [Content] ='USD'
 WHERE id=202947748


   --row number: 19431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201729 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202947749


   --row number: 19432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201729 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202947750


   --row number: 19433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201729 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202947751


   --row number: 19434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201729 , [Content] ='20%'
 WHERE id=202947752


   --row number: 19435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201731 , [Content] ='Yes'
 WHERE id=202947974


   --row number: 19436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201731 , [Content] ='EXEMPT'
 WHERE id=202947975


   --row number: 19437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201731 , [Content] ='NO'
 WHERE id=202947976


   --row number: 19438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201731 , [Content] ='2 - Professionals'
 WHERE id=202947977


   --row number: 19439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201731 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202947978


   --row number: 19440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201731 , [Content] ='Technical'
 WHERE id=202947979


   --row number: 19441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201731 , [Content] ='09/05/18'
 WHERE id=202947980


   --row number: 19442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201731 , [Content] ='5144 US - MRKT 2'
 WHERE id=202947960


   --row number: 19443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201731 , [Content] ='US - MRKT 2'
 WHERE id=202947961


   --row number: 19444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201731 , [Content] ='AMS'
 WHERE id=202947962


   --row number: 19445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201731 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202947963


   --row number: 19446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201731 , [Content] ='Engineering'
 WHERE id=202947964


   --row number: 19447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201731 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202947965


   --row number: 19448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201731 , [Content] ='Software'
 WHERE id=202947966


   --row number: 19449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201731 , [Content] ='IC4'
 WHERE id=202947967


   --row number: 19450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201731 , [Content] ='USD'
 WHERE id=202947969


   --row number: 19451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201731 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202947970


   --row number: 19452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201731 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202947971


   --row number: 19453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201731 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202947972


   --row number: 19454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201731 , [Content] ='20%'
 WHERE id=202947973


   --row number: 19455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201734 , [Content] ='Yes'
 WHERE id=202948182


   --row number: 19456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201734 , [Content] ='EXEMPT'
 WHERE id=202948183


   --row number: 19457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201734 , [Content] ='NO'
 WHERE id=202948184


   --row number: 19458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201734 , [Content] ='2 - Professionals'
 WHERE id=202948185


   --row number: 19459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201734 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202948186


   --row number: 19460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201734 , [Content] ='Technical'
 WHERE id=202948187


   --row number: 19461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201734 , [Content] ='09/05/18'
 WHERE id=202948188


   --row number: 19462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201734 , [Content] ='5144 US - MRKT 2'
 WHERE id=202948168


   --row number: 19463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201734 , [Content] ='US - MRKT 2'
 WHERE id=202948169


   --row number: 19464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201734 , [Content] ='AMS'
 WHERE id=202948170


   --row number: 19465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201734 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202948171


   --row number: 19466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201734 , [Content] ='Engineering'
 WHERE id=202948172


   --row number: 19467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201734 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202948173


   --row number: 19468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201734 , [Content] ='Software'
 WHERE id=202948174


   --row number: 19469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201734 , [Content] ='IC4'
 WHERE id=202948175


   --row number: 19470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201734 , [Content] ='USD'
 WHERE id=202948177


   --row number: 19471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201734 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=202948178


   --row number: 19472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201734 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202948179


   --row number: 19473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201734 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=202948180


   --row number: 19474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201734 , [Content] ='20%'
 WHERE id=202948181


   --row number: 19475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201793 , [Content] ='Yes'
 WHERE id=202953247


   --row number: 19476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201793 , [Content] ='EXEMPT'
 WHERE id=202953248


   --row number: 19477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201793 , [Content] ='NO'
 WHERE id=202953249


   --row number: 19478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201793 , [Content] ='2 - Professionals'
 WHERE id=202953250


   --row number: 19479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201793 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202953251


   --row number: 19480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201793 , [Content] ='Technical'
 WHERE id=202953252


   --row number: 19481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201793 , [Content] ='09/05/18'
 WHERE id=202953253


   --row number: 19482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201793 , [Content] ='5144 US - MRKT 1'
 WHERE id=202953233


   --row number: 19483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201793 , [Content] ='US - MRKT 1'
 WHERE id=202953234


   --row number: 19484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201793 , [Content] ='AMS'
 WHERE id=202953235


   --row number: 19485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201793 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202953236


   --row number: 19486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201793 , [Content] ='Engineering'
 WHERE id=202953237


   --row number: 19487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201793 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=202953238


   --row number: 19488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201793 , [Content] ='Software'
 WHERE id=202953239


   --row number: 19489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201793 , [Content] ='IC4'
 WHERE id=202953240


   --row number: 19490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201793 , [Content] ='USD'
 WHERE id=202953242


   --row number: 19491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201793 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=202953243


   --row number: 19492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201793 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=202953244


   --row number: 19493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201793 , [Content] ='148,200 / 179,200 / 210,200 / 241,300 / 272,400'
 WHERE id=202953245


   --row number: 19494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3201793 , [Content] ='20%'
 WHERE id=202953246


   --row number: 19495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3201846 , [Content] ='75/25'
 WHERE id=202957802


   --row number: 19496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201846 , [Content] ='Yes'
 WHERE id=202957803


   --row number: 19497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201846 , [Content] ='EXEMPT'
 WHERE id=202957804


   --row number: 19498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201846 , [Content] ='NO'
 WHERE id=202957805


   --row number: 19499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201846 , [Content] ='4 - Sales Workers'
 WHERE id=202957806


   --row number: 19500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201846 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202957807


   --row number: 19501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201846 , [Content] ='Technical'
 WHERE id=202957808


   --row number: 19502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201846 , [Content] ='09/05/18'
 WHERE id=202957809


   --row number: 19503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201846 , [Content] ='S1413 US - MRKT 2'
 WHERE id=202957789


   --row number: 19504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201846 , [Content] ='US - MRKT 2'
 WHERE id=202957790


   --row number: 19505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201846 , [Content] ='AMS'
 WHERE id=202957791


   --row number: 19506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201846 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202957792


   --row number: 19507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201846 , [Content] ='Solution Consulting'
 WHERE id=202957793


   --row number: 19508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201846 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=202957794


   --row number: 19509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201846 , [Content] ='Solution Consultant Core'
 WHERE id=202957795


   --row number: 19510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201846 , [Content] ='IC3'
 WHERE id=202957796


   --row number: 19511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201846 , [Content] ='USD'
 WHERE id=202957798


   --row number: 19512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201846 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=202957799


   --row number: 19513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201846 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=202957800


   --row number: 19514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201846 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=202957801


   --row number: 19515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201886 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=202960715


   --row number: 19516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3201886 , [Content] ='75/25'
 WHERE id=202960717


   --row number: 19517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201886 , [Content] ='Yes'
 WHERE id=202960718


   --row number: 19518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201886 , [Content] ='EXEMPT'
 WHERE id=202960719


   --row number: 19519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201886 , [Content] ='NO'
 WHERE id=202960721


   --row number: 19520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201886 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202960723


   --row number: 19521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201886 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202960724


   --row number: 19522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201886 , [Content] ='Technical'
 WHERE id=202960725


   --row number: 19523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201886 , [Content] ='09/05/18'
 WHERE id=202960726


   --row number: 19524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201886 , [Content] ='191,250 / 208,125 / 225,000 / 241,875 / 258,750'
 WHERE id=202960716


   --row number: 19525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201886 , [Content] ='S1403 US - MRKT 1'
 WHERE id=202960704


   --row number: 19526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201886 , [Content] ='US - MRKT 1'
 WHERE id=202960705


   --row number: 19527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201886 , [Content] ='AMS'
 WHERE id=202960706


   --row number: 19528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201886 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202960707


   --row number: 19529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201886 , [Content] ='Solution Consulting'
 WHERE id=202960708


   --row number: 19530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201886 , [Content] ='S1403 - Mgr, Solution Consulting M3'
 WHERE id=202960709


   --row number: 19531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201886 , [Content] ='Solution Consultant Core'
 WHERE id=202960710


   --row number: 19532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201886 , [Content] ='M3'
 WHERE id=202960711


   --row number: 19533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201886 , [Content] ='USD'
 WHERE id=202960713


   --row number: 19534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201886 , [Content] ='143,438 / 156,094 / 168,750 / 181,406 / 194,063'
 WHERE id=202960714


   --row number: 19535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3201900 , [Content] ='Yes'
 WHERE id=202962253


   --row number: 19536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3201900 , [Content] ='EXEMPT'
 WHERE id=202962254


   --row number: 19537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3201900 , [Content] ='NO'
 WHERE id=202962255


   --row number: 19538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3201900 , [Content] ='4 - Sales Workers'
 WHERE id=202962256


   --row number: 19539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3201900 , [Content] ='8742-Salespersons - Outside'
 WHERE id=202962257


   --row number: 19540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3201900 , [Content] ='Technical'
 WHERE id=202962258


   --row number: 19541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3201900 , [Content] ='09/05/18'
 WHERE id=202962259


   --row number: 19542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3201900 , [Content] ='S1413 US - MRKT 2'
 WHERE id=202962239


   --row number: 19543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3201900 , [Content] ='US - MRKT 2'
 WHERE id=202962240


   --row number: 19544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3201900 , [Content] ='AMS'
 WHERE id=202962241


   --row number: 19545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3201900 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202962242


   --row number: 19546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3201900 , [Content] ='Solution Consulting'
 WHERE id=202962243


   --row number: 19547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3201900 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=202962244


   --row number: 19548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3201900 , [Content] ='Solution Consultant Core'
 WHERE id=202962245


   --row number: 19549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3201900 , [Content] ='IC3'
 WHERE id=202962246


   --row number: 19550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3201900 , [Content] ='USD'
 WHERE id=202962248


   --row number: 19551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3201900 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=202962249


   --row number: 19552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3201900 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=202962250


   --row number: 19553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3201900 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=202962251


   --row number: 19554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3201900 , [Content] ='75/25'
 WHERE id=202962252


   --row number: 19555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202165 , [Content] ='EXEMPT'
 WHERE id=202981728


   --row number: 19556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202165 , [Content] ='NO'
 WHERE id=202981729


   --row number: 19557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202165 , [Content] ='2 - Professionals'
 WHERE id=202981730


   --row number: 19558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202165 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202981731


   --row number: 19559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202165 , [Content] ='Non Technical'
 WHERE id=202981732


   --row number: 19560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202165 , [Content] ='09/05/18'
 WHERE id=202981733


   --row number: 19561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202165 , [Content] ='5615 US - MRKT 1'
 WHERE id=202981713


   --row number: 19562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202165 , [Content] ='US - MRKT 1'
 WHERE id=202981714


   --row number: 19563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202165 , [Content] ='AMS'
 WHERE id=202981715


   --row number: 19564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202165 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202981716


   --row number: 19565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202165 , [Content] ='Marketing'
 WHERE id=202981717


   --row number: 19566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202165 , [Content] ='5615 - Marketing Mgr IC5'
 WHERE id=202981718


   --row number: 19567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202165 , [Content] ='Marketing'
 WHERE id=202981719


   --row number: 19568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202165 , [Content] ='IC5'
 WHERE id=202981720


   --row number: 19569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202165 , [Content] ='USD'
 WHERE id=202981722


   --row number: 19570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202165 , [Content] ='116,900 / 141,400 / 165,900 / 190,400 / 214,900'
 WHERE id=202981723


   --row number: 19571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202165 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=202981724


   --row number: 19572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202165 , [Content] ='140,300 / 169,700 / 199,100 / 228,500 / 257,900'
 WHERE id=202981725


   --row number: 19573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202165 , [Content] ='20%'
 WHERE id=202981726


   --row number: 19574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202165 , [Content] ='Yes'
 WHERE id=202981727


   --row number: 19575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202174 , [Content] ='EXEMPT'
 WHERE id=202982440


   --row number: 19576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202174 , [Content] ='NO'
 WHERE id=202982441


   --row number: 19577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202174 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=202982442


   --row number: 19578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202174 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202982443


   --row number: 19579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202174 , [Content] ='Non Technical'
 WHERE id=202982444


   --row number: 19580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202174 , [Content] ='09/05/18'
 WHERE id=202982445


   --row number: 19581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202174 , [Content] ='2656 US - MRKT 1'
 WHERE id=202982425


   --row number: 19582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202174 , [Content] ='US - MRKT 1'
 WHERE id=202982426


   --row number: 19583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202174 , [Content] ='AMS'
 WHERE id=202982427


   --row number: 19584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202174 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202982428


   --row number: 19585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202174 , [Content] ='Marketing'
 WHERE id=202982429


   --row number: 19586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202174 , [Content] ='2656 - Sr Dir, Trade Show/Events Mgmt M6'
 WHERE id=202982430


   --row number: 19587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202174 , [Content] ='Events'
 WHERE id=202982431


   --row number: 19588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202174 , [Content] ='M6'
 WHERE id=202982432


   --row number: 19589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202174 , [Content] ='USD'
 WHERE id=202982434


   --row number: 19590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202174 , [Content] ='143,100 / 175,300 / 207,500 / 239,700 / 271,900'
 WHERE id=202982435


   --row number: 19591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202174 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=202982436


   --row number: 19592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202174 , [Content] ='186,000 / 227,900 / 269,800 / 311,650 / 353,500'
 WHERE id=202982437


   --row number: 19593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202174 , [Content] ='30%'
 WHERE id=202982438


   --row number: 19594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202174 , [Content] ='Yes'
 WHERE id=202982439


   --row number: 19595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202210 , [Content] ='6392 US - MRKT 2'
 WHERE id=202985476


   --row number: 19596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202210 , [Content] ='US - MRKT 2'
 WHERE id=202985477


   --row number: 19597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202210 , [Content] ='AMS'
 WHERE id=202985478


   --row number: 19598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202210 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202985479


   --row number: 19599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202210 , [Content] ='Legal'
 WHERE id=202985480


   --row number: 19600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202210 , [Content] ='6392 - Legal Counsel IC2'
 WHERE id=202985481


   --row number: 19601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202210 , [Content] ='Legal Counsel'
 WHERE id=202985482


   --row number: 19602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202210 , [Content] ='EXEMPT'
 WHERE id=202985493


   --row number: 19603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202210 , [Content] ='NO'
 WHERE id=202985494


   --row number: 19604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202210 , [Content] ='2 - Professionals'
 WHERE id=202985495


   --row number: 19605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202210 , [Content] ='8810-Clerical Office Employees'
 WHERE id=202985496


   --row number: 19606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202210 , [Content] ='Non Technical'
 WHERE id=202985497


   --row number: 19607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202210 , [Content] ='09/05/18'
 WHERE id=202985498


   --row number: 19608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202210 , [Content] ='IC2'
 WHERE id=202985484


   --row number: 19609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202210 , [Content] ='USD'
 WHERE id=202985487


   --row number: 19610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202210 , [Content] ='104,400 / 123,200 / 142,000 / 160,800 / 179,600'
 WHERE id=202985488


   --row number: 19611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202210 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=202985489


   --row number: 19612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202210 , [Content] ='120,100 / 141,700 / 163,300 / 184,900 / 206,500'
 WHERE id=202985490


   --row number: 19613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202210 , [Content] ='15%'
 WHERE id=202985491


   --row number: 19614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202210 , [Content] ='Yes'
 WHERE id=202985492


   --row number: 19615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202306 , [Content] ='Yes'
 WHERE id=202994084


   --row number: 19616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202306 , [Content] ='EXEMPT'
 WHERE id=202994085


   --row number: 19617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202306 , [Content] ='NO'
 WHERE id=202994086


   --row number: 19618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202306 , [Content] ='2 - Professionals'
 WHERE id=202994087


   --row number: 19619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202306 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=202994088


   --row number: 19620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202306 , [Content] ='Technical'
 WHERE id=202994089


   --row number: 19621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202306 , [Content] ='09/05/18'
 WHERE id=202994090


   --row number: 19622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202306 , [Content] ='5173 US - MRKT 1'
 WHERE id=202994070


   --row number: 19623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202306 , [Content] ='US - MRKT 1'
 WHERE id=202994071


   --row number: 19624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202306 , [Content] ='AMS'
 WHERE id=202994072


   --row number: 19625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202306 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=202994073


   --row number: 19626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202306 , [Content] ='Engineering'
 WHERE id=202994074


   --row number: 19627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202306 , [Content] ='5173 - Machine Learning Engineer IC3'
 WHERE id=202994075


   --row number: 19628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202306 , [Content] ='Machine Learning'
 WHERE id=202994076


   --row number: 19629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202306 , [Content] ='IC3'
 WHERE id=202994077


   --row number: 19630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202306 , [Content] ='USD'
 WHERE id=202994079


   --row number: 19631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202306 , [Content] ='117,600 / 138,800 / 160,000 / 181,150 / 202,300'
 WHERE id=202994080


   --row number: 19632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202306 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=202994081


   --row number: 19633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202306 , [Content] ='135,200 / 159,600 / 184,000 / 208,300 / 232,600'
 WHERE id=202994082


   --row number: 19634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202306 , [Content] ='15%'
 WHERE id=202994083


   --row number: 19635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202394 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=203002187


   --row number: 19636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202394 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=203002188


   --row number: 19637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202394 , [Content] ='10%'
 WHERE id=203002189


   --row number: 19638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202394 , [Content] ='Yes'
 WHERE id=203002190


   --row number: 19639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202394 , [Content] ='EXEMPT'
 WHERE id=203002191


   --row number: 19640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202394 , [Content] ='NO'
 WHERE id=203002192


   --row number: 19641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202394 , [Content] ='2 - Professionals'
 WHERE id=203002193


   --row number: 19642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202394 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203002194


   --row number: 19643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202394 , [Content] ='5141 US - MRKT 1'
 WHERE id=203002176


   --row number: 19644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202394 , [Content] ='US - MRKT 1'
 WHERE id=203002177


   --row number: 19645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202394 , [Content] ='AMS'
 WHERE id=203002178


   --row number: 19646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202394 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203002179


   --row number: 19647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202394 , [Content] ='Engineering'
 WHERE id=203002180


   --row number: 19648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202394 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=203002181


   --row number: 19649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202394 , [Content] ='Software'
 WHERE id=203002182


   --row number: 19650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202394 , [Content] ='IC1'
 WHERE id=203002183


   --row number: 19651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202394 , [Content] ='USD'
 WHERE id=203002185


   --row number: 19652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202394 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=203002186


   --row number: 19653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202394 , [Content] ='Technical'
 WHERE id=203002195


   --row number: 19654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202403 , [Content] ='USD'
 WHERE id=203003444


   --row number: 19655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202403 , [Content] ='165,200 / 202,350 / 239,500 / 276,700 / 313,900'
 WHERE id=203003445


   --row number: 19656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202403 , [Content] ='420,000 / 630,000 / 840,000 / 1,050,000 / 1,260,000'
 WHERE id=203003446


   --row number: 19657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202403 , [Content] ='214,800 / 263,100 / 311,400 / 359,750 / 408,100'
 WHERE id=203003447


   --row number: 19658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202403 , [Content] ='30%'
 WHERE id=203003448


   --row number: 19659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202394 , [Content] ='09/05/18'
 WHERE id=203002196


   --row number: 19660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202403 , [Content] ='2246 US - MRKT 1'
 WHERE id=203003435


   --row number: 19661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202403 , [Content] ='US - MRKT 1'
 WHERE id=203003436


   --row number: 19662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202403 , [Content] ='AMS'
 WHERE id=203003437


   --row number: 19663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202403 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203003438


   --row number: 19664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202403 , [Content] ='Engineering'
 WHERE id=203003439


   --row number: 19665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202403 , [Content] ='2246 - Sr Dir, Product Mgmt M6'
 WHERE id=203003440


   --row number: 19666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202403 , [Content] ='Product Mgmt Mgr'
 WHERE id=203003441


   --row number: 19667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202403 , [Content] ='M6'
 WHERE id=203003442


   --row number: 19668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202403 , [Content] ='Yes'
 WHERE id=203003449


   --row number: 19669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202403 , [Content] ='EXEMPT'
 WHERE id=203003450


   --row number: 19670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202403 , [Content] ='NO'
 WHERE id=203003451


   --row number: 19671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202403 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203003452


   --row number: 19672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202403 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203003453


   --row number: 19673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202403 , [Content] ='Technical'
 WHERE id=203003454


   --row number: 19674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202403 , [Content] ='09/05/18'
 WHERE id=203003455


   --row number: 19675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202537 , [Content] ='Sales'
 WHERE id=203019402


   --row number: 19676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202537 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=203019403


   --row number: 19677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202537 , [Content] ='Sales Management'
 WHERE id=203019404


   --row number: 19678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202537 , [Content] ='S315 US - MRKT 3'
 WHERE id=203019398


   --row number: 19679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202537 , [Content] ='US - MRKT 3'
 WHERE id=203019399


   --row number: 19680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202537 , [Content] ='AMS'
 WHERE id=203019400


   --row number: 19681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202537 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203019401


   --row number: 19682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3202537 , [Content] ='50/50'
 WHERE id=203019411


   --row number: 19683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202537 , [Content] ='Yes'
 WHERE id=203019412


   --row number: 19684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202537 , [Content] ='EXEMPT'
 WHERE id=203019413


   --row number: 19685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202537 , [Content] ='M5'
 WHERE id=203019405


   --row number: 19686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202537 , [Content] ='USD'
 WHERE id=203019407


   --row number: 19687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202537 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203019414


   --row number: 19688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202537 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203019415


   --row number: 19689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202537 , [Content] ='159,375 / 173,438 / 187,500 / 201,563 / 215,625'
 WHERE id=203019408


   --row number: 19690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202537 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=203019409


   --row number: 19691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202537 , [Content] ='318,750 / 346,875 / 375,000 / 403,125 / 431,250'
 WHERE id=203019410


   --row number: 19692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202537 , [Content] ='Technical'
 WHERE id=203019416


   --row number: 19693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202537 , [Content] ='09/05/18'
 WHERE id=203019417


   --row number: 19694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3202558 , [Content] ='EXEMPT'
 WHERE id=203027201


   --row number: 19695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3202558 , [Content] ='NO'
 WHERE id=203027202


   --row number: 19696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202558 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203027203


   --row number: 19697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202558 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203027204


   --row number: 19698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202558 , [Content] ='Technical'
 WHERE id=203027205


   --row number: 19699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202558 , [Content] ='2706 US - MRKT 1'
 WHERE id=203027187


   --row number: 19700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202558 , [Content] ='US - MRKT 1'
 WHERE id=203027188


   --row number: 19701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202558 , [Content] ='AMS'
 WHERE id=203027189


   --row number: 19702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202558 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203027190


   --row number: 19703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202558 , [Content] ='Marketing'
 WHERE id=203027191


   --row number: 19704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202558 , [Content] ='2706 - Sr Dir, Product Portfolio Mgmt M6'
 WHERE id=203027192


   --row number: 19705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202558 , [Content] ='Product Mgrs'
 WHERE id=203027193


   --row number: 19706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202558 , [Content] ='M6'
 WHERE id=203027194


   --row number: 19707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202558 , [Content] ='USD'
 WHERE id=203027196


   --row number: 19708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202558 , [Content] ='165,700 / 203,000 / 240,300 / 277,550 / 314,800'
 WHERE id=203027197


   --row number: 19709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202558 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=203027198


   --row number: 19710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202558 , [Content] ='30%'
 WHERE id=203027199


   --row number: 19711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202558 , [Content] ='Yes'
 WHERE id=203027200


   --row number: 19712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202558 , [Content] ='02/09/18'
 WHERE id=203027206


   --row number: 19713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3202757 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=203063427


   --row number: 19714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3202757 , [Content] ='Yes'
 WHERE id=203063430


   --row number: 19715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3202757 , [Content] ='2 - Professionals'
 WHERE id=203063431


   --row number: 19716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3202757 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203063432


   --row number: 19717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3202757 , [Content] ='Technical'
 WHERE id=203063433


   --row number: 19718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3202757 , [Content] ='09/05/18'
 WHERE id=203063434


   --row number: 19719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3202757 , [Content] ='58,900 / 69,450 / 80,000 / 90,650 / 101,300'
 WHERE id=203063428


   --row number: 19720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3202757 , [Content] ='15%'
 WHERE id=203063429


   --row number: 19721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3202757 , [Content] ='5763 DEU'
 WHERE id=203063416


   --row number: 19722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3202757 , [Content] ='DEU'
 WHERE id=203063417


   --row number: 19723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3202757 , [Content] ='EMEA'
 WHERE id=203063418


   --row number: 19724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3202757 , [Content] ='GERMANY'
 WHERE id=203063419


   --row number: 19725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3202757 , [Content] ='Professional Services'
 WHERE id=203063420


   --row number: 19726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3202757 , [Content] ='5763 - Technology Consultant IC3'
 WHERE id=203063421


   --row number: 19727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3202757 , [Content] ='Technology Consultant'
 WHERE id=203063422


   --row number: 19728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3202757 , [Content] ='IC3'
 WHERE id=203063423


   --row number: 19729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3202757 , [Content] ='EUR'
 WHERE id=203063425


   --row number: 19730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3202757 , [Content] ='51,200 / 60,400 / 69,600 / 78,850 / 88,100'
 WHERE id=203063426


   --row number: 19731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187685 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=203074811


   --row number: 19732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3203277 , [Content] ='20%'
 WHERE id=203113254


   --row number: 19733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3203277 , [Content] ='Yes'
 WHERE id=203113255


   --row number: 19734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3203277 , [Content] ='EXEMPT'
 WHERE id=203113256


   --row number: 19735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3203277 , [Content] ='NO'
 WHERE id=203113257


   --row number: 19736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3203277 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203113258


   --row number: 19737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3203277 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203113259


   --row number: 19738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3203277 , [Content] ='Non Technical'
 WHERE id=203113260


   --row number: 19739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3203277 , [Content] ='09/05/18'
 WHERE id=203113261


   --row number: 19740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3203277 , [Content] ='3093 US - MRKT 1'
 WHERE id=203113241


   --row number: 19741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3203277 , [Content] ='US - MRKT 1'
 WHERE id=203113242


   --row number: 19742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3203277 , [Content] ='AMS'
 WHERE id=203113243


   --row number: 19743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3203277 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203113244


   --row number: 19744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3203277 , [Content] ='Finance'
 WHERE id=203113245


   --row number: 19745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3203277 , [Content] ='3093 - Mgr, Treasury M3'
 WHERE id=203113246


   --row number: 19746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3203277 , [Content] ='Treasury'
 WHERE id=203113247


   --row number: 19747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3203277 , [Content] ='M3'
 WHERE id=203113248


   --row number: 19748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3203298 , [Content] ='114,900 / 138,950 / 163,000 / 187,100 / 211,200'
 WHERE id=203115265


   --row number: 19749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3203298 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203115266


   --row number: 19750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3203298 , [Content] ='137,900 / 166,750 / 195,600 / 224,500 / 253,400'
 WHERE id=203115267


   --row number: 19751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3203298 , [Content] ='20%'
 WHERE id=203115268


   --row number: 19752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3203298 , [Content] ='Yes'
 WHERE id=203115269


   --row number: 19753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3203298 , [Content] ='EXEMPT'
 WHERE id=203115270


   --row number: 19754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3203298 , [Content] ='NO'
 WHERE id=203115271


   --row number: 19755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3203298 , [Content] ='2 - Professionals'
 WHERE id=203115272


   --row number: 19756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3203298 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203115273


   --row number: 19757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3203298 , [Content] ='Non Technical'
 WHERE id=203115274


   --row number: 19758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3203298 , [Content] ='09/05/18'
 WHERE id=203115275


   --row number: 19759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3203277 , [Content] ='USD'
 WHERE id=203113250


   --row number: 19760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3203277 , [Content] ='117,400 / 142,000 / 166,600 / 191,200 / 215,800'
 WHERE id=203113251


   --row number: 19761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3203277 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203113252


   --row number: 19762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3203277 , [Content] ='140,900 / 170,400 / 199,900 / 229,450 / 259,000'
 WHERE id=203113253


   --row number: 19763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3203298 , [Content] ='6393 US - MRKT 2'
 WHERE id=203115255


   --row number: 19764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3203298 , [Content] ='US - MRKT 2'
 WHERE id=203115256


   --row number: 19765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3203298 , [Content] ='AMS'
 WHERE id=203115257


   --row number: 19766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3203298 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203115258


   --row number: 19767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3203298 , [Content] ='Legal'
 WHERE id=203115259


   --row number: 19768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3203298 , [Content] ='6393 - Legal Counsel IC3'
 WHERE id=203115260


   --row number: 19769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3203298 , [Content] ='Legal Counsel'
 WHERE id=203115261


   --row number: 19770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3203298 , [Content] ='IC3'
 WHERE id=203115262


   --row number: 19771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3203298 , [Content] ='USD'
 WHERE id=203115264


   --row number: 19772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3203342 , [Content] ='3395 US - MRKT 1'
 WHERE id=203119377


   --row number: 19773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3203342 , [Content] ='US - MRKT 1'
 WHERE id=203119378


   --row number: 19774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3203342 , [Content] ='AMS'
 WHERE id=203119379


   --row number: 19775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3203342 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203119380


   --row number: 19776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3203342 , [Content] ='Legal'
 WHERE id=203119381


   --row number: 19777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3203342 , [Content] ='3395 - Dir, Corporate Counsel Mgmt M5'
 WHERE id=203119382


   --row number: 19778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3203342 , [Content] ='Legal Counsel'
 WHERE id=203119383


   --row number: 19779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3203342 , [Content] ='M5'
 WHERE id=203119384


   --row number: 19780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3203342 , [Content] ='USD'
 WHERE id=203119386


   --row number: 19781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3203342 , [Content] ='166,900 / 204,450 / 242,000 / 279,550 / 317,100'
 WHERE id=203119387


   --row number: 19782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3203342 , [Content] ='Yes'
 WHERE id=203119391


   --row number: 19783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3203342 , [Content] ='EXEMPT'
 WHERE id=203119392


   --row number: 19784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3203342 , [Content] ='NO'
 WHERE id=203119393


   --row number: 19785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3203342 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203119394


   --row number: 19786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3203342 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203119395


   --row number: 19787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3203342 , [Content] ='Non Technical'
 WHERE id=203119396


   --row number: 19788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3203342 , [Content] ='09/05/18'
 WHERE id=203119397


   --row number: 19789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3203342 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=203119388


   --row number: 19790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3203342 , [Content] ='208,600 / 255,550 / 302,500 / 349,450 / 396,400'
 WHERE id=203119389


   --row number: 19791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3203342 , [Content] ='25%'
 WHERE id=203119390


   --row number: 19792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3203562 , [Content] ='EMEA'
 WHERE id=203138643


   --row number: 19793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3203562 , [Content] ='09/05/18'
 WHERE id=203138655


   --row number: 19794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3203562 , [Content] ='GERMANY'
 WHERE id=203138644


   --row number: 19795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3203562 , [Content] ='Sales'
 WHERE id=203138645


   --row number: 19796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3203562 , [Content] ='S1224-CE - Customer Education Inside Sales Rep IC4'
 WHERE id=203138646


   --row number: 19797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3203562 , [Content] ='Inside Sales'
 WHERE id=203138647


   --row number: 19798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3203562 , [Content] ='IC4'
 WHERE id=203138648


   --row number: 19799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3203562 , [Content] ='EUR'
 WHERE id=203138650


   --row number: 19800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3203562 , [Content] ='60/40'
 WHERE id=203138651


   --row number: 19801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3203562 , [Content] ='No'
 WHERE id=203138652


   --row number: 19802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3203562 , [Content] ='4 - Sales Workers'
 WHERE id=203138653


   --row number: 19803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3203562 , [Content] ='Non Technical'
 WHERE id=203138654


   --row number: 19804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3203562 , [Content] ='S1224-CE DEU'
 WHERE id=203138641


   --row number: 19805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3203562 , [Content] ='DEU'
 WHERE id=203138642


   --row number: 19806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3203733 , [Content] ='EXEMPT'
 WHERE id=203152637


   --row number: 19807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3203733 , [Content] ='NO'
 WHERE id=203152638


   --row number: 19808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3203733 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203152639


   --row number: 19809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3203733 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203152640


   --row number: 19810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3203733 , [Content] ='Non Technical'
 WHERE id=203152641


   --row number: 19811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3203733 , [Content] ='09/05/18'
 WHERE id=203152642


   --row number: 19812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3203733 , [Content] ='3075 US - MRKT 1'
 WHERE id=203152622


   --row number: 19813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3203733 , [Content] ='US - MRKT 1'
 WHERE id=203152623


   --row number: 19814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3203733 , [Content] ='AMS'
 WHERE id=203152624


   --row number: 19815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3203733 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203152625


   --row number: 19816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3203733 , [Content] ='Finance'
 WHERE id=203152626


   --row number: 19817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3203733 , [Content] ='3075 - Dir, Investor Relations Mgmt M5'
 WHERE id=203152627


   --row number: 19818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3203733 , [Content] ='Investor Relations'
 WHERE id=203152628


   --row number: 19819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3203733 , [Content] ='M5'
 WHERE id=203152629


   --row number: 19820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3203733 , [Content] ='USD'
 WHERE id=203152631


   --row number: 19821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3203733 , [Content] ='144,800 / 177,400 / 210,000 / 242,550 / 275,100'
 WHERE id=203152632


   --row number: 19822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3203733 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=203152633


   --row number: 19823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3203733 , [Content] ='181,000 / 221,750 / 262,500 / 303,200 / 343,900'
 WHERE id=203152634


   --row number: 19824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3203733 , [Content] ='25%'
 WHERE id=203152635


   --row number: 19825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3203733 , [Content] ='Yes'
 WHERE id=203152636


   --row number: 19826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204083 , [Content] ='20%'
 WHERE id=203179339


   --row number: 19827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204083 , [Content] ='Yes'
 WHERE id=203179340


   --row number: 19828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204083 , [Content] ='EXEMPT'
 WHERE id=203179341


   --row number: 19829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204083 , [Content] ='NO'
 WHERE id=203179342


   --row number: 19830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204083 , [Content] ='2 - Professionals'
 WHERE id=203179343


   --row number: 19831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204083 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203179344


   --row number: 19832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204083 , [Content] ='Technical'
 WHERE id=203179345


   --row number: 19833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204083 , [Content] ='09/05/18'
 WHERE id=203179346


   --row number: 19834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204083 , [Content] ='5184 US - MRKT 2'
 WHERE id=203179326


   --row number: 19835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204083 , [Content] ='US - MRKT 2'
 WHERE id=203179327


   --row number: 19836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204083 , [Content] ='AMS'
 WHERE id=203179328


   --row number: 19837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204083 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203179329


   --row number: 19838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204083 , [Content] ='Engineering'
 WHERE id=203179330


   --row number: 19839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204083 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=203179331


   --row number: 19840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204083 , [Content] ='Quality'
 WHERE id=203179332


   --row number: 19841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204083 , [Content] ='IC4'
 WHERE id=203179333


   --row number: 19842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204083 , [Content] ='USD'
 WHERE id=203179335


   --row number: 19843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204083 , [Content] ='91,600 / 110,800 / 130,000 / 149,200 / 168,400'
 WHERE id=203179336


   --row number: 19844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204083 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203179337


   --row number: 19845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204083 , [Content] ='109,900 / 132,950 / 156,000 / 179,050 / 202,100'
 WHERE id=203179338


   --row number: 19846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204112 , [Content] ='EXEMPT'
 WHERE id=203181909


   --row number: 19847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204112 , [Content] ='NO'
 WHERE id=203181910


   --row number: 19848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204112 , [Content] ='2 - Professionals'
 WHERE id=203181911


   --row number: 19849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204112 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203181912


   --row number: 19850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204112 , [Content] ='Technical'
 WHERE id=203181913


   --row number: 19851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204112 , [Content] ='10/05/18'
 WHERE id=203181914


   --row number: 19852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204112 , [Content] ='6484 US - MRKT 1'
 WHERE id=203181893


   --row number: 19853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204112 , [Content] ='US - MRKT 1'
 WHERE id=203181894


   --row number: 19854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204112 , [Content] ='AMS'
 WHERE id=203181895


   --row number: 19855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204112 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203181896


   --row number: 19856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204112 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=203181897


   --row number: 19857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204112 , [Content] ='6484 - Staff Production Service Engineer IC4'
 WHERE id=203181898


   --row number: 19858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204112 , [Content] ='Production service'
 WHERE id=203181899


   --row number: 19859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204112 , [Content] ='IC4'
 WHERE id=203181900


   --row number: 19860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204112 , [Content] ='USD'
 WHERE id=203181902


   --row number: 19861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204112 , [Content] ='111,500 / 134,850 / 158,200 / 181,550 / 204,900'
 WHERE id=203181903


   --row number: 19862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204112 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203181904


   --row number: 19863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204112 , [Content] ='20%'
 WHERE id=203181906


   --row number: 19864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204112 , [Content] ='Yes'
 WHERE id=203181908


   --row number: 19865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204119 , [Content] ='EXEMPT'
 WHERE id=203182462


   --row number: 19866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204119 , [Content] ='NO'
 WHERE id=203182463


   --row number: 19867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204119 , [Content] ='2 - Professionals'
 WHERE id=203182464


   --row number: 19868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204119 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203182465


   --row number: 19869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204119 , [Content] ='Non Technical'
 WHERE id=203182466


   --row number: 19870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204119 , [Content] ='09/05/18'
 WHERE id=203182467


   --row number: 19871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204119 , [Content] ='6604 US - MRKT 1'
 WHERE id=203182447


   --row number: 19872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204119 , [Content] ='US - MRKT 1'
 WHERE id=203182448


   --row number: 19873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204119 , [Content] ='AMS'
 WHERE id=203182449


   --row number: 19874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204119 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203182450


   --row number: 19875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204119 , [Content] ='Marketing'
 WHERE id=203182451


   --row number: 19876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204119 , [Content] ='6604 - Graphics Designer IC4'
 WHERE id=203182452


   --row number: 19877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204119 , [Content] ='Graphic Arts Design'
 WHERE id=203182453


   --row number: 19878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204119 , [Content] ='IC4'
 WHERE id=203182454


   --row number: 19879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204119 , [Content] ='USD'
 WHERE id=203182456


   --row number: 19880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204119 , [Content] ='88,500 / 104,400 / 120,300 / 136,250 / 152,200'
 WHERE id=203182457


   --row number: 19881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204119 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203182458


   --row number: 19882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204119 , [Content] ='101,800 / 120,050 / 138,300 / 156,650 / 175,000'
 WHERE id=203182459


   --row number: 19883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204119 , [Content] ='15%'
 WHERE id=203182460


   --row number: 19884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204119 , [Content] ='Yes'
 WHERE id=203182461


   --row number: 19885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204129 , [Content] ='Yes'
 WHERE id=203183182


   --row number: 19886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204129 , [Content] ='EXEMPT'
 WHERE id=203183183


   --row number: 19887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204129 , [Content] ='NO'
 WHERE id=203183184


   --row number: 19888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204129 , [Content] ='5 - Administrative Support Workers'
 WHERE id=203183185


   --row number: 19889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204129 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203183186


   --row number: 19890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204129 , [Content] ='Non Technical'
 WHERE id=203183187


   --row number: 19891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204129 , [Content] ='09/05/18'
 WHERE id=203183188


   --row number: 19892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204129 , [Content] ='6504 US - MRKT 2'
 WHERE id=203183168


   --row number: 19893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204129 , [Content] ='US - MRKT 2'
 WHERE id=203183169


   --row number: 19894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204129 , [Content] ='AMS'
 WHERE id=203183170


   --row number: 19895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204129 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203183171


   --row number: 19896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204129 , [Content] ='Administration'
 WHERE id=203183172


   --row number: 19897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204129 , [Content] ='6504 - Executive Assistant IC4'
 WHERE id=203183173


   --row number: 19898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204129 , [Content] ='Executive Assistant'
 WHERE id=203183174


   --row number: 19899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204129 , [Content] ='IC4'
 WHERE id=203183175


   --row number: 19900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204129 , [Content] ='USD'
 WHERE id=203183177


   --row number: 19901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204129 , [Content] ='77,900 / 91,900 / 105,900 / 119,950 / 134,000'
 WHERE id=203183178


   --row number: 19902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204129 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203183179


   --row number: 19903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204129 , [Content] ='89,600 / 105,700 / 121,800 / 137,950 / 154,100'
 WHERE id=203183180


   --row number: 19904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204129 , [Content] ='15%'
 WHERE id=203183181


   --row number: 19905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204335 , [Content] ='EXEMPT'
 WHERE id=203205961


   --row number: 19906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204335 , [Content] ='NO'
 WHERE id=203205962


   --row number: 19907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204335 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203205963


   --row number: 19908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204335 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203205964


   --row number: 19909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204335 , [Content] ='Technical'
 WHERE id=203205965


   --row number: 19910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204335 , [Content] ='09/05/18'
 WHERE id=203205966


   --row number: 19911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204335 , [Content] ='S1876 US - MRKT 1'
 WHERE id=203205946


   --row number: 19912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204335 , [Content] ='US - MRKT 1'
 WHERE id=203205947


   --row number: 19913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204335 , [Content] ='AMS'
 WHERE id=203205948


   --row number: 19914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204335 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203205949


   --row number: 19915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204335 , [Content] ='Sales Operations'
 WHERE id=203205950


   --row number: 19916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204335 , [Content] ='S1876 - Sr Dir, Sales Training and Enablement Mgmt M6'
 WHERE id=203205951


   --row number: 19917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204335 , [Content] ='Sales Training/Enablement'
 WHERE id=203205952


   --row number: 19918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204335 , [Content] ='M6'
 WHERE id=203205953


   --row number: 19919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204335 , [Content] ='USD'
 WHERE id=203205955


   --row number: 19920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204335 , [Content] ='144,800 / 177,400 / 210,000 / 242,550 / 275,100'
 WHERE id=203205956


   --row number: 19921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204335 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=203205957


   --row number: 19922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204335 , [Content] ='188,200 / 230,600 / 273,000 / 315,300 / 357,600'
 WHERE id=203205958


   --row number: 19923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204335 , [Content] ='30%'
 WHERE id=203205959


   --row number: 19924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204335 , [Content] ='Yes'
 WHERE id=203205960


   --row number: 19925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204342 , [Content] ='5175 US - MRKT 1'
 WHERE id=203206619


   --row number: 19926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204342 , [Content] ='US - MRKT 1'
 WHERE id=203206620


   --row number: 19927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204342 , [Content] ='AMS'
 WHERE id=203206621


   --row number: 19928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204342 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203206622


   --row number: 19929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204342 , [Content] ='Engineering'
 WHERE id=203206623


   --row number: 19930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204342 , [Content] ='5175 - Machine Learning Engineer IC5'
 WHERE id=203206624


   --row number: 19931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204342 , [Content] ='Machine Learning'
 WHERE id=203206625


   --row number: 19932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204342 , [Content] ='IC5'
 WHERE id=203206626


   --row number: 19933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204342 , [Content] ='USD'
 WHERE id=203206628


   --row number: 19934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204342 , [Content] ='137,900 / 168,950 / 200,000 / 231,000 / 262,000'
 WHERE id=203206629


   --row number: 19935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204342 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=203206630


   --row number: 19936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204342 , [Content] ='172,400 / 211,200 / 250,000 / 288,750 / 327,500'
 WHERE id=203206631


   --row number: 19937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204342 , [Content] ='Yes'
 WHERE id=203206633


   --row number: 19938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204342 , [Content] ='EXEMPT'
 WHERE id=203206634


   --row number: 19939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204342 , [Content] ='NO'
 WHERE id=203206635


   --row number: 19940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204342 , [Content] ='2 - Professionals'
 WHERE id=203206636


   --row number: 19941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204342 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203206637


   --row number: 19942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204342 , [Content] ='Technical'
 WHERE id=203206638


   --row number: 19943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204342 , [Content] ='09/05/18'
 WHERE id=203206639


   --row number: 19944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204342 , [Content] ='25%'
 WHERE id=203206632


   --row number: 19945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204399 , [Content] ='6722 - Purchasing Analyst IC2'
 WHERE id=203213252


   --row number: 19946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204399 , [Content] ='Procurement'
 WHERE id=203213253


   --row number: 19947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204399 , [Content] ='IC2'
 WHERE id=203213254


   --row number: 19948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204399 , [Content] ='USD'
 WHERE id=203213256


   --row number: 19949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204399 , [Content] ='62,000 / 70,850 / 79,700 / 88,500 / 97,300'
 WHERE id=203213257


   --row number: 19950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204399 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=203213258


   --row number: 19951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204399 , [Content] ='68,200 / 77,950 / 87,700 / 97,350 / 107,000'
 WHERE id=203213259


   --row number: 19952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204399 , [Content] ='10%'
 WHERE id=203213260


   --row number: 19953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204399 , [Content] ='6722 US - MRKT 1'
 WHERE id=203213247


   --row number: 19954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204399 , [Content] ='US - MRKT 1'
 WHERE id=203213248


   --row number: 19955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204399 , [Content] ='AMS'
 WHERE id=203213249


   --row number: 19956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204399 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203213250


   --row number: 19957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204399 , [Content] ='Administration'
 WHERE id=203213251


   --row number: 19958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204399 , [Content] ='Yes'
 WHERE id=203213261


   --row number: 19959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3204399 , [Content] ='EXEMPT'
 WHERE id=203213262


   --row number: 19960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3204399 , [Content] ='NO'
 WHERE id=203213263


   --row number: 19961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204399 , [Content] ='2 - Professionals'
 WHERE id=203213264


   --row number: 19962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204399 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203213265


   --row number: 19963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204399 , [Content] ='Non Technical'
 WHERE id=203213266


   --row number: 19964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204399 , [Content] ='09/05/18'
 WHERE id=203213267


   --row number: 19965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204698 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=203257006


   --row number: 19966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3204698 , [Content] ='75/25'
 WHERE id=203257014


   --row number: 19967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204698 , [Content] ='Yes'
 WHERE id=203257015


   --row number: 19968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204698 , [Content] ='4 - Sales Workers'
 WHERE id=203257016


   --row number: 19969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204698 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203257017


   --row number: 19970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204698 , [Content] ='Technical'
 WHERE id=203257018


   --row number: 19971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204698 , [Content] ='09/05/18'
 WHERE id=203257019


   --row number: 19972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204698 , [Content] ='Solution Consultant Core'
 WHERE id=203257007


   --row number: 19973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204698 , [Content] ='IC4'
 WHERE id=203257008


   --row number: 19974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204698 , [Content] ='SGD'
 WHERE id=203257010


   --row number: 19975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204698 , [Content] ='146,625 / 159,563 / 172,500 / 185,438 / 198,375'
 WHERE id=203257011


   --row number: 19976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204698 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=203257012


   --row number: 19977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204698 , [Content] ='195,500 / 212,750 / 230,000 / 247,250 / 264,500'
 WHERE id=203257013


   --row number: 19978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204698 , [Content] ='S1414 SGP'
 WHERE id=203257001


   --row number: 19979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204698 , [Content] ='SGP'
 WHERE id=203257002


   --row number: 19980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204698 , [Content] ='APAC'
 WHERE id=203257003


   --row number: 19981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204698 , [Content] ='SINGAPORE'
 WHERE id=203257004


   --row number: 19982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204698 , [Content] ='Solution Consulting'
 WHERE id=203257005


   --row number: 19983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204700 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203257433


   --row number: 19984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204700 , [Content] ='Non Technical'
 WHERE id=203257434


   --row number: 19985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204700 , [Content] ='09/05/18'
 WHERE id=203257435


   --row number: 19986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204700 , [Content] ='S1373 AUS'
 WHERE id=203257419


   --row number: 19987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204700 , [Content] ='AUS'
 WHERE id=203257420


   --row number: 19988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204700 , [Content] ='APAC'
 WHERE id=203257421


   --row number: 19989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204700 , [Content] ='AUSTRALIA'
 WHERE id=203257422


   --row number: 19990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204700 , [Content] ='Sales'
 WHERE id=203257423


   --row number: 19991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204700 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=203257424


   --row number: 19992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204700 , [Content] ='Inside/Contract Renewal'
 WHERE id=203257425


   --row number: 19993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204700 , [Content] ='A3'
 WHERE id=203257426


   --row number: 19994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204700 , [Content] ='AUD'
 WHERE id=203257428


   --row number: 19995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204700 , [Content] ='13,200 / 18,600 / 24,000 / 29,400 / 34,800'
 WHERE id=203257429


   --row number: 19996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3204700 , [Content] ='70/30'
 WHERE id=203257430


   --row number: 19997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204700 , [Content] ='Yes'
 WHERE id=203257431


   --row number: 19998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204700 , [Content] ='4 - Sales Workers'
 WHERE id=203257432


   --row number: 19999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204790 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203270822


   --row number: 20000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204790 , [Content] ='Non Technical'
 WHERE id=203270823


   --row number: 20001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204790 , [Content] ='09/05/18'
 WHERE id=203270824


   --row number: 20002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204790 , [Content] ='6723 IND'
 WHERE id=203270807


   --row number: 20003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204790 , [Content] ='IND'
 WHERE id=203270808


   --row number: 20004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204790 , [Content] ='APAC'
 WHERE id=203270809


   --row number: 20005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204790 , [Content] ='INDIA'
 WHERE id=203270810


   --row number: 20006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204790 , [Content] ='Administration'
 WHERE id=203270811


   --row number: 20007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204790 , [Content] ='6723 - Purchasing Analyst IC3'
 WHERE id=203270812


   --row number: 20008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204790 , [Content] ='Procurement'
 WHERE id=203270813


   --row number: 20009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204790 , [Content] ='IC3'
 WHERE id=203270814


   --row number: 20010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204790 , [Content] ='INR'
 WHERE id=203270816


   --row number: 20011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204790 , [Content] ='655,200 / 802,600 / 950,000 / 1,097,450 / 1,244,900'
 WHERE id=203270817


   --row number: 20012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204790 , [Content] ='720,700 / 882,850 / 1,045,000 / 1,207,200 / 1,369,400'
 WHERE id=203270818


   --row number: 20013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204790 , [Content] ='10%'
 WHERE id=203270819


   --row number: 20014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204790 , [Content] ='No'
 WHERE id=203270820


   --row number: 20015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204790 , [Content] ='2 - Professionals'
 WHERE id=203270821


   --row number: 20016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204795 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203271252


   --row number: 20017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204795 , [Content] ='Non Technical'
 WHERE id=203271253


   --row number: 20018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204795 , [Content] ='6102 IND'
 WHERE id=203271237


   --row number: 20019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204795 , [Content] ='IND'
 WHERE id=203271238


   --row number: 20020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204795 , [Content] ='APAC'
 WHERE id=203271239


   --row number: 20021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204795 , [Content] ='INDIA'
 WHERE id=203271240


   --row number: 20022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204795 , [Content] ='Finance'
 WHERE id=203271241


   --row number: 20023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204795 , [Content] ='6102 - Accountant IC2'
 WHERE id=203271242


   --row number: 20024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204795 , [Content] ='Accounting'
 WHERE id=203271243


   --row number: 20025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204795 , [Content] ='IC2'
 WHERE id=203271244


   --row number: 20026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204795 , [Content] ='INR'
 WHERE id=203271246


   --row number: 20027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204795 , [Content] ='620,700 / 760,350 / 900,000 / 1,039,650 / 1,179,300'
 WHERE id=203271247


   --row number: 20028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204795 , [Content] ='682,800 / 836,400 / 990,000 / 1,143,600 / 1,297,200'
 WHERE id=203271248


   --row number: 20029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204795 , [Content] ='10%'
 WHERE id=203271249


   --row number: 20030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204795 , [Content] ='No'
 WHERE id=203271250


   --row number: 20031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204795 , [Content] ='2 - Professionals'
 WHERE id=203271251


   --row number: 20032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204795 , [Content] ='09/05/18'
 WHERE id=203271254


   --row number: 20033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204800 , [Content] ='5183 IND'
 WHERE id=203271580


   --row number: 20034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204800 , [Content] ='IND'
 WHERE id=203271581


   --row number: 20035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204800 , [Content] ='APAC'
 WHERE id=203271582


   --row number: 20036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204800 , [Content] ='INDIA'
 WHERE id=203271583


   --row number: 20037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204800 , [Content] ='Engineering'
 WHERE id=203271584


   --row number: 20038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204800 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=203271585


   --row number: 20039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204800 , [Content] ='Quality'
 WHERE id=203271586


   --row number: 20040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204800 , [Content] ='15%'
 WHERE id=203271593


   --row number: 20041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204800 , [Content] ='Yes'
 WHERE id=203271594


   --row number: 20042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204800 , [Content] ='2 - Professionals'
 WHERE id=203271595


   --row number: 20043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204800 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203271596


   --row number: 20044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204800 , [Content] ='Technical'
 WHERE id=203271597


   --row number: 20045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204800 , [Content] ='10/26/2018'
 WHERE id=203271598


   --row number: 20046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204800 , [Content] ='IC3'
 WHERE id=203271587


   --row number: 20047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204800 , [Content] ='INR'
 WHERE id=203271589


   --row number: 20048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204800 , [Content] ='1,344,800 / 1,647,400 / 1,950,000 / 2,252,550 / 2,555,100'
 WHERE id=203271590


   --row number: 20049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204800 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=203271591


   --row number: 20050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204866 , [Content] ='APAC'
 WHERE id=203277185


   --row number: 20051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204866 , [Content] ='2 - Professionals'
 WHERE id=203277197


   --row number: 20052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204866 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203277198


   --row number: 20053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204866 , [Content] ='Technical'
 WHERE id=203277199


   --row number: 20054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204866 , [Content] ='09/05/18'
 WHERE id=203277200


   --row number: 20055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204866 , [Content] ='INDIA'
 WHERE id=203277186


   --row number: 20056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204866 , [Content] ='Engineering'
 WHERE id=203277187


   --row number: 20057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204866 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=203277188


   --row number: 20058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204866 , [Content] ='Software'
 WHERE id=203277189


   --row number: 20059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204866 , [Content] ='IC2'
 WHERE id=203277190


   --row number: 20060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204866 , [Content] ='5142 IND'
 WHERE id=203277183


   --row number: 20061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204866 , [Content] ='IND'
 WHERE id=203277184


   --row number: 20062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204866 , [Content] ='INR'
 WHERE id=203277192


   --row number: 20063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204866 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=203277193


   --row number: 20064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204866 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=203277194


   --row number: 20065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204866 , [Content] ='10%'
 WHERE id=203277195


   --row number: 20066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204866 , [Content] ='No'
 WHERE id=203277196


   --row number: 20067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3204961 , [Content] ='20%'
 WHERE id=203285503


   --row number: 20068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3204961 , [Content] ='Yes'
 WHERE id=203285504


   --row number: 20069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3204961 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203285505


   --row number: 20070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3204961 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203285506


   --row number: 20071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3204961 , [Content] ='Technical'
 WHERE id=203285507


   --row number: 20072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3204961 , [Content] ='09/05/18'
 WHERE id=203285508


   --row number: 20073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3204961 , [Content] ='2553 DEU'
 WHERE id=203285490


   --row number: 20074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3204961 , [Content] ='DEU'
 WHERE id=203285491


   --row number: 20075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3204961 , [Content] ='EMEA'
 WHERE id=203285492


   --row number: 20076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3204961 , [Content] ='GERMANY'
 WHERE id=203285493


   --row number: 20077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3204961 , [Content] ='Professional Services'
 WHERE id=203285494


   --row number: 20078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3204961 , [Content] ='2553 - Mgr, Professional Services Mgmt M3'
 WHERE id=203285495


   --row number: 20079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3204961 , [Content] ='Professional Services'
 WHERE id=203285496


   --row number: 20080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3204961 , [Content] ='M3'
 WHERE id=203285497


   --row number: 20081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3204961 , [Content] ='EUR'
 WHERE id=203285499


   --row number: 20082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3204961 , [Content] ='63,900 / 77,300 / 90,700 / 104,100 / 117,500'
 WHERE id=203285500


   --row number: 20083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3204961 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=203285501


   --row number: 20084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3204961 , [Content] ='76,700 / 92,750 / 108,800 / 124,900 / 141,000'
 WHERE id=203285502


   --row number: 20085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3205357 , [Content] ='EXEMPT'
 WHERE id=203316608


   --row number: 20086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205357 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203316611


   --row number: 20087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205357 , [Content] ='Technical'
 WHERE id=203316612


   --row number: 20088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205357 , [Content] ='10/05/18'
 WHERE id=203316613


   --row number: 20089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3205357 , [Content] ='NO'
 WHERE id=203316609


   --row number: 20090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205357 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203316610


   --row number: 20091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205357 , [Content] ='2144 US - MRKT 2'
 WHERE id=203316593


   --row number: 20092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205357 , [Content] ='US - MRKT 2'
 WHERE id=203316594


   --row number: 20093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205357 , [Content] ='AMS'
 WHERE id=203316595


   --row number: 20094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205357 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203316596


   --row number: 20095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205357 , [Content] ='Engineering'
 WHERE id=203316597


   --row number: 20096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205357 , [Content] ='2144 - Sr Mgr, Software Engrg Mgmt M4'
 WHERE id=203316598


   --row number: 20097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205357 , [Content] ='Software'
 WHERE id=203316599


   --row number: 20098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205357 , [Content] ='M4'
 WHERE id=203316600


   --row number: 20099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205357 , [Content] ='USD'
 WHERE id=203316602


   --row number: 20100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205357 , [Content] ='123,500 / 151,300 / 179,100 / 206,900 / 234,700'
 WHERE id=203316603


   --row number: 20101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205357 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=203316604


   --row number: 20102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205357 , [Content] ='25%'
 WHERE id=203316606


   --row number: 20103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205357 , [Content] ='Yes'
 WHERE id=203316607


   --row number: 20104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205386 , [Content] ='Yes'
 WHERE id=203319825


   --row number: 20105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3205386 , [Content] ='EXEMPT'
 WHERE id=203319826


   --row number: 20106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3205386 , [Content] ='NO'
 WHERE id=203319827


   --row number: 20107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205386 , [Content] ='2 - Professionals'
 WHERE id=203319828


   --row number: 20108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205386 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203319829


   --row number: 20109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205386 , [Content] ='Technical'
 WHERE id=203319830


   --row number: 20110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205386 , [Content] ='09/05/18'
 WHERE id=203319831


   --row number: 20111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205386 , [Content] ='5183 US - MRKT 2'
 WHERE id=203319811


   --row number: 20112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205386 , [Content] ='US - MRKT 2'
 WHERE id=203319812


   --row number: 20113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205386 , [Content] ='AMS'
 WHERE id=203319813


   --row number: 20114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205386 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203319814


   --row number: 20115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205386 , [Content] ='Engineering'
 WHERE id=203319815


   --row number: 20116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205386 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=203319816


   --row number: 20117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205386 , [Content] ='Quality'
 WHERE id=203319817


   --row number: 20118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205386 , [Content] ='IC3'
 WHERE id=203319818


   --row number: 20119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205386 , [Content] ='USD'
 WHERE id=203319820


   --row number: 20120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205386 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=203319821


   --row number: 20121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205386 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203319822


   --row number: 20122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3205386 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=203319823


   --row number: 20123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205386 , [Content] ='15%'
 WHERE id=203319824


   --row number: 20124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205565 , [Content] ='Yes'
 WHERE id=203333106


   --row number: 20125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205565 , [Content] ='2 - Professionals'
 WHERE id=203333107


   --row number: 20126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205565 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203333108


   --row number: 20127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205565 , [Content] ='Technical'
 WHERE id=203333109


   --row number: 20128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205565 , [Content] ='09/05/18'
 WHERE id=203333110


   --row number: 20129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205565 , [Content] ='5224 IND'
 WHERE id=203333092


   --row number: 20130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205565 , [Content] ='IND'
 WHERE id=203333093


   --row number: 20131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205565 , [Content] ='APAC'
 WHERE id=203333094


   --row number: 20132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205565 , [Content] ='INDIA'
 WHERE id=203333095


   --row number: 20133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205565 , [Content] ='Engineering'
 WHERE id=203333096


   --row number: 20134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205565 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=203333097


   --row number: 20135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205565 , [Content] ='Product Mgmt Mgr'
 WHERE id=203333098


   --row number: 20136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205565 , [Content] ='IC4'
 WHERE id=203333099


   --row number: 20137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205565 , [Content] ='INR'
 WHERE id=203333101


   --row number: 20138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205565 , [Content] ='2,310,300 / 2,830,150 / 3,350,000 / 3,869,800 / 4,389,600'
 WHERE id=203333102


   --row number: 20139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205565 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=203333103


   --row number: 20140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3205565 , [Content] ='2,772,400 / 3,396,200 / 4,020,000 / 4,643,750 / 5,267,500'
 WHERE id=203333104


   --row number: 20141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205565 , [Content] ='20%'
 WHERE id=203333105


   --row number: 20142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3205580 , [Content] ='EXEMPT'
 WHERE id=203334639


   --row number: 20143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3205580 , [Content] ='NO'
 WHERE id=203334640


   --row number: 20144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205580 , [Content] ='2 - Professionals'
 WHERE id=203334641


   --row number: 20145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205580 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203334642


   --row number: 20146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205580 , [Content] ='Non Technical'
 WHERE id=203334643


   --row number: 20147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205580 , [Content] ='09/05/18'
 WHERE id=203334644


   --row number: 20148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205580 , [Content] ='6724 US - MRKT 1'
 WHERE id=203334624


   --row number: 20149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205580 , [Content] ='US - MRKT 1'
 WHERE id=203334625


   --row number: 20150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205580 , [Content] ='AMS'
 WHERE id=203334626


   --row number: 20151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205580 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203334627


   --row number: 20152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205580 , [Content] ='Administration'
 WHERE id=203334628


   --row number: 20153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205580 , [Content] ='6724 - Purchasing Analyst IC4'
 WHERE id=203334629


   --row number: 20154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205580 , [Content] ='Procurement'
 WHERE id=203334630


   --row number: 20155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205580 , [Content] ='IC4'
 WHERE id=203334631


   --row number: 20156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205580 , [Content] ='USD'
 WHERE id=203334633


   --row number: 20157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205580 , [Content] ='98,800 / 116,600 / 134,400 / 152,150 / 169,900'
 WHERE id=203334634


   --row number: 20158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205580 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203334635


   --row number: 20159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3205580 , [Content] ='113,600 / 134,100 / 154,600 / 175,000 / 195,400'
 WHERE id=203334636


   --row number: 20160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205580 , [Content] ='15%'
 WHERE id=203334637


   --row number: 20161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205580 , [Content] ='Yes'
 WHERE id=203334638


   --row number: 20162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205630 , [Content] ='Yes'
 WHERE id=203339207


   --row number: 20163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3205630 , [Content] ='EXEMPT'
 WHERE id=203339208


   --row number: 20164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3205630 , [Content] ='NO'
 WHERE id=203339209


   --row number: 20165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205630 , [Content] ='2 - Professionals'
 WHERE id=203339210


   --row number: 20166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205630 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203339211


   --row number: 20167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205630 , [Content] ='Technical'
 WHERE id=203339212


   --row number: 20168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205630 , [Content] ='09/05/18'
 WHERE id=203339213


   --row number: 20169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205630 , [Content] ='5142 US - MRKT 2'
 WHERE id=203339193


   --row number: 20170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205630 , [Content] ='US - MRKT 2'
 WHERE id=203339194


   --row number: 20171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205630 , [Content] ='AMS'
 WHERE id=203339195


   --row number: 20172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205630 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203339196


   --row number: 20173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205630 , [Content] ='Engineering'
 WHERE id=203339197


   --row number: 20174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205630 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=203339198


   --row number: 20175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205630 , [Content] ='Software'
 WHERE id=203339199


   --row number: 20176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205630 , [Content] ='IC2'
 WHERE id=203339200


   --row number: 20177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205630 , [Content] ='USD'
 WHERE id=203339202


   --row number: 20178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205630 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=203339203


   --row number: 20179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205630 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=203339204


   --row number: 20180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3205630 , [Content] ='84,400 / 98,300 / 112,200 / 126,100 / 140,000'
 WHERE id=203339205


   --row number: 20181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205630 , [Content] ='10%'
 WHERE id=203339206


   --row number: 20182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205814 , [Content] ='Yes'
 WHERE id=203356607


   --row number: 20183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3205814 , [Content] ='EXEMPT'
 WHERE id=203356608


   --row number: 20184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3205814 , [Content] ='NO'
 WHERE id=203356609


   --row number: 20185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205814 , [Content] ='2 - Professionals'
 WHERE id=203356610


   --row number: 20186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205814 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203356611


   --row number: 20187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205814 , [Content] ='Technical'
 WHERE id=203356612


   --row number: 20188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205814 , [Content] ='09/05/18'
 WHERE id=203356613


   --row number: 20189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205814 , [Content] ='5144 US - MRKT 2'
 WHERE id=203356593


   --row number: 20190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205814 , [Content] ='US - MRKT 2'
 WHERE id=203356594


   --row number: 20191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205814 , [Content] ='AMS'
 WHERE id=203356595


   --row number: 20192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205814 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203356596


   --row number: 20193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205814 , [Content] ='Engineering'
 WHERE id=203356597


   --row number: 20194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205814 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=203356598


   --row number: 20195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205814 , [Content] ='Software'
 WHERE id=203356599


   --row number: 20196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205814 , [Content] ='IC4'
 WHERE id=203356600


   --row number: 20197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205814 , [Content] ='USD'
 WHERE id=203356602


   --row number: 20198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205814 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=203356603


   --row number: 20199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205814 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=203356604


   --row number: 20200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3205814 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=203356605


   --row number: 20201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205814 , [Content] ='20%'
 WHERE id=203356606


   --row number: 20202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3205824 , [Content] ='Yes'
 WHERE id=203357678


   --row number: 20203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3205824 , [Content] ='EXEMPT'
 WHERE id=203357679


   --row number: 20204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3205824 , [Content] ='NO'
 WHERE id=203357680


   --row number: 20205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3205824 , [Content] ='2 - Professionals'
 WHERE id=203357681


   --row number: 20206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3205824 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203357682


   --row number: 20207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3205824 , [Content] ='Technical'
 WHERE id=203357683


   --row number: 20208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3205824 , [Content] ='09/05/18'
 WHERE id=203357684


   --row number: 20209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3205824 , [Content] ='5184 US - MRKT 1'
 WHERE id=203357664


   --row number: 20210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3205824 , [Content] ='US - MRKT 1'
 WHERE id=203357665


   --row number: 20211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3205824 , [Content] ='AMS'
 WHERE id=203357666


   --row number: 20212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3205824 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203357667


   --row number: 20213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3205824 , [Content] ='Engineering'
 WHERE id=203357668


   --row number: 20214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3205824 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=203357669


   --row number: 20215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3205824 , [Content] ='Quality'
 WHERE id=203357670


   --row number: 20216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3205824 , [Content] ='IC4'
 WHERE id=203357671


   --row number: 20217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3205824 , [Content] ='USD'
 WHERE id=203357673


   --row number: 20218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3205824 , [Content] ='103,300 / 124,950 / 146,600 / 168,250 / 189,900'
 WHERE id=203357674


   --row number: 20219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3205824 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203357675


   --row number: 20220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3205824 , [Content] ='124,000 / 149,950 / 175,900 / 201,900 / 227,900'
 WHERE id=203357676


   --row number: 20221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3205824 , [Content] ='20%'
 WHERE id=203357677


   --row number: 20222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3206055 , [Content] ='EXEMPT'
 WHERE id=203376277


   --row number: 20223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3206055 , [Content] ='NO'
 WHERE id=203376278


   --row number: 20224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206055 , [Content] ='2 - Professionals'
 WHERE id=203376279


   --row number: 20225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206055 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203376280


   --row number: 20226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206055 , [Content] ='Non Technical'
 WHERE id=203376281


   --row number: 20227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206055 , [Content] ='09/05/18'
 WHERE id=203376282


   --row number: 20228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206055 , [Content] ='5614 US - MRKT 1'
 WHERE id=203376262


   --row number: 20229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206055 , [Content] ='US - MRKT 1'
 WHERE id=203376263


   --row number: 20230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206055 , [Content] ='AMS'
 WHERE id=203376264


   --row number: 20231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206055 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203376265


   --row number: 20232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206055 , [Content] ='Marketing'
 WHERE id=203376266


   --row number: 20233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206055 , [Content] ='5614 - Marketing Mgr IC4'
 WHERE id=203376267


   --row number: 20234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206055 , [Content] ='Marketing'
 WHERE id=203376268


   --row number: 20235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206055 , [Content] ='IC4'
 WHERE id=203376269


   --row number: 20236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206055 , [Content] ='USD'
 WHERE id=203376271


   --row number: 20237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206055 , [Content] ='107,200 / 126,500 / 145,800 / 165,100 / 184,400'
 WHERE id=203376272


   --row number: 20238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206055 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203376273


   --row number: 20239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206055 , [Content] ='123,300 / 145,500 / 167,700 / 189,900 / 212,100'
 WHERE id=203376274


   --row number: 20240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206055 , [Content] ='15%'
 WHERE id=203376275


   --row number: 20241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206055 , [Content] ='Yes'
 WHERE id=203376276


   --row number: 20242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206101 , [Content] ='Yes'
 WHERE id=203381606


   --row number: 20243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3206101 , [Content] ='EXEMPT'
 WHERE id=203381607


   --row number: 20244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3206101 , [Content] ='NO'
 WHERE id=203381608


   --row number: 20245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206101 , [Content] ='2 - Professionals'
 WHERE id=203381609


   --row number: 20246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206101 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203381610


   --row number: 20247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206101 , [Content] ='Non Technical'
 WHERE id=203381611


   --row number: 20248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206101 , [Content] ='09/05/18'
 WHERE id=203381612


   --row number: 20249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206101 , [Content] ='5615 US - MRKT 1'
 WHERE id=203381592


   --row number: 20250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206101 , [Content] ='US - MRKT 1'
 WHERE id=203381593


   --row number: 20251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206101 , [Content] ='AMS'
 WHERE id=203381594


   --row number: 20252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206101 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203381595


   --row number: 20253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206101 , [Content] ='Marketing'
 WHERE id=203381596


   --row number: 20254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206101 , [Content] ='5615 - Marketing Mgr IC5'
 WHERE id=203381597


   --row number: 20255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206101 , [Content] ='Marketing'
 WHERE id=203381598


   --row number: 20256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206101 , [Content] ='IC5'
 WHERE id=203381599


   --row number: 20257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206101 , [Content] ='USD'
 WHERE id=203381601


   --row number: 20258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206101 , [Content] ='116,900 / 141,400 / 165,900 / 190,400 / 214,900'
 WHERE id=203381602


   --row number: 20259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206101 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203381603


   --row number: 20260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206101 , [Content] ='140,300 / 169,700 / 199,100 / 228,500 / 257,900'
 WHERE id=203381604


   --row number: 20261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206101 , [Content] ='20%'
 WHERE id=203381605


   --row number: 20262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206109 , [Content] ='6585 US - MRKT 1'
 WHERE id=203382585


   --row number: 20263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206109 , [Content] ='US - MRKT 1'
 WHERE id=203382586


   --row number: 20264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206109 , [Content] ='AMS'
 WHERE id=203382587


   --row number: 20265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206109 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203382588


   --row number: 20266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206109 , [Content] ='Info Systems/Technology'
 WHERE id=203382589


   --row number: 20267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206109 , [Content] ='6585 - Sr Staff Information Security Engineer IC5'
 WHERE id=203382590


   --row number: 20268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206109 , [Content] ='Security'
 WHERE id=203382591


   --row number: 20269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206109 , [Content] ='IC5'
 WHERE id=203382592


   --row number: 20270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206109 , [Content] ='124,100 / 152,050 / 180,000 / 207,900 / 235,800'
 WHERE id=203382594


   --row number: 20271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206109 , [Content] ='2 - Professionals'
 WHERE id=203382600


   --row number: 20272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206109 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203382601


   --row number: 20273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206109 , [Content] ='Technical'
 WHERE id=203382602


   --row number: 20274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206109 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=203382595


   --row number: 20275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206109 , [Content] ='25%'
 WHERE id=203382596


   --row number: 20276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206109 , [Content] ='Yes'
 WHERE id=203382597


   --row number: 20277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3206109 , [Content] ='EXEMPT'
 WHERE id=203382598


   --row number: 20278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3206109 , [Content] ='NO'
 WHERE id=203382599


   --row number: 20279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206296 , [Content] ='S316.1 - Sr Dir, Sales M6'
 WHERE id=203407407


   --row number: 20280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3206296 , [Content] ='EXEMPT'
 WHERE id=203407417


   --row number: 20281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3206296 , [Content] ='NO'
 WHERE id=203407418


   --row number: 20282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206296 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203407419


   --row number: 20283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206296 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203407420


   --row number: 20284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206296 , [Content] ='Technical'
 WHERE id=203407421


   --row number: 20285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206296 , [Content] ='04/05/18'
 WHERE id=203407422


   --row number: 20286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206296 , [Content] ='Sales Management'
 WHERE id=203407408


   --row number: 20287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206296 , [Content] ='M6'
 WHERE id=203407409


   --row number: 20288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206296 , [Content] ='USD'
 WHERE id=203407411


   --row number: 20289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206296 , [Content] ='S316.1 US - MRKT 1'
 WHERE id=203407402


   --row number: 20290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206296 , [Content] ='US - MRKT 1'
 WHERE id=203407403


   --row number: 20291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206296 , [Content] ='AMS'
 WHERE id=203407404


   --row number: 20292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206296 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203407405


   --row number: 20293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206296 , [Content] ='Sales'
 WHERE id=203407406


   --row number: 20294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206296 , [Content] ='178,500 / 194,250 / 210,000 / 225,750 / 241,500'
 WHERE id=203407412


   --row number: 20295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206296 , [Content] ='240,000 / 360,000 / 480,000 / 600,000 / 720,000'
 WHERE id=203407413


   --row number: 20296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206296 , [Content] ='357,000 / 388,500 / 420,000 / 451,500 / 483,000'
 WHERE id=203407414


   --row number: 20297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206296 , [Content] ='50/50'
 WHERE id=203407415


   --row number: 20298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206296 , [Content] ='Yes'
 WHERE id=203407416


   --row number: 20299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206334 , [Content] ='2 - Professionals'
 WHERE id=203422697


   --row number: 20300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206334 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203422698


   --row number: 20301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206334 , [Content] ='Technical'
 WHERE id=203422699


   --row number: 20302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206334 , [Content] ='6/27/2018'
 WHERE id=203422700


   --row number: 20303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206335 , [Content] ='5143 IND'
 WHERE id=203422773


   --row number: 20304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206335 , [Content] ='IND'
 WHERE id=203422774


   --row number: 20305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206335 , [Content] ='APAC'
 WHERE id=203422775


   --row number: 20306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206335 , [Content] ='INDIA'
 WHERE id=203422776


   --row number: 20307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206335 , [Content] ='Engineering'
 WHERE id=203422777


   --row number: 20308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206335 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203422778


   --row number: 20309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206335 , [Content] ='Software'
 WHERE id=203422779


   --row number: 20310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206335 , [Content] ='IC3'
 WHERE id=203422780


   --row number: 20311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206335 , [Content] ='INR'
 WHERE id=203422782


   --row number: 20312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206335 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=203422783


   --row number: 20313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206335 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=203422784


   --row number: 20314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206335 , [Content] ='15%'
 WHERE id=203422785


   --row number: 20315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206335 , [Content] ='Yes'
 WHERE id=203422786


   --row number: 20316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206335 , [Content] ='2 - Professionals'
 WHERE id=203422787


   --row number: 20317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206335 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203422788


   --row number: 20318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206335 , [Content] ='Technical'
 WHERE id=203422789


   --row number: 20319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206335 , [Content] ='6/27/2018'
 WHERE id=203422790


   --row number: 20320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206334 , [Content] ='5143 IND'
 WHERE id=203422683


   --row number: 20321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206334 , [Content] ='IND'
 WHERE id=203422684


   --row number: 20322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206334 , [Content] ='APAC'
 WHERE id=203422685


   --row number: 20323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206334 , [Content] ='INDIA'
 WHERE id=203422686


   --row number: 20324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206334 , [Content] ='Engineering'
 WHERE id=203422687


   --row number: 20325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206334 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203422688


   --row number: 20326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206334 , [Content] ='Software'
 WHERE id=203422689


   --row number: 20327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206334 , [Content] ='IC3'
 WHERE id=203422690


   --row number: 20328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206334 , [Content] ='INR'
 WHERE id=203422692


   --row number: 20329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206334 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=203422693


   --row number: 20330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206334 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=203422694


   --row number: 20331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206334 , [Content] ='15%'
 WHERE id=203422695


   --row number: 20332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206334 , [Content] ='Yes'
 WHERE id=203422696


   --row number: 20333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206336 , [Content] ='5143 IND'
 WHERE id=203422809


   --row number: 20334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206336 , [Content] ='IND'
 WHERE id=203422810


   --row number: 20335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206336 , [Content] ='APAC'
 WHERE id=203422811


   --row number: 20336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206336 , [Content] ='INDIA'
 WHERE id=203422812


   --row number: 20337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206336 , [Content] ='Engineering'
 WHERE id=203422813


   --row number: 20338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206336 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203422814


   --row number: 20339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206336 , [Content] ='Software'
 WHERE id=203422815


   --row number: 20340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206336 , [Content] ='IC3'
 WHERE id=203422816


   --row number: 20341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206336 , [Content] ='INR'
 WHERE id=203422818


   --row number: 20342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206336 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=203422819


   --row number: 20343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206336 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=203422820


   --row number: 20344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206336 , [Content] ='15%'
 WHERE id=203422821


   --row number: 20345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206336 , [Content] ='Yes'
 WHERE id=203422822


   --row number: 20346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206336 , [Content] ='2 - Professionals'
 WHERE id=203422823


   --row number: 20347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206336 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203422824


   --row number: 20348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206336 , [Content] ='Technical'
 WHERE id=203422825


   --row number: 20349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206336 , [Content] ='6/27/2018'
 WHERE id=203422826


   --row number: 20350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206758 , [Content] ='Non Technical'
 WHERE id=203653991


   --row number: 20351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206758 , [Content] ='04/05/18'
 WHERE id=203653992


   --row number: 20352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206758 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203653990


   --row number: 20353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206758 , [Content] ='4 - Sales Workers'
 WHERE id=203653989


   --row number: 20354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206758 , [Content] ='No'
 WHERE id=203653988


   --row number: 20355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206758 , [Content] ='60/40'
 WHERE id=203653987


   --row number: 20356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206758 , [Content] ='782,000 / 851,000 / 920,000 / 989,000 / 1,058,000'
 WHERE id=203653986


   --row number: 20357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206758 , [Content] ='469,200 / 510,600 / 552,000 / 593,400 / 634,800'
 WHERE id=203653985


   --row number: 20358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206758 , [Content] ='INR'
 WHERE id=203653984


   --row number: 20359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206758 , [Content] ='A1'
 WHERE id=203653982


   --row number: 20360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206758 , [Content] ='Inside Sales'
 WHERE id=203653981


   --row number: 20361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206758 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203653980


   --row number: 20362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206758 , [Content] ='Sales'
 WHERE id=203653979


   --row number: 20363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206758 , [Content] ='INDIA'
 WHERE id=203653978


   --row number: 20364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206758 , [Content] ='APAC'
 WHERE id=203653977


   --row number: 20365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206758 , [Content] ='IND'
 WHERE id=203653976


   --row number: 20366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206758 , [Content] ='S1331 IND'
 WHERE id=203653975


   --row number: 20367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206777 , [Content] ='Non Technical'
 WHERE id=203656314


   --row number: 20368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206777 , [Content] ='09/05/18'
 WHERE id=203656315


   --row number: 20369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206777 , [Content] ='S1373 UK'
 WHERE id=203656300


   --row number: 20370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206777 , [Content] ='UK'
 WHERE id=203656301


   --row number: 20371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206777 , [Content] ='EMEA'
 WHERE id=203656302


   --row number: 20372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206777 , [Content] ='UNITED KINGDOM'
 WHERE id=203656303


   --row number: 20373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206777 , [Content] ='Sales'
 WHERE id=203656304


   --row number: 20374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206777 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=203656305


   --row number: 20375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206777 , [Content] ='Inside/Contract Renewal'
 WHERE id=203656306


   --row number: 20376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206777 , [Content] ='A3'
 WHERE id=203656307


   --row number: 20377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206777 , [Content] ='GBP'
 WHERE id=203656309


   --row number: 20378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206777 , [Content] ='70/30'
 WHERE id=203656310


   --row number: 20379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206777 , [Content] ='No'
 WHERE id=203656311


   --row number: 20380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206777 , [Content] ='4 - Sales Workers'
 WHERE id=203656312


   --row number: 20381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206777 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203656313


   --row number: 20382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206778 , [Content] ='Non Technical'
 WHERE id=203656370


   --row number: 20383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206778 , [Content] ='09/05/18'
 WHERE id=203656371


   --row number: 20384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206778 , [Content] ='S1373 UK'
 WHERE id=203656356


   --row number: 20385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206778 , [Content] ='UK'
 WHERE id=203656357


   --row number: 20386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206778 , [Content] ='EMEA'
 WHERE id=203656358


   --row number: 20387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206778 , [Content] ='UNITED KINGDOM'
 WHERE id=203656359


   --row number: 20388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206778 , [Content] ='Sales'
 WHERE id=203656360


   --row number: 20389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206778 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=203656361


   --row number: 20390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206778 , [Content] ='Inside/Contract Renewal'
 WHERE id=203656362


   --row number: 20391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206778 , [Content] ='A3'
 WHERE id=203656363


   --row number: 20392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206778 , [Content] ='GBP'
 WHERE id=203656365


   --row number: 20393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206778 , [Content] ='70/30'
 WHERE id=203656366


   --row number: 20394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206778 , [Content] ='No'
 WHERE id=203656367


   --row number: 20395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206778 , [Content] ='4 - Sales Workers'
 WHERE id=203656368


   --row number: 20396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206778 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203656369


   --row number: 20397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206780 , [Content] ='Non Technical'
 WHERE id=203656562


   --row number: 20398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206780 , [Content] ='09/05/18'
 WHERE id=203656563


   --row number: 20399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206780 , [Content] ='S1373 NLD'
 WHERE id=203656548


   --row number: 20400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206780 , [Content] ='NLD'
 WHERE id=203656549


   --row number: 20401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206780 , [Content] ='EMEA'
 WHERE id=203656550


   --row number: 20402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206780 , [Content] ='NETHERLANDS'
 WHERE id=203656551


   --row number: 20403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206780 , [Content] ='Sales'
 WHERE id=203656552


   --row number: 20404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206780 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=203656553


   --row number: 20405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206780 , [Content] ='Inside/Contract Renewal'
 WHERE id=203656554


   --row number: 20406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206780 , [Content] ='A3'
 WHERE id=203656555


   --row number: 20407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206780 , [Content] ='EUR'
 WHERE id=203656557


   --row number: 20408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206780 , [Content] ='70/30'
 WHERE id=203656558


   --row number: 20409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206780 , [Content] ='No'
 WHERE id=203656559


   --row number: 20410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206780 , [Content] ='4 - Sales Workers'
 WHERE id=203656560


   --row number: 20411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206780 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203656561


   --row number: 20412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206783 , [Content] ='Non Technical'
 WHERE id=203656733


   --row number: 20413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206783 , [Content] ='09/05/18'
 WHERE id=203656734


   --row number: 20414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206783 , [Content] ='S1373 NLD'
 WHERE id=203656719


   --row number: 20415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206783 , [Content] ='NLD'
 WHERE id=203656720


   --row number: 20416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206783 , [Content] ='EMEA'
 WHERE id=203656721


   --row number: 20417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206783 , [Content] ='NETHERLANDS'
 WHERE id=203656722


   --row number: 20418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206783 , [Content] ='Sales'
 WHERE id=203656723


   --row number: 20419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206783 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=203656724


   --row number: 20420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206783 , [Content] ='Inside/Contract Renewal'
 WHERE id=203656725


   --row number: 20421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206783 , [Content] ='A3'
 WHERE id=203656726


   --row number: 20422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206783 , [Content] ='EUR'
 WHERE id=203656728


   --row number: 20423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206783 , [Content] ='70/30'
 WHERE id=203656729


   --row number: 20424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206783 , [Content] ='No'
 WHERE id=203656730


   --row number: 20425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206783 , [Content] ='4 - Sales Workers'
 WHERE id=203656731


   --row number: 20426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206783 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203656732


   --row number: 20427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206784 , [Content] ='Non Technical'
 WHERE id=203656788


   --row number: 20428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206784 , [Content] ='09/05/18'
 WHERE id=203656789


   --row number: 20429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206784 , [Content] ='S1373 NLD'
 WHERE id=203656774


   --row number: 20430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206784 , [Content] ='NLD'
 WHERE id=203656775


   --row number: 20431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206784 , [Content] ='EMEA'
 WHERE id=203656776


   --row number: 20432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206784 , [Content] ='NETHERLANDS'
 WHERE id=203656777


   --row number: 20433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206784 , [Content] ='Sales'
 WHERE id=203656778


   --row number: 20434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206784 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=203656779


   --row number: 20435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206784 , [Content] ='Inside/Contract Renewal'
 WHERE id=203656780


   --row number: 20436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206784 , [Content] ='A3'
 WHERE id=203656781


   --row number: 20437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206784 , [Content] ='EUR'
 WHERE id=203656783


   --row number: 20438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206784 , [Content] ='70/30'
 WHERE id=203656784


   --row number: 20439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206784 , [Content] ='No'
 WHERE id=203656785


   --row number: 20440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206784 , [Content] ='4 - Sales Workers'
 WHERE id=203656786


   --row number: 20441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206784 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203656787


   --row number: 20442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206794 , [Content] ='2 - Professionals'
 WHERE id=203658088


   --row number: 20443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206794 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203658089


   --row number: 20444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206794 , [Content] ='Technical'
 WHERE id=203658090


   --row number: 20445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206794 , [Content] ='09/05/18'
 WHERE id=203658091


   --row number: 20446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206794 , [Content] ='6584 UK'
 WHERE id=203658073


   --row number: 20447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206794 , [Content] ='UK'
 WHERE id=203658074


   --row number: 20448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206794 , [Content] ='EMEA'
 WHERE id=203658075


   --row number: 20449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206794 , [Content] ='UNITED KINGDOM'
 WHERE id=203658076


   --row number: 20450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206794 , [Content] ='Info Systems/Technology'
 WHERE id=203658077


   --row number: 20451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206794 , [Content] ='6584 - Staff Information Security Engineer IC4'
 WHERE id=203658078


   --row number: 20452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206794 , [Content] ='Security'
 WHERE id=203658079


   --row number: 20453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206794 , [Content] ='IC4'
 WHERE id=203658080


   --row number: 20454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206794 , [Content] ='GBP'
 WHERE id=203658082


   --row number: 20455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206794 , [Content] ='48,000 / 58,050 / 68,100 / 78,150 / 88,200'
 WHERE id=203658083


   --row number: 20456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206794 , [Content] ='132,000 / 186,000 / 240,000 / 294,000 / 348,000'
 WHERE id=203658084


   --row number: 20457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206794 , [Content] ='57,600 / 69,650 / 81,700 / 93,750 / 105,800'
 WHERE id=203658085


   --row number: 20458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206794 , [Content] ='20%'
 WHERE id=203658086


   --row number: 20459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206794 , [Content] ='Yes'
 WHERE id=203658087


   --row number: 20460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206796 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203658496


   --row number: 20461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206796 , [Content] ='Non Technical'
 WHERE id=203658497


   --row number: 20462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206796 , [Content] ='09/05/18'
 WHERE id=203658498


   --row number: 20463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206796 , [Content] ='6102 IND'
 WHERE id=203658481


   --row number: 20464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206796 , [Content] ='IND'
 WHERE id=203658482


   --row number: 20465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206796 , [Content] ='APAC'
 WHERE id=203658483


   --row number: 20466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206796 , [Content] ='INDIA'
 WHERE id=203658484


   --row number: 20467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206796 , [Content] ='Finance'
 WHERE id=203658485


   --row number: 20468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206796 , [Content] ='6102 - Accountant IC2'
 WHERE id=203658486


   --row number: 20469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206796 , [Content] ='Accounting'
 WHERE id=203658487


   --row number: 20470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206796 , [Content] ='IC2'
 WHERE id=203658488


   --row number: 20471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206796 , [Content] ='INR'
 WHERE id=203658490


   --row number: 20472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206796 , [Content] ='620,700 / 760,350 / 900,000 / 1,039,650 / 1,179,300'
 WHERE id=203658491


   --row number: 20473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206796 , [Content] ='682,800 / 836,400 / 990,000 / 1,143,600 / 1,297,200'
 WHERE id=203658492


   --row number: 20474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206796 , [Content] ='10%'
 WHERE id=203658493


   --row number: 20475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206796 , [Content] ='No'
 WHERE id=203658494


   --row number: 20476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206796 , [Content] ='2 - Professionals'
 WHERE id=203658495


   --row number: 20477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206799 , [Content] ='6723 IND'
 WHERE id=203658740


   --row number: 20478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206799 , [Content] ='IND'
 WHERE id=203658741


   --row number: 20479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206799 , [Content] ='APAC'
 WHERE id=203658742


   --row number: 20480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206799 , [Content] ='INDIA'
 WHERE id=203658743


   --row number: 20481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206799 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203658755


   --row number: 20482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206799 , [Content] ='Non Technical'
 WHERE id=203658756


   --row number: 20483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206799 , [Content] ='09/05/18'
 WHERE id=203658757


   --row number: 20484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206799 , [Content] ='Administration'
 WHERE id=203658744


   --row number: 20485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206799 , [Content] ='6723 - Purchasing Analyst IC3'
 WHERE id=203658745


   --row number: 20486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206799 , [Content] ='Procurement'
 WHERE id=203658746


   --row number: 20487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206799 , [Content] ='IC3'
 WHERE id=203658747


   --row number: 20488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206799 , [Content] ='INR'
 WHERE id=203658749


   --row number: 20489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206799 , [Content] ='655,200 / 802,600 / 950,000 / 1,097,450 / 1,244,900'
 WHERE id=203658750


   --row number: 20490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206799 , [Content] ='720,700 / 882,850 / 1,045,000 / 1,207,200 / 1,369,400'
 WHERE id=203658751


   --row number: 20491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206799 , [Content] ='10%'
 WHERE id=203658752


   --row number: 20492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206799 , [Content] ='No'
 WHERE id=203658753


   --row number: 20493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206799 , [Content] ='2 - Professionals'
 WHERE id=203658754


   --row number: 20494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206800 , [Content] ='S1331 UK'
 WHERE id=203658896


   --row number: 20495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206800 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203658911


   --row number: 20496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206800 , [Content] ='Non Technical'
 WHERE id=203658912


   --row number: 20497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206800 , [Content] ='09/05/18'
 WHERE id=203658913


   --row number: 20498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206800 , [Content] ='UK'
 WHERE id=203658897


   --row number: 20499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206800 , [Content] ='EMEA'
 WHERE id=203658898


   --row number: 20500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206800 , [Content] ='UNITED KINGDOM'
 WHERE id=203658899


   --row number: 20501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206800 , [Content] ='Sales'
 WHERE id=203658900


   --row number: 20502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206800 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203658901


   --row number: 20503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206800 , [Content] ='Inside Sales'
 WHERE id=203658902


   --row number: 20504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206800 , [Content] ='A1'
 WHERE id=203658903


   --row number: 20505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206800 , [Content] ='GBP'
 WHERE id=203658905


   --row number: 20506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206800 , [Content] ='20,400 / 22,200 / 24,000 / 25,800 / 27,600'
 WHERE id=203658906


   --row number: 20507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206800 , [Content] ='34,000 / 37,000 / 40,000 / 43,000 / 46,000'
 WHERE id=203658907


   --row number: 20508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206800 , [Content] ='60/40'
 WHERE id=203658908


   --row number: 20509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206800 , [Content] ='No'
 WHERE id=203658909


   --row number: 20510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206800 , [Content] ='4 - Sales Workers'
 WHERE id=203658910


   --row number: 20511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206801 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203658973


   --row number: 20512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206801 , [Content] ='Non Technical'
 WHERE id=203658974


   --row number: 20513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206801 , [Content] ='09/05/18'
 WHERE id=203658975


   --row number: 20514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206801 , [Content] ='S1331 UK'
 WHERE id=203658958


   --row number: 20515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206801 , [Content] ='UK'
 WHERE id=203658959


   --row number: 20516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206801 , [Content] ='EMEA'
 WHERE id=203658960


   --row number: 20517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206801 , [Content] ='UNITED KINGDOM'
 WHERE id=203658961


   --row number: 20518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206801 , [Content] ='Sales'
 WHERE id=203658962


   --row number: 20519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206801 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203658963


   --row number: 20520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206801 , [Content] ='Inside Sales'
 WHERE id=203658964


   --row number: 20521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206801 , [Content] ='A1'
 WHERE id=203658965


   --row number: 20522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206801 , [Content] ='GBP'
 WHERE id=203658967


   --row number: 20523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206801 , [Content] ='20,400 / 22,200 / 24,000 / 25,800 / 27,600'
 WHERE id=203658968


   --row number: 20524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206801 , [Content] ='34,000 / 37,000 / 40,000 / 43,000 / 46,000'
 WHERE id=203658969


   --row number: 20525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206801 , [Content] ='60/40'
 WHERE id=203658970


   --row number: 20526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206801 , [Content] ='No'
 WHERE id=203658971


   --row number: 20527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206801 , [Content] ='4 - Sales Workers'
 WHERE id=203658972


   --row number: 20528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206803 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203659111


   --row number: 20529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206803 , [Content] ='Non Technical'
 WHERE id=203659112


   --row number: 20530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206803 , [Content] ='09/05/18'
 WHERE id=203659113


   --row number: 20531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206804 , [Content] ='S1331 UK'
 WHERE id=203659149


   --row number: 20532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206804 , [Content] ='UK'
 WHERE id=203659150


   --row number: 20533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206804 , [Content] ='EMEA'
 WHERE id=203659151


   --row number: 20534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206804 , [Content] ='UNITED KINGDOM'
 WHERE id=203659152


   --row number: 20535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206804 , [Content] ='Sales'
 WHERE id=203659153


   --row number: 20536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206804 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203659154


   --row number: 20537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206804 , [Content] ='Inside Sales'
 WHERE id=203659155


   --row number: 20538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206804 , [Content] ='A1'
 WHERE id=203659156


   --row number: 20539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206804 , [Content] ='GBP'
 WHERE id=203659158


   --row number: 20540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206804 , [Content] ='20,400 / 22,200 / 24,000 / 25,800 / 27,600'
 WHERE id=203659159


   --row number: 20541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206804 , [Content] ='34,000 / 37,000 / 40,000 / 43,000 / 46,000'
 WHERE id=203659160


   --row number: 20542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206804 , [Content] ='60/40'
 WHERE id=203659161


   --row number: 20543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206804 , [Content] ='No'
 WHERE id=203659162


   --row number: 20544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206804 , [Content] ='4 - Sales Workers'
 WHERE id=203659163


   --row number: 20545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206804 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203659164


   --row number: 20546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206804 , [Content] ='Non Technical'
 WHERE id=203659165


   --row number: 20547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206803 , [Content] ='S1331 UK'
 WHERE id=203659096


   --row number: 20548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206803 , [Content] ='UK'
 WHERE id=203659097


   --row number: 20549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206803 , [Content] ='EMEA'
 WHERE id=203659098


   --row number: 20550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206803 , [Content] ='UNITED KINGDOM'
 WHERE id=203659099


   --row number: 20551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206803 , [Content] ='Sales'
 WHERE id=203659100


   --row number: 20552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206803 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203659101


   --row number: 20553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206803 , [Content] ='Inside Sales'
 WHERE id=203659102


   --row number: 20554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206803 , [Content] ='A1'
 WHERE id=203659103


   --row number: 20555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206803 , [Content] ='GBP'
 WHERE id=203659105


   --row number: 20556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206803 , [Content] ='20,400 / 22,200 / 24,000 / 25,800 / 27,600'
 WHERE id=203659106


   --row number: 20557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206803 , [Content] ='34,000 / 37,000 / 40,000 / 43,000 / 46,000'
 WHERE id=203659107


   --row number: 20558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206803 , [Content] ='60/40'
 WHERE id=203659108


   --row number: 20559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206803 , [Content] ='No'
 WHERE id=203659109


   --row number: 20560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206803 , [Content] ='4 - Sales Workers'
 WHERE id=203659110


   --row number: 20561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206804 , [Content] ='09/05/18'
 WHERE id=203659166


   --row number: 20562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206805 , [Content] ='S1331 UK'
 WHERE id=203659222


   --row number: 20563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206805 , [Content] ='UK'
 WHERE id=203659223


   --row number: 20564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206805 , [Content] ='EMEA'
 WHERE id=203659224


   --row number: 20565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206805 , [Content] ='UNITED KINGDOM'
 WHERE id=203659225


   --row number: 20566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206805 , [Content] ='Sales'
 WHERE id=203659226


   --row number: 20567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206805 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203659227


   --row number: 20568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206805 , [Content] ='Inside Sales'
 WHERE id=203659228


   --row number: 20569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206805 , [Content] ='A1'
 WHERE id=203659229


   --row number: 20570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206805 , [Content] ='GBP'
 WHERE id=203659231


   --row number: 20571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206805 , [Content] ='20,400 / 22,200 / 24,000 / 25,800 / 27,600'
 WHERE id=203659232


   --row number: 20572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206805 , [Content] ='34,000 / 37,000 / 40,000 / 43,000 / 46,000'
 WHERE id=203659233


   --row number: 20573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206805 , [Content] ='60/40'
 WHERE id=203659234


   --row number: 20574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206805 , [Content] ='No'
 WHERE id=203659235


   --row number: 20575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206805 , [Content] ='4 - Sales Workers'
 WHERE id=203659236


   --row number: 20576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206805 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203659237


   --row number: 20577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206805 , [Content] ='Non Technical'
 WHERE id=203659238


   --row number: 20578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206805 , [Content] ='09/05/18'
 WHERE id=203659239


   --row number: 20579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206949 , [Content] ='5143 ISR'
 WHERE id=203674468


   --row number: 20580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206949 , [Content] ='ISR'
 WHERE id=203674469


   --row number: 20581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206949 , [Content] ='EMEA'
 WHERE id=203674470


   --row number: 20582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206949 , [Content] ='ISRAEL'
 WHERE id=203674471


   --row number: 20583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206949 , [Content] ='Engineering'
 WHERE id=203674472


   --row number: 20584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206949 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203674473


   --row number: 20585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206949 , [Content] ='Software'
 WHERE id=203674474


   --row number: 20586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206949 , [Content] ='IC3'
 WHERE id=203674475


   --row number: 20587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206949 , [Content] ='ILS'
 WHERE id=203674477


   --row number: 20588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206949 , [Content] ='261,700 / 308,800 / 355,900 / 403,000 / 450,100'
 WHERE id=203674478


   --row number: 20589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206949 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=203674479


   --row number: 20590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206949 , [Content] ='15%'
 WHERE id=203674480


   --row number: 20591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206949 , [Content] ='Yes'
 WHERE id=203674481


   --row number: 20592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206949 , [Content] ='2 - Professionals'
 WHERE id=203674482


   --row number: 20593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206949 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203674483


   --row number: 20594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206949 , [Content] ='Technical'
 WHERE id=203674484


   --row number: 20595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206949 , [Content] ='7/20/18'
 WHERE id=203674485


   --row number: 20596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206960 , [Content] ='Yes'
 WHERE id=203675458


   --row number: 20597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206960 , [Content] ='2 - Professionals'
 WHERE id=203675459


   --row number: 20598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206960 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203675460


   --row number: 20599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206960 , [Content] ='Technical'
 WHERE id=203675461


   --row number: 20600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206960 , [Content] ='7/20/18'
 WHERE id=203675462


   --row number: 20601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206960 , [Content] ='15%'
 WHERE id=203675457


   --row number: 20602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206960 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=203675456


   --row number: 20603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206960 , [Content] ='261,700 / 308,800 / 355,900 / 403,000 / 450,100'
 WHERE id=203675455


   --row number: 20604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206960 , [Content] ='ILS'
 WHERE id=203675454


   --row number: 20605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206960 , [Content] ='IC3'
 WHERE id=203675452


   --row number: 20606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206960 , [Content] ='Software'
 WHERE id=203675451


   --row number: 20607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206960 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203675450


   --row number: 20608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206960 , [Content] ='Engineering'
 WHERE id=203675449


   --row number: 20609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206960 , [Content] ='ISRAEL'
 WHERE id=203675448


   --row number: 20610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206960 , [Content] ='EMEA'
 WHERE id=203675447


   --row number: 20611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206960 , [Content] ='ISR'
 WHERE id=203675446


   --row number: 20612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206960 , [Content] ='5143 ISR'
 WHERE id=203675445


   --row number: 20613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206964 , [Content] ='2 - Professionals'
 WHERE id=203675824


   --row number: 20614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206964 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203675825


   --row number: 20615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206964 , [Content] ='Technical'
 WHERE id=203675826


   --row number: 20616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206964 , [Content] ='7/20/18'
 WHERE id=203675827


   --row number: 20617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206964 , [Content] ='5145 ISR'
 WHERE id=203675810


   --row number: 20618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206964 , [Content] ='ISR'
 WHERE id=203675811


   --row number: 20619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206964 , [Content] ='EMEA'
 WHERE id=203675812


   --row number: 20620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206964 , [Content] ='ISRAEL'
 WHERE id=203675813


   --row number: 20621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206964 , [Content] ='Engineering'
 WHERE id=203675814


   --row number: 20622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206964 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=203675815


   --row number: 20623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206964 , [Content] ='Software'
 WHERE id=203675816


   --row number: 20624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206964 , [Content] ='IC5'
 WHERE id=203675817


   --row number: 20625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206964 , [Content] ='ILS'
 WHERE id=203675819


   --row number: 20626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206964 , [Content] ='328,100 / 401,900 / 475,700 / 549,550 / 623,400'
 WHERE id=203675820


   --row number: 20627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3206964 , [Content] ='186,000 / 261,000 / 336,000 / 411,000 / 486,000'
 WHERE id=203675821


   --row number: 20628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3206964 , [Content] ='25%'
 WHERE id=203675822


   --row number: 20629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206964 , [Content] ='Yes'
 WHERE id=203675823


   --row number: 20630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3206987 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203678315


   --row number: 20631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3206987 , [Content] ='Non Technical'
 WHERE id=203678316


   --row number: 20632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3206987 , [Content] ='09/05/18'
 WHERE id=203678317


   --row number: 20633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3206987 , [Content] ='S1331 UK'
 WHERE id=203678300


   --row number: 20634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3206987 , [Content] ='UK'
 WHERE id=203678301


   --row number: 20635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3206987 , [Content] ='EMEA'
 WHERE id=203678302


   --row number: 20636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3206987 , [Content] ='UNITED KINGDOM'
 WHERE id=203678303


   --row number: 20637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3206987 , [Content] ='Sales'
 WHERE id=203678304


   --row number: 20638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3206987 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=203678305


   --row number: 20639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3206987 , [Content] ='Inside Sales'
 WHERE id=203678306


   --row number: 20640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3206987 , [Content] ='A1'
 WHERE id=203678307


   --row number: 20641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3206987 , [Content] ='GBP'
 WHERE id=203678309


   --row number: 20642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3206987 , [Content] ='20,400 / 22,200 / 24,000 / 25,800 / 27,600'
 WHERE id=203678310


   --row number: 20643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3206987 , [Content] ='34,000 / 37,000 / 40,000 / 43,000 / 46,000'
 WHERE id=203678311


   --row number: 20644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3206987 , [Content] ='60/40'
 WHERE id=203678312


   --row number: 20645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3206987 , [Content] ='No'
 WHERE id=203678313


   --row number: 20646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3206987 , [Content] ='4 - Sales Workers'
 WHERE id=203678314


   --row number: 20647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3207187 , [Content] ='15%'
 WHERE id=203696708


   --row number: 20648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3207187 , [Content] ='Yes'
 WHERE id=203696709


   --row number: 20649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3207187 , [Content] ='EXEMPT'
 WHERE id=203696710


   --row number: 20650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3207187 , [Content] ='NO'
 WHERE id=203696711


   --row number: 20651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3207187 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203696712


   --row number: 20652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3207187 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203696713


   --row number: 20653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3207187 , [Content] ='Technical'
 WHERE id=203696714


   --row number: 20654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3207187 , [Content] ='09/05/18'
 WHERE id=203696715


   --row number: 20655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3207187 , [Content] ='2812 US - MRKT 2'
 WHERE id=203696695


   --row number: 20656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3207187 , [Content] ='US - MRKT 2'
 WHERE id=203696696


   --row number: 20657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3207187 , [Content] ='AMS'
 WHERE id=203696697


   --row number: 20658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3207187 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203696698


   --row number: 20659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3207187 , [Content] ='Customer Support'
 WHERE id=203696699


   --row number: 20660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3207187 , [Content] ='2812 - Sup, Customer Support Mgmt M2'
 WHERE id=203696700


   --row number: 20661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3207187 , [Content] ='Customer Support'
 WHERE id=203696701


   --row number: 20662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3207187 , [Content] ='M2'
 WHERE id=203696702


   --row number: 20663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3207187 , [Content] ='USD'
 WHERE id=203696704


   --row number: 20664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3207187 , [Content] ='64,600 / 76,200 / 87,800 / 99,450 / 111,100'
 WHERE id=203696705


   --row number: 20665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3207187 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203696706


   --row number: 20666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3207187 , [Content] ='74,300 / 87,650 / 101,000 / 114,400 / 127,800'
 WHERE id=203696707


   --row number: 20667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3207637 , [Content] ='5612 US - MRKT 1'
 WHERE id=203742013


   --row number: 20668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3207637 , [Content] ='US - MRKT 1'
 WHERE id=203742014


   --row number: 20669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3207637 , [Content] ='AMS'
 WHERE id=203742015


   --row number: 20670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3207637 , [Content] ='EXEMPT'
 WHERE id=203742028


   --row number: 20671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3207637 , [Content] ='NO'
 WHERE id=203742029


   --row number: 20672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3207637 , [Content] ='2 - Professionals'
 WHERE id=203742030


   --row number: 20673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3207637 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203742031


   --row number: 20674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3207637 , [Content] ='Non Technical'
 WHERE id=203742032


   --row number: 20675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3207637 , [Content] ='10/05/18'
 WHERE id=203742033


   --row number: 20676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3207637 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203742016


   --row number: 20677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3207637 , [Content] ='Marketing'
 WHERE id=203742017


   --row number: 20678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3207637 , [Content] ='5612 - Marketing Mgr IC2'
 WHERE id=203742018


   --row number: 20679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3207637 , [Content] ='Marketing'
 WHERE id=203742019


   --row number: 20680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3207637 , [Content] ='IC2'
 WHERE id=203742020


   --row number: 20681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3207637 , [Content] ='USD'
 WHERE id=203742022


   --row number: 20682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3207637 , [Content] ='68,100 / 77,800 / 87,500 / 97,200 / 106,900'
 WHERE id=203742023


   --row number: 20683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3207637 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=203742024


   --row number: 20684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3207637 , [Content] ='74,900 / 85,600 / 96,300 / 106,950 / 117,600'
 WHERE id=203742025


   --row number: 20685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3207637 , [Content] ='10%'
 WHERE id=203742026


   --row number: 20686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3207637 , [Content] ='Yes'
 WHERE id=203742027


   --row number: 20687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3207885 , [Content] ='5143 US - MRKT 2'
 WHERE id=203770003


   --row number: 20688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3207885 , [Content] ='US - MRKT 2'
 WHERE id=203770004


   --row number: 20689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3207885 , [Content] ='AMS'
 WHERE id=203770005


   --row number: 20690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3207885 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203770006


   --row number: 20691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3207885 , [Content] ='Engineering'
 WHERE id=203770007


   --row number: 20692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3207885 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203770008


   --row number: 20693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3207885 , [Content] ='Software'
 WHERE id=203770009


   --row number: 20694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3207885 , [Content] ='IC3'
 WHERE id=203770010


   --row number: 20695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3207885 , [Content] ='USD'
 WHERE id=203770012


   --row number: 20696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3207885 , [Content] ='Yes'
 WHERE id=203770017


   --row number: 20697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3207885 , [Content] ='EXEMPT'
 WHERE id=203770018


   --row number: 20698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3207885 , [Content] ='NO'
 WHERE id=203770019


   --row number: 20699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3207885 , [Content] ='2 - Professionals'
 WHERE id=203770020


   --row number: 20700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3207885 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203770021


   --row number: 20701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3207885 , [Content] ='Technical'
 WHERE id=203770022


   --row number: 20702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3207885 , [Content] ='10/05/18'
 WHERE id=203770023


   --row number: 20703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3207885 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=203770013


   --row number: 20704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3207885 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=203770014


   --row number: 20705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3207885 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=203770015


   --row number: 20706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3207885 , [Content] ='15%'
 WHERE id=203770016


   --row number: 20707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3208392 , [Content] ='JAPAN'
 WHERE id=203840168


   --row number: 20708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3208392 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203840180


   --row number: 20709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3208392 , [Content] ='Technical'
 WHERE id=203840181


   --row number: 20710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3208392 , [Content] ='7/20/18'
 WHERE id=203840182


   --row number: 20711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3208392 , [Content] ='Sales Operations'
 WHERE id=203840169


   --row number: 20712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3208392 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=203840170


   --row number: 20713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3208392 , [Content] ='Sales Operations'
 WHERE id=203840171


   --row number: 20714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3208392 , [Content] ='IC2'
 WHERE id=203840172


   --row number: 20715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3208392 , [Content] ='JPY'
 WHERE id=203840174


   --row number: 20716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3208392 , [Content] ='6,381,300 / 7,290,650 / 8,200,000 / 9,109,300 / 10,018,600'
 WHERE id=203840175


   --row number: 20717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3208392 , [Content] ='S1832 JPN'
 WHERE id=203840165


   --row number: 20718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3208392 , [Content] ='JPN'
 WHERE id=203840166


   --row number: 20719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3208392 , [Content] ='APAC'
 WHERE id=203840167


   --row number: 20720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3208392 , [Content] ='16,800 / 23,400 / 30,000 / 36,600 / 43,200'
 WHERE id=203840176


   --row number: 20721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3208392 , [Content] ='10%'
 WHERE id=203840177


   --row number: 20722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3208392 , [Content] ='Yes'
 WHERE id=203840178


   --row number: 20723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3208392 , [Content] ='2 - Professionals'
 WHERE id=203840179


   --row number: 20724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3208530 , [Content] ='Yes'
 WHERE id=203869094


   --row number: 20725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3208530 , [Content] ='2 - Professionals'
 WHERE id=203869095


   --row number: 20726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3208530 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203869096


   --row number: 20727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3208530 , [Content] ='Technical'
 WHERE id=203869097


   --row number: 20728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3208530 , [Content] ='10/05/18'
 WHERE id=203869098


   --row number: 20729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3208530 , [Content] ='5143 ISR'
 WHERE id=203869080


   --row number: 20730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3208530 , [Content] ='ISR'
 WHERE id=203869081


   --row number: 20731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3208530 , [Content] ='EMEA'
 WHERE id=203869082


   --row number: 20732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3208530 , [Content] ='ISRAEL'
 WHERE id=203869083


   --row number: 20733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3208530 , [Content] ='Engineering'
 WHERE id=203869084


   --row number: 20734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3208530 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203869085


   --row number: 20735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3208530 , [Content] ='Software'
 WHERE id=203869086


   --row number: 20736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3208530 , [Content] ='IC3'
 WHERE id=203869087


   --row number: 20737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3208530 , [Content] ='ILS'
 WHERE id=203869089


   --row number: 20738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3208530 , [Content] ='261,700 / 308,800 / 355,900 / 403,000 / 450,100'
 WHERE id=203869090


   --row number: 20739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3208530 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=203869091


   --row number: 20740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3208530 , [Content] ='301,000 / 355,150 / 409,300 / 463,450 / 517,600'
 WHERE id=203869092


   --row number: 20741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3208530 , [Content] ='15%'
 WHERE id=203869093


   --row number: 20742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3208531 , [Content] ='2 - Professionals'
 WHERE id=203869143


   --row number: 20743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3208531 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203869144


   --row number: 20744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3208531 , [Content] ='Technical'
 WHERE id=203869145


   --row number: 20745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3208531 , [Content] ='10/05/18'
 WHERE id=203869146


   --row number: 20746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3208531 , [Content] ='5143 ISR'
 WHERE id=203869128


   --row number: 20747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3208531 , [Content] ='ISR'
 WHERE id=203869129


   --row number: 20748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3208531 , [Content] ='EMEA'
 WHERE id=203869130


   --row number: 20749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3208531 , [Content] ='ISRAEL'
 WHERE id=203869131


   --row number: 20750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3208531 , [Content] ='Engineering'
 WHERE id=203869132


   --row number: 20751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3208531 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203869133


   --row number: 20752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3208531 , [Content] ='Software'
 WHERE id=203869134


   --row number: 20753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3208531 , [Content] ='IC3'
 WHERE id=203869135


   --row number: 20754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3208531 , [Content] ='ILS'
 WHERE id=203869137


   --row number: 20755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3208531 , [Content] ='261,700 / 308,800 / 355,900 / 403,000 / 450,100'
 WHERE id=203869138


   --row number: 20756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3208531 , [Content] ='80,400 / 112,200 / 144,000 / 176,400 / 208,800'
 WHERE id=203869139


   --row number: 20757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3208531 , [Content] ='301,000 / 355,150 / 409,300 / 463,450 / 517,600'
 WHERE id=203869140


   --row number: 20758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3208531 , [Content] ='15%'
 WHERE id=203869141


   --row number: 20759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3208531 , [Content] ='Yes'
 WHERE id=203869142


   --row number: 20760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3208533 , [Content] ='Yes'
 WHERE id=203869331


   --row number: 20761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3208534 , [Content] ='5143 IRL'
 WHERE id=203869377


   --row number: 20762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3208534 , [Content] ='IRL'
 WHERE id=203869378


   --row number: 20763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3208534 , [Content] ='EMEA'
 WHERE id=203869379


   --row number: 20764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3208534 , [Content] ='IRELAND'
 WHERE id=203869380


   --row number: 20765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3208534 , [Content] ='Engineering'
 WHERE id=203869381


   --row number: 20766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3208534 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203869382


   --row number: 20767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3208534 , [Content] ='Software'
 WHERE id=203869383


   --row number: 20768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3208534 , [Content] ='IC3'
 WHERE id=203869384


   --row number: 20769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3208534 , [Content] ='EUR'
 WHERE id=203869386


   --row number: 20770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3208534 , [Content] ='50,700 / 59,850 / 69,000 / 78,100 / 87,200'
 WHERE id=203869387


   --row number: 20771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3208534 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=203869388


   --row number: 20772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3208534 , [Content] ='58,300 / 68,850 / 79,400 / 89,850 / 100,300'
 WHERE id=203869389


   --row number: 20773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3208534 , [Content] ='15%'
 WHERE id=203869390


   --row number: 20774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3208534 , [Content] ='Yes'
 WHERE id=203869391


   --row number: 20775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3208534 , [Content] ='2 - Professionals'
 WHERE id=203869392


   --row number: 20776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3208534 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203869393


   --row number: 20777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3208534 , [Content] ='Technical'
 WHERE id=203869394


   --row number: 20778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3208534 , [Content] ='10/05/18'
 WHERE id=203869395


   --row number: 20779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3208533 , [Content] ='2 - Professionals'
 WHERE id=203869332


   --row number: 20780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3208533 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203869333


   --row number: 20781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3208533 , [Content] ='Technical'
 WHERE id=203869334


   --row number: 20782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3208533 , [Content] ='10/05/18'
 WHERE id=203869335


   --row number: 20783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3208533 , [Content] ='5143 IRL'
 WHERE id=203869317


   --row number: 20784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3208533 , [Content] ='IRL'
 WHERE id=203869318


   --row number: 20785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3208533 , [Content] ='EMEA'
 WHERE id=203869319


   --row number: 20786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3208533 , [Content] ='IRELAND'
 WHERE id=203869320


   --row number: 20787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3208533 , [Content] ='Engineering'
 WHERE id=203869321


   --row number: 20788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3208533 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=203869322


   --row number: 20789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3208533 , [Content] ='Software'
 WHERE id=203869323


   --row number: 20790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3208533 , [Content] ='IC3'
 WHERE id=203869324


   --row number: 20791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3208533 , [Content] ='EUR'
 WHERE id=203869326


   --row number: 20792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3208533 , [Content] ='50,700 / 59,850 / 69,000 / 78,100 / 87,200'
 WHERE id=203869327


   --row number: 20793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3208533 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=203869328


   --row number: 20794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3208533 , [Content] ='58,300 / 68,850 / 79,400 / 89,850 / 100,300'
 WHERE id=203869329


   --row number: 20795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209169 , [Content] ='6433 US - MRKT 1'
 WHERE id=203928689


   --row number: 20796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209169 , [Content] ='US - MRKT 1'
 WHERE id=203928690


   --row number: 20797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209169 , [Content] ='AMS'
 WHERE id=203928691


   --row number: 20798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209169 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203928692


   --row number: 20799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209169 , [Content] ='Info Systems/Technology'
 WHERE id=203928693


   --row number: 20800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209169 , [Content] ='6433 - Sr Unified Communications Engineer IC3'
 WHERE id=203928694


   --row number: 20801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209169 , [Content] ='Unified Communications'
 WHERE id=203928695


   --row number: 20802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209169 , [Content] ='IC3'
 WHERE id=203928696


   --row number: 20803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209169 , [Content] ='USD'
 WHERE id=203928698


   --row number: 20804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209169 , [Content] ='81,300 / 95,950 / 110,600 / 125,200 / 139,800'
 WHERE id=203928699


   --row number: 20805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209169 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=203928700


   --row number: 20806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209169 , [Content] ='93,500 / 110,350 / 127,200 / 144,000 / 160,800'
 WHERE id=203928701


   --row number: 20807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3209169 , [Content] ='15%'
 WHERE id=203928702


   --row number: 20808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3209169 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=203928703


   --row number: 20809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209169 , [Content] ='Yes'
 WHERE id=203928704


   --row number: 20810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209169 , [Content] ='EXEMPT'
 WHERE id=203928705


   --row number: 20811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209169 , [Content] ='YES'
 WHERE id=203928706


   --row number: 20812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209169 , [Content] ='2 - Professionals'
 WHERE id=203928707


   --row number: 20813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209169 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203928708


   --row number: 20814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209169 , [Content] ='Non Technical'
 WHERE id=203928709


   --row number: 20815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3208533 , [Content] ='15%'
 WHERE id=203869330


   --row number: 20816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3208586 , [Content] ='2717 UK'
 WHERE id=203874235


   --row number: 20817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3208586 , [Content] ='UK'
 WHERE id=203874236


   --row number: 20818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3208586 , [Content] ='EMEA'
 WHERE id=203874237


   --row number: 20819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3208586 , [Content] ='UNITED KINGDOM'
 WHERE id=203874238


   --row number: 20820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3208586 , [Content] ='Executive'
 WHERE id=203874239


   --row number: 20821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3208586 , [Content] ='2717 - VP, Business Strategy Mgmt M7'
 WHERE id=203874240


   --row number: 20822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3208586 , [Content] ='Vice President'
 WHERE id=203874241


   --row number: 20823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3208586 , [Content] ='M7'
 WHERE id=203874242


   --row number: 20824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3208586 , [Content] ='GBP'
 WHERE id=203874244


   --row number: 20825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3208586 , [Content] ='Yes'
 WHERE id=203874245


   --row number: 20826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3208586 , [Content] ='10/05/18'
 WHERE id=203874246


   --row number: 20827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209169 , [Content] ='10/05/18'
 WHERE id=203928710


   --row number: 20828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209418 , [Content] ='9999 US - MRKT 1'
 WHERE id=203951233


   --row number: 20829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209418 , [Content] ='US - MRKT 1'
 WHERE id=203951234


   --row number: 20830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209418 , [Content] ='AMS'
 WHERE id=203951235


   --row number: 20831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209418 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203951236


   --row number: 20832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209418 , [Content] ='9999 - Intern'
 WHERE id=203951237


   --row number: 20833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209418 , [Content] ='USD'
 WHERE id=203951238


   --row number: 20834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209418 , [Content] ='No'
 WHERE id=203951239


   --row number: 20835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209418 , [Content] ='NON-EXEMPT'
 WHERE id=203951240


   --row number: 20836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209418 , [Content] ='7/20/18'
 WHERE id=203951241


   --row number: 20837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209538 , [Content] ='S1414 US - MRKT 2'
 WHERE id=203960246


   --row number: 20838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209538 , [Content] ='US - MRKT 2'
 WHERE id=203960247


   --row number: 20839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209538 , [Content] ='AMS'
 WHERE id=203960248


   --row number: 20840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209538 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203960249


   --row number: 20841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209538 , [Content] ='Solution Consulting'
 WHERE id=203960250


   --row number: 20842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209538 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=203960251


   --row number: 20843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209538 , [Content] ='Solution Consultant Core'
 WHERE id=203960252


   --row number: 20844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209538 , [Content] ='IC4'
 WHERE id=203960253


   --row number: 20845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209538 , [Content] ='USD'
 WHERE id=203960255


   --row number: 20846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209538 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=203960256


   --row number: 20847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209538 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=203960257


   --row number: 20848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209538 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=203960258


   --row number: 20849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209538 , [Content] ='75/25'
 WHERE id=203960259


   --row number: 20850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209538 , [Content] ='Yes'
 WHERE id=203960260


   --row number: 20851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209538 , [Content] ='EXEMPT'
 WHERE id=203960261


   --row number: 20852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209538 , [Content] ='NO'
 WHERE id=203960262


   --row number: 20853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209538 , [Content] ='4 - Sales Workers'
 WHERE id=203960263


   --row number: 20854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209538 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203960264


   --row number: 20855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209538 , [Content] ='Technical'
 WHERE id=203960265


   --row number: 20856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209538 , [Content] ='10/05/18'
 WHERE id=203960266


   --row number: 20857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209563 , [Content] ='S1414 US - MRKT 3'
 WHERE id=203962672


   --row number: 20858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209563 , [Content] ='US - MRKT 3'
 WHERE id=203962673


   --row number: 20859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209563 , [Content] ='AMS'
 WHERE id=203962674


   --row number: 20860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209563 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203962675


   --row number: 20861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209563 , [Content] ='Solution Consulting'
 WHERE id=203962676


   --row number: 20862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209563 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=203962677


   --row number: 20863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209563 , [Content] ='Solution Consultant Core'
 WHERE id=203962679


   --row number: 20864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209563 , [Content] ='IC4'
 WHERE id=203962680


   --row number: 20865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209563 , [Content] ='USD'
 WHERE id=203962682


   --row number: 20866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209563 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=203962683


   --row number: 20867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209563 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=203962684


   --row number: 20868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209563 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=203962685


   --row number: 20869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209563 , [Content] ='75/25'
 WHERE id=203962686


   --row number: 20870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209563 , [Content] ='Yes'
 WHERE id=203962687


   --row number: 20871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209563 , [Content] ='EXEMPT'
 WHERE id=203962688


   --row number: 20872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209563 , [Content] ='4 - Sales Workers'
 WHERE id=203962689


   --row number: 20873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209563 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203962690


   --row number: 20874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209563 , [Content] ='Technical'
 WHERE id=203962691


   --row number: 20875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209563 , [Content] ='10/05/18'
 WHERE id=203962692


   --row number: 20876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209580 , [Content] ='S1413 US - MRKT 1'
 WHERE id=203964139


   --row number: 20877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209580 , [Content] ='US - MRKT 1'
 WHERE id=203964140


   --row number: 20878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209580 , [Content] ='AMS'
 WHERE id=203964141


   --row number: 20879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209580 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203964142


   --row number: 20880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209580 , [Content] ='Solution Consulting'
 WHERE id=203964143


   --row number: 20881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209580 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=203964144


   --row number: 20882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209580 , [Content] ='Solution Consultant Core'
 WHERE id=203964145


   --row number: 20883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209580 , [Content] ='IC3'
 WHERE id=203964146


   --row number: 20884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209580 , [Content] ='USD'
 WHERE id=203964148


   --row number: 20885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209580 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=203964149


   --row number: 20886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209580 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=203964150


   --row number: 20887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209580 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=203964151


   --row number: 20888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209580 , [Content] ='75/25'
 WHERE id=203964152


   --row number: 20889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209580 , [Content] ='Yes'
 WHERE id=203964153


   --row number: 20890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209580 , [Content] ='EXEMPT'
 WHERE id=203964154


   --row number: 20891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209580 , [Content] ='NO'
 WHERE id=203964155


   --row number: 20892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209580 , [Content] ='4 - Sales Workers'
 WHERE id=203964156


   --row number: 20893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209580 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203964157


   --row number: 20894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209580 , [Content] ='Technical'
 WHERE id=203964158


   --row number: 20895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209580 , [Content] ='10/05/18'
 WHERE id=203964159


   --row number: 20896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209609 , [Content] ='50/50'
 WHERE id=203966995


   --row number: 20897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209609 , [Content] ='Yes'
 WHERE id=203966996


   --row number: 20898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209609 , [Content] ='EXEMPT'
 WHERE id=203966997


   --row number: 20899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209609 , [Content] ='NO'
 WHERE id=203966998


   --row number: 20900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209609 , [Content] ='4 - Sales Workers'
 WHERE id=203966999


   --row number: 20901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209609 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203967000


   --row number: 20902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209609 , [Content] ='Technical'
 WHERE id=203967001


   --row number: 20903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209609 , [Content] ='10/05/18'
 WHERE id=203967002


   --row number: 20904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209609 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=203966994


   --row number: 20905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209609 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=203966993


   --row number: 20906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209609 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=203966992


   --row number: 20907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209609 , [Content] ='USD'
 WHERE id=203966991


   --row number: 20908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209609 , [Content] ='IC5'
 WHERE id=203966989


   --row number: 20909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209609 , [Content] ='Enterprise Accounts'
 WHERE id=203966988


   --row number: 20910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209609 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=203966987


   --row number: 20911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209609 , [Content] ='Sales'
 WHERE id=203966986


   --row number: 20912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209609 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203966985


   --row number: 20913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209609 , [Content] ='AMS'
 WHERE id=203966984


   --row number: 20914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209609 , [Content] ='US - MRKT 1'
 WHERE id=203966983


   --row number: 20915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209609 , [Content] ='S635 US - MRKT 1'
 WHERE id=203966982


   --row number: 20916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209622 , [Content] ='NO'
 WHERE id=203968438


   --row number: 20917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209622 , [Content] ='4 - Sales Workers'
 WHERE id=203968439


   --row number: 20918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209622 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203968440


   --row number: 20919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209622 , [Content] ='Technical'
 WHERE id=203968441


   --row number: 20920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209622 , [Content] ='10/05/18'
 WHERE id=203968442


   --row number: 20921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209622 , [Content] ='S1413 US - MRKT 1'
 WHERE id=203968422


   --row number: 20922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209622 , [Content] ='US - MRKT 1'
 WHERE id=203968423


   --row number: 20923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209622 , [Content] ='AMS'
 WHERE id=203968424


   --row number: 20924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209622 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203968425


   --row number: 20925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209622 , [Content] ='Solution Consulting'
 WHERE id=203968426


   --row number: 20926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209622 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=203968427


   --row number: 20927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209622 , [Content] ='Solution Consultant Core'
 WHERE id=203968428


   --row number: 20928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209622 , [Content] ='IC3'
 WHERE id=203968429


   --row number: 20929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209622 , [Content] ='USD'
 WHERE id=203968431


   --row number: 20930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209622 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=203968432


   --row number: 20931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209622 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=203968433


   --row number: 20932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209622 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=203968434


   --row number: 20933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209622 , [Content] ='75/25'
 WHERE id=203968435


   --row number: 20934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209622 , [Content] ='Yes'
 WHERE id=203968436


   --row number: 20935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209622 , [Content] ='EXEMPT'
 WHERE id=203968437


   --row number: 20936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209623 , [Content] ='5464 US - MRKT 1'
 WHERE id=203968551


   --row number: 20937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209623 , [Content] ='US - MRKT 1'
 WHERE id=203968552


   --row number: 20938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209623 , [Content] ='AMS'
 WHERE id=203968553


   --row number: 20939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209623 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203968554


   --row number: 20940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209623 , [Content] ='Marketing'
 WHERE id=203968555


   --row number: 20941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3209623 , [Content] ='20%'
 WHERE id=203968564


   --row number: 20942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209623 , [Content] ='Yes'
 WHERE id=203968565


   --row number: 20943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209623 , [Content] ='EXEMPT'
 WHERE id=203968566


   --row number: 20944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209623 , [Content] ='NO'
 WHERE id=203968567


   --row number: 20945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209623 , [Content] ='2 - Professionals'
 WHERE id=203968568


   --row number: 20946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209623 , [Content] ='8810-Clerical Office Employees'
 WHERE id=203968569


   --row number: 20947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209623 , [Content] ='Technical'
 WHERE id=203968570


   --row number: 20948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209623 , [Content] ='10/05/18'
 WHERE id=203968571


   --row number: 20949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209623 , [Content] ='5464 - Product Portfolio Mgr IC4'
 WHERE id=203968556


   --row number: 20950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209623 , [Content] ='Product Mgrs'
 WHERE id=203968557


   --row number: 20951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209623 , [Content] ='IC4'
 WHERE id=203968558


   --row number: 20952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209623 , [Content] ='USD'
 WHERE id=203968560


   --row number: 20953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209623 , [Content] ='113,300 / 137,050 / 160,800 / 184,550 / 208,300'
 WHERE id=203968561


   --row number: 20954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209623 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=203968562


   --row number: 20955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209623 , [Content] ='136,000 / 164,500 / 193,000 / 221,500 / 250,000'
 WHERE id=203968563


   --row number: 20956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209627 , [Content] ='S1413 US - MRKT 1'
 WHERE id=203968908


   --row number: 20957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209627 , [Content] ='US - MRKT 1'
 WHERE id=203968909


   --row number: 20958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209627 , [Content] ='AMS'
 WHERE id=203968910


   --row number: 20959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209627 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203968911


   --row number: 20960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209627 , [Content] ='Solution Consulting'
 WHERE id=203968912


   --row number: 20961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209627 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=203968913


   --row number: 20962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209627 , [Content] ='Solution Consultant Core'
 WHERE id=203968914


   --row number: 20963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209627 , [Content] ='IC3'
 WHERE id=203968915


   --row number: 20964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209627 , [Content] ='USD'
 WHERE id=203968917


   --row number: 20965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209627 , [Content] ='NO'
 WHERE id=203968924


   --row number: 20966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209627 , [Content] ='4 - Sales Workers'
 WHERE id=203968925


   --row number: 20967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209627 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203968926


   --row number: 20968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209627 , [Content] ='Technical'
 WHERE id=203968927


   --row number: 20969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209627 , [Content] ='10/05/18'
 WHERE id=203968928


   --row number: 20970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209627 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=203968918


   --row number: 20971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209627 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=203968919


   --row number: 20972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209627 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=203968920


   --row number: 20973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209627 , [Content] ='75/25'
 WHERE id=203968921


   --row number: 20974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209627 , [Content] ='Yes'
 WHERE id=203968922


   --row number: 20975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209627 , [Content] ='EXEMPT'
 WHERE id=203968923


   --row number: 20976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209645 , [Content] ='75/25'
 WHERE id=203970587


   --row number: 20977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209645 , [Content] ='Yes'
 WHERE id=203970588


   --row number: 20978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209645 , [Content] ='EXEMPT'
 WHERE id=203970589


   --row number: 20979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209645 , [Content] ='NO'
 WHERE id=203970590


   --row number: 20980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209645 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203970591


   --row number: 20981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209645 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203970592


   --row number: 20982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209645 , [Content] ='Technical'
 WHERE id=203970593


   --row number: 20983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209645 , [Content] ='10/05/18'
 WHERE id=203970594


   --row number: 20984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209645 , [Content] ='S1404 US - MRKT 2'
 WHERE id=203970574


   --row number: 20985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209645 , [Content] ='US - MRKT 2'
 WHERE id=203970575


   --row number: 20986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209645 , [Content] ='AMS'
 WHERE id=203970576


   --row number: 20987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209645 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203970577


   --row number: 20988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209645 , [Content] ='Solution Consulting'
 WHERE id=203970578


   --row number: 20989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209645 , [Content] ='S1404 - Sr Mgr, Solution Consulting M4'
 WHERE id=203970579


   --row number: 20990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209645 , [Content] ='Solution Consultant Core'
 WHERE id=203970580


   --row number: 20991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209645 , [Content] ='M4'
 WHERE id=203970581


   --row number: 20992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209645 , [Content] ='USD'
 WHERE id=203970583


   --row number: 20993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209645 , [Content] ='162,563 / 176,906 / 191,250 / 205,594 / 219,938'
 WHERE id=203970584


   --row number: 20994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209645 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=203970585


   --row number: 20995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209645 , [Content] ='216,750 / 235,875 / 255,000 / 274,125 / 293,250'
 WHERE id=203970586


   --row number: 20996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209667 , [Content] ='Yes'
 WHERE id=203972404


   --row number: 20997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209667 , [Content] ='EXEMPT'
 WHERE id=203972405


   --row number: 20998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209667 , [Content] ='NO'
 WHERE id=203972406


   --row number: 20999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209667 , [Content] ='2 - Professionals'
 WHERE id=203972407


   --row number: 21000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209667 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=203972408


   --row number: 21001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209667 , [Content] ='Technical'
 WHERE id=203972409


   --row number: 21002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209667 , [Content] ='10/05/18'
 WHERE id=203972410


   --row number: 21003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209667 , [Content] ='5142 US - MRKT 1'
 WHERE id=203972390


   --row number: 21004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209667 , [Content] ='US - MRKT 1'
 WHERE id=203972391


   --row number: 21005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209667 , [Content] ='AMS'
 WHERE id=203972392


   --row number: 21006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209667 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203972393


   --row number: 21007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209667 , [Content] ='Engineering'
 WHERE id=203972394


   --row number: 21008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209667 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=203972395


   --row number: 21009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209667 , [Content] ='Software'
 WHERE id=203972396


   --row number: 21010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209667 , [Content] ='IC2'
 WHERE id=203972397


   --row number: 21011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209667 , [Content] ='USD'
 WHERE id=203972399


   --row number: 21012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209667 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=203972400


   --row number: 21013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209667 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=203972401


   --row number: 21014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209667 , [Content] ='100,900 / 117,550 / 134,200 / 150,800 / 167,400'
 WHERE id=203972402


   --row number: 21015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3209667 , [Content] ='10%'
 WHERE id=203972403


   --row number: 21016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3209683 , [Content] ='75/25'
 WHERE id=203973603


   --row number: 21017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3209683 , [Content] ='Yes'
 WHERE id=203973604


   --row number: 21018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3209683 , [Content] ='EXEMPT'
 WHERE id=203973605


   --row number: 21019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3209683 , [Content] ='NO'
 WHERE id=203973606


   --row number: 21020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3209683 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=203973607


   --row number: 21021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3209683 , [Content] ='8742-Salespersons - Outside'
 WHERE id=203973608


   --row number: 21022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3209683 , [Content] ='Technical'
 WHERE id=203973609


   --row number: 21023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3209683 , [Content] ='10/05/18'
 WHERE id=203973610


   --row number: 21024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3209683 , [Content] ='S1406 US - MRKT 1'
 WHERE id=203973590


   --row number: 21025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3209683 , [Content] ='US - MRKT 1'
 WHERE id=203973591


   --row number: 21026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3209683 , [Content] ='AMS'
 WHERE id=203973592


   --row number: 21027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3209683 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=203973593


   --row number: 21028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3209683 , [Content] ='Solution Consulting'
 WHERE id=203973594


   --row number: 21029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3209683 , [Content] ='S1406 - Sr Dir, Solution Consulting M6'
 WHERE id=203973595


   --row number: 21030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3209683 , [Content] ='Solution Consultant Core'
 WHERE id=203973596


   --row number: 21031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3209683 , [Content] ='M6'
 WHERE id=203973597


   --row number: 21032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3209683 , [Content] ='USD'
 WHERE id=203973599


   --row number: 21033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3209683 , [Content] ='204,000 / 222,000 / 240,000 / 258,000 / 276,000'
 WHERE id=203973600


   --row number: 21034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3209683 , [Content] ='240,000 / 360,000 / 480,000 / 600,000 / 720,000'
 WHERE id=203973601


   --row number: 21035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3209683 , [Content] ='272,000 / 296,000 / 320,000 / 344,000 / 368,000'
 WHERE id=203973602


   --row number: 21036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3210321 , [Content] ='15%'
 WHERE id=204035007


   --row number: 21037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3210321 , [Content] ='Yes'
 WHERE id=204035008


   --row number: 21038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3210321 , [Content] ='EXEMPT'
 WHERE id=204035009


   --row number: 21039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3210321 , [Content] ='NO'
 WHERE id=204035010


   --row number: 21040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3210321 , [Content] ='2 - Professionals'
 WHERE id=204035011


   --row number: 21041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3210321 , [Content] ='8810-Clerical Office Employees'
 WHERE id=204035012


   --row number: 21042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3210321 , [Content] ='Technical'
 WHERE id=204035013


   --row number: 21043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3210321 , [Content] ='10/05/18'
 WHERE id=204035014


   --row number: 21044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3210321 , [Content] ='4684 US - MRKT 2'
 WHERE id=204034994


   --row number: 21045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3210321 , [Content] ='US - MRKT 2'
 WHERE id=204034995


   --row number: 21046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3210321 , [Content] ='AMS'
 WHERE id=204034996


   --row number: 21047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3210321 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=204034997


   --row number: 21048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3210321 , [Content] ='Business Strategy'
 WHERE id=204034998


   --row number: 21049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3210321 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=204034999


   --row number: 21050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3210321 , [Content] ='Business Process'
 WHERE id=204035000


   --row number: 21051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3210321 , [Content] ='IC4'
 WHERE id=204035001


   --row number: 21052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3210321 , [Content] ='USD'
 WHERE id=204035003


   --row number: 21053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3210321 , [Content] ='87,300 / 103,000 / 118,700 / 134,450 / 150,200'
 WHERE id=204035004


   --row number: 21054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3210321 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=204035005


   --row number: 21055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3210321 , [Content] ='100,400 / 118,450 / 136,500 / 154,600 / 172,700'
 WHERE id=204035006


   --row number: 21056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3210526 , [Content] ='Yes'
 WHERE id=204074805


   --row number: 21057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3210526 , [Content] ='EXEMPT'
 WHERE id=204074806


   --row number: 21058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3210526 , [Content] ='2 - Professionals'
 WHERE id=204074807


   --row number: 21059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3210526 , [Content] ='8810-Clerical Office Employees'
 WHERE id=204074808


   --row number: 21060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3210526 , [Content] ='Technical'
 WHERE id=204074809


   --row number: 21061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3210526 , [Content] ='10/05/18'
 WHERE id=204074810


   --row number: 21062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3210526 , [Content] ='5874 US - MRKT 3'
 WHERE id=204074791


   --row number: 21063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3210526 , [Content] ='US - MRKT 3'
 WHERE id=204074792


   --row number: 21064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3210526 , [Content] ='AMS'
 WHERE id=204074793


   --row number: 21065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3210526 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=204074794


   --row number: 21066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3210526 , [Content] ='Professional Services'
 WHERE id=204074795


   --row number: 21067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3210526 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=204074796


   --row number: 21068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3210526 , [Content] ='Engagement Mgrs'
 WHERE id=204074797


   --row number: 21069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3210526 , [Content] ='IC4'
 WHERE id=204074798


   --row number: 21070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3210526 , [Content] ='USD'
 WHERE id=204074800


   --row number: 21071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3210526 , [Content] ='84,200 / 101,850 / 119,500 / 137,150 / 154,800'
 WHERE id=204074801


   --row number: 21072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3210526 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=204074802


   --row number: 21073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3210526 , [Content] ='101,000 / 122,200 / 143,400 / 164,600 / 185,800'
 WHERE id=204074803


   --row number: 21074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3210526 , [Content] ='20%'
 WHERE id=204074804


   --row number: 21075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3210528 , [Content] ='S1332 US - MRKT 2'
 WHERE id=204075392


   --row number: 21076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3210528 , [Content] ='US - MRKT 2'
 WHERE id=204075393


   --row number: 21077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3210528 , [Content] ='AMS'
 WHERE id=204075394


   --row number: 21078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3210528 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=204075395


   --row number: 21079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3210528 , [Content] ='Sales'
 WHERE id=204075396


   --row number: 21080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3210528 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=204075397


   --row number: 21081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3210528 , [Content] ='NO'
 WHERE id=204075407


   --row number: 21082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3210528 , [Content] ='4 - Sales Workers'
 WHERE id=204075408


   --row number: 21083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3210528 , [Content] ='8810-Clerical Office Employees'
 WHERE id=204075409


   --row number: 21084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3210528 , [Content] ='Non Technical'
 WHERE id=204075410


   --row number: 21085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3210528 , [Content] ='10/05/18'
 WHERE id=204075411


   --row number: 21086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3210528 , [Content] ='Inside Sales'
 WHERE id=204075398


   --row number: 21087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3210528 , [Content] ='A2'
 WHERE id=204075399


   --row number: 21088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3210528 , [Content] ='USD'
 WHERE id=204075401


   --row number: 21089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3210528 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=204075402


   --row number: 21090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3210528 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=204075403


   --row number: 21091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3210528 , [Content] ='60/40'
 WHERE id=204075404


   --row number: 21092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3210528 , [Content] ='No'
 WHERE id=204075405


   --row number: 21093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3210528 , [Content] ='NON-EXEMPT'
 WHERE id=204075406


   --row number: 21094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3211038 , [Content] ='Yes'
 WHERE id=204133569


   --row number: 21095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3211038 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=204133570


   --row number: 21096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3211038 , [Content] ='8742-Salespersons - Outside'
 WHERE id=204133571


   --row number: 21097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3211038 , [Content] ='Technical'
 WHERE id=204133572


   --row number: 21098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3211038 , [Content] ='10/05/18'
 WHERE id=204133573


   --row number: 21099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3211038 , [Content] ='S316.1 UK'
 WHERE id=204133555


   --row number: 21100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3211038 , [Content] ='UK'
 WHERE id=204133556


   --row number: 21101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3211038 , [Content] ='EMEA'
 WHERE id=204133557


   --row number: 21102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3211038 , [Content] ='UNITED KINGDOM'
 WHERE id=204133558


   --row number: 21103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3211038 , [Content] ='Sales'
 WHERE id=204133559


   --row number: 21104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3211038 , [Content] ='S316.1 - Sr Dir, Sales M6'
 WHERE id=204133560


   --row number: 21105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3211038 , [Content] ='Sales Management'
 WHERE id=204133561


   --row number: 21106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3211038 , [Content] ='M6'
 WHERE id=204133562


   --row number: 21107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3211038 , [Content] ='GBP'
 WHERE id=204133564


   --row number: 21108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3211038 , [Content] ='119,000 / 129,500 / 140,000 / 150,500 / 161,000'
 WHERE id=204133565


   --row number: 21109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3211038 , [Content] ='192,000 / 288,000 / 384,000 / 480,000 / 576,000'
 WHERE id=204133566


   --row number: 21110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3211038 , [Content] ='238,000 / 259,000 / 280,000 / 301,000 / 322,000'
 WHERE id=204133567


   --row number: 21111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3211038 , [Content] ='50/50'
 WHERE id=204133568


   --row number: 21112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3211155 , [Content] ='5223 US - MRKT 2'
 WHERE id=204142038


   --row number: 21113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3211155 , [Content] ='US - MRKT 2'
 WHERE id=204142039


   --row number: 21114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3211155 , [Content] ='AMS'
 WHERE id=204142040


   --row number: 21115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3211155 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=204142041


   --row number: 21116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3211155 , [Content] ='Engineering'
 WHERE id=204142042


   --row number: 21117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3211155 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=204142043


   --row number: 21118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3211155 , [Content] ='Product Mgmt Mgr'
 WHERE id=204142044


   --row number: 21119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3211155 , [Content] ='IC3'
 WHERE id=204142045


   --row number: 21120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3211155 , [Content] ='USD'
 WHERE id=204142047


   --row number: 21121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3211155 , [Content] ='89,000 / 105,000 / 121,000 / 137,050 / 153,100'
 WHERE id=204142048


   --row number: 21122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3211155 , [Content] ='Yes'
 WHERE id=204142052


   --row number: 21123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3211155 , [Content] ='EXEMPT'
 WHERE id=204142053


   --row number: 21124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3211155 , [Content] ='NO'
 WHERE id=204142054


   --row number: 21125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3211155 , [Content] ='2 - Professionals'
 WHERE id=204142055


   --row number: 21126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3211155 , [Content] ='8810-Clerical Office Employees'
 WHERE id=204142056


   --row number: 21127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3211155 , [Content] ='Technical'
 WHERE id=204142057


   --row number: 21128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3211155 , [Content] ='10/05/18'
 WHERE id=204142058


   --row number: 21129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3211155 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=204142049


   --row number: 21130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3211155 , [Content] ='102,400 / 120,800 / 139,200 / 157,650 / 176,100'
 WHERE id=204142050


   --row number: 21131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3211155 , [Content] ='15%'
 WHERE id=204142051


   --row number: 21132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3211177 , [Content] ='AMS'
 WHERE id=204143719


   --row number: 21133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3211177 , [Content] ='Yes'
 WHERE id=204143731


   --row number: 21134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3211177 , [Content] ='EXEMPT'
 WHERE id=204143732


   --row number: 21135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3211177 , [Content] ='NO'
 WHERE id=204143733


   --row number: 21136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3211177 , [Content] ='2 - Professionals'
 WHERE id=204143734


   --row number: 21137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3211177 , [Content] ='8810-Clerical Office Employees'
 WHERE id=204143735


   --row number: 21138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3211177 , [Content] ='Technical'
 WHERE id=204143736


   --row number: 21139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3211177 , [Content] ='10/05/18'
 WHERE id=204143737


   --row number: 21140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3211177 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=204143720


   --row number: 21141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3211177 , [Content] ='Engineering'
 WHERE id=204143721


   --row number: 21142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3211177 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=204143722


   --row number: 21143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3211177 , [Content] ='Product Mgmt Mgr'
 WHERE id=204143723


   --row number: 21144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3211177 , [Content] ='IC3'
 WHERE id=204143724


   --row number: 21145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3211177 , [Content] ='USD'
 WHERE id=204143726


   --row number: 21146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3211177 , [Content] ='101,300 / 119,500 / 137,700 / 155,950 / 174,200'
 WHERE id=204143727


   --row number: 21147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3211177 , [Content] ='5223 US - MRKT 1'
 WHERE id=204143717


   --row number: 21148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3211177 , [Content] ='US - MRKT 1'
 WHERE id=204143718


   --row number: 21149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3211177 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=204143728


   --row number: 21150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3211177 , [Content] ='116,500 / 137,450 / 158,400 / 179,350 / 200,300'
 WHERE id=204143729


   --row number: 21151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3211177 , [Content] ='15%'
 WHERE id=204143730


 ----------------------------------------------

 
--(625 row(s) affected)


   --row number: 1

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58882 and itemid =2788336


   --row number: 2

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58882 and itemid =2792234


   --row number: 3

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=70430 and itemid =2788336


   --row number: 4

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=70430 and itemid =2792234


   --row number: 5

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2397693


   --row number: 6

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3149559


   --row number: 7

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2586877


   --row number: 8

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2401377


   --row number: 9

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2408937


   --row number: 10

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3102116


   --row number: 11

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3121757


   --row number: 12

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3101947


   --row number: 13

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3072420


   --row number: 14

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3162889


   --row number: 15

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2783730


   --row number: 16

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2978388


   --row number: 17

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3039522


   --row number: 18

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2495299


   --row number: 19

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2758925


   --row number: 20

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3206109


   --row number: 21

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3073815


   --row number: 22

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2614462


   --row number: 23

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3035731


   --row number: 24

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3073805


   --row number: 25

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3107613


   --row number: 26

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2743672


   --row number: 27

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3115584


   --row number: 28

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3150472


   --row number: 29

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =2731037


   --row number: 30

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3104965


   --row number: 31

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3200401


   --row number: 32

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3097008


   --row number: 33

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=133434 and itemid =3150722


   --row number: 34

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40094 and itemid =2788336


   --row number: 35

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40094 and itemid =2792234


   --row number: 36

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40095 and itemid =2788336


   --row number: 37

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40095 and itemid =2792234


   --row number: 38

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58880 and itemid =2788336


   --row number: 39

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58880 and itemid =2792234


   --row number: 40

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3066859


   --row number: 41

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3133906


   --row number: 42

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2788336


   --row number: 43

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2792234


   --row number: 44

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2586877


   --row number: 45

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2401377


   --row number: 46

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3089699


   --row number: 47

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3100699


   --row number: 48

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3121757


   --row number: 49

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3072420


   --row number: 50

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3174075


   --row number: 51

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3206783


   --row number: 52

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3204700


   --row number: 53

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3206778


   --row number: 54

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3117231


   --row number: 55

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3206784


   --row number: 56

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2901867


   --row number: 57

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3039522


   --row number: 58

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3090280


   --row number: 59

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3115798


   --row number: 60

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2970117


   --row number: 61

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3178784


   --row number: 62

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3117300


   --row number: 63

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3150649


   --row number: 64

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2920300


   --row number: 65

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2920334


   --row number: 66

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3107613


   --row number: 67

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3203562


   --row number: 68

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2897003


   --row number: 69

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2970115


   --row number: 70

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3031022


   --row number: 71

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3037953


   --row number: 72

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3173827


   --row number: 73

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3188872


   --row number: 74

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2970120


   --row number: 75

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3014763


   --row number: 76

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3032125


   --row number: 77

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3128081


   --row number: 78

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3131862


   --row number: 79

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3133904


   --row number: 80

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3206777


   --row number: 81

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3206780


   --row number: 82

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2821072


   --row number: 83

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =2982838


   --row number: 84

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3052724


   --row number: 85

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3090432


   --row number: 86

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3090465


   --row number: 87

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3141455


   --row number: 88

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3141762


   --row number: 89

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69931 and itemid =3150722


   --row number: 90

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2915928


   --row number: 91

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2971284


   --row number: 92

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3018612


   --row number: 93

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3063881


   --row number: 94

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3064239


   --row number: 95

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3064264


   --row number: 96

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3080001


   --row number: 97

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3090269


   --row number: 98

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3101799


   --row number: 99

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102486


   --row number: 100

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3121114


   --row number: 101

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3179854


   --row number: 102

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3201900


   --row number: 103

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209622


   --row number: 104

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2812617


   --row number: 105

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3035741


   --row number: 106

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3076707


   --row number: 107

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3103458


   --row number: 108

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3132198


   --row number: 109

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136645


   --row number: 110

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3147495


   --row number: 111

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3149559


   --row number: 112

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3180174


   --row number: 113

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3196998


   --row number: 114

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200508


   --row number: 115

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2788336


   --row number: 116

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2792234


   --row number: 117

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2826149


   --row number: 118

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2916289


   --row number: 119

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3064267


   --row number: 120

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102134


   --row number: 121

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102292


   --row number: 122

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3116092


   --row number: 123

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136644


   --row number: 124

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3141381


   --row number: 125

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2586877


   --row number: 126

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2847086


   --row number: 127

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3018601


   --row number: 128

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3018622


   --row number: 129

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3030962


   --row number: 130

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3050862


   --row number: 131

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3064260


   --row number: 132

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3070263


   --row number: 133

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2408937


   --row number: 134

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2822062


   --row number: 135

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2885667


   --row number: 136

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3064240


   --row number: 137

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3097915


   --row number: 138

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3097918


   --row number: 139

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3142807


   --row number: 140

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3148713


   --row number: 141

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3182579


   --row number: 142

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102109


   --row number: 143

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102116


   --row number: 144

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3105328


   --row number: 145

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3120435


   --row number: 146

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3121757


   --row number: 147

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200584


   --row number: 148

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200775


   --row number: 149

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3101445


   --row number: 150

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3101797


   --row number: 151

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3101947


   --row number: 152

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3120791


   --row number: 153

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3147462


   --row number: 154

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3154135


   --row number: 155

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3133560


   --row number: 156

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3138542


   --row number: 157

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3141233


   --row number: 158

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3180172


   --row number: 159

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2265417


   --row number: 160

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2882107


   --row number: 161

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2927333


   --row number: 162

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3055193


   --row number: 163

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3058133


   --row number: 164

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3072420


   --row number: 165

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3167197


   --row number: 166

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3174075


   --row number: 167

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3179790


   --row number: 168

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3185516


   --row number: 169

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3190514


   --row number: 170

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3202537


   --row number: 171

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206783


   --row number: 172

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206801


   --row number: 173

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206805


   --row number: 174

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3183628


   --row number: 175

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3186450


   --row number: 176

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3195606


   --row number: 177

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3204700


   --row number: 178

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206758


   --row number: 179

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206778


   --row number: 180

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206800


   --row number: 181

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206804


   --row number: 182

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3076723


   --row number: 183

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3105726


   --row number: 184

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3106348


   --row number: 185

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3108898


   --row number: 186

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3147514


   --row number: 187

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3174080


   --row number: 188

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200791


   --row number: 189

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3204698


   --row number: 190

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206784


   --row number: 191

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206803


   --row number: 192

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209580


   --row number: 193

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209609


   --row number: 194

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209627


   --row number: 195

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3211038


   --row number: 196

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2656405


   --row number: 197

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2824770


   --row number: 198

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2853565


   --row number: 199

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2861700


   --row number: 200

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2946647


   --row number: 201

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2975563


   --row number: 202

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206987


   --row number: 203

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209683


   --row number: 204

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2989446


   --row number: 205

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2990351


   --row number: 206

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3007723


   --row number: 207

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3008473


   --row number: 208

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3023859


   --row number: 209

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3039522


   --row number: 210

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3069017


   --row number: 211

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3084287


   --row number: 212

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3089542


   --row number: 213

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3092465


   --row number: 214

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3092846


   --row number: 215

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3095775


   --row number: 216

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102489


   --row number: 217

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3114448


   --row number: 218

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3119456


   --row number: 219

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3121719


   --row number: 220

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3125331


   --row number: 221

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3125605


   --row number: 222

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3126866


   --row number: 223

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2808380


   --row number: 224

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2841767


   --row number: 225

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3133512


   --row number: 226

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136650


   --row number: 227

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136651


   --row number: 228

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3146283


   --row number: 229

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3146656


   --row number: 230

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3154324


   --row number: 231

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3155334


   --row number: 232

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2850631


   --row number: 233

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2903851


   --row number: 234

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2945331


   --row number: 235

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2971767


   --row number: 236

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3024068


   --row number: 237

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3179807


   --row number: 238

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3180223


   --row number: 239

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3188550


   --row number: 240

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3039451


   --row number: 241

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3054578


   --row number: 242

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3054975


   --row number: 243

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3056367


   --row number: 244

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200596


   --row number: 245

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200784


   --row number: 246

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3201846


   --row number: 247

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3109595


   --row number: 248

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3117093


   --row number: 249

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3123239


   --row number: 250

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3123576


   --row number: 251

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3126873


   --row number: 252

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3143769


   --row number: 253

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3146286


   --row number: 254

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3149763


   --row number: 255

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3151860


   --row number: 256

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3168724


   --row number: 257

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3177041


   --row number: 258

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3180153


   --row number: 259

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3187688


   --row number: 260

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3190617


   --row number: 261

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3191070


   --row number: 262

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3192345


   --row number: 263

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3193633


   --row number: 264

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2614462


   --row number: 265

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2704765


   --row number: 266

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2807018


   --row number: 267

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2946228


   --row number: 268

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3003841


   --row number: 269

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3077248


   --row number: 270

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3080307


   --row number: 271

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3081893


   --row number: 272

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3107613


   --row number: 273

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3123566


   --row number: 274

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3126471


   --row number: 275

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3130053


   --row number: 276

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3133534


   --row number: 277

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136641


   --row number: 278

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3162821


   --row number: 279

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3163563


   --row number: 280

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3168224


   --row number: 281

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3179863


   --row number: 282

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3188341


   --row number: 283

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3188414


   --row number: 284

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3188539


   --row number: 285

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3191125


   --row number: 286

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209563


   --row number: 287

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3195682


   --row number: 288

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3199627


   --row number: 289

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200591


   --row number: 290

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3203562


   --row number: 291

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209538


   --row number: 292

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3210528


   --row number: 293

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2853032


   --row number: 294

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2854907


   --row number: 295

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2874792


   --row number: 296

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2908003


   --row number: 297

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2983253


   --row number: 298

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2998557


   --row number: 299

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3034897


   --row number: 300

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3035892


   --row number: 301

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3061985


   --row number: 302

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3062079


   --row number: 303

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3066117


   --row number: 304

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3090150


   --row number: 305

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3091275


   --row number: 306

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209645


   --row number: 307

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3098523


   --row number: 308

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3102479


   --row number: 309

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3104978


   --row number: 310

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3109585


   --row number: 311

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3114396


   --row number: 312

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3125314


   --row number: 313

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3135454


   --row number: 314

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136648


   --row number: 315

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3143078


   --row number: 316

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3149667


   --row number: 317

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2830817


   --row number: 318

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2853013


   --row number: 319

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3154140


   --row number: 320

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3162113


   --row number: 321

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3162820


   --row number: 322

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3168721


   --row number: 323

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3173535


   --row number: 324

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3177068


   --row number: 325

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3185964


   --row number: 326

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2914189


   --row number: 327

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2916288


   --row number: 328

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2920372


   --row number: 329

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2925160


   --row number: 330

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2972231


   --row number: 331

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3012909


   --row number: 332

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3032125


   --row number: 333

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3037190


   --row number: 334

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3041448


   --row number: 335

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3044477


   --row number: 336

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3054566


   --row number: 337

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3055882


   --row number: 338

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3076768


   --row number: 339

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3080000


   --row number: 340

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3081755


   --row number: 341

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3084481


   --row number: 342

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3114361


   --row number: 343

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3119451


   --row number: 344

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3133492


   --row number: 345

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3135563


   --row number: 346

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3136649


   --row number: 347

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3140281


   --row number: 348

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3141378


   --row number: 349

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3144083


   --row number: 350

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3151872


   --row number: 351

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3154160


   --row number: 352

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3154537


   --row number: 353

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3162817


   --row number: 354

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3172052


   --row number: 355

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3172087


   --row number: 356

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3172129


   --row number: 357

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3177107


   --row number: 358

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3195616


   --row number: 359

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3195664


   --row number: 360

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200401


   --row number: 361

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200783


   --row number: 362

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3201886


   --row number: 363

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3209418


   --row number: 364

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206777


   --row number: 365

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206780


   --row number: 366

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2683667


   --row number: 367

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2732449


   --row number: 368

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =2899509


   --row number: 369

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3006239


   --row number: 370

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3006468


   --row number: 371

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3044476


   --row number: 372

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3054501


   --row number: 373

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3055971


   --row number: 374

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3056359


   --row number: 375

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3066422


   --row number: 376

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3083711


   --row number: 377

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3087480


   --row number: 378

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3097830


   --row number: 379

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3110627


   --row number: 380

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3114299


   --row number: 381

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3125935


   --row number: 382

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3133571


   --row number: 383

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3134278


   --row number: 384

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3149759


   --row number: 385

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3150722


   --row number: 386

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3151873


   --row number: 387

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3155352


   --row number: 388

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3156564


   --row number: 389

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3162819


   --row number: 390

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3169016


   --row number: 391

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3180231


   --row number: 392

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3185452


   --row number: 393

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3186227


   --row number: 394

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3198719


   --row number: 395

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200774


   --row number: 396

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3200781


   --row number: 397

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3206296


   --row number: 398

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69933 and itemid =3208586


   --row number: 399

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69930 and itemid =2788336


   --row number: 400

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69930 and itemid =2792234


   --row number: 401

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=69930 and itemid =2477230


   --row number: 402

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3018612


   --row number: 403

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3121822


   --row number: 404

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3133906


   --row number: 405

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3134075


   --row number: 406

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3082738


   --row number: 407

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3154244


   --row number: 408

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3156642


   --row number: 409

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3166979


   --row number: 410

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2788336


   --row number: 411

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2792234


   --row number: 412

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3015771


   --row number: 413

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3018601


   --row number: 414

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3018622


   --row number: 415

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2868437


   --row number: 416

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099351


   --row number: 417

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3121368


   --row number: 418

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3200775


   --row number: 419

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099384


   --row number: 420

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3156822


   --row number: 421

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3174079


   --row number: 422

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2820485


   --row number: 423

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3201173


   --row number: 424

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206783


   --row number: 425

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206778


   --row number: 426

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206796


   --row number: 427

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206799


   --row number: 428

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099365


   --row number: 429

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3129870


   --row number: 430

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3179720


   --row number: 431

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3200791


   --row number: 432

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206784


   --row number: 433

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2762575


   --row number: 434

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2824512


   --row number: 435

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2914241


   --row number: 436

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2929073


   --row number: 437

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2946592


   --row number: 438

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2946647


   --row number: 439

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3024262


   --row number: 440

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3077944


   --row number: 441

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3090280


   --row number: 442

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3150092


   --row number: 443

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2843411


   --row number: 444

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3161101


   --row number: 445

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3178784


   --row number: 446

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3189214


   --row number: 447

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3033018


   --row number: 448

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3054380


   --row number: 449

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099787


   --row number: 450

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3131724


   --row number: 451

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3167214


   --row number: 452

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3189215


   --row number: 453

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3189580


   --row number: 454

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3192345


   --row number: 455

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2826952


   --row number: 456

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2920334


   --row number: 457

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2979055


   --row number: 458

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3040050


   --row number: 459

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3076756


   --row number: 460

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3084296


   --row number: 461

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3098682


   --row number: 462

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099725


   --row number: 463

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3128180


   --row number: 464

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3128213


   --row number: 465

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3130053


   --row number: 466

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3150569


   --row number: 467

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3154477


   --row number: 468

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3161087


   --row number: 469

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3185931


   --row number: 470

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3203562


   --row number: 471

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2764552


   --row number: 472

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2821098


   --row number: 473

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2841082


   --row number: 474

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2853963


   --row number: 475

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2944265


   --row number: 476

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2969924


   --row number: 477

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2977228


   --row number: 478

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2977265


   --row number: 479

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2979057


   --row number: 480

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2982118


   --row number: 481

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2983253


   --row number: 482

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3004593


   --row number: 483

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3035200


   --row number: 484

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3054388


   --row number: 485

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3094546


   --row number: 486

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3096314


   --row number: 487

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2684930


   --row number: 488

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099747


   --row number: 489

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3103010


   --row number: 490

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3103034


   --row number: 491

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3104978


   --row number: 492

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3119501


   --row number: 493

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3131621


   --row number: 494

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3139205


   --row number: 495

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3144049


   --row number: 496

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3148244


   --row number: 497

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2822623


   --row number: 498

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2896863


   --row number: 499

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2916317


   --row number: 500

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2922544


   --row number: 501

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2946589


   --row number: 502

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2970120


   --row number: 503

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2975486


   --row number: 504

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2977001


   --row number: 505

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2977257


   --row number: 506

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2999524


   --row number: 507

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3012725


   --row number: 508

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3058342


   --row number: 509

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3064774


   --row number: 510

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3076768


   --row number: 511

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3082736


   --row number: 512

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3096295


   --row number: 513

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3111912


   --row number: 514

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3131862


   --row number: 515

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3133904


   --row number: 516

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3154319


   --row number: 517

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3166980


   --row number: 518

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3204790


   --row number: 519

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3204795


   --row number: 520

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206777


   --row number: 521

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3206780


   --row number: 522

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2729570


   --row number: 523

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2892377


   --row number: 524

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =2930890


   --row number: 525

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3035198


   --row number: 526

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3096315


   --row number: 527

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3099319


   --row number: 528

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3123987


   --row number: 529

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3124000


   --row number: 530

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3131699


   --row number: 531

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3134072


   --row number: 532

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3143257


   --row number: 533

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3171848


   --row number: 534

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3200774


   --row number: 535

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=40104 and itemid =3204866


   --row number: 536

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58885 and itemid =2788336


   --row number: 537

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58885 and itemid =2792234


   --row number: 538

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58886 and itemid =2788336


   --row number: 539

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58886 and itemid =2792234


   --row number: 540

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58886 and itemid =3133534


   --row number: 541

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58886 and itemid =2917597


   --row number: 542

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=58886 and itemid =3149759


   --row number: 543

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=85933 and itemid =2788336


   --row number: 544

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=85933 and itemid =2792234


   --row number: 545

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=85933 and itemid =2477230


   --row number: 546

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=85933 and itemid =3204112


   --row number: 547

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =2788336


   --row number: 548

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =2792234


   --row number: 549

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3188614


   --row number: 550

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3190312


   --row number: 551

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3190326


   --row number: 552

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3188699


   --row number: 553

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3189926


   --row number: 554

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3189937


   --row number: 555

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3188679


   --row number: 556

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3189944


   --row number: 557

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3083711


   --row number: 558

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3188716


   --row number: 559

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87518 and itemid =3208586


   --row number: 560

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87516 and itemid =2788336


   --row number: 561

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87516 and itemid =2792234


   --row number: 562

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87516 and itemid =2477230


   --row number: 563

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87516 and itemid =3208586


   --row number: 564

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87517 and itemid =2788336


   --row number: 565

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87517 and itemid =2792234


   --row number: 566

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87517 and itemid =2477230


   --row number: 567

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87517 and itemid =3203562


   --row number: 568

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=87517 and itemid =3208586


   --row number: 569

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=107219 and itemid =2788336


   --row number: 570

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=107219 and itemid =2792234


   --row number: 571

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=107219 and itemid =3035731


   --row number: 572

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2397693


   --row number: 573

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3149559


   --row number: 574

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2788336


   --row number: 575

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2792234


   --row number: 576

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2586877


   --row number: 577

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2401377


   --row number: 578

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2408937


   --row number: 579

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3102116


   --row number: 580

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3121757


   --row number: 581

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3101947


   --row number: 582

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2477230


   --row number: 583

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3072420


   --row number: 584

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3174075


   --row number: 585

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3162889


   --row number: 586

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2783730


   --row number: 587

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2978388


   --row number: 588

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3039522


   --row number: 589

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2495299


   --row number: 590

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2758925


   --row number: 591

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3206109


   --row number: 592

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3073815


   --row number: 593

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2614462


   --row number: 594

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3035731


   --row number: 595

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3073805


   --row number: 596

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3107613


   --row number: 597

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2743672


   --row number: 598

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3104360


   --row number: 599

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3115584


   --row number: 600

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3150472


   --row number: 601

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2731037


   --row number: 602

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3104965


   --row number: 603

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3200401


   --row number: 604

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =2708835


   --row number: 605

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3097008


   --row number: 606

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=134049 and itemid =3150722


   --row number: 607

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =2788336


   --row number: 608

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =2792234


   --row number: 609

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =2586877


   --row number: 610

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3121757


   --row number: 611

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =2477230


   --row number: 612

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3072420


   --row number: 613

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3174075


   --row number: 614

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3206783


   --row number: 615

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3204700


   --row number: 616

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3206778


   --row number: 617

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3206784


   --row number: 618

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3039522


   --row number: 619

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3107613


   --row number: 620

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3203562


   --row number: 621

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3032125


   --row number: 622

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3206777


   --row number: 623

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3206780


   --row number: 624

   UPDATE [T_CustomFieldContent]
   SET companyid=-companyid , fieldid=-fieldid , itemid=-itemid 
 WHERE companyid=1159 and fieldid=137510 and itemid =3150722
