
--Total 3000


   --row number: 15001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3169016 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=200109554


   --row number: 15002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3169016 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200109555


   --row number: 15003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3169016 , [Content] ='Technical'
 WHERE id=200109556


   --row number: 15004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3169016 , [Content] ='09/05/18'
 WHERE id=200109557


   --row number: 15005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3169016 , [Content] ='S315 US - MRKT 1'
 WHERE id=200109537


   --row number: 15006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3169016 , [Content] ='US - MRKT 1'
 WHERE id=200109538


   --row number: 15007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3169016 , [Content] ='AMS'
 WHERE id=200109539


   --row number: 15008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3169016 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200109540


   --row number: 15009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3169016 , [Content] ='Sales'
 WHERE id=200109541


   --row number: 15010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3169016 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=200109542


   --row number: 15011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3169016 , [Content] ='Sales Management'
 WHERE id=200109543


   --row number: 15012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3169016 , [Content] ='M5'
 WHERE id=200109544


   --row number: 15013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3169016 , [Content] ='USD'
 WHERE id=200109546


   --row number: 15014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3169016 , [Content] ='159,375 / 173,438 / 187,500 / 201,563 / 215,625'
 WHERE id=200109547


   --row number: 15015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3169016 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=200109548


   --row number: 15016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3170370 , [Content] ='USD'
 WHERE id=200175676


   --row number: 15017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3170370 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=200175677


   --row number: 15018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3170370 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=200175678


   --row number: 15019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3170370 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=200175679


   --row number: 15020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3170370 , [Content] ='15%'
 WHERE id=200175680


   --row number: 15021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3170370 , [Content] ='Yes'
 WHERE id=200175681


   --row number: 15022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3170370 , [Content] ='EXEMPT'
 WHERE id=200175682


   --row number: 15023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3170370 , [Content] ='NO'
 WHERE id=200175683


   --row number: 15024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3170370 , [Content] ='2 - Professionals'
 WHERE id=200175684


   --row number: 15025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3170370 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200175685


   --row number: 15026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3170370 , [Content] ='Technical'
 WHERE id=200175686


   --row number: 15027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3170370 , [Content] ='09/05/18'
 WHERE id=200175687


   --row number: 15028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3170370 , [Content] ='IC3'
 WHERE id=200175674


   --row number: 15029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3170370 , [Content] ='5143 US - MRKT 1'
 WHERE id=200175667


   --row number: 15030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3170370 , [Content] ='US - MRKT 1'
 WHERE id=200175668


   --row number: 15031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3170370 , [Content] ='AMS'
 WHERE id=200175669


   --row number: 15032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3170370 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200175670


   --row number: 15033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3170370 , [Content] ='Engineering'
 WHERE id=200175671


   --row number: 15034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3170370 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=200175672


   --row number: 15035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3170370 , [Content] ='Software'
 WHERE id=200175673


   --row number: 15036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3170385 , [Content] ='Yes'
 WHERE id=200177019


   --row number: 15037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3170385 , [Content] ='EXEMPT'
 WHERE id=200177020


   --row number: 15038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3170385 , [Content] ='NO'
 WHERE id=200177021


   --row number: 15039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3171179 , [Content] ='6482 US - MRKT 1'
 WHERE id=200249780


   --row number: 15040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3171179 , [Content] ='US - MRKT 1'
 WHERE id=200249781


   --row number: 15041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3171179 , [Content] ='AMS'
 WHERE id=200249782


   --row number: 15042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3171179 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200249783


   --row number: 15043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3171179 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=200249784


   --row number: 15044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3171179 , [Content] ='6482 - Production Service Engineer IC2'
 WHERE id=200249785


   --row number: 15045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3171179 , [Content] ='Production service'
 WHERE id=200249786


   --row number: 15046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3171179 , [Content] ='IC2'
 WHERE id=200249787


   --row number: 15047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3171179 , [Content] ='USD'
 WHERE id=200249789


   --row number: 15048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3171179 , [Content] ='83,500 / 97,300 / 111,100 / 124,850 / 138,600'
 WHERE id=200249790


   --row number: 15049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3171179 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200249791


   --row number: 15050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3171179 , [Content] ='91,900 / 107,050 / 122,200 / 137,350 / 152,500'
 WHERE id=200249792


   --row number: 15051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3171179 , [Content] ='10%'
 WHERE id=200249793


   --row number: 15052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3171179 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=200249794


   --row number: 15053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3171179 , [Content] ='Yes'
 WHERE id=200249795


   --row number: 15054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3171179 , [Content] ='EXEMPT'
 WHERE id=200249796


   --row number: 15055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3171179 , [Content] ='YES'
 WHERE id=200249797


   --row number: 15056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3171179 , [Content] ='2 - Professionals'
 WHERE id=200249798


   --row number: 15057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3171179 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200249799


   --row number: 15058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3171179 , [Content] ='Technical'
 WHERE id=200249800


   --row number: 15059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3170385 , [Content] ='5142 US - MRKT 1'
 WHERE id=200177005


   --row number: 15060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3170385 , [Content] ='US - MRKT 1'
 WHERE id=200177006


   --row number: 15061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3170385 , [Content] ='AMS'
 WHERE id=200177007


   --row number: 15062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3170385 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200177008


   --row number: 15063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3170385 , [Content] ='Engineering'
 WHERE id=200177009


   --row number: 15064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3170385 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=200177010


   --row number: 15065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3170385 , [Content] ='Software'
 WHERE id=200177011


   --row number: 15066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3170385 , [Content] ='IC2'
 WHERE id=200177012


   --row number: 15067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3170385 , [Content] ='USD'
 WHERE id=200177014


   --row number: 15068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3170385 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=200177015


   --row number: 15069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3170385 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=200177016


   --row number: 15070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3170385 , [Content] ='100,900 / 117,550 / 134,200 / 150,800 / 167,400'
 WHERE id=200177017


   --row number: 15071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3170385 , [Content] ='10%'
 WHERE id=200177018


   --row number: 15072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3170385 , [Content] ='2 - Professionals'
 WHERE id=200177029


   --row number: 15073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3170385 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200177031


   --row number: 15074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3170385 , [Content] ='Technical'
 WHERE id=200177032


   --row number: 15075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3170385 , [Content] ='09/05/18'
 WHERE id=200177033


   --row number: 15076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3171179 , [Content] ='09/05/18'
 WHERE id=200249801


   --row number: 15077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3171191 , [Content] ='5143 US - MRKT 1'
 WHERE id=200250485


   --row number: 15078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3171191 , [Content] ='US - MRKT 1'
 WHERE id=200250486


   --row number: 15079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3171191 , [Content] ='AMS'
 WHERE id=200250487


   --row number: 15080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3171191 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200250488


   --row number: 15081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3171191 , [Content] ='Engineering'
 WHERE id=200250489


   --row number: 15082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3171191 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=200250490


   --row number: 15083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3171191 , [Content] ='Software'
 WHERE id=200250491


   --row number: 15084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3171191 , [Content] ='IC3'
 WHERE id=200250492


   --row number: 15085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3171191 , [Content] ='USD'
 WHERE id=200250494


   --row number: 15086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3171191 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=200250495


   --row number: 15087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3171191 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=200250496


   --row number: 15088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3171191 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=200250497


   --row number: 15089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3171191 , [Content] ='15%'
 WHERE id=200250498


   --row number: 15090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3171191 , [Content] ='Yes'
 WHERE id=200250499


   --row number: 15091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3171191 , [Content] ='EXEMPT'
 WHERE id=200250500


   --row number: 15092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3171191 , [Content] ='NO'
 WHERE id=200250501


   --row number: 15093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3171191 , [Content] ='2 - Professionals'
 WHERE id=200250502


   --row number: 15094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3171191 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200250503


   --row number: 15095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3171191 , [Content] ='Technical'
 WHERE id=200250504


   --row number: 15096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3171191 , [Content] ='09/05/18'
 WHERE id=200250505


   --row number: 15097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3171519 , [Content] ='5615 US - MRKT 2'
 WHERE id=200280402


   --row number: 15098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3171519 , [Content] ='US - MRKT 2'
 WHERE id=200280403


   --row number: 15099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3171519 , [Content] ='AMS'
 WHERE id=200280404


   --row number: 15100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3171519 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200280405


   --row number: 15101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3171519 , [Content] ='Marketing'
 WHERE id=200280406


   --row number: 15102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3171519 , [Content] ='5615 - Marketing Mgr IC5'
 WHERE id=200280407


   --row number: 15103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3171519 , [Content] ='Marketing'
 WHERE id=200280408


   --row number: 15104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3171519 , [Content] ='IC5'
 WHERE id=200280409


   --row number: 15105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3171519 , [Content] ='USD'
 WHERE id=200280411


   --row number: 15106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3171519 , [Content] ='109,400 / 132,300 / 155,200 / 178,150 / 201,100'
 WHERE id=200280412


   --row number: 15107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3171519 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=200280413


   --row number: 15108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3171519 , [Content] ='131,300 / 158,750 / 186,200 / 213,750 / 241,300'
 WHERE id=200280414


   --row number: 15109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3171519 , [Content] ='20%'
 WHERE id=200280415


   --row number: 15110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3171519 , [Content] ='Yes'
 WHERE id=200280416


   --row number: 15111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3171519 , [Content] ='EXEMPT'
 WHERE id=200280417


   --row number: 15112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3171519 , [Content] ='NO'
 WHERE id=200280418


   --row number: 15113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3171519 , [Content] ='2 - Professionals'
 WHERE id=200280419


   --row number: 15114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3171519 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200280420


   --row number: 15115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3171519 , [Content] ='Non Technical'
 WHERE id=200280421


   --row number: 15116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3171519 , [Content] ='10/05/18'
 WHERE id=200280422


   --row number: 15117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3171566 , [Content] ='6003 US - MRKT 1'
 WHERE id=200285422


   --row number: 15118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3171566 , [Content] ='US - MRKT 1'
 WHERE id=200285423


   --row number: 15119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3171566 , [Content] ='AMS'
 WHERE id=200285424


   --row number: 15120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3171566 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200285425


   --row number: 15121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3171566 , [Content] ='Finance'
 WHERE id=200285426


   --row number: 15122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3171566 , [Content] ='6003 - Sr. FP&A Analyst IC3'
 WHERE id=200285427


   --row number: 15123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3171566 , [Content] ='FP&A'
 WHERE id=200285428


   --row number: 15124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3171566 , [Content] ='IC3'
 WHERE id=200285429


   --row number: 15125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3171566 , [Content] ='USD'
 WHERE id=200285431


   --row number: 15126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3171566 , [Content] ='82,200 / 95,750 / 109,300 / 122,900 / 136,500'
 WHERE id=200285432


   --row number: 15127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3171566 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200285433


   --row number: 15128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3171566 , [Content] ='90,400 / 105,300 / 120,200 / 135,200 / 150,200'
 WHERE id=200285434


   --row number: 15129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3171566 , [Content] ='10%'
 WHERE id=200285435


   --row number: 15130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3171566 , [Content] ='Yes'
 WHERE id=200285436


   --row number: 15131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3171566 , [Content] ='EXEMPT'
 WHERE id=200285437


   --row number: 15132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3171566 , [Content] ='NO'
 WHERE id=200285438


   --row number: 15133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3171566 , [Content] ='2 - Professionals'
 WHERE id=200285439


   --row number: 15134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3171566 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200285440


   --row number: 15135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3171566 , [Content] ='Non Technical'
 WHERE id=200285441


   --row number: 15136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3171566 , [Content] ='09/05/18'
 WHERE id=200285442


   --row number: 15137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3171848 , [Content] ='5142 IND'
 WHERE id=200330630


   --row number: 15138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3171848 , [Content] ='IND'
 WHERE id=200330631


   --row number: 15139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3171848 , [Content] ='APAC'
 WHERE id=200330632


   --row number: 15140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3171848 , [Content] ='INDIA'
 WHERE id=200330633


   --row number: 15141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3171848 , [Content] ='Engineering'
 WHERE id=200330634


   --row number: 15142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3171848 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=200330635


   --row number: 15143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3171848 , [Content] ='Software'
 WHERE id=200330636


   --row number: 15144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3171848 , [Content] ='IC2'
 WHERE id=200330637


   --row number: 15145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3171848 , [Content] ='INR'
 WHERE id=200330639


   --row number: 15146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3171848 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=200330640


   --row number: 15147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3171848 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=200330641


   --row number: 15148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3171848 , [Content] ='10%'
 WHERE id=200330642


   --row number: 15149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3171848 , [Content] ='No'
 WHERE id=200330643


   --row number: 15150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3171848 , [Content] ='2 - Professionals'
 WHERE id=200330644


   --row number: 15151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3171848 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200330645


   --row number: 15152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3171848 , [Content] ='Technical'
 WHERE id=200330646


   --row number: 15153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3171848 , [Content] ='09/05/18'
 WHERE id=200330647


   --row number: 15154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3171959 , [Content] ='S1833 US - MRKT 1'
 WHERE id=200337881


   --row number: 15155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3171959 , [Content] ='US - MRKT 1'
 WHERE id=200337882


   --row number: 15156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3171959 , [Content] ='AMS'
 WHERE id=200337883


   --row number: 15157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3171959 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200337884


   --row number: 15158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3171959 , [Content] ='Sales Operations'
 WHERE id=200337885


   --row number: 15159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3171959 , [Content] ='S1833 - Sales Operations Analyst IC3'
 WHERE id=200337886


   --row number: 15160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3171959 , [Content] ='Sales Operations'
 WHERE id=200337887


   --row number: 15161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3171959 , [Content] ='IC3'
 WHERE id=200337888


   --row number: 15162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3171959 , [Content] ='USD'
 WHERE id=200337890


   --row number: 15163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3171959 , [Content] ='68,100 / 79,350 / 90,600 / 101,800 / 113,000'
 WHERE id=200337891


   --row number: 15164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3171959 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200337892


   --row number: 15165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3171959 , [Content] ='74,900 / 87,300 / 99,700 / 112,000 / 124,300'
 WHERE id=200337893


   --row number: 15166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3171959 , [Content] ='10%'
 WHERE id=200337894


   --row number: 15167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3171959 , [Content] ='Yes'
 WHERE id=200337895


   --row number: 15168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3171959 , [Content] ='EXEMPT'
 WHERE id=200337896


   --row number: 15169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3171959 , [Content] ='NO'
 WHERE id=200337897


   --row number: 15170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3171959 , [Content] ='2 - Professionals'
 WHERE id=200337898


   --row number: 15171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3171959 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200337899


   --row number: 15172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3171959 , [Content] ='Technical'
 WHERE id=200337900


   --row number: 15173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3171959 , [Content] ='09/05/18'
 WHERE id=200337901


   --row number: 15174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172005 , [Content] ='3633 US - MRKT 2'
 WHERE id=200339997


   --row number: 15175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172005 , [Content] ='US - MRKT 2'
 WHERE id=200339998


   --row number: 15176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172005 , [Content] ='AMS'
 WHERE id=200339999


   --row number: 15177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172005 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200340000


   --row number: 15178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172005 , [Content] ='Administration'
 WHERE id=200340001


   --row number: 15179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172005 , [Content] ='3633 - Mgr, Project Mgmt M3'
 WHERE id=200340002


   --row number: 15180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172005 , [Content] ='Project/Program Mgrs'
 WHERE id=200340003


   --row number: 15181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172005 , [Content] ='M3'
 WHERE id=200340004


   --row number: 15182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172005 , [Content] ='USD'
 WHERE id=200340006


   --row number: 15183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172005 , [Content] ='86,000 / 104,000 / 122,000 / 140,050 / 158,100'
 WHERE id=200340007


   --row number: 15184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172005 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=200340008


   --row number: 15185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172005 , [Content] ='103,200 / 124,800 / 146,400 / 168,050 / 189,700'
 WHERE id=200340009


   --row number: 15186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3172005 , [Content] ='20%'
 WHERE id=200340010


   --row number: 15187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172005 , [Content] ='Yes'
 WHERE id=200340011


   --row number: 15188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3172005 , [Content] ='EXEMPT'
 WHERE id=200340012


   --row number: 15189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3172005 , [Content] ='NO'
 WHERE id=200340013


   --row number: 15190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172005 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=200340014


   --row number: 15191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172005 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200340015


   --row number: 15192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172005 , [Content] ='Non Technical'
 WHERE id=200340016


   --row number: 15193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172005 , [Content] ='09/05/18'
 WHERE id=200340017


   --row number: 15194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172052 , [Content] ='S1414 US - MRKT 1'
 WHERE id=200342017


   --row number: 15195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172052 , [Content] ='US - MRKT 1'
 WHERE id=200342018


   --row number: 15196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172052 , [Content] ='AMS'
 WHERE id=200342019


   --row number: 15197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172052 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200342020


   --row number: 15198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172052 , [Content] ='Solution Consulting'
 WHERE id=200342021


   --row number: 15199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172052 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=200342022


   --row number: 15200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172052 , [Content] ='Solution Consultant Core'
 WHERE id=200342023


   --row number: 15201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172052 , [Content] ='IC4'
 WHERE id=200342024


   --row number: 15202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172052 , [Content] ='USD'
 WHERE id=200342026


   --row number: 15203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172052 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=200342027


   --row number: 15204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172052 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=200342028


   --row number: 15205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172052 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=200342029


   --row number: 15206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3172052 , [Content] ='75/25'
 WHERE id=200342030


   --row number: 15207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172052 , [Content] ='Yes'
 WHERE id=200342031


   --row number: 15208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3172052 , [Content] ='EXEMPT'
 WHERE id=200342032


   --row number: 15209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3172052 , [Content] ='NO'
 WHERE id=200342033


   --row number: 15210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172052 , [Content] ='4 - Sales Workers'
 WHERE id=200342034


   --row number: 15211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172052 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200342035


   --row number: 15212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172052 , [Content] ='Technical'
 WHERE id=200342036


   --row number: 15213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172052 , [Content] ='09/05/18'
 WHERE id=200342037


   --row number: 15214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172087 , [Content] ='S1414 US - MRKT 2'
 WHERE id=200343539


   --row number: 15215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172087 , [Content] ='US - MRKT 2'
 WHERE id=200343540


   --row number: 15216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172087 , [Content] ='AMS'
 WHERE id=200343541


   --row number: 15217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172087 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200343542


   --row number: 15218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172087 , [Content] ='Solution Consulting'
 WHERE id=200343543


   --row number: 15219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172087 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=200343544


   --row number: 15220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172087 , [Content] ='Solution Consultant Core'
 WHERE id=200343545


   --row number: 15221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172087 , [Content] ='IC4'
 WHERE id=200343546


   --row number: 15222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172087 , [Content] ='USD'
 WHERE id=200343548


   --row number: 15223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172087 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=200343549


   --row number: 15224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172087 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=200343550


   --row number: 15225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172087 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=200343551


   --row number: 15226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3172087 , [Content] ='75/25'
 WHERE id=200343552


   --row number: 15227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172087 , [Content] ='Yes'
 WHERE id=200343553


   --row number: 15228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3172087 , [Content] ='EXEMPT'
 WHERE id=200343554


   --row number: 15229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3172087 , [Content] ='NO'
 WHERE id=200343555


   --row number: 15230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172087 , [Content] ='4 - Sales Workers'
 WHERE id=200343556


   --row number: 15231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172087 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200343557


   --row number: 15232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172087 , [Content] ='Technical'
 WHERE id=200343558


   --row number: 15233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172087 , [Content] ='09/05/18'
 WHERE id=200343559


   --row number: 15234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172104 , [Content] ='5143 IND'
 WHERE id=200344661


   --row number: 15235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172104 , [Content] ='IND'
 WHERE id=200344662


   --row number: 15236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172104 , [Content] ='APAC'
 WHERE id=200344663


   --row number: 15237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172104 , [Content] ='INDIA'
 WHERE id=200344664


   --row number: 15238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172104 , [Content] ='Engineering'
 WHERE id=200344665


   --row number: 15239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172104 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=200344666


   --row number: 15240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172104 , [Content] ='Software'
 WHERE id=200344667


   --row number: 15241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172104 , [Content] ='IC3'
 WHERE id=200344668


   --row number: 15242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172104 , [Content] ='INR'
 WHERE id=200344670


   --row number: 15243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172104 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=200344671


   --row number: 15244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172104 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=200344672


   --row number: 15245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172104 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=200344673


   --row number: 15246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3172104 , [Content] ='15%'
 WHERE id=200344674


   --row number: 15247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172104 , [Content] ='Yes'
 WHERE id=200344675


   --row number: 15248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172104 , [Content] ='2 - Professionals'
 WHERE id=200344676


   --row number: 15249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172104 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200344677


   --row number: 15250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172104 , [Content] ='Technical'
 WHERE id=200344678


   --row number: 15251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172104 , [Content] ='09/05/18'
 WHERE id=200344679


   --row number: 15252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172129 , [Content] ='9999 SGP'
 WHERE id=200347086


   --row number: 15253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172129 , [Content] ='SGP'
 WHERE id=200347087


   --row number: 15254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172129 , [Content] ='APAC'
 WHERE id=200347088


   --row number: 15255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172129 , [Content] ='Singapore'
 WHERE id=200347089


   --row number: 15256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172129 , [Content] ='9999 - Intern'
 WHERE id=200347090


   --row number: 15257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172129 , [Content] ='SGD'
 WHERE id=200347091


   --row number: 15258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172129 , [Content] ='No'
 WHERE id=200347092


   --row number: 15259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172129 , [Content] ='09/05/18'
 WHERE id=200347093


   --row number: 15260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172937 , [Content] ='BRL'
 WHERE id=200426911


   --row number: 15261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172937 , [Content] ='140,900 / 170,400 / 199,900 / 229,450 / 259,000'
 WHERE id=200426912


   --row number: 15262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172937 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=200426913


   --row number: 15263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172937 , [Content] ='169,100 / 204,500 / 239,900 / 275,350 / 310,800'
 WHERE id=200426915


   --row number: 15264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3172937 , [Content] ='20%'
 WHERE id=200426917


   --row number: 15265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172937 , [Content] ='Yes'
 WHERE id=200426919


   --row number: 15266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172937 , [Content] ='2 - Professionals'
 WHERE id=200426920


   --row number: 15267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172937 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200426921


   --row number: 15268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172937 , [Content] ='Technical'
 WHERE id=200426922


   --row number: 15269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172937 , [Content] ='09/05/18'
 WHERE id=200426923


   --row number: 15270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172937 , [Content] ='IC4'
 WHERE id=200426909


   --row number: 15271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172937 , [Content] ='Engagement Mgrs'
 WHERE id=200426908


   --row number: 15272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172937 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=200426907


   --row number: 15273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172937 , [Content] ='Professional Services'
 WHERE id=200426906


   --row number: 15274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172937 , [Content] ='BRAZIL'
 WHERE id=200426905


   --row number: 15275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172937 , [Content] ='LATAM'
 WHERE id=200426904


   --row number: 15276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172937 , [Content] ='BRA'
 WHERE id=200426903


   --row number: 15277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172937 , [Content] ='5874 BRA'
 WHERE id=200426902


   --row number: 15278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172944 , [Content] ='Yes'
 WHERE id=200427797


   --row number: 15279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172944 , [Content] ='2 - Professionals'
 WHERE id=200427798


   --row number: 15280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172944 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200427799


   --row number: 15281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172944 , [Content] ='Technical'
 WHERE id=200427800


   --row number: 15282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172944 , [Content] ='09/05/18'
 WHERE id=200427801


   --row number: 15283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172944 , [Content] ='5764 BRA'
 WHERE id=200427783


   --row number: 15284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172944 , [Content] ='BRA'
 WHERE id=200427784


   --row number: 15285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172944 , [Content] ='LATAM'
 WHERE id=200427785


   --row number: 15286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172944 , [Content] ='BRAZIL'
 WHERE id=200427786


   --row number: 15287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172944 , [Content] ='Professional Services'
 WHERE id=200427787


   --row number: 15288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172944 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=200427788


   --row number: 15289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172944 , [Content] ='Technology Consultant'
 WHERE id=200427789


   --row number: 15290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172944 , [Content] ='IC4'
 WHERE id=200427790


   --row number: 15291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172944 , [Content] ='BRL'
 WHERE id=200427792


   --row number: 15292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172944 , [Content] ='140,700 / 170,150 / 199,600 / 229,100 / 258,600'
 WHERE id=200427793


   --row number: 15293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172944 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=200427794


   --row number: 15294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172944 , [Content] ='168,800 / 204,150 / 239,500 / 274,900 / 310,300'
 WHERE id=200427795


   --row number: 15295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3172944 , [Content] ='20%'
 WHERE id=200427796


   --row number: 15296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3172990 , [Content] ='5923 US - MRKT 1'
 WHERE id=200432371


   --row number: 15297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3172990 , [Content] ='Yes'
 WHERE id=200432390


   --row number: 15298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3172990 , [Content] ='EXEMPT'
 WHERE id=200432391


   --row number: 15299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3172990 , [Content] ='NO'
 WHERE id=200432392


   --row number: 15300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3172990 , [Content] ='2 - Professionals'
 WHERE id=200432393


   --row number: 15301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3172990 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200432394


   --row number: 15302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3172990 , [Content] ='Non Technical'
 WHERE id=200432395


   --row number: 15303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3172990 , [Content] ='09/05/18'
 WHERE id=200432396


   --row number: 15304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3172990 , [Content] ='US - MRKT 1'
 WHERE id=200432374


   --row number: 15305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3172990 , [Content] ='AMS'
 WHERE id=200432377


   --row number: 15306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3172990 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200432379


   --row number: 15307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3172990 , [Content] ='Info Systems/Technology'
 WHERE id=200432380


   --row number: 15308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3172990 , [Content] ='5923 - Compliance Analyst IC3'
 WHERE id=200432381


   --row number: 15309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3172990 , [Content] ='Compliance'
 WHERE id=200432382


   --row number: 15310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3172990 , [Content] ='IC3'
 WHERE id=200432383


   --row number: 15311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3172990 , [Content] ='USD'
 WHERE id=200432385


   --row number: 15312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3172990 , [Content] ='78,900 / 91,950 / 105,000 / 118,000 / 131,000'
 WHERE id=200432386


   --row number: 15313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3172990 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200432387


   --row number: 15314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3172990 , [Content] ='86,800 / 101,150 / 115,500 / 129,800 / 144,100'
 WHERE id=200432388


   --row number: 15315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3172990 , [Content] ='10%'
 WHERE id=200432389


   --row number: 15316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173007 , [Content] ='NON-EXEMPT'
 WHERE id=200433755


   --row number: 15317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173007 , [Content] ='NO'
 WHERE id=200433756


   --row number: 15318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173007 , [Content] ='2 - Professionals'
 WHERE id=200433757


   --row number: 15319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173007 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200433758


   --row number: 15320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173007 , [Content] ='Non Technical'
 WHERE id=200433759


   --row number: 15321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173007 , [Content] ='09/05/18'
 WHERE id=200433760


   --row number: 15322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173007 , [Content] ='6631 US - MRKT 1'
 WHERE id=200433741


   --row number: 15323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173007 , [Content] ='US - MRKT 1'
 WHERE id=200433742


   --row number: 15324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173007 , [Content] ='AMS'
 WHERE id=200433743


   --row number: 15325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173007 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200433744


   --row number: 15326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173007 , [Content] ='Administration'
 WHERE id=200433745


   --row number: 15327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173007 , [Content] ='6631 - Project/Program Manager IC1'
 WHERE id=200433746


   --row number: 15328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173007 , [Content] ='Project/Program Mgrs'
 WHERE id=200433747


   --row number: 15329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173007 , [Content] ='IC1'
 WHERE id=200433748


   --row number: 15330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173007 , [Content] ='USD'
 WHERE id=200433750


   --row number: 15331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173007 , [Content] ='57,400 / 65,200 / 73,000 / 80,750 / 88,500'
 WHERE id=200433751


   --row number: 15332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173007 , [Content] ='63,100 / 71,700 / 80,300 / 88,850 / 97,400'
 WHERE id=200433752


   --row number: 15333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173007 , [Content] ='10%'
 WHERE id=200433753


   --row number: 15334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173007 , [Content] ='No'
 WHERE id=200433754


   --row number: 15335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173039 , [Content] ='Yes'
 WHERE id=200435974


   --row number: 15336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173039 , [Content] ='EXEMPT'
 WHERE id=200435975


   --row number: 15337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173039 , [Content] ='NO'
 WHERE id=200435976


   --row number: 15338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173039 , [Content] ='2 - Professionals'
 WHERE id=200435977


   --row number: 15339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173039 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200435978


   --row number: 15340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173039 , [Content] ='Non Technical'
 WHERE id=200435979


   --row number: 15341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173039 , [Content] ='09/05/18'
 WHERE id=200435980


   --row number: 15342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173039 , [Content] ='6103 US - MRKT 1'
 WHERE id=200435960


   --row number: 15343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173039 , [Content] ='US - MRKT 1'
 WHERE id=200435961


   --row number: 15344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173039 , [Content] ='AMS'
 WHERE id=200435962


   --row number: 15345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173039 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200435963


   --row number: 15346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173039 , [Content] ='Finance'
 WHERE id=200435964


   --row number: 15347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173039 , [Content] ='6103 - Sr. Accountant IC3'
 WHERE id=200435965


   --row number: 15348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173039 , [Content] ='Accounting'
 WHERE id=200435966


   --row number: 15349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173039 , [Content] ='IC3'
 WHERE id=200435967


   --row number: 15350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173039 , [Content] ='USD'
 WHERE id=200435969


   --row number: 15351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173039 , [Content] ='79,200 / 92,300 / 105,400 / 118,450 / 131,500'
 WHERE id=200435970


   --row number: 15352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173039 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200435971


   --row number: 15353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173039 , [Content] ='87,100 / 101,500 / 115,900 / 130,300 / 144,700'
 WHERE id=200435972


   --row number: 15354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173039 , [Content] ='10%'
 WHERE id=200435973


   --row number: 15355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173220 , [Content] ='6013 US - MRKT 2'
 WHERE id=200449877


   --row number: 15356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173220 , [Content] ='US - MRKT 2'
 WHERE id=200449878


   --row number: 15357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173220 , [Content] ='AMS'
 WHERE id=200449879


   --row number: 15358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173220 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200449880


   --row number: 15359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173220 , [Content] ='Business Strategy'
 WHERE id=200449881


   --row number: 15360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173220 , [Content] ='6013 - Business Analytics IC3'
 WHERE id=200449882


   --row number: 15361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173220 , [Content] ='Business Analytics'
 WHERE id=200449883


   --row number: 15362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173220 , [Content] ='IC3'
 WHERE id=200449884


   --row number: 15363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173220 , [Content] ='USD'
 WHERE id=200449886


   --row number: 15364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173220 , [Content] ='71,700 / 83,500 / 95,300 / 107,150 / 119,000'
 WHERE id=200449887


   --row number: 15365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173220 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200449888


   --row number: 15366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173220 , [Content] ='78,900 / 91,850 / 104,800 / 117,850 / 130,900'
 WHERE id=200449889


   --row number: 15367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173220 , [Content] ='EXEMPT'
 WHERE id=200449892


   --row number: 15368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173220 , [Content] ='NO'
 WHERE id=200449893


   --row number: 15369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173220 , [Content] ='2 - Professionals'
 WHERE id=200449894


   --row number: 15370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173220 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200449895


   --row number: 15371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173220 , [Content] ='Non Technical'
 WHERE id=200449896


   --row number: 15372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173220 , [Content] ='09/05/18'
 WHERE id=200449897


   --row number: 15373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173220 , [Content] ='10%'
 WHERE id=200449890


   --row number: 15374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173220 , [Content] ='Yes'
 WHERE id=200449891


   --row number: 15375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173223 , [Content] ='Operations'
 WHERE id=200450058


   --row number: 15376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173223 , [Content] ='Yes'
 WHERE id=200450068


   --row number: 15377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173223 , [Content] ='EXEMPT'
 WHERE id=200450069


   --row number: 15378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173223 , [Content] ='NO'
 WHERE id=200450070


   --row number: 15379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173223 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=200450071


   --row number: 15380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173223 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200450072


   --row number: 15381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173223 , [Content] ='Non Technical'
 WHERE id=200450073


   --row number: 15382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173223 , [Content] ='09/05/18'
 WHERE id=200450074


   --row number: 15383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173223 , [Content] ='1454 - Sr Mgr, Procurement Mgmt M4'
 WHERE id=200450059


   --row number: 15384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173223 , [Content] ='Procurement'
 WHERE id=200450060


   --row number: 15385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173223 , [Content] ='M4'
 WHERE id=200450061


   --row number: 15386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173223 , [Content] ='USD'
 WHERE id=200450063


   --row number: 15387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173223 , [Content] ='120,700 / 147,850 / 175,000 / 202,150 / 229,300'
 WHERE id=200450064


   --row number: 15388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173223 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=200450065


   --row number: 15389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173223 , [Content] ='1454 US - MRKT 1'
 WHERE id=200450054


   --row number: 15390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173223 , [Content] ='US - MRKT 1'
 WHERE id=200450055


   --row number: 15391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173223 , [Content] ='AMS'
 WHERE id=200450056


   --row number: 15392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173223 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200450057


   --row number: 15393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173223 , [Content] ='150,900 / 184,850 / 218,800 / 252,700 / 286,600'
 WHERE id=200450066


   --row number: 15394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173223 , [Content] ='25%'
 WHERE id=200450067


   --row number: 15395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173224 , [Content] ='EXEMPT'
 WHERE id=200450157


   --row number: 15396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173224 , [Content] ='NO'
 WHERE id=200450158


   --row number: 15397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173224 , [Content] ='2 - Professionals'
 WHERE id=200450159


   --row number: 15398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173224 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200450160


   --row number: 15399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173224 , [Content] ='Non Technical'
 WHERE id=200450161


   --row number: 15400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173224 , [Content] ='09/05/18'
 WHERE id=200450162


   --row number: 15401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173224 , [Content] ='6013 US - MRKT 2'
 WHERE id=200450142


   --row number: 15402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173224 , [Content] ='US - MRKT 2'
 WHERE id=200450143


   --row number: 15403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173224 , [Content] ='AMS'
 WHERE id=200450144


   --row number: 15404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173224 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200450145


   --row number: 15405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173224 , [Content] ='Business Strategy'
 WHERE id=200450146


   --row number: 15406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173224 , [Content] ='6013 - Business Analytics IC3'
 WHERE id=200450147


   --row number: 15407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173224 , [Content] ='Business Analytics'
 WHERE id=200450148


   --row number: 15408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173224 , [Content] ='IC3'
 WHERE id=200450149


   --row number: 15409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173224 , [Content] ='USD'
 WHERE id=200450151


   --row number: 15410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173224 , [Content] ='71,700 / 83,500 / 95,300 / 107,150 / 119,000'
 WHERE id=200450152


   --row number: 15411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173224 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200450153


   --row number: 15412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173224 , [Content] ='78,900 / 91,850 / 104,800 / 117,850 / 130,900'
 WHERE id=200450154


   --row number: 15413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173224 , [Content] ='10%'
 WHERE id=200450155


   --row number: 15414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173224 , [Content] ='Yes'
 WHERE id=200450156


   --row number: 15415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173229 , [Content] ='6013 US - MRKT 2'
 WHERE id=200450893


   --row number: 15416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173229 , [Content] ='US - MRKT 2'
 WHERE id=200450894


   --row number: 15417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173229 , [Content] ='AMS'
 WHERE id=200450895


   --row number: 15418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173229 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200450896


   --row number: 15419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173229 , [Content] ='EXEMPT'
 WHERE id=200450909


   --row number: 15420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173229 , [Content] ='NO'
 WHERE id=200450910


   --row number: 15421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173229 , [Content] ='2 - Professionals'
 WHERE id=200450911


   --row number: 15422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173229 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200450912


   --row number: 15423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173229 , [Content] ='Non Technical'
 WHERE id=200450913


   --row number: 15424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173229 , [Content] ='09/05/18'
 WHERE id=200450914


   --row number: 15425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173229 , [Content] ='Business Strategy'
 WHERE id=200450898


   --row number: 15426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173229 , [Content] ='6013 - Business Analytics IC3'
 WHERE id=200450899


   --row number: 15427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173229 , [Content] ='Business Analytics'
 WHERE id=200450900


   --row number: 15428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173229 , [Content] ='IC3'
 WHERE id=200450901


   --row number: 15429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173229 , [Content] ='USD'
 WHERE id=200450903


   --row number: 15430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173229 , [Content] ='71,700 / 83,500 / 95,300 / 107,150 / 119,000'
 WHERE id=200450904


   --row number: 15431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173229 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200450905


   --row number: 15432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173229 , [Content] ='78,900 / 91,850 / 104,800 / 117,850 / 130,900'
 WHERE id=200450906


   --row number: 15433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173229 , [Content] ='10%'
 WHERE id=200450907


   --row number: 15434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173229 , [Content] ='Yes'
 WHERE id=200450908


   --row number: 15435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173259 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200453772


   --row number: 15436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173259 , [Content] ='Engineering'
 WHERE id=200453773


   --row number: 15437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173259 , [Content] ='2255 - Dir, UI Engineering Mgmt M5'
 WHERE id=200453774


   --row number: 15438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173259 , [Content] ='UI'
 WHERE id=200453775


   --row number: 15439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173259 , [Content] ='M5'
 WHERE id=200453776


   --row number: 15440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173259 , [Content] ='USD'
 WHERE id=200453778


   --row number: 15441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173259 , [Content] ='135,900 / 166,500 / 197,100 / 227,650 / 258,200'
 WHERE id=200453779


   --row number: 15442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173259 , [Content] ='2255 US - MRKT 2'
 WHERE id=200453769


   --row number: 15443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173259 , [Content] ='US - MRKT 2'
 WHERE id=200453770


   --row number: 15444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173259 , [Content] ='AMS'
 WHERE id=200453771


   --row number: 15445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173259 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=200453780


   --row number: 15446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173259 , [Content] ='169,900 / 208,150 / 246,400 / 284,600 / 322,800'
 WHERE id=200453781


   --row number: 15447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173259 , [Content] ='25%'
 WHERE id=200453782


   --row number: 15448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173259 , [Content] ='Yes'
 WHERE id=200453783


   --row number: 15449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173259 , [Content] ='EXEMPT'
 WHERE id=200453784


   --row number: 15450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173259 , [Content] ='NO'
 WHERE id=200453785


   --row number: 15451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173259 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=200453786


   --row number: 15452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173259 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200453787


   --row number: 15453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173259 , [Content] ='Technical'
 WHERE id=200453788


   --row number: 15454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173259 , [Content] ='09/05/18'
 WHERE id=200453789


   --row number: 15455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173535 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=200477828


   --row number: 15456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3173535 , [Content] ='60/40'
 WHERE id=200477830


   --row number: 15457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173535 , [Content] ='Yes'
 WHERE id=200477831


   --row number: 15458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173535 , [Content] ='EXEMPT'
 WHERE id=200477832


   --row number: 15459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173535 , [Content] ='NO'
 WHERE id=200477833


   --row number: 15460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173535 , [Content] ='4 - Sales Workers'
 WHERE id=200477834


   --row number: 15461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173535 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200477835


   --row number: 15462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173535 , [Content] ='Technical'
 WHERE id=200477836


   --row number: 15463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173535 , [Content] ='09/05/18'
 WHERE id=200477837


   --row number: 15464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173535 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=200477829


   --row number: 15465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3116476 , [Content] ='114,600 / 138,600 / 162,600 / 186,600 / 210,600'
 WHERE id=200477561


   --row number: 15466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173535 , [Content] ='S665 US - MRKT 1'
 WHERE id=200477817


   --row number: 15467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173535 , [Content] ='US - MRKT 1'
 WHERE id=200477818


   --row number: 15468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173535 , [Content] ='AMS'
 WHERE id=200477819


   --row number: 15469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173535 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200477820


   --row number: 15470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173535 , [Content] ='Sales'
 WHERE id=200477821


   --row number: 15471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173535 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=200477822


   --row number: 15472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173535 , [Content] ='Product Line Sales'
 WHERE id=200477823


   --row number: 15473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173535 , [Content] ='IC5'
 WHERE id=200477824


   --row number: 15474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173535 , [Content] ='USD'
 WHERE id=200477826


   --row number: 15475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173535 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=200477827


   --row number: 15476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173654 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=200490124


   --row number: 15477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173654 , [Content] ='Yes'
 WHERE id=200490128


   --row number: 15478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173654 , [Content] ='EXEMPT'
 WHERE id=200490129


   --row number: 15479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173654 , [Content] ='NO'
 WHERE id=200490130


   --row number: 15480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173654 , [Content] ='2 - Professionals'
 WHERE id=200490131


   --row number: 15481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173654 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200490132


   --row number: 15482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173654 , [Content] ='Technical'
 WHERE id=200490133


   --row number: 15483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173654 , [Content] ='09/05/18'
 WHERE id=200490134


   --row number: 15484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173654 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200490125


   --row number: 15485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173654 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=200490126


   --row number: 15486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173654 , [Content] ='10%'
 WHERE id=200490127


   --row number: 15487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173654 , [Content] ='5141 US - MRKT 1'
 WHERE id=200490114


   --row number: 15488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173654 , [Content] ='US - MRKT 1'
 WHERE id=200490115


   --row number: 15489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173654 , [Content] ='AMS'
 WHERE id=200490116


   --row number: 15490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173654 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200490117


   --row number: 15491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173654 , [Content] ='Engineering'
 WHERE id=200490118


   --row number: 15492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173654 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200490119


   --row number: 15493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173654 , [Content] ='Software'
 WHERE id=200490120


   --row number: 15494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173654 , [Content] ='IC1'
 WHERE id=200490121


   --row number: 15495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173654 , [Content] ='USD'
 WHERE id=200490123


   --row number: 15496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173686 , [Content] ='EXEMPT'
 WHERE id=200493818


   --row number: 15497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173686 , [Content] ='Technical'
 WHERE id=200493822


   --row number: 15498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173686 , [Content] ='09/05/18'
 WHERE id=200493823


   --row number: 15499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173686 , [Content] ='NO'
 WHERE id=200493819


   --row number: 15500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173686 , [Content] ='2 - Professionals'
 WHERE id=200493820


   --row number: 15501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173686 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200493821


   --row number: 15502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173686 , [Content] ='5596 US - MRKT 1'
 WHERE id=200493803


   --row number: 15503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173686 , [Content] ='US - MRKT 1'
 WHERE id=200493804


   --row number: 15504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173686 , [Content] ='AMS'
 WHERE id=200493805


   --row number: 15505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173686 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200493806


   --row number: 15506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173686 , [Content] ='Marketing'
 WHERE id=200493807


   --row number: 15507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173686 , [Content] ='5596 - Product Marketing Mgr IC6'
 WHERE id=200493808


   --row number: 15508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173686 , [Content] ='Product Marketing'
 WHERE id=200493809


   --row number: 15509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173686 , [Content] ='IC6'
 WHERE id=200493810


   --row number: 15510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173686 , [Content] ='USD'
 WHERE id=200493812


   --row number: 15511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173686 , [Content] ='139,500 / 170,900 / 202,300 / 233,700 / 265,100'
 WHERE id=200493813


   --row number: 15512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173686 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=200493814


   --row number: 15513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173686 , [Content] ='174,400 / 213,650 / 252,900 / 292,150 / 331,400'
 WHERE id=200493815


   --row number: 15514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173686 , [Content] ='25%'
 WHERE id=200493816


   --row number: 15515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173686 , [Content] ='Yes'
 WHERE id=200493817


   --row number: 15516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173727 , [Content] ='20%'
 WHERE id=200497853


   --row number: 15517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173727 , [Content] ='Yes'
 WHERE id=200497854


   --row number: 15518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3173727 , [Content] ='EXEMPT'
 WHERE id=200497855


   --row number: 15519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3173727 , [Content] ='NO'
 WHERE id=200497856


   --row number: 15520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173727 , [Content] ='2 - Professionals'
 WHERE id=200497857


   --row number: 15521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173727 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200497858


   --row number: 15522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173727 , [Content] ='Technical'
 WHERE id=200497859


   --row number: 15523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173727 , [Content] ='09/05/18'
 WHERE id=200497860


   --row number: 15524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173727 , [Content] ='5764 US - MRKT 1'
 WHERE id=200497840


   --row number: 15525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173727 , [Content] ='US - MRKT 1'
 WHERE id=200497841


   --row number: 15526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173727 , [Content] ='AMS'
 WHERE id=200497842


   --row number: 15527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173727 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200497843


   --row number: 15528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173727 , [Content] ='Professional Services'
 WHERE id=200497844


   --row number: 15529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173727 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=200497845


   --row number: 15530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173727 , [Content] ='Technology Consultant'
 WHERE id=200497846


   --row number: 15531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173727 , [Content] ='IC4'
 WHERE id=200497847


   --row number: 15532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173727 , [Content] ='USD'
 WHERE id=200497849


   --row number: 15533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3173727 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=200497850


   --row number: 15534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173727 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=200497851


   --row number: 15535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3173727 , [Content] ='120,000 / 145,150 / 170,300 / 195,450 / 220,600'
 WHERE id=200497852


   --row number: 15536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3173827 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200508945


   --row number: 15537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3173827 , [Content] ='Technical'
 WHERE id=200508946


   --row number: 15538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3173827 , [Content] ='09/05/18'
 WHERE id=200508947


   --row number: 15539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3173827 , [Content] ='6643 JPN'
 WHERE id=200508930


   --row number: 15540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3173827 , [Content] ='JPN'
 WHERE id=200508931


   --row number: 15541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3173827 , [Content] ='APAC'
 WHERE id=200508932


   --row number: 15542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3173827 , [Content] ='JAPAN'
 WHERE id=200508933


   --row number: 15543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3173827 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=200508934


   --row number: 15544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3173827 , [Content] ='6643 - Data Center Operations Analyst IC3'
 WHERE id=200508935


   --row number: 15545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3173827 , [Content] ='Data center operations'
 WHERE id=200508936


   --row number: 15546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3173827 , [Content] ='IC3'
 WHERE id=200508937


   --row number: 15547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3173827 , [Content] ='JPY'
 WHERE id=200508939


   --row number: 15548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3173827 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=200508941


   --row number: 15549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3173827 , [Content] ='15%'
 WHERE id=200508942


   --row number: 15550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3173827 , [Content] ='Yes'
 WHERE id=200508943


   --row number: 15551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3173827 , [Content] ='2 - Professionals'
 WHERE id=200508944


   --row number: 15552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3174075 , [Content] ='JPY'
 WHERE id=200559353


   --row number: 15553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3174075 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=200559354


   --row number: 15554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3174075 , [Content] ='60/40'
 WHERE id=200559355


   --row number: 15555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3174075 , [Content] ='Yes'
 WHERE id=200559356


   --row number: 15556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3174075 , [Content] ='4 - Sales Workers'
 WHERE id=200559357


   --row number: 15557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3174075 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200559358


   --row number: 15558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3174075 , [Content] ='Technical'
 WHERE id=200559359


   --row number: 15559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3174075 , [Content] ='S1613 JPN'
 WHERE id=200559344


   --row number: 15560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3174075 , [Content] ='JPN'
 WHERE id=200559345


   --row number: 15561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3174075 , [Content] ='APAC'
 WHERE id=200559346


   --row number: 15562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3174075 , [Content] ='JAPAN'
 WHERE id=200559347


   --row number: 15563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3174075 , [Content] ='Sales'
 WHERE id=200559348


   --row number: 15564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3174075 , [Content] ='S1613 - Regional Partner Mgr IC3'
 WHERE id=200559349


   --row number: 15565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3174075 , [Content] ='Partner Sales'
 WHERE id=200559350


   --row number: 15566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3174075 , [Content] ='IC3'
 WHERE id=200559351


   --row number: 15567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3174079 , [Content] ='10%'
 WHERE id=200559864


   --row number: 15568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3174079 , [Content] ='No'
 WHERE id=200559865


   --row number: 15569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3174079 , [Content] ='2 - Professionals'
 WHERE id=200559866


   --row number: 15570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3174079 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200559867


   --row number: 15571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3174079 , [Content] ='Technical'
 WHERE id=200559868


   --row number: 15572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3174079 , [Content] ='7/20/18'
 WHERE id=200559869


   --row number: 15573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3174079 , [Content] ='5142 IND'
 WHERE id=200559853


   --row number: 15574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3174079 , [Content] ='IND'
 WHERE id=200559854


   --row number: 15575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3174079 , [Content] ='APAC'
 WHERE id=200559855


   --row number: 15576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3174079 , [Content] ='INDIA'
 WHERE id=200559856


   --row number: 15577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3174079 , [Content] ='Engineering'
 WHERE id=200559857


   --row number: 15578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3174079 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=200559858


   --row number: 15579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3174079 , [Content] ='Software'
 WHERE id=200559859


   --row number: 15580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3174079 , [Content] ='IC2'
 WHERE id=200559860


   --row number: 15581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3174079 , [Content] ='INR'
 WHERE id=200559862


   --row number: 15582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3174079 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=200559863


   --row number: 15583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3174080 , [Content] ='9,562,500 / 10,406,250 / 11,250,000 / 12,093,750 / 12,937,500'
 WHERE id=200560003


   --row number: 15584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3174080 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=200560004


   --row number: 15585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3174080 , [Content] ='12,750,000 / 13,875,000 / 15,000,000 / 16,125,000 / 17,250,000'
 WHERE id=200560005


   --row number: 15586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3174080 , [Content] ='75/25'
 WHERE id=200560006


   --row number: 15587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3174080 , [Content] ='Yes'
 WHERE id=200560007


   --row number: 15588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3174080 , [Content] ='4 - Sales Workers'
 WHERE id=200560008


   --row number: 15589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3174080 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200560009


   --row number: 15590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3174080 , [Content] ='Technical'
 WHERE id=200560010


   --row number: 15591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3174080 , [Content] ='09/05/18'
 WHERE id=200560011


   --row number: 15592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3174080 , [Content] ='S1414 JPN'
 WHERE id=200559993


   --row number: 15593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3174080 , [Content] ='JPN'
 WHERE id=200559994


   --row number: 15594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3174080 , [Content] ='APAC'
 WHERE id=200559995


   --row number: 15595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3174080 , [Content] ='JAPAN'
 WHERE id=200559996


   --row number: 15596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3174080 , [Content] ='Solution Consulting'
 WHERE id=200559997


   --row number: 15597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3174080 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=200559998


   --row number: 15598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3174080 , [Content] ='Solution Consultant Core'
 WHERE id=200559999


   --row number: 15599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3174080 , [Content] ='IC4'
 WHERE id=200560000


   --row number: 15600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3174080 , [Content] ='JPY'
 WHERE id=200560002


   --row number: 15601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3174690 , [Content] ='AMS'
 WHERE id=200612480


   --row number: 15602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3174690 , [Content] ='Legal Counsel'
 WHERE id=200612484


   --row number: 15603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3174690 , [Content] ='IC4'
 WHERE id=200612485


   --row number: 15604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3174690 , [Content] ='USD'
 WHERE id=200612487


   --row number: 15605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3174690 , [Content] ='134,800 / 165,100 / 195,400 / 225,750 / 256,100'
 WHERE id=200612488


   --row number: 15606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3174690 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=200612489


   --row number: 15607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3174690 , [Content] ='168,500 / 206,400 / 244,300 / 282,200 / 320,100'
 WHERE id=200612490


   --row number: 15608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3174690 , [Content] ='25%'
 WHERE id=200612491


   --row number: 15609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3174690 , [Content] ='Yes'
 WHERE id=200612492


   --row number: 15610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3174690 , [Content] ='EXEMPT'
 WHERE id=200612493


   --row number: 15611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3174690 , [Content] ='NO'
 WHERE id=200612494


   --row number: 15612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3174690 , [Content] ='2 - Professionals'
 WHERE id=200612495


   --row number: 15613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3174690 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200612496


   --row number: 15614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3174690 , [Content] ='Non Technical'
 WHERE id=200612497


   --row number: 15615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3174690 , [Content] ='09/05/18'
 WHERE id=200612498


   --row number: 15616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3174690 , [Content] ='6394 US - MRKT 1'
 WHERE id=200612478


   --row number: 15617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3174690 , [Content] ='US - MRKT 1'
 WHERE id=200612479


   --row number: 15618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3174690 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200612481


   --row number: 15619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3174690 , [Content] ='Legal'
 WHERE id=200612482


   --row number: 15620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3174690 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=200612483


   --row number: 15621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3166980 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=200568584


   --row number: 15622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175315 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200668223


   --row number: 15623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175315 , [Content] ='EXEMPT'
 WHERE id=200668227


   --row number: 15624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175315 , [Content] ='NO'
 WHERE id=200668228


   --row number: 15625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175315 , [Content] ='2 - Professionals'
 WHERE id=200668229


   --row number: 15626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175315 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200668230


   --row number: 15627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175315 , [Content] ='Non Technical'
 WHERE id=200668231


   --row number: 15628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175315 , [Content] ='09/05/18'
 WHERE id=200668232


   --row number: 15629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175315 , [Content] ='79,000 / 92,050 / 105,100 / 118,100 / 131,100'
 WHERE id=200668224


   --row number: 15630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175315 , [Content] ='10%'
 WHERE id=200668225


   --row number: 15631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175315 , [Content] ='Yes'
 WHERE id=200668226


   --row number: 15632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175315 , [Content] ='4963 US - MRKT 1'
 WHERE id=200668212


   --row number: 15633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175315 , [Content] ='USD'
 WHERE id=200668221


   --row number: 15634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175315 , [Content] ='71,800 / 83,650 / 95,500 / 107,350 / 119,200'
 WHERE id=200668222


   --row number: 15635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175315 , [Content] ='US - MRKT 1'
 WHERE id=200668213


   --row number: 15636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175315 , [Content] ='AMS'
 WHERE id=200668214


   --row number: 15637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175315 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200668215


   --row number: 15638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175315 , [Content] ='Marketing'
 WHERE id=200668216


   --row number: 15639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175315 , [Content] ='4963 - Content Producer IC3'
 WHERE id=200668217


   --row number: 15640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175315 , [Content] ='Content Development'
 WHERE id=200668218


   --row number: 15641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175315 , [Content] ='IC3'
 WHERE id=200668219


   --row number: 15642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175359 , [Content] ='EXEMPT'
 WHERE id=200671269


   --row number: 15643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175359 , [Content] ='NO'
 WHERE id=200671270


   --row number: 15644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175359 , [Content] ='2 - Professionals'
 WHERE id=200671271


   --row number: 15645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175359 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200671272


   --row number: 15646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175359 , [Content] ='Technical'
 WHERE id=200671273


   --row number: 15647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175359 , [Content] ='09/05/18'
 WHERE id=200671274


   --row number: 15648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175359 , [Content] ='5204 US - MRKT 1'
 WHERE id=200671254


   --row number: 15649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175359 , [Content] ='US - MRKT 1'
 WHERE id=200671255


   --row number: 15650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175359 , [Content] ='AMS'
 WHERE id=200671256


   --row number: 15651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175359 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200671257


   --row number: 15652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175359 , [Content] ='Engineering'
 WHERE id=200671258


   --row number: 15653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175359 , [Content] ='5204 - Staff Systems Design Engineer IC4'
 WHERE id=200671259


   --row number: 15654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175359 , [Content] ='Systems Design'
 WHERE id=200671260


   --row number: 15655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175359 , [Content] ='IC4'
 WHERE id=200671261


   --row number: 15656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175359 , [Content] ='USD'
 WHERE id=200671263


   --row number: 15657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175359 , [Content] ='111,200 / 134,500 / 157,800 / 181,100 / 204,400'
 WHERE id=200671264


   --row number: 15658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175359 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=200671265


   --row number: 15659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175359 , [Content] ='133,400 / 161,400 / 189,400 / 217,350 / 245,300'
 WHERE id=200671266


   --row number: 15660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175359 , [Content] ='20%'
 WHERE id=200671267


   --row number: 15661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175359 , [Content] ='Yes'
 WHERE id=200671268


   --row number: 15662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175589 , [Content] ='Yes'
 WHERE id=200687467


   --row number: 15663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175589 , [Content] ='EXEMPT'
 WHERE id=200687468


   --row number: 15664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175589 , [Content] ='NO'
 WHERE id=200687469


   --row number: 15665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175589 , [Content] ='2 - Professionals'
 WHERE id=200687470


   --row number: 15666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175589 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200687471


   --row number: 15667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175589 , [Content] ='Technical'
 WHERE id=200687472


   --row number: 15668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175589 , [Content] ='09/05/18'
 WHERE id=200687473


   --row number: 15669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175589 , [Content] ='5142 US - MRKT 1'
 WHERE id=200687453


   --row number: 15670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175589 , [Content] ='US - MRKT 1'
 WHERE id=200687454


   --row number: 15671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175589 , [Content] ='AMS'
 WHERE id=200687455


   --row number: 15672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175589 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200687456


   --row number: 15673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175589 , [Content] ='Engineering'
 WHERE id=200687457


   --row number: 15674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175589 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=200687458


   --row number: 15675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175589 , [Content] ='Software'
 WHERE id=200687459


   --row number: 15676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175589 , [Content] ='IC2'
 WHERE id=200687460


   --row number: 15677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175589 , [Content] ='USD'
 WHERE id=200687462


   --row number: 15678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175589 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=200687463


   --row number: 15679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175589 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=200687464


   --row number: 15680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175589 , [Content] ='100,900 / 117,550 / 134,200 / 150,800 / 167,400'
 WHERE id=200687465


   --row number: 15681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175589 , [Content] ='10%'
 WHERE id=200687466


   --row number: 15682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175625 , [Content] ='Yes'
 WHERE id=200690430


   --row number: 15683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175625 , [Content] ='EXEMPT'
 WHERE id=200690431


   --row number: 15684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175625 , [Content] ='NO'
 WHERE id=200690432


   --row number: 15685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175625 , [Content] ='2 - Professionals'
 WHERE id=200690433


   --row number: 15686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175625 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200690434


   --row number: 15687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175625 , [Content] ='Technical'
 WHERE id=200690435


   --row number: 15688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175625 , [Content] ='09/05/18'
 WHERE id=200690436


   --row number: 15689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175625 , [Content] ='5144 US - MRKT 2'
 WHERE id=200690416


   --row number: 15690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175625 , [Content] ='US - MRKT 2'
 WHERE id=200690417


   --row number: 15691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175625 , [Content] ='AMS'
 WHERE id=200690418


   --row number: 15692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175625 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200690419


   --row number: 15693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175625 , [Content] ='Engineering'
 WHERE id=200690420


   --row number: 15694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175625 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=200690421


   --row number: 15695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175625 , [Content] ='Software'
 WHERE id=200690422


   --row number: 15696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175625 , [Content] ='IC4'
 WHERE id=200690423


   --row number: 15697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175625 , [Content] ='USD'
 WHERE id=200690425


   --row number: 15698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175625 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=200690426


   --row number: 15699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175625 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=200690427


   --row number: 15700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175625 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=200690428


   --row number: 15701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175625 , [Content] ='20%'
 WHERE id=200690429


   --row number: 15702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175639 , [Content] ='Yes'
 WHERE id=200691953


   --row number: 15703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175639 , [Content] ='EXEMPT'
 WHERE id=200691954


   --row number: 15704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175639 , [Content] ='NO'
 WHERE id=200691955


   --row number: 15705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175639 , [Content] ='2 - Professionals'
 WHERE id=200691956


   --row number: 15706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175639 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200691957


   --row number: 15707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175639 , [Content] ='Technical'
 WHERE id=200691958


   --row number: 15708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175639 , [Content] ='09/05/18'
 WHERE id=200691959


   --row number: 15709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175639 , [Content] ='5144 US - MRKT 2'
 WHERE id=200691939


   --row number: 15710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175639 , [Content] ='US - MRKT 2'
 WHERE id=200691940


   --row number: 15711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175639 , [Content] ='AMS'
 WHERE id=200691941


   --row number: 15712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175639 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200691942


   --row number: 15713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175639 , [Content] ='Engineering'
 WHERE id=200691943


   --row number: 15714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175639 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=200691944


   --row number: 15715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175639 , [Content] ='Software'
 WHERE id=200691945


   --row number: 15716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175639 , [Content] ='IC4'
 WHERE id=200691946


   --row number: 15717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175639 , [Content] ='USD'
 WHERE id=200691948


   --row number: 15718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175639 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=200691949


   --row number: 15719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175639 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=200691950


   --row number: 15720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175639 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=200691951


   --row number: 15721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175639 , [Content] ='20%'
 WHERE id=200691952


   --row number: 15722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175660 , [Content] ='Yes'
 WHERE id=200693625


   --row number: 15723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175660 , [Content] ='EXEMPT'
 WHERE id=200693626


   --row number: 15724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175660 , [Content] ='NO'
 WHERE id=200693627


   --row number: 15725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175660 , [Content] ='2 - Professionals'
 WHERE id=200693628


   --row number: 15726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175660 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200693629


   --row number: 15727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175660 , [Content] ='Non Technical'
 WHERE id=200693630


   --row number: 15728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175660 , [Content] ='09/05/18'
 WHERE id=200693631


   --row number: 15729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175660 , [Content] ='6633 US - MRKT 2'
 WHERE id=200693611


   --row number: 15730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175660 , [Content] ='US - MRKT 2'
 WHERE id=200693612


   --row number: 15731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175660 , [Content] ='AMS'
 WHERE id=200693613


   --row number: 15732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175660 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200693614


   --row number: 15733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175660 , [Content] ='Administration'
 WHERE id=200693615


   --row number: 15734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175660 , [Content] ='6633 - Project/Program Manager IC3'
 WHERE id=200693616


   --row number: 15735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175660 , [Content] ='Project/Program Mgrs'
 WHERE id=200693617


   --row number: 15736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175660 , [Content] ='IC3'
 WHERE id=200693618


   --row number: 15737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175660 , [Content] ='USD'
 WHERE id=200693620


   --row number: 15738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175660 , [Content] ='73,800 / 85,950 / 98,100 / 110,300 / 122,500'
 WHERE id=200693621


   --row number: 15739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175660 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200693622


   --row number: 15740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175660 , [Content] ='81,200 / 94,550 / 107,900 / 121,350 / 134,800'
 WHERE id=200693623


   --row number: 15741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175660 , [Content] ='10%'
 WHERE id=200693624


   --row number: 15742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175752 , [Content] ='Yes'
 WHERE id=200702328


   --row number: 15743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175752 , [Content] ='EXEMPT'
 WHERE id=200702329


   --row number: 15744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175752 , [Content] ='NO'
 WHERE id=200702330


   --row number: 15745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175752 , [Content] ='2 - Professionals'
 WHERE id=200702331


   --row number: 15746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175752 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200702332


   --row number: 15747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175752 , [Content] ='Technical'
 WHERE id=200702333


   --row number: 15748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175752 , [Content] ='09/05/18'
 WHERE id=200702334


   --row number: 15749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175752 , [Content] ='5143 US - MRKT 1'
 WHERE id=200702314


   --row number: 15750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175752 , [Content] ='US - MRKT 1'
 WHERE id=200702315


   --row number: 15751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175752 , [Content] ='AMS'
 WHERE id=200702316


   --row number: 15752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175752 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200702317


   --row number: 15753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175752 , [Content] ='Engineering'
 WHERE id=200702318


   --row number: 15754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175752 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=200702319


   --row number: 15755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175752 , [Content] ='Software'
 WHERE id=200702320


   --row number: 15756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175752 , [Content] ='IC3'
 WHERE id=200702321


   --row number: 15757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175752 , [Content] ='USD'
 WHERE id=200702323


   --row number: 15758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175752 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=200702324


   --row number: 15759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175752 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=200702325


   --row number: 15760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175752 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=200702326


   --row number: 15761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175752 , [Content] ='15%'
 WHERE id=200702327


   --row number: 15762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175772 , [Content] ='Yes'
 WHERE id=200704700


   --row number: 15763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175772 , [Content] ='EXEMPT'
 WHERE id=200704701


   --row number: 15764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175772 , [Content] ='NO'
 WHERE id=200704702


   --row number: 15765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175772 , [Content] ='2 - Professionals'
 WHERE id=200704703


   --row number: 15766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175772 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200704704


   --row number: 15767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175772 , [Content] ='Technical'
 WHERE id=200704705


   --row number: 15768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175772 , [Content] ='09/05/18'
 WHERE id=200704706


   --row number: 15769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175772 , [Content] ='5595 US - MRKT 1'
 WHERE id=200704686


   --row number: 15770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175772 , [Content] ='US - MRKT 1'
 WHERE id=200704687


   --row number: 15771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175772 , [Content] ='AMS'
 WHERE id=200704688


   --row number: 15772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175772 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200704689


   --row number: 15773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175772 , [Content] ='Marketing'
 WHERE id=200704690


   --row number: 15774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175772 , [Content] ='5595 - Product Marketing Mgr IC5'
 WHERE id=200704691


   --row number: 15775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175772 , [Content] ='Product Marketing'
 WHERE id=200704692


   --row number: 15776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175772 , [Content] ='IC5'
 WHERE id=200704693


   --row number: 15777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175772 , [Content] ='USD'
 WHERE id=200704695


   --row number: 15778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175772 , [Content] ='126,300 / 154,750 / 183,200 / 211,600 / 240,000'
 WHERE id=200704696


   --row number: 15779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175772 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=200704697


   --row number: 15780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175772 , [Content] ='157,900 / 193,450 / 229,000 / 264,500 / 300,000'
 WHERE id=200704698


   --row number: 15781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175772 , [Content] ='25%'
 WHERE id=200704699


   --row number: 15782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175778 , [Content] ='Yes'
 WHERE id=200705540


   --row number: 15783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175778 , [Content] ='EXEMPT'
 WHERE id=200705541


   --row number: 15784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175778 , [Content] ='NO'
 WHERE id=200705542


   --row number: 15785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175778 , [Content] ='2 - Professionals'
 WHERE id=200705543


   --row number: 15786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175778 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200705544


   --row number: 15787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175778 , [Content] ='Technical'
 WHERE id=200705545


   --row number: 15788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175778 , [Content] ='09/05/18'
 WHERE id=200705546


   --row number: 15789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175778 , [Content] ='S1833 US - MRKT 2'
 WHERE id=200705526


   --row number: 15790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175778 , [Content] ='US - MRKT 2'
 WHERE id=200705527


   --row number: 15791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175778 , [Content] ='AMS'
 WHERE id=200705528


   --row number: 15792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175778 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200705529


   --row number: 15793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175778 , [Content] ='Sales Operations'
 WHERE id=200705530


   --row number: 15794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175778 , [Content] ='S1833 - Sales Operations Analyst IC3'
 WHERE id=200705531


   --row number: 15795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175778 , [Content] ='Sales Operations'
 WHERE id=200705532


   --row number: 15796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175778 , [Content] ='IC3'
 WHERE id=200705533


   --row number: 15797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175778 , [Content] ='USD'
 WHERE id=200705535


   --row number: 15798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175778 , [Content] ='60,200 / 70,100 / 80,000 / 89,950 / 99,900'
 WHERE id=200705536


   --row number: 15799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175778 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200705537


   --row number: 15800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175778 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=200705538


   --row number: 15801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175778 , [Content] ='10%'
 WHERE id=200705539


   --row number: 15802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175796 , [Content] ='Yes'
 WHERE id=200708907


   --row number: 15803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175796 , [Content] ='EXEMPT'
 WHERE id=200708908


   --row number: 15804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175796 , [Content] ='NO'
 WHERE id=200708909


   --row number: 15805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175796 , [Content] ='2 - Professionals'
 WHERE id=200708910


   --row number: 15806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175796 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200708911


   --row number: 15807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175796 , [Content] ='Technical'
 WHERE id=200708912


   --row number: 15808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175796 , [Content] ='09/05/18'
 WHERE id=200708913


   --row number: 15809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175796 , [Content] ='5184 US - MRKT 1'
 WHERE id=200708893


   --row number: 15810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175796 , [Content] ='US - MRKT 1'
 WHERE id=200708894


   --row number: 15811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175796 , [Content] ='AMS'
 WHERE id=200708895


   --row number: 15812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175796 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200708896


   --row number: 15813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175796 , [Content] ='Engineering'
 WHERE id=200708897


   --row number: 15814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175796 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=200708898


   --row number: 15815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175796 , [Content] ='Quality'
 WHERE id=200708899


   --row number: 15816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175796 , [Content] ='IC4'
 WHERE id=200708900


   --row number: 15817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175796 , [Content] ='USD'
 WHERE id=200708902


   --row number: 15818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175796 , [Content] ='103,300 / 124,950 / 146,600 / 168,250 / 189,900'
 WHERE id=200708903


   --row number: 15819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175796 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=200708904


   --row number: 15820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175796 , [Content] ='124,000 / 149,950 / 175,900 / 201,900 / 227,900'
 WHERE id=200708905


   --row number: 15821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175796 , [Content] ='20%'
 WHERE id=200708906


   --row number: 15822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3175990 , [Content] ='Yes'
 WHERE id=200744809


   --row number: 15823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3175990 , [Content] ='EXEMPT'
 WHERE id=200744810


   --row number: 15824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3175990 , [Content] ='NO'
 WHERE id=200744811


   --row number: 15825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3175990 , [Content] ='2 - Professionals'
 WHERE id=200744812


   --row number: 15826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3175990 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200744813


   --row number: 15827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3175990 , [Content] ='Technical'
 WHERE id=200744814


   --row number: 15828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3175990 , [Content] ='09/05/18'
 WHERE id=200744815


   --row number: 15829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3175990 , [Content] ='5885 US - MRKT 2'
 WHERE id=200744795


   --row number: 15830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3175990 , [Content] ='US - MRKT 2'
 WHERE id=200744796


   --row number: 15831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3175990 , [Content] ='AMS'
 WHERE id=200744797


   --row number: 15832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3175990 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200744798


   --row number: 15833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3175990 , [Content] ='Professional Services'
 WHERE id=200744799


   --row number: 15834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3175990 , [Content] ='5885 - Customer/Technical Trainer IC5'
 WHERE id=200744800


   --row number: 15835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3175990 , [Content] ='Customer/Tech Training'
 WHERE id=200744801


   --row number: 15836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3175990 , [Content] ='IC5'
 WHERE id=200744802


   --row number: 15837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3175990 , [Content] ='USD'
 WHERE id=200744804


   --row number: 15838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3175990 , [Content] ='91,500 / 110,650 / 129,800 / 149,000 / 168,200'
 WHERE id=200744805


   --row number: 15839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3175990 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=200744806


   --row number: 15840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3175990 , [Content] ='109,800 / 132,800 / 155,800 / 178,800 / 201,800'
 WHERE id=200744807


   --row number: 15841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3175990 , [Content] ='20%'
 WHERE id=200744808


   --row number: 15842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177030 , [Content] ='68,500 / 78,250 / 88,000 / 97,800 / 107,600'
 WHERE id=200790517


   --row number: 15843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177030 , [Content] ='Yes'
 WHERE id=200790519


   --row number: 15844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177030 , [Content] ='EXEMPT'
 WHERE id=200790520


   --row number: 15845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177030 , [Content] ='NO'
 WHERE id=200790521


   --row number: 15846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177030 , [Content] ='2 - Professionals'
 WHERE id=200790522


   --row number: 15847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177030 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200790523


   --row number: 15848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177030 , [Content] ='Technical'
 WHERE id=200790524


   --row number: 15849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177030 , [Content] ='09/05/18'
 WHERE id=200790525


   --row number: 15850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177030 , [Content] ='10%'
 WHERE id=200790518


   --row number: 15851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177030 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200790508


   --row number: 15852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177030 , [Content] ='Engineering'
 WHERE id=200790509


   --row number: 15853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177030 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200790510


   --row number: 15854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177030 , [Content] ='Software'
 WHERE id=200790511


   --row number: 15855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177030 , [Content] ='IC1'
 WHERE id=200790512


   --row number: 15856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177030 , [Content] ='USD'
 WHERE id=200790514


   --row number: 15857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177030 , [Content] ='62,300 / 71,150 / 80,000 / 88,900 / 97,800'
 WHERE id=200790515


   --row number: 15858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177030 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200790516


   --row number: 15859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177030 , [Content] ='5141 US - MRKT 2'
 WHERE id=200790505


   --row number: 15860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177030 , [Content] ='US - MRKT 2'
 WHERE id=200790506


   --row number: 15861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177030 , [Content] ='AMS'
 WHERE id=200790507


   --row number: 15862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177041 , [Content] ='Yes'
 WHERE id=200791526


   --row number: 15863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177041 , [Content] ='4 - Sales Workers'
 WHERE id=200791527


   --row number: 15864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177041 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200791528


   --row number: 15865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177041 , [Content] ='Technical'
 WHERE id=200791529


   --row number: 15866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177041 , [Content] ='09/05/18'
 WHERE id=200791530


   --row number: 15867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177041 , [Content] ='S1416-S UK'
 WHERE id=200791512


   --row number: 15868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177041 , [Content] ='UK'
 WHERE id=200791513


   --row number: 15869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177041 , [Content] ='EMEA'
 WHERE id=200791514


   --row number: 15870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177041 , [Content] ='UNITED KINGDOM'
 WHERE id=200791515


   --row number: 15871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177041 , [Content] ='Solution Consulting'
 WHERE id=200791516


   --row number: 15872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177041 , [Content] ='S1416-S - Principal Enterprise (Client) Strategist IC6'
 WHERE id=200791517


   --row number: 15873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177041 , [Content] ='Solution Consultant Strategy'
 WHERE id=200791518


   --row number: 15874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177041 , [Content] ='IC6'
 WHERE id=200791519


   --row number: 15875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177041 , [Content] ='GBP'
 WHERE id=200791521


   --row number: 15876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177041 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=200791522


   --row number: 15877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177041 , [Content] ='114,000 / 171,000 / 228,000 / 285,000 / 342,000'
 WHERE id=200791523


   --row number: 15878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177041 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=200791524


   --row number: 15879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3177041 , [Content] ='75/25'
 WHERE id=200791525


   --row number: 15880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177068 , [Content] ='S1415 UK'
 WHERE id=200794091


   --row number: 15881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177068 , [Content] ='UK'
 WHERE id=200794092


   --row number: 15882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177068 , [Content] ='EMEA'
 WHERE id=200794093


   --row number: 15883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177068 , [Content] ='UNITED KINGDOM'
 WHERE id=200794094


   --row number: 15884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177068 , [Content] ='Solution Consulting'
 WHERE id=200794095


   --row number: 15885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177068 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=200794096


   --row number: 15886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177068 , [Content] ='Yes'
 WHERE id=200794105


   --row number: 15887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177068 , [Content] ='4 - Sales Workers'
 WHERE id=200794106


   --row number: 15888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177068 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200794107


   --row number: 15889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177068 , [Content] ='Technical'
 WHERE id=200794108


   --row number: 15890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177068 , [Content] ='09/05/18'
 WHERE id=200794109


   --row number: 15891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177068 , [Content] ='Solution Consultant Core'
 WHERE id=200794097


   --row number: 15892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177068 , [Content] ='IC5'
 WHERE id=200794098


   --row number: 15893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177068 , [Content] ='GBP'
 WHERE id=200794100


   --row number: 15894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177068 , [Content] ='79,050 / 86,025 / 93,000 / 99,975 / 106,950'
 WHERE id=200794101


   --row number: 15895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177068 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=200794102


   --row number: 15896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177068 , [Content] ='105,400 / 114,700 / 124,000 / 133,300 / 142,600'
 WHERE id=200794103


   --row number: 15897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3177068 , [Content] ='75/25'
 WHERE id=200794104


   --row number: 15898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177081 , [Content] ='Yes'
 WHERE id=200795038


   --row number: 15899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177081 , [Content] ='2 - Professionals'
 WHERE id=200795039


   --row number: 15900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177081 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200795040


   --row number: 15901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177081 , [Content] ='Technical'
 WHERE id=200795041


   --row number: 15902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177081 , [Content] ='1/29/18'
 WHERE id=200795042


   --row number: 15903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177081 , [Content] ='6595 IRL'
 WHERE id=200795025


   --row number: 15904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177081 , [Content] ='IRL'
 WHERE id=200795026


   --row number: 15905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177081 , [Content] ='EMEA'
 WHERE id=200795027


   --row number: 15906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177081 , [Content] ='IRELAND'
 WHERE id=200795028


   --row number: 15907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177081 , [Content] ='Info Systems/Technology'
 WHERE id=200795029


   --row number: 15908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177081 , [Content] ='6595 - Sr Staff Database Engineer IC5'
 WHERE id=200795030


   --row number: 15909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177081 , [Content] ='Database Engineer'
 WHERE id=200795031


   --row number: 15910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177081 , [Content] ='IC5'
 WHERE id=200795032


   --row number: 15911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177081 , [Content] ='EUR'
 WHERE id=200795034


   --row number: 15912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177081 , [Content] ='70,300 / 86,150 / 102,000 / 117,800 / 133,600'
 WHERE id=200795035


   --row number: 15913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177081 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=200795036


   --row number: 15914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177081 , [Content] ='25%'
 WHERE id=200795037


   --row number: 15915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177107 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200797059


   --row number: 15916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177107 , [Content] ='Non Technical'
 WHERE id=200797060


   --row number: 15917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177107 , [Content] ='09/05/18'
 WHERE id=200797061


   --row number: 15918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177107 , [Content] ='S1333 UK'
 WHERE id=200797044


   --row number: 15919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177107 , [Content] ='UK'
 WHERE id=200797045


   --row number: 15920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177107 , [Content] ='EMEA'
 WHERE id=200797046


   --row number: 15921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177107 , [Content] ='UNITED KINGDOM'
 WHERE id=200797047


   --row number: 15922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177107 , [Content] ='Sales'
 WHERE id=200797048


   --row number: 15923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177107 , [Content] ='S1333 - Account Development Rep A3'
 WHERE id=200797049


   --row number: 15924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177107 , [Content] ='Inside Sales'
 WHERE id=200797050


   --row number: 15925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177107 , [Content] ='A3'
 WHERE id=200797051


   --row number: 15926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177107 , [Content] ='GBP'
 WHERE id=200797053


   --row number: 15927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177107 , [Content] ='29,580 / 32,190 / 34,800 / 37,410 / 40,020'
 WHERE id=200797054


   --row number: 15928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177107 , [Content] ='49,300 / 53,650 / 58,000 / 62,350 / 66,700'
 WHERE id=200797055


   --row number: 15929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3177107 , [Content] ='60/40'
 WHERE id=200797056


   --row number: 15930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177107 , [Content] ='No'
 WHERE id=200797057


   --row number: 15931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177107 , [Content] ='4 - Sales Workers'
 WHERE id=200797058


   --row number: 15932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177161 , [Content] ='EXEMPT'
 WHERE id=200801662


   --row number: 15933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177161 , [Content] ='NO'
 WHERE id=200801663


   --row number: 15934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177161 , [Content] ='2 - Professionals'
 WHERE id=200801664


   --row number: 15935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177161 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200801665


   --row number: 15936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177161 , [Content] ='Technical'
 WHERE id=200801666


   --row number: 15937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177161 , [Content] ='09/05/18'
 WHERE id=200801667


   --row number: 15938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177161 , [Content] ='5141 US - MRKT 1'
 WHERE id=200801647


   --row number: 15939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177161 , [Content] ='US - MRKT 1'
 WHERE id=200801648


   --row number: 15940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177161 , [Content] ='AMS'
 WHERE id=200801649


   --row number: 15941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177161 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200801650


   --row number: 15942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177161 , [Content] ='Engineering'
 WHERE id=200801651


   --row number: 15943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177161 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200801652


   --row number: 15944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177161 , [Content] ='Software'
 WHERE id=200801653


   --row number: 15945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177161 , [Content] ='IC1'
 WHERE id=200801654


   --row number: 15946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177161 , [Content] ='USD'
 WHERE id=200801656


   --row number: 15947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177161 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=200801657


   --row number: 15948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177161 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200801658


   --row number: 15949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177161 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=200801659


   --row number: 15950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177161 , [Content] ='10%'
 WHERE id=200801660


   --row number: 15951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177161 , [Content] ='Yes'
 WHERE id=200801661


   --row number: 15952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177169 , [Content] ='Yes'
 WHERE id=200802425


   --row number: 15953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177169 , [Content] ='EXEMPT'
 WHERE id=200802426


   --row number: 15954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177169 , [Content] ='NO'
 WHERE id=200802427


   --row number: 15955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177169 , [Content] ='2 - Professionals'
 WHERE id=200802428


   --row number: 15956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177169 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200802429


   --row number: 15957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177169 , [Content] ='Technical'
 WHERE id=200802430


   --row number: 15958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177169 , [Content] ='09/05/18'
 WHERE id=200802431


   --row number: 15959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177169 , [Content] ='5141 US - MRKT 1'
 WHERE id=200802411


   --row number: 15960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177169 , [Content] ='US - MRKT 1'
 WHERE id=200802412


   --row number: 15961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177169 , [Content] ='AMS'
 WHERE id=200802413


   --row number: 15962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177169 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200802414


   --row number: 15963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177169 , [Content] ='Engineering'
 WHERE id=200802415


   --row number: 15964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177169 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200802416


   --row number: 15965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177169 , [Content] ='Software'
 WHERE id=200802417


   --row number: 15966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177169 , [Content] ='IC1'
 WHERE id=200802418


   --row number: 15967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177169 , [Content] ='USD'
 WHERE id=200802420


   --row number: 15968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177169 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=200802421


   --row number: 15969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177169 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200802422


   --row number: 15970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177169 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=200802423


   --row number: 15971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177169 , [Content] ='10%'
 WHERE id=200802424


   --row number: 15972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177182 , [Content] ='EXEMPT'
 WHERE id=200803412


   --row number: 15973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177182 , [Content] ='NO'
 WHERE id=200803413


   --row number: 15974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177182 , [Content] ='2 - Professionals'
 WHERE id=200803414


   --row number: 15975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177182 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200803415


   --row number: 15976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177182 , [Content] ='Technical'
 WHERE id=200803416


   --row number: 15977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177182 , [Content] ='09/05/18'
 WHERE id=200803417


   --row number: 15978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177182 , [Content] ='5141 US - MRKT 1'
 WHERE id=200803397


   --row number: 15979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177182 , [Content] ='US - MRKT 1'
 WHERE id=200803398


   --row number: 15980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177182 , [Content] ='AMS'
 WHERE id=200803399


   --row number: 15981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177182 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200803400


   --row number: 15982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177182 , [Content] ='Engineering'
 WHERE id=200803401


   --row number: 15983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177182 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200803402


   --row number: 15984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177182 , [Content] ='Software'
 WHERE id=200803403


   --row number: 15985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177182 , [Content] ='IC1'
 WHERE id=200803404


   --row number: 15986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177182 , [Content] ='USD'
 WHERE id=200803406


   --row number: 15987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177182 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=200803407


   --row number: 15988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177182 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200803408


   --row number: 15989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177182 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=200803409


   --row number: 15990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177182 , [Content] ='10%'
 WHERE id=200803410


   --row number: 15991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177182 , [Content] ='Yes'
 WHERE id=200803411


   --row number: 15992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177568 , [Content] ='NO'
 WHERE id=200831017


   --row number: 15993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177568 , [Content] ='2 - Professionals'
 WHERE id=200831018


   --row number: 15994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177568 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200831019


   --row number: 15995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177568 , [Content] ='Technical'
 WHERE id=200831020


   --row number: 15996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177568 , [Content] ='09/05/18'
 WHERE id=200831021


   --row number: 15997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177568 , [Content] ='5141 US - MRKT 1'
 WHERE id=200830999


   --row number: 15998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177568 , [Content] ='US - MRKT 1'
 WHERE id=200831002


   --row number: 15999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177568 , [Content] ='AMS'
 WHERE id=200831003


   --row number: 16000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177568 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200831004


   --row number: 16001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177568 , [Content] ='Engineering'
 WHERE id=200831005


   --row number: 16002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177568 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200831006


   --row number: 16003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177568 , [Content] ='Software'
 WHERE id=200831007


   --row number: 16004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177568 , [Content] ='IC1'
 WHERE id=200831008


   --row number: 16005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177568 , [Content] ='USD'
 WHERE id=200831010


   --row number: 16006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177568 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=200831011


   --row number: 16007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177568 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200831012


   --row number: 16008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177568 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=200831013


   --row number: 16009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177568 , [Content] ='10%'
 WHERE id=200831014


   --row number: 16010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177568 , [Content] ='Yes'
 WHERE id=200831015


   --row number: 16011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177568 , [Content] ='EXEMPT'
 WHERE id=200831016


   --row number: 16012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177651 , [Content] ='NO'
 WHERE id=200839067


   --row number: 16013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177651 , [Content] ='2 - Professionals'
 WHERE id=200839068


   --row number: 16014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177651 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200839069


   --row number: 16015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177651 , [Content] ='Technical'
 WHERE id=200839070


   --row number: 16016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177651 , [Content] ='09/05/18'
 WHERE id=200839071


   --row number: 16017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177651 , [Content] ='5141 US - MRKT 1'
 WHERE id=200839051


   --row number: 16018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177651 , [Content] ='US - MRKT 1'
 WHERE id=200839052


   --row number: 16019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177651 , [Content] ='AMS'
 WHERE id=200839053


   --row number: 16020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177651 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200839054


   --row number: 16021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177651 , [Content] ='Engineering'
 WHERE id=200839055


   --row number: 16022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177651 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=200839056


   --row number: 16023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177651 , [Content] ='Software'
 WHERE id=200839057


   --row number: 16024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177651 , [Content] ='IC1'
 WHERE id=200839058


   --row number: 16025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177651 , [Content] ='USD'
 WHERE id=200839060


   --row number: 16026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177651 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=200839061


   --row number: 16027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177651 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=200839062


   --row number: 16028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177651 , [Content] ='93,200 / 106,450 / 119,700 / 133,000 / 146,300'
 WHERE id=200839063


   --row number: 16029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177651 , [Content] ='10%'
 WHERE id=200839064


   --row number: 16030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177651 , [Content] ='Yes'
 WHERE id=200839065


   --row number: 16031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177651 , [Content] ='EXEMPT'
 WHERE id=200839066


   --row number: 16032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177686 , [Content] ='EXEMPT'
 WHERE id=200842193


   --row number: 16033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177686 , [Content] ='NO'
 WHERE id=200842194


   --row number: 16034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177686 , [Content] ='2 - Professionals'
 WHERE id=200842195


   --row number: 16035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177686 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200842196


   --row number: 16036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177686 , [Content] ='Technical'
 WHERE id=200842197


   --row number: 16037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177686 , [Content] ='09/05/18'
 WHERE id=200842198


   --row number: 16038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177686 , [Content] ='5142 US - MRKT 2'
 WHERE id=200842178


   --row number: 16039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177686 , [Content] ='US - MRKT 2'
 WHERE id=200842179


   --row number: 16040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177686 , [Content] ='AMS'
 WHERE id=200842180


   --row number: 16041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177686 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200842181


   --row number: 16042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177686 , [Content] ='Engineering'
 WHERE id=200842182


   --row number: 16043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177686 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=200842183


   --row number: 16044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177686 , [Content] ='Software'
 WHERE id=200842184


   --row number: 16045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177686 , [Content] ='IC2'
 WHERE id=200842185


   --row number: 16046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177686 , [Content] ='USD'
 WHERE id=200842187


   --row number: 16047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177686 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=200842188


   --row number: 16048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177686 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=200842189


   --row number: 16049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177686 , [Content] ='84,400 / 98,300 / 112,200 / 126,100 / 140,000'
 WHERE id=200842190


   --row number: 16050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177686 , [Content] ='10%'
 WHERE id=200842191


   --row number: 16051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177686 , [Content] ='Yes'
 WHERE id=200842192


   --row number: 16052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177706 , [Content] ='5225 US - MRKT 3'
 WHERE id=200844273


   --row number: 16053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177706 , [Content] ='US - MRKT 3'
 WHERE id=200844274


   --row number: 16054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177706 , [Content] ='AMS'
 WHERE id=200844275


   --row number: 16055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177706 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200844276


   --row number: 16056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177706 , [Content] ='Engineering'
 WHERE id=200844277


   --row number: 16057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177706 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=200844278


   --row number: 16058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177706 , [Content] ='Product Mgmt Mgr'
 WHERE id=200844279


   --row number: 16059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177706 , [Content] ='IC5'
 WHERE id=200844280


   --row number: 16060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177706 , [Content] ='USD'
 WHERE id=200844282


   --row number: 16061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177706 , [Content] ='97,900 / 119,950 / 142,000 / 164,000 / 186,000'
 WHERE id=200844283


   --row number: 16062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177706 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=200844284


   --row number: 16063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177706 , [Content] ='25%'
 WHERE id=200844285


   --row number: 16064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177706 , [Content] ='Yes'
 WHERE id=200844286


   --row number: 16065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177706 , [Content] ='2 - Professionals'
 WHERE id=200844287


   --row number: 16066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177706 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200844288


   --row number: 16067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177706 , [Content] ='Technical'
 WHERE id=200844289


   --row number: 16068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177706 , [Content] ='10/05/18'
 WHERE id=200844290


   --row number: 16069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3177715 , [Content] ='10%'
 WHERE id=200844909


   --row number: 16070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3177715 , [Content] ='Yes'
 WHERE id=200844910


   --row number: 16071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177715 , [Content] ='EXEMPT'
 WHERE id=200844911


   --row number: 16072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3177715 , [Content] ='NO'
 WHERE id=200844912


   --row number: 16073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3177715 , [Content] ='2 - Professionals'
 WHERE id=200844913


   --row number: 16074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3177715 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200844914


   --row number: 16075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3177715 , [Content] ='Technical'
 WHERE id=200844915


   --row number: 16076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3177715 , [Content] ='09/05/18'
 WHERE id=200844916


   --row number: 16077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3177715 , [Content] ='5181 US - MRKT 2'
 WHERE id=200844896


   --row number: 16078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3177715 , [Content] ='US - MRKT 2'
 WHERE id=200844897


   --row number: 16079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3177715 , [Content] ='AMS'
 WHERE id=200844898


   --row number: 16080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3177715 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200844899


   --row number: 16081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3177715 , [Content] ='Engineering'
 WHERE id=200844900


   --row number: 16082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3177715 , [Content] ='5181 - Assoc Software QA Engineer IC1'
 WHERE id=200844901


   --row number: 16083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3177715 , [Content] ='Quality'
 WHERE id=200844902


   --row number: 16084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3177715 , [Content] ='IC1'
 WHERE id=200844903


   --row number: 16085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3177715 , [Content] ='USD'
 WHERE id=200844905


   --row number: 16086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3177715 , [Content] ='55,300 / 63,200 / 71,100 / 78,950 / 86,800'
 WHERE id=200844906


   --row number: 16087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3177715 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=200844907


   --row number: 16088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3177715 , [Content] ='60,800 / 69,500 / 78,200 / 86,850 / 95,500'
 WHERE id=200844908


   --row number: 16089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3178784 , [Content] ='09/05/18'
 WHERE id=200911790


   --row number: 16090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3178784 , [Content] ='6663 IND'
 WHERE id=200911775


   --row number: 16091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3178784 , [Content] ='IND'
 WHERE id=200911776


   --row number: 16092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3178784 , [Content] ='APAC'
 WHERE id=200911777


   --row number: 16093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3178784 , [Content] ='INDIA'
 WHERE id=200911778


   --row number: 16094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3178784 , [Content] ='Marketing'
 WHERE id=200911779


   --row number: 16095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3178784 , [Content] ='6663 - Community Affairs Specialist IC3'
 WHERE id=200911780


   --row number: 16096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3178784 , [Content] ='Community Affairs'
 WHERE id=200911781


   --row number: 16097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3178784 , [Content] ='IC3'
 WHERE id=200911782


   --row number: 16098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3178784 , [Content] ='INR'
 WHERE id=200911784


   --row number: 16099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3178784 , [Content] ='10%'
 WHERE id=200911785


   --row number: 16100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3178784 , [Content] ='No'
 WHERE id=200911786


   --row number: 16101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3178784 , [Content] ='2 - Professionals'
 WHERE id=200911787


   --row number: 16102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3178784 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200911788


   --row number: 16103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3178784 , [Content] ='Non Technical'
 WHERE id=200911789


   --row number: 16104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179399 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201119912


   --row number: 16105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179399 , [Content] ='INR'
 WHERE id=201119916


   --row number: 16106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179399 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=201119917


   --row number: 16107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3179399 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=201119918


   --row number: 16108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179399 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=201119919


   --row number: 16109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3179399 , [Content] ='15%'
 WHERE id=201119920


   --row number: 16110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179399 , [Content] ='Yes'
 WHERE id=201119921


   --row number: 16111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179399 , [Content] ='2 - Professionals'
 WHERE id=201119922


   --row number: 16112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179399 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201119923


   --row number: 16113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179399 , [Content] ='Technical'
 WHERE id=201119924


   --row number: 16114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179399 , [Content] ='09/05/18'
 WHERE id=201119925


   --row number: 16115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179399 , [Content] ='Software'
 WHERE id=201119913


   --row number: 16116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179399 , [Content] ='IC3'
 WHERE id=201119914


   --row number: 16117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179399 , [Content] ='5143 IND'
 WHERE id=201119907


   --row number: 16118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179399 , [Content] ='IND'
 WHERE id=201119908


   --row number: 16119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179399 , [Content] ='APAC'
 WHERE id=201119909


   --row number: 16120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179399 , [Content] ='INDIA'
 WHERE id=201119910


   --row number: 16121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179399 , [Content] ='Engineering'
 WHERE id=201119911


   --row number: 16122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179709 , [Content] ='2 - Professionals'
 WHERE id=201150487


   --row number: 16123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179709 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201150488


   --row number: 16124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179709 , [Content] ='Technical'
 WHERE id=201150489


   --row number: 16125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179709 , [Content] ='09/05/18'
 WHERE id=201150490


   --row number: 16126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179709 , [Content] ='6464 IND'
 WHERE id=201150472


   --row number: 16127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179709 , [Content] ='IND'
 WHERE id=201150473


   --row number: 16128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179709 , [Content] ='APAC'
 WHERE id=201150474


   --row number: 16129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179709 , [Content] ='INDIA'
 WHERE id=201150475


   --row number: 16130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179709 , [Content] ='Info Systems/Technology'
 WHERE id=201150476


   --row number: 16131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179709 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=201150477


   --row number: 16132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179709 , [Content] ='Business Systems Analysis'
 WHERE id=201150478


   --row number: 16133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179709 , [Content] ='IC4'
 WHERE id=201150479


   --row number: 16134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179709 , [Content] ='INR'
 WHERE id=201150481


   --row number: 16135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179709 , [Content] ='1,724,100 / 2,112,050 / 2,500,000 / 2,887,900 / 3,275,800'
 WHERE id=201150482


   --row number: 16136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3179709 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=201150483


   --row number: 16137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179709 , [Content] ='1,982,700 / 2,428,850 / 2,875,000 / 3,321,100 / 3,767,200'
 WHERE id=201150484


   --row number: 16138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3179709 , [Content] ='15%'
 WHERE id=201150485


   --row number: 16139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179709 , [Content] ='Yes'
 WHERE id=201150486


   --row number: 16140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179720 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201151929


   --row number: 16141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179720 , [Content] ='Technical'
 WHERE id=201151930


   --row number: 16142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179720 , [Content] ='09/05/18'
 WHERE id=201151931


   --row number: 16143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179720 , [Content] ='6463 IND'
 WHERE id=201151914


   --row number: 16144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179720 , [Content] ='IND'
 WHERE id=201151915


   --row number: 16145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179720 , [Content] ='APAC'
 WHERE id=201151916


   --row number: 16146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179720 , [Content] ='INDIA'
 WHERE id=201151917


   --row number: 16147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179720 , [Content] ='Info Systems/Technology'
 WHERE id=201151918


   --row number: 16148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179720 , [Content] ='6463 - Business Systems Analyst IC3'
 WHERE id=201151919


   --row number: 16149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179720 , [Content] ='Business Systems Analysis'
 WHERE id=201151920


   --row number: 16150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179720 , [Content] ='IC3'
 WHERE id=201151921


   --row number: 16151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179720 , [Content] ='INR'
 WHERE id=201151923


   --row number: 16152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179720 , [Content] ='1,202,400 / 1,472,950 / 1,743,500 / 2,014,050 / 2,284,600'
 WHERE id=201151924


   --row number: 16153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179720 , [Content] ='1,322,600 / 1,620,250 / 1,917,900 / 2,215,500 / 2,513,100'
 WHERE id=201151925


   --row number: 16154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3179720 , [Content] ='10%'
 WHERE id=201151926


   --row number: 16155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179720 , [Content] ='No'
 WHERE id=201151927


   --row number: 16156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179720 , [Content] ='2 - Professionals'
 WHERE id=201151928


   --row number: 16157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3179790 , [Content] ='60/40'
 WHERE id=201158541


   --row number: 16158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179790 , [Content] ='Yes'
 WHERE id=201158542


   --row number: 16159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3179790 , [Content] ='EXEMPT'
 WHERE id=201158543


   --row number: 16160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179790 , [Content] ='4 - Sales Workers'
 WHERE id=201158544


   --row number: 16161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179790 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201158545


   --row number: 16162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179790 , [Content] ='Technical'
 WHERE id=201158546


   --row number: 16163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179790 , [Content] ='09/05/18'
 WHERE id=201158547


   --row number: 16164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179790 , [Content] ='S665 US - MRKT 3'
 WHERE id=201158528


   --row number: 16165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179790 , [Content] ='US - MRKT 3'
 WHERE id=201158529


   --row number: 16166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179790 , [Content] ='AMS'
 WHERE id=201158530


   --row number: 16167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179790 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201158531


   --row number: 16168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179790 , [Content] ='Sales'
 WHERE id=201158532


   --row number: 16169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179790 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201158533


   --row number: 16170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179790 , [Content] ='Product Line Sales'
 WHERE id=201158534


   --row number: 16171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179790 , [Content] ='IC5'
 WHERE id=201158535


   --row number: 16172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179790 , [Content] ='USD'
 WHERE id=201158537


   --row number: 16173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179790 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201158538


   --row number: 16174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3179790 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201158539


   --row number: 16175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179790 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201158540


   --row number: 16176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179807 , [Content] ='Yes'
 WHERE id=201160155


   --row number: 16177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3179807 , [Content] ='EXEMPT'
 WHERE id=201160156


   --row number: 16178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3179807 , [Content] ='NO'
 WHERE id=201160157


   --row number: 16179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179807 , [Content] ='4 - Sales Workers'
 WHERE id=201160158


   --row number: 16180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179807 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201160159


   --row number: 16181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179807 , [Content] ='Technical'
 WHERE id=201160160


   --row number: 16182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179807 , [Content] ='09/05/18'
 WHERE id=201160161


   --row number: 16183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179807 , [Content] ='S665 US - MRKT 2'
 WHERE id=201160141


   --row number: 16184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179807 , [Content] ='US - MRKT 2'
 WHERE id=201160142


   --row number: 16185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179807 , [Content] ='AMS'
 WHERE id=201160143


   --row number: 16186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179807 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201160144


   --row number: 16187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179807 , [Content] ='Sales'
 WHERE id=201160145


   --row number: 16188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179807 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201160146


   --row number: 16189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179807 , [Content] ='Product Line Sales'
 WHERE id=201160147


   --row number: 16190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179807 , [Content] ='IC5'
 WHERE id=201160148


   --row number: 16191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179807 , [Content] ='USD'
 WHERE id=201160150


   --row number: 16192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179807 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201160151


   --row number: 16193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3179807 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201160152


   --row number: 16194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179807 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201160153


   --row number: 16195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3179807 , [Content] ='60/40'
 WHERE id=201160154


   --row number: 16196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3177706 , [Content] ='EXEMPT'
 WHERE id=201179139


   --row number: 16197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181049 , [Content] ='Engineering'
 WHERE id=201288020


   --row number: 16198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181049 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201288027


   --row number: 16199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3181049 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=201288028


   --row number: 16200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181049 , [Content] ='15%'
 WHERE id=201288029


   --row number: 16201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181049 , [Content] ='Yes'
 WHERE id=201288030


   --row number: 16202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181049 , [Content] ='EXEMPT'
 WHERE id=201288031


   --row number: 16203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181049 , [Content] ='NO'
 WHERE id=201288032


   --row number: 16204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181049 , [Content] ='2 - Professionals'
 WHERE id=201288033


   --row number: 16205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181049 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201288034


   --row number: 16206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181049 , [Content] ='Technical'
 WHERE id=201288035


   --row number: 16207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181049 , [Content] ='09/05/18'
 WHERE id=201288036


   --row number: 16208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181049 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201288021


   --row number: 16209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181049 , [Content] ='Software'
 WHERE id=201288022


   --row number: 16210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181049 , [Content] ='IC3'
 WHERE id=201288023


   --row number: 16211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181049 , [Content] ='USD'
 WHERE id=201288025


   --row number: 16212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181049 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=201288026


   --row number: 16213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181049 , [Content] ='5143 US - MRKT 1'
 WHERE id=201288016


   --row number: 16214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181049 , [Content] ='US - MRKT 1'
 WHERE id=201288017


   --row number: 16215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181049 , [Content] ='AMS'
 WHERE id=201288018


   --row number: 16216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181049 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201288019


   --row number: 16217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181051 , [Content] ='Yes'
 WHERE id=201288499


   --row number: 16218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181051 , [Content] ='EXEMPT'
 WHERE id=201288500


   --row number: 16219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181051 , [Content] ='NO'
 WHERE id=201288501


   --row number: 16220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181051 , [Content] ='2 - Professionals'
 WHERE id=201288502


   --row number: 16221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181051 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201288503


   --row number: 16222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181051 , [Content] ='Technical'
 WHERE id=201288504


   --row number: 16223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181051 , [Content] ='09/05/18'
 WHERE id=201288505


   --row number: 16224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3181051 , [Content] ='100,900 / 117,550 / 134,200 / 150,800 / 167,400'
 WHERE id=201288497


   --row number: 16225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181051 , [Content] ='10%'
 WHERE id=201288498


   --row number: 16226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181051 , [Content] ='5142 US - MRKT 1'
 WHERE id=201288485


   --row number: 16227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181051 , [Content] ='US - MRKT 1'
 WHERE id=201288486


   --row number: 16228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181051 , [Content] ='AMS'
 WHERE id=201288487


   --row number: 16229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181051 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201288488


   --row number: 16230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181051 , [Content] ='Engineering'
 WHERE id=201288489


   --row number: 16231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181051 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=201288490


   --row number: 16232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181051 , [Content] ='Software'
 WHERE id=201288491


   --row number: 16233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181051 , [Content] ='IC2'
 WHERE id=201288492


   --row number: 16234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181051 , [Content] ='USD'
 WHERE id=201288494


   --row number: 16235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181051 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=201288495


   --row number: 16236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181051 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=201288496


   --row number: 16237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181056 , [Content] ='Yes'
 WHERE id=201288970


   --row number: 16238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181056 , [Content] ='EXEMPT'
 WHERE id=201288971


   --row number: 16239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181056 , [Content] ='NO'
 WHERE id=201288972


   --row number: 16240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181056 , [Content] ='2 - Professionals'
 WHERE id=201288973


   --row number: 16241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181056 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201288974


   --row number: 16242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181056 , [Content] ='Technical'
 WHERE id=201288975


   --row number: 16243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181056 , [Content] ='09/05/18'
 WHERE id=201288976


   --row number: 16244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181056 , [Content] ='5183 US - MRKT 2'
 WHERE id=201288956


   --row number: 16245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181056 , [Content] ='US - MRKT 2'
 WHERE id=201288957


   --row number: 16246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181056 , [Content] ='AMS'
 WHERE id=201288958


   --row number: 16247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181056 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201288959


   --row number: 16248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181056 , [Content] ='Engineering'
 WHERE id=201288960


   --row number: 16249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181056 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=201288961


   --row number: 16250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181056 , [Content] ='Quality'
 WHERE id=201288962


   --row number: 16251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181056 , [Content] ='IC3'
 WHERE id=201288963


   --row number: 16252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181056 , [Content] ='USD'
 WHERE id=201288965


   --row number: 16253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181056 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=201288966


   --row number: 16254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181056 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201288967


   --row number: 16255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3181056 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=201288968


   --row number: 16256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181056 , [Content] ='15%'
 WHERE id=201288969


   --row number: 16257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181061 , [Content] ='Yes'
 WHERE id=201289505


   --row number: 16258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181061 , [Content] ='EXEMPT'
 WHERE id=201289506


   --row number: 16259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181061 , [Content] ='NO'
 WHERE id=201289507


   --row number: 16260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181061 , [Content] ='2 - Professionals'
 WHERE id=201289508


   --row number: 16261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181061 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201289509


   --row number: 16262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181061 , [Content] ='Technical'
 WHERE id=201289510


   --row number: 16263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181061 , [Content] ='09/05/18'
 WHERE id=201289511


   --row number: 16264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181061 , [Content] ='5143 US - MRKT 2'
 WHERE id=201289491


   --row number: 16265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181061 , [Content] ='US - MRKT 2'
 WHERE id=201289492


   --row number: 16266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181061 , [Content] ='AMS'
 WHERE id=201289493


   --row number: 16267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181061 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201289494


   --row number: 16268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181061 , [Content] ='Engineering'
 WHERE id=201289495


   --row number: 16269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181061 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201289496


   --row number: 16270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181061 , [Content] ='Software'
 WHERE id=201289497


   --row number: 16271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181061 , [Content] ='IC3'
 WHERE id=201289498


   --row number: 16272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181061 , [Content] ='USD'
 WHERE id=201289500


   --row number: 16273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181061 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=201289501


   --row number: 16274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181061 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201289502


   --row number: 16275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3181061 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=201289503


   --row number: 16276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181061 , [Content] ='15%'
 WHERE id=201289504


   --row number: 16277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181095 , [Content] ='Yes'
 WHERE id=201295519


   --row number: 16278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181095 , [Content] ='EXEMPT'
 WHERE id=201295520


   --row number: 16279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181095 , [Content] ='NO'
 WHERE id=201295521


   --row number: 16280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181095 , [Content] ='2 - Professionals'
 WHERE id=201295522


   --row number: 16281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181095 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201295523


   --row number: 16282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181095 , [Content] ='Technical'
 WHERE id=201295524


   --row number: 16283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181095 , [Content] ='09/05/18'
 WHERE id=201295525


   --row number: 16284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181095 , [Content] ='5183 US - MRKT 2'
 WHERE id=201295505


   --row number: 16285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181095 , [Content] ='US - MRKT 2'
 WHERE id=201295506


   --row number: 16286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181095 , [Content] ='AMS'
 WHERE id=201295507


   --row number: 16287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181095 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201295508


   --row number: 16288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181095 , [Content] ='Engineering'
 WHERE id=201295509


   --row number: 16289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181095 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=201295510


   --row number: 16290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181095 , [Content] ='Quality'
 WHERE id=201295511


   --row number: 16291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181095 , [Content] ='IC3'
 WHERE id=201295512


   --row number: 16292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181095 , [Content] ='USD'
 WHERE id=201295514


   --row number: 16293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181095 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=201295515


   --row number: 16294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181095 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201295516


   --row number: 16295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3181095 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=201295517


   --row number: 16296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181095 , [Content] ='15%'
 WHERE id=201295518


   --row number: 16297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3142409 , [Content] ='166,600 / 204,100 / 241,600 / 279,100 / 316,600'
 WHERE id=202542146


   --row number: 16298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3099307 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=202050829


   --row number: 16299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3099307 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=202050830


   --row number: 16300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3164937 , [Content] ='40,400 / 47,650 / 54,900 / 62,200 / 69,500'
 WHERE id=202057960


   --row number: 16301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3108644 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=202765020


   --row number: 16302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3139205 , [Content] ='1,076,500 / 1,318,700 / 1,560,900 / 1,803,050 / 2,045,200'
 WHERE id=203335247


   --row number: 16303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3125248 , [Content] ='138,600 / 169,800 / 201,000 / 232,200 / 263,400'
 WHERE id=204042842


   --row number: 16304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3130733 , [Content] ='94,200 / 111,150 / 128,100 / 145,050 / 162,000'
 WHERE id=204293893


   --row number: 16305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3144049 , [Content] ='773,900 / 948,000 / 1,122,100 / 1,296,250 / 1,470,400'
 WHERE id=203865271


   --row number: 16306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3114860 , [Content] ='85,900 / 101,350 / 116,800 / 132,300 / 147,800'
 WHERE id=205715578


   --row number: 16307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3114860 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=205715579


   --row number: 16308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3131621 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=204907586


   --row number: 16309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3111912 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=205161186


   --row number: 16310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3141146 , [Content] ='EXEMPT'
 WHERE id=205886970


   --row number: 16311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3099333 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=205391418


   --row number: 16312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3099333 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=205391419


   --row number: 16313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3141146 , [Content] ='NO'
 WHERE id=205886971


   --row number: 16314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3166979 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=205670171


   --row number: 16315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3149763 , [Content] ='NO'
 WHERE id=205784054


   --row number: 16316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133856 , [Content] ='6,240,600 / 7,270,300 / 8,300,000 / 9,329,700 / 10,359,400'
 WHERE id=206430944


   --row number: 16317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3129707 , [Content] ='88,700 / 104,650 / 120,600 / 136,550 / 152,500'
 WHERE id=205338433


   --row number: 16318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179854 , [Content] ='S665 US - MRKT 3'
 WHERE id=201164114


   --row number: 16319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179854 , [Content] ='US - MRKT 3'
 WHERE id=201164115


   --row number: 16320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179854 , [Content] ='AMS'
 WHERE id=201164116


   --row number: 16321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179854 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201164117


   --row number: 16322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179854 , [Content] ='Sales'
 WHERE id=201164118


   --row number: 16323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179854 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201164119


   --row number: 16324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179854 , [Content] ='Product Line Sales'
 WHERE id=201164120


   --row number: 16325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179854 , [Content] ='IC5'
 WHERE id=201164121


   --row number: 16326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179854 , [Content] ='USD'
 WHERE id=201164123


   --row number: 16327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179854 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201164124


   --row number: 16328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3179854 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201164125


   --row number: 16329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179854 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201164126


   --row number: 16330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3179854 , [Content] ='60/40'
 WHERE id=201164127


   --row number: 16331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179854 , [Content] ='Yes'
 WHERE id=201164128


   --row number: 16332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3179854 , [Content] ='EXEMPT'
 WHERE id=201164129


   --row number: 16333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179854 , [Content] ='4 - Sales Workers'
 WHERE id=201164130


   --row number: 16334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179854 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201164131


   --row number: 16335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179854 , [Content] ='Technical'
 WHERE id=201164132


   --row number: 16336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179854 , [Content] ='09/05/18'
 WHERE id=201164133


   --row number: 16337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3179863 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201165700


   --row number: 16338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3179863 , [Content] ='Yes'
 WHERE id=201165702


   --row number: 16339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3179863 , [Content] ='EXEMPT'
 WHERE id=201165703


   --row number: 16340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3179863 , [Content] ='4 - Sales Workers'
 WHERE id=201165705


   --row number: 16341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3179863 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201165706


   --row number: 16342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3179863 , [Content] ='Technical'
 WHERE id=201165707


   --row number: 16343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3179863 , [Content] ='09/05/18'
 WHERE id=201165708


   --row number: 16344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3179863 , [Content] ='S665 US - MRKT 3'
 WHERE id=201165688


   --row number: 16345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3179863 , [Content] ='US - MRKT 3'
 WHERE id=201165689


   --row number: 16346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3179863 , [Content] ='AMS'
 WHERE id=201165690


   --row number: 16347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3179863 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201165691


   --row number: 16348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3179863 , [Content] ='Sales'
 WHERE id=201165692


   --row number: 16349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3179863 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201165693


   --row number: 16350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3179863 , [Content] ='Product Line Sales'
 WHERE id=201165694


   --row number: 16351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3179863 , [Content] ='60/40'
 WHERE id=201165701


   --row number: 16352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3179863 , [Content] ='IC5'
 WHERE id=201165695


   --row number: 16353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3179863 , [Content] ='USD'
 WHERE id=201165697


   --row number: 16354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3179863 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201165698


   --row number: 16355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3179863 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201165699


   --row number: 16356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3180153 , [Content] ='Yes'
 WHERE id=201195281


   --row number: 16357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3180153 , [Content] ='EXEMPT'
 WHERE id=201195282


   --row number: 16358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3180153 , [Content] ='NO'
 WHERE id=201195283


   --row number: 16359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3180153 , [Content] ='4 - Sales Workers'
 WHERE id=201195284


   --row number: 16360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3180153 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201195285


   --row number: 16361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3180153 , [Content] ='Technical'
 WHERE id=201195286


   --row number: 16362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3180153 , [Content] ='09/05/18'
 WHERE id=201195287


   --row number: 16363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3180153 , [Content] ='S665 US - MRKT 2'
 WHERE id=201195267


   --row number: 16364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3180153 , [Content] ='US - MRKT 2'
 WHERE id=201195268


   --row number: 16365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3180153 , [Content] ='AMS'
 WHERE id=201195269


   --row number: 16366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3180153 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201195270


   --row number: 16367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3180153 , [Content] ='Sales'
 WHERE id=201195271


   --row number: 16368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3180153 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201195272


   --row number: 16369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3180153 , [Content] ='Product Line Sales'
 WHERE id=201195273


   --row number: 16370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3180153 , [Content] ='IC5'
 WHERE id=201195274


   --row number: 16371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3180153 , [Content] ='USD'
 WHERE id=201195276


   --row number: 16372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3180153 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201195277


   --row number: 16373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3180153 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201195278


   --row number: 16374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3180153 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201195279


   --row number: 16375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3180153 , [Content] ='60/40'
 WHERE id=201195280


   --row number: 16376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3180172 , [Content] ='Yes'
 WHERE id=201197843


   --row number: 16377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3180172 , [Content] ='EXEMPT'
 WHERE id=201197844


   --row number: 16378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3180172 , [Content] ='NO'
 WHERE id=201197845


   --row number: 16379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3180172 , [Content] ='4 - Sales Workers'
 WHERE id=201197846


   --row number: 16380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3180172 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201197847


   --row number: 16381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3180172 , [Content] ='Technical'
 WHERE id=201197848


   --row number: 16382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3180172 , [Content] ='09/05/18'
 WHERE id=201197849


   --row number: 16383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3180172 , [Content] ='S665 US - MRKT 1'
 WHERE id=201197828


   --row number: 16384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3180172 , [Content] ='US - MRKT 1'
 WHERE id=201197829


   --row number: 16385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3180172 , [Content] ='AMS'
 WHERE id=201197830


   --row number: 16386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3180172 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201197831


   --row number: 16387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3180172 , [Content] ='Sales'
 WHERE id=201197832


   --row number: 16388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3180172 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201197833


   --row number: 16389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3180172 , [Content] ='Product Line Sales'
 WHERE id=201197835


   --row number: 16390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3180172 , [Content] ='IC5'
 WHERE id=201197836


   --row number: 16391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3180172 , [Content] ='USD'
 WHERE id=201197838


   --row number: 16392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3180172 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201197839


   --row number: 16393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3180172 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201197840


   --row number: 16394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3180172 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201197841


   --row number: 16395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3180172 , [Content] ='60/40'
 WHERE id=201197842


   --row number: 16396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3180174 , [Content] ='EXEMPT'
 WHERE id=201198122


   --row number: 16397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3180174 , [Content] ='NO'
 WHERE id=201198123


   --row number: 16398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3180174 , [Content] ='4 - Sales Workers'
 WHERE id=201198124


   --row number: 16399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3180174 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201198125


   --row number: 16400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3180174 , [Content] ='Technical'
 WHERE id=201198126


   --row number: 16401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3180174 , [Content] ='09/05/18'
 WHERE id=201198127


   --row number: 16402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3180174 , [Content] ='Yes'
 WHERE id=201198121


   --row number: 16403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3180174 , [Content] ='S665 US - MRKT 1'
 WHERE id=201198107


   --row number: 16404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3180174 , [Content] ='US - MRKT 1'
 WHERE id=201198108


   --row number: 16405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3180174 , [Content] ='AMS'
 WHERE id=201198109


   --row number: 16406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3180174 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201198110


   --row number: 16407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3180174 , [Content] ='Sales'
 WHERE id=201198111


   --row number: 16408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3180174 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201198112


   --row number: 16409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3180174 , [Content] ='Product Line Sales'
 WHERE id=201198113


   --row number: 16410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3180174 , [Content] ='IC5'
 WHERE id=201198114


   --row number: 16411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3180174 , [Content] ='USD'
 WHERE id=201198116


   --row number: 16412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3180174 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201198117


   --row number: 16413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3180174 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201198118


   --row number: 16414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3180174 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201198119


   --row number: 16415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3180174 , [Content] ='60/40'
 WHERE id=201198120


   --row number: 16416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3180223 , [Content] ='Yes'
 WHERE id=201204355


   --row number: 16417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3180223 , [Content] ='4 - Sales Workers'
 WHERE id=201204356


   --row number: 16418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3180223 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201204357


   --row number: 16419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3180223 , [Content] ='Technical'
 WHERE id=201204358


   --row number: 16420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3180223 , [Content] ='09/05/18'
 WHERE id=201204359


   --row number: 16421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3180223 , [Content] ='S665 CAN'
 WHERE id=201204341


   --row number: 16422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3180223 , [Content] ='CAN'
 WHERE id=201204342


   --row number: 16423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3180223 , [Content] ='AMS'
 WHERE id=201204343


   --row number: 16424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3180223 , [Content] ='CANADA'
 WHERE id=201204344


   --row number: 16425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3180223 , [Content] ='Sales'
 WHERE id=201204345


   --row number: 16426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3180223 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201204346


   --row number: 16427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3180223 , [Content] ='Product Line Sales'
 WHERE id=201204347


   --row number: 16428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3180223 , [Content] ='IC5'
 WHERE id=201204348


   --row number: 16429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3180223 , [Content] ='CAD'
 WHERE id=201204350


   --row number: 16430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3180223 , [Content] ='151,215 / 164,558 / 177,900 / 191,243 / 204,585'
 WHERE id=201204351


   --row number: 16431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3180223 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=201204352


   --row number: 16432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3180223 , [Content] ='252,025 / 274,263 / 296,500 / 318,738 / 340,975'
 WHERE id=201204353


   --row number: 16433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3180223 , [Content] ='60/40'
 WHERE id=201204354


   --row number: 16434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3180231 , [Content] ='Yes'
 WHERE id=201205494


   --row number: 16435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3180231 , [Content] ='4 - Sales Workers'
 WHERE id=201205495


   --row number: 16436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3180231 , [Content] ='S1415 CAN'
 WHERE id=201205480


   --row number: 16437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3180231 , [Content] ='CAN'
 WHERE id=201205481


   --row number: 16438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3180231 , [Content] ='AMS'
 WHERE id=201205482


   --row number: 16439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3180231 , [Content] ='CANADA'
 WHERE id=201205483


   --row number: 16440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3180231 , [Content] ='Solution Consulting'
 WHERE id=201205484


   --row number: 16441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3180231 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=201205485


   --row number: 16442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3180231 , [Content] ='Solution Consultant Core'
 WHERE id=201205486


   --row number: 16443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3180231 , [Content] ='IC5'
 WHERE id=201205487


   --row number: 16444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3180231 , [Content] ='CAD'
 WHERE id=201205489


   --row number: 16445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3180231 , [Content] ='149,813 / 163,031 / 176,250 / 189,469 / 202,688'
 WHERE id=201205490


   --row number: 16446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3180231 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=201205491


   --row number: 16447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3180231 , [Content] ='199,750 / 217,375 / 235,000 / 252,625 / 270,250'
 WHERE id=201205492


   --row number: 16448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3180231 , [Content] ='75/25'
 WHERE id=201205493


   --row number: 16449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3180231 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201205496


   --row number: 16450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3180231 , [Content] ='Technical'
 WHERE id=201205497


   --row number: 16451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3180231 , [Content] ='09/05/18'
 WHERE id=201205498


   --row number: 16452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3180730 , [Content] ='USD'
 WHERE id=201255157


   --row number: 16453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3180730 , [Content] ='NON-EXEMPT'
 WHERE id=201255163


   --row number: 16454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3180730 , [Content] ='NO'
 WHERE id=201255164


   --row number: 16455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3180730 , [Content] ='2 - Professionals'
 WHERE id=201255165


   --row number: 16456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3180730 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201255166


   --row number: 16457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3180730 , [Content] ='Non Technical'
 WHERE id=201255167


   --row number: 16458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3180730 , [Content] ='10/05/18'
 WHERE id=201255168


   --row number: 16459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3180730 , [Content] ='41,700 / 47,350 / 53,000 / 58,650 / 64,300'
 WHERE id=201255158


   --row number: 16460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3180730 , [Content] ='45,900 / 52,100 / 58,300 / 64,500 / 70,700'
 WHERE id=201255160


   --row number: 16461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3180730 , [Content] ='10%'
 WHERE id=201255161


   --row number: 16462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3180730 , [Content] ='No'
 WHERE id=201255162


   --row number: 16463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3180730 , [Content] ='4961 US - MRKT 2'
 WHERE id=201255148


   --row number: 16464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3180730 , [Content] ='US - MRKT 2'
 WHERE id=201255149


   --row number: 16465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3180730 , [Content] ='AMS'
 WHERE id=201255150


   --row number: 16466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3180730 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201255151


   --row number: 16467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3180730 , [Content] ='Marketing'
 WHERE id=201255152


   --row number: 16468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3180730 , [Content] ='4961 - Content Producer IC1'
 WHERE id=201255153


   --row number: 16469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3180730 , [Content] ='Content Development'
 WHERE id=201255154


   --row number: 16470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3180730 , [Content] ='IC1'
 WHERE id=201255155


   --row number: 16471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181037 , [Content] ='5224 US - MRKT 1'
 WHERE id=201286310


   --row number: 16472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181037 , [Content] ='Yes'
 WHERE id=201286324


   --row number: 16473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181037 , [Content] ='EXEMPT'
 WHERE id=201286325


   --row number: 16474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181037 , [Content] ='NO'
 WHERE id=201286326


   --row number: 16475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181037 , [Content] ='2 - Professionals'
 WHERE id=201286327


   --row number: 16476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181037 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201286328


   --row number: 16477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181037 , [Content] ='Technical'
 WHERE id=201286329


   --row number: 16478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181037 , [Content] ='10/26/2018'
 WHERE id=201286330


   --row number: 16479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181037 , [Content] ='US - MRKT 1'
 WHERE id=201286311


   --row number: 16480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181037 , [Content] ='AMS'
 WHERE id=201286312


   --row number: 16481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181037 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201286313


   --row number: 16482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181037 , [Content] ='Engineering'
 WHERE id=201286314


   --row number: 16483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181037 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=201286315


   --row number: 16484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181037 , [Content] ='Product Mgmt Mgr'
 WHERE id=201286316


   --row number: 16485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181037 , [Content] ='IC4'
 WHERE id=201286317


   --row number: 16486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181037 , [Content] ='USD'
 WHERE id=201286319


   --row number: 16487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181037 , [Content] ='113,400 / 137,150 / 160,900 / 184,650 / 208,400'
 WHERE id=201286320


   --row number: 16488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181037 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=201286321


   --row number: 16489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181037 , [Content] ='20%'
 WHERE id=201286323


   --row number: 16490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3181044 , [Content] ='5374 US - MRKT 2'
 WHERE id=201286934


   --row number: 16491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3181044 , [Content] ='US - MRKT 2'
 WHERE id=201286935


   --row number: 16492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3181044 , [Content] ='AMS'
 WHERE id=201286936


   --row number: 16493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3181044 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201286937


   --row number: 16494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3181044 , [Content] ='Engineering'
 WHERE id=201286938


   --row number: 16495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3181044 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=201286939


   --row number: 16496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3181044 , [Content] ='Yes'
 WHERE id=201286948


   --row number: 16497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3181044 , [Content] ='EXEMPT'
 WHERE id=201286949


   --row number: 16498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3181044 , [Content] ='NO'
 WHERE id=201286950


   --row number: 16499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3181044 , [Content] ='2 - Professionals'
 WHERE id=201286951


   --row number: 16500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3181044 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201286952


   --row number: 16501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3181044 , [Content] ='Technical'
 WHERE id=201286953


   --row number: 16502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3181044 , [Content] ='09/05/18'
 WHERE id=201286954


   --row number: 16503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3181044 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=201286940


   --row number: 16504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3181044 , [Content] ='IC4'
 WHERE id=201286941


   --row number: 16505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3181044 , [Content] ='USD'
 WHERE id=201286943


   --row number: 16506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3181044 , [Content] ='96,100 / 116,250 / 136,400 / 156,500 / 176,600'
 WHERE id=201286944


   --row number: 16507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3181044 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=201286945


   --row number: 16508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3181044 , [Content] ='115,300 / 139,500 / 163,700 / 187,800 / 211,900'
 WHERE id=201286946


   --row number: 16509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3181044 , [Content] ='20%'
 WHERE id=201286947


   --row number: 16510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3182579 , [Content] ='Yes'
 WHERE id=201310710


   --row number: 16511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3182579 , [Content] ='EXEMPT'
 WHERE id=201310711


   --row number: 16512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3182579 , [Content] ='NO'
 WHERE id=201310712


   --row number: 16513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3182579 , [Content] ='4 - Sales Workers'
 WHERE id=201310713


   --row number: 16514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3182579 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201310714


   --row number: 16515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3182579 , [Content] ='Technical'
 WHERE id=201310715


   --row number: 16516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3182579 , [Content] ='09/05/18'
 WHERE id=201310716


   --row number: 16517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3182579 , [Content] ='S664 US - MRKT 1'
 WHERE id=201310696


   --row number: 16518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3182579 , [Content] ='US - MRKT 1'
 WHERE id=201310697


   --row number: 16519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3182579 , [Content] ='AMS'
 WHERE id=201310698


   --row number: 16520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3182579 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201310699


   --row number: 16521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3182579 , [Content] ='Sales'
 WHERE id=201310700


   --row number: 16522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3182579 , [Content] ='S664 - Product Line Sales Mgr IC4'
 WHERE id=201310701


   --row number: 16523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3182579 , [Content] ='Product Line Sales'
 WHERE id=201310702


   --row number: 16524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3182579 , [Content] ='IC4'
 WHERE id=201310703


   --row number: 16525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3182579 , [Content] ='USD'
 WHERE id=201310705


   --row number: 16526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3182579 , [Content] ='139,995 / 152,348 / 164,700 / 177,053 / 189,405'
 WHERE id=201310706


   --row number: 16527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3182579 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=201310707


   --row number: 16528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3182579 , [Content] ='233,325 / 253,913 / 274,500 / 295,088 / 315,675'
 WHERE id=201310708


   --row number: 16529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3182579 , [Content] ='60/40'
 WHERE id=201310709


   --row number: 16530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3183628 , [Content] ='Yes'
 WHERE id=201321146


   --row number: 16531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3183628 , [Content] ='EXEMPT'
 WHERE id=201321147


   --row number: 16532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3183628 , [Content] ='NO'
 WHERE id=201321148


   --row number: 16533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3183628 , [Content] ='4 - Sales Workers'
 WHERE id=201321149


   --row number: 16534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3183628 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201321150


   --row number: 16535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3183628 , [Content] ='Technical'
 WHERE id=201321151


   --row number: 16536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3183628 , [Content] ='09/05/18'
 WHERE id=201321152


   --row number: 16537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3183628 , [Content] ='S664 US - MRKT 2'
 WHERE id=201321132


   --row number: 16538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3183628 , [Content] ='US - MRKT 2'
 WHERE id=201321133


   --row number: 16539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3183628 , [Content] ='AMS'
 WHERE id=201321134


   --row number: 16540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3183628 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201321135


   --row number: 16541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3183628 , [Content] ='Sales'
 WHERE id=201321136


   --row number: 16542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3183628 , [Content] ='S664 - Product Line Sales Mgr IC4'
 WHERE id=201321137


   --row number: 16543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3183628 , [Content] ='Product Line Sales'
 WHERE id=201321138


   --row number: 16544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3183628 , [Content] ='IC4'
 WHERE id=201321139


   --row number: 16545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3183628 , [Content] ='USD'
 WHERE id=201321141


   --row number: 16546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3183628 , [Content] ='139,995 / 152,348 / 164,700 / 177,053 / 189,405'
 WHERE id=201321142


   --row number: 16547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3183628 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=201321143


   --row number: 16548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3183628 , [Content] ='233,325 / 253,913 / 274,500 / 295,088 / 315,675'
 WHERE id=201321144


   --row number: 16549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3183628 , [Content] ='60/40'
 WHERE id=201321145


   --row number: 16550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3185397 , [Content] ='Yes'
 WHERE id=201344122


   --row number: 16551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3185397 , [Content] ='EXEMPT'
 WHERE id=201344123


   --row number: 16552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3185397 , [Content] ='NO'
 WHERE id=201344124


   --row number: 16553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3185397 , [Content] ='2 - Professionals'
 WHERE id=201344125


   --row number: 16554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3185397 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201344126


   --row number: 16555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3185397 , [Content] ='Technical'
 WHERE id=201344127


   --row number: 16556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3185397 , [Content] ='5142 US - MRKT 2'
 WHERE id=201344108


   --row number: 16557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3185397 , [Content] ='US - MRKT 2'
 WHERE id=201344109


   --row number: 16558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3185397 , [Content] ='AMS'
 WHERE id=201344110


   --row number: 16559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3185397 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201344111


   --row number: 16560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3185397 , [Content] ='Engineering'
 WHERE id=201344112


   --row number: 16561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3185397 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=201344113


   --row number: 16562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3185397 , [Content] ='Software'
 WHERE id=201344114


   --row number: 16563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3185397 , [Content] ='IC2'
 WHERE id=201344115


   --row number: 16564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3185397 , [Content] ='USD'
 WHERE id=201344117


   --row number: 16565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3185397 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=201344118


   --row number: 16566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3185397 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=201344119


   --row number: 16567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3185397 , [Content] ='84,400 / 98,300 / 112,200 / 126,100 / 140,000'
 WHERE id=201344120


   --row number: 16568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3185397 , [Content] ='10%'
 WHERE id=201344121


   --row number: 16569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3185397 , [Content] ='09/05/18'
 WHERE id=201344128


   --row number: 16570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3185402 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=201344557


   --row number: 16571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3185402 , [Content] ='10%'
 WHERE id=201344560


   --row number: 16572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3185402 , [Content] ='Yes'
 WHERE id=201344561


   --row number: 16573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3185402 , [Content] ='EXEMPT'
 WHERE id=201344562


   --row number: 16574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3185402 , [Content] ='NO'
 WHERE id=201344563


   --row number: 16575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3185402 , [Content] ='2 - Professionals'
 WHERE id=201344564


   --row number: 16576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3185402 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201344565


   --row number: 16577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3185402 , [Content] ='Technical'
 WHERE id=201344566


   --row number: 16578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3185402 , [Content] ='09/05/18'
 WHERE id=201344567


   --row number: 16579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3185402 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=201344558


   --row number: 16580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3185402 , [Content] ='100,900 / 117,550 / 134,200 / 150,800 / 167,400'
 WHERE id=201344559


   --row number: 16581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3185402 , [Content] ='5142 US - MRKT 1'
 WHERE id=201344547


   --row number: 16582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3185402 , [Content] ='US - MRKT 1'
 WHERE id=201344548


   --row number: 16583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3185402 , [Content] ='AMS'
 WHERE id=201344549


   --row number: 16584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3185402 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201344550


   --row number: 16585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3185402 , [Content] ='Engineering'
 WHERE id=201344551


   --row number: 16586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3185402 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=201344552


   --row number: 16587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3185402 , [Content] ='Software'
 WHERE id=201344553


   --row number: 16588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3185402 , [Content] ='IC2'
 WHERE id=201344554


   --row number: 16589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3185402 , [Content] ='USD'
 WHERE id=201344556


   --row number: 16590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3185452 , [Content] ='Yes'
 WHERE id=201362734


   --row number: 16591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3185452 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201362735


   --row number: 16592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3185452 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201362736


   --row number: 16593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3185452 , [Content] ='Technical'
 WHERE id=201362737


   --row number: 16594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3185452 , [Content] ='09/05/18'
 WHERE id=201362738


   --row number: 16595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3185452 , [Content] ='M6'
 WHERE id=201362727


   --row number: 16596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3185452 , [Content] ='SGD'
 WHERE id=201362729


   --row number: 16597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3185452 , [Content] ='286,875 / 312,188 / 337,500 / 362,813 / 388,125'
 WHERE id=201362730


   --row number: 16598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3185452 , [Content] ='192,000 / 288,000 / 384,000 / 480,000 / 576,000'
 WHERE id=201362731


   --row number: 16599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3185452 , [Content] ='382,500 / 416,250 / 450,000 / 483,750 / 517,500'
 WHERE id=201362732


   --row number: 16600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3185452 , [Content] ='75/25'
 WHERE id=201362733


   --row number: 16601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3185452 , [Content] ='S1406 SGP'
 WHERE id=201362720


   --row number: 16602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3185452 , [Content] ='SGP'
 WHERE id=201362721


   --row number: 16603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3185452 , [Content] ='APAC'
 WHERE id=201362722


   --row number: 16604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3185452 , [Content] ='SINGAPORE'
 WHERE id=201362723


   --row number: 16605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3185452 , [Content] ='Solution Consulting'
 WHERE id=201362724


   --row number: 16606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3185452 , [Content] ='S1406 - Sr Dir, Solution Consulting M6'
 WHERE id=201362725


   --row number: 16607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3185452 , [Content] ='Solution Consultant Core'
 WHERE id=201362726


   --row number: 16608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3185931 , [Content] ='IC3'
 WHERE id=201429411


   --row number: 16609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3185931 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201429419


   --row number: 16610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3185931 , [Content] ='Technical'
 WHERE id=201429420


   --row number: 16611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3185931 , [Content] ='09/05/18'
 WHERE id=201429421


   --row number: 16612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3185931 , [Content] ='EUR'
 WHERE id=201429413


   --row number: 16613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3185931 , [Content] ='43,400 / 50,550 / 57,700 / 64,850 / 72,000'
 WHERE id=201429414


   --row number: 16614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3185931 , [Content] ='47,700 / 55,600 / 63,500 / 71,350 / 79,200'
 WHERE id=201429415


   --row number: 16615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3185931 , [Content] ='10%'
 WHERE id=201429416


   --row number: 16616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3185931 , [Content] ='No'
 WHERE id=201429417


   --row number: 16617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3185931 , [Content] ='2 - Professionals'
 WHERE id=201429418


   --row number: 16618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3185931 , [Content] ='S1833 NLD'
 WHERE id=201429404


   --row number: 16619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3185931 , [Content] ='NLD'
 WHERE id=201429405


   --row number: 16620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3185931 , [Content] ='EMEA'
 WHERE id=201429406


   --row number: 16621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3185931 , [Content] ='NETHERLANDS'
 WHERE id=201429407


   --row number: 16622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3185931 , [Content] ='Sales Operations'
 WHERE id=201429408


   --row number: 16623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3185931 , [Content] ='S1833 - Sales Operations Analyst IC3'
 WHERE id=201429409


   --row number: 16624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3185931 , [Content] ='Sales Operations'
 WHERE id=201429410


   --row number: 16625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3185964 , [Content] ='Yes'
 WHERE id=201432702


   --row number: 16626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3185964 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201432703


   --row number: 16627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3185964 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201432704


   --row number: 16628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3185964 , [Content] ='Technical'
 WHERE id=201432705


   --row number: 16629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3185964 , [Content] ='09/05/18'
 WHERE id=201432706


   --row number: 16630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3185964 , [Content] ='S1403 CHE'
 WHERE id=201432688


   --row number: 16631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3185964 , [Content] ='CHE'
 WHERE id=201432689


   --row number: 16632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3185964 , [Content] ='EMEA'
 WHERE id=201432690


   --row number: 16633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3185964 , [Content] ='SWITZERLAND'
 WHERE id=201432691


   --row number: 16634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3185964 , [Content] ='Solution Consulting'
 WHERE id=201432692


   --row number: 16635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3185964 , [Content] ='S1403 - Mgr, Solution Consulting M3'
 WHERE id=201432693


   --row number: 16636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3185964 , [Content] ='Solution Consultant Core'
 WHERE id=201432694


   --row number: 16637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3185964 , [Content] ='M3'
 WHERE id=201432695


   --row number: 16638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3185964 , [Content] ='CHF'
 WHERE id=201432697


   --row number: 16639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3185964 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=201432698


   --row number: 16640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3185964 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=201432699


   --row number: 16641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3185964 , [Content] ='187,000 / 203,500 / 220,000 / 236,500 / 253,000'
 WHERE id=201432700


   --row number: 16642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3185964 , [Content] ='75/25'
 WHERE id=201432701


   --row number: 16643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3186002 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201435152


   --row number: 16644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3186002 , [Content] ='Technical'
 WHERE id=201435153


   --row number: 16645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3186002 , [Content] ='09/05/18'
 WHERE id=201435154


   --row number: 16646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3186002 , [Content] ='S1864 NLD'
 WHERE id=201435137


   --row number: 16647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3186002 , [Content] ='NLD'
 WHERE id=201435138


   --row number: 16648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3186002 , [Content] ='EMEA'
 WHERE id=201435139


   --row number: 16649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3186002 , [Content] ='NETHERLANDS'
 WHERE id=201435140


   --row number: 16650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3186002 , [Content] ='Sales Operations'
 WHERE id=201435141


   --row number: 16651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3186002 , [Content] ='S1864 - Sales Operations Specialist A4'
 WHERE id=201435142


   --row number: 16652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3186002 , [Content] ='Sales Operations'
 WHERE id=201435143


   --row number: 16653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3186002 , [Content] ='A4'
 WHERE id=201435144


   --row number: 16654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3186002 , [Content] ='EUR'
 WHERE id=201435146


   --row number: 16655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3186002 , [Content] ='39,900 / 45,250 / 50,600 / 56,000 / 61,400'
 WHERE id=201435147


   --row number: 16656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3186002 , [Content] ='43,100 / 48,850 / 54,600 / 60,450 / 66,300'
 WHERE id=201435148


   --row number: 16657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3186002 , [Content] ='8%'
 WHERE id=201435149


   --row number: 16658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3186002 , [Content] ='No'
 WHERE id=201435150


   --row number: 16659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3186002 , [Content] ='5 - Administrative Support Workers'
 WHERE id=201435151


   --row number: 16660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3186227 , [Content] ='Yes'
 WHERE id=201456054


   --row number: 16661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3186227 , [Content] ='EXEMPT'
 WHERE id=201456055


   --row number: 16662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3186227 , [Content] ='NO'
 WHERE id=201456056


   --row number: 16663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3186227 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201456057


   --row number: 16664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3186227 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201456058


   --row number: 16665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3186227 , [Content] ='Technical'
 WHERE id=201456059


   --row number: 16666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3186227 , [Content] ='09/05/18'
 WHERE id=201456060


   --row number: 16667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3186227 , [Content] ='S1404 US - MRKT 2'
 WHERE id=201456040


   --row number: 16668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3186227 , [Content] ='US - MRKT 2'
 WHERE id=201456041


   --row number: 16669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3186227 , [Content] ='AMS'
 WHERE id=201456042


   --row number: 16670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3186227 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201456043


   --row number: 16671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3186227 , [Content] ='Solution Consulting'
 WHERE id=201456044


   --row number: 16672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3186227 , [Content] ='S1404 - Sr Mgr, Solution Consulting M4'
 WHERE id=201456045


   --row number: 16673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3186227 , [Content] ='Solution Consultant Core'
 WHERE id=201456046


   --row number: 16674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3186227 , [Content] ='M4'
 WHERE id=201456047


   --row number: 16675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3186227 , [Content] ='USD'
 WHERE id=201456049


   --row number: 16676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3186227 , [Content] ='162,563 / 176,906 / 191,250 / 205,594 / 219,938'
 WHERE id=201456050


   --row number: 16677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3186227 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201456051


   --row number: 16678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3186227 , [Content] ='216,750 / 235,875 / 255,000 / 274,125 / 293,250'
 WHERE id=201456052


   --row number: 16679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3186227 , [Content] ='75/25'
 WHERE id=201456053


   --row number: 16680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3186450 , [Content] ='9999 US - MRKT 1'
 WHERE id=201480934


   --row number: 16681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3186450 , [Content] ='US - MRKT 1'
 WHERE id=201480935


   --row number: 16682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3186450 , [Content] ='AMS'
 WHERE id=201480936


   --row number: 16683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3186450 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201480937


   --row number: 16684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3186450 , [Content] ='9999 - Intern'
 WHERE id=201480938


   --row number: 16685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3186450 , [Content] ='USD'
 WHERE id=201480939


   --row number: 16686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3186450 , [Content] ='No'
 WHERE id=201480940


   --row number: 16687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3186450 , [Content] ='NON-EXEMPT'
 WHERE id=201480941


   --row number: 16688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3186450 , [Content] ='NO'
 WHERE id=201480942


   --row number: 16689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3186450 , [Content] ='09/05/18'
 WHERE id=201480943


   --row number: 16690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187327 , [Content] ='5223 US - MRKT 1'
 WHERE id=201580210


   --row number: 16691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187327 , [Content] ='US - MRKT 1'
 WHERE id=201580211


   --row number: 16692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187327 , [Content] ='AMS'
 WHERE id=201580212


   --row number: 16693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187327 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201580213


   --row number: 16694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187327 , [Content] ='Engineering'
 WHERE id=201580214


   --row number: 16695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187327 , [Content] ='5223 - Sr. Product Mgmt Mgr IC3'
 WHERE id=201580215


   --row number: 16696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187327 , [Content] ='Product Mgmt Mgr'
 WHERE id=201580216


   --row number: 16697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187327 , [Content] ='IC3'
 WHERE id=201580217


   --row number: 16698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187327 , [Content] ='USD'
 WHERE id=201580219


   --row number: 16699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3187327 , [Content] ='101,300 / 119,500 / 137,700 / 155,950 / 174,200'
 WHERE id=201580220


   --row number: 16700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187327 , [Content] ='Yes'
 WHERE id=201580224


   --row number: 16701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3187327 , [Content] ='EXEMPT'
 WHERE id=201580225


   --row number: 16702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3187327 , [Content] ='NO'
 WHERE id=201580226


   --row number: 16703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187327 , [Content] ='2 - Professionals'
 WHERE id=201580227


   --row number: 16704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187327 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201580228


   --row number: 16705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187327 , [Content] ='Technical'
 WHERE id=201580229


   --row number: 16706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187327 , [Content] ='10/05/18'
 WHERE id=201580230


   --row number: 16707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187327 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201580221


   --row number: 16708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3187327 , [Content] ='116,500 / 137,450 / 158,400 / 179,350 / 200,300'
 WHERE id=201580222


   --row number: 16709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3187327 , [Content] ='15%'
 WHERE id=201580223


   --row number: 16710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3185516 , [Content] ='IC4'
 WHERE id=201610902


   --row number: 16711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3185516 , [Content] ='Technical'
 WHERE id=201610903


   --row number: 16712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3185516 , [Content] ='09/05/18'
 WHERE id=201610905


   --row number: 16713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3185516 , [Content] ='12,750,000 / 13,875,000 / 15,000,000 / 16,125,000 / 17,250,000'
 WHERE id=201610906


   --row number: 16714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3185516 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=201610907


   --row number: 16715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3185516 , [Content] ='9,562,500 / 10,406,250 / 11,250,000 / 12,093,750 / 12,937,500'
 WHERE id=201610908


   --row number: 16716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3185516 , [Content] ='75/25'
 WHERE id=201610909


   --row number: 16717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3185516 , [Content] ='S1414 JPN'
 WHERE id=201610910


   --row number: 16718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3185516 , [Content] ='Solution Consultant Core'
 WHERE id=201610893


   --row number: 16719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3185516 , [Content] ='JPN'
 WHERE id=201610894


   --row number: 16720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3185516 , [Content] ='APAC'
 WHERE id=201610895


   --row number: 16721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3185516 , [Content] ='Yes'
 WHERE id=201610896


   --row number: 16722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3185516 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201610897


   --row number: 16723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3185516 , [Content] ='Solution Consulting'
 WHERE id=201610898


   --row number: 16724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3185516 , [Content] ='4 - Sales Workers'
 WHERE id=201610899


   --row number: 16725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3185516 , [Content] ='JPY'
 WHERE id=201610911


   --row number: 16726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3185516 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=201610900


   --row number: 16727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3185516 , [Content] ='JAPAN'
 WHERE id=201610901


   --row number: 16728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187474 , [Content] ='Technical'
 WHERE id=201611960


   --row number: 16729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187474 , [Content] ='09/05/18'
 WHERE id=201611961


   --row number: 16730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187474 , [Content] ='3514 JPN'
 WHERE id=201611945


   --row number: 16731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187474 , [Content] ='JPN'
 WHERE id=201611946


   --row number: 16732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187474 , [Content] ='APAC'
 WHERE id=201611947


   --row number: 16733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187474 , [Content] ='JAPAN'
 WHERE id=201611948


   --row number: 16734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187474 , [Content] ='Info Systems/Technology'
 WHERE id=201611949


   --row number: 16735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187474 , [Content] ='3514 - Sr Mgr, Business Systems Mgmt M4'
 WHERE id=201611950


   --row number: 16736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187474 , [Content] ='Business Systems Analysis'
 WHERE id=201611951


   --row number: 16737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187474 , [Content] ='M4'
 WHERE id=201611952


   --row number: 16738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187474 , [Content] ='JPY'
 WHERE id=201611954


   --row number: 16739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187474 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=201611955


   --row number: 16740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3187474 , [Content] ='25%'
 WHERE id=201611956


   --row number: 16741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187474 , [Content] ='Yes'
 WHERE id=201611957


   --row number: 16742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187474 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201611958


   --row number: 16743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187474 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201611959


   --row number: 16744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187526 , [Content] ='Yes'
 WHERE id=201618284


   --row number: 16745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187526 , [Content] ='2 - Professionals'
 WHERE id=201618285


   --row number: 16746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187526 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201618286


   --row number: 16747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187526 , [Content] ='Technical'
 WHERE id=201618287


   --row number: 16748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187526 , [Content] ='09/05/18'
 WHERE id=201618288


   --row number: 16749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187526 , [Content] ='5143 IND'
 WHERE id=201618270


   --row number: 16750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187526 , [Content] ='IND'
 WHERE id=201618271


   --row number: 16751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187526 , [Content] ='APAC'
 WHERE id=201618272


   --row number: 16752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187526 , [Content] ='INDIA'
 WHERE id=201618273


   --row number: 16753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187526 , [Content] ='Engineering'
 WHERE id=201618274


   --row number: 16754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187526 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201618275


   --row number: 16755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187526 , [Content] ='Software'
 WHERE id=201618276


   --row number: 16756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187526 , [Content] ='IC3'
 WHERE id=201618277


   --row number: 16757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187526 , [Content] ='INR'
 WHERE id=201618279


   --row number: 16758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3187526 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=201618280


   --row number: 16759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187526 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=201618281


   --row number: 16760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3187526 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=201618282


   --row number: 16761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3187526 , [Content] ='15%'
 WHERE id=201618283


   --row number: 16762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187530 , [Content] ='5143 IND'
 WHERE id=201618669


   --row number: 16763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187530 , [Content] ='IND'
 WHERE id=201618670


   --row number: 16764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187530 , [Content] ='APAC'
 WHERE id=201618671


   --row number: 16765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187530 , [Content] ='Yes'
 WHERE id=201618683


   --row number: 16766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187530 , [Content] ='2 - Professionals'
 WHERE id=201618684


   --row number: 16767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187530 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201618685


   --row number: 16768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187530 , [Content] ='Technical'
 WHERE id=201618686


   --row number: 16769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187530 , [Content] ='09/05/18'
 WHERE id=201618687


   --row number: 16770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187530 , [Content] ='INDIA'
 WHERE id=201618672


   --row number: 16771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187530 , [Content] ='Engineering'
 WHERE id=201618673


   --row number: 16772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187530 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201618674


   --row number: 16773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187530 , [Content] ='Software'
 WHERE id=201618675


   --row number: 16774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187530 , [Content] ='IC3'
 WHERE id=201618676


   --row number: 16775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187530 , [Content] ='INR'
 WHERE id=201618678


   --row number: 16776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3187530 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=201618679


   --row number: 16777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187530 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=201618680


   --row number: 16778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3187530 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=201618681


   --row number: 16779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3187530 , [Content] ='15%'
 WHERE id=201618682


   --row number: 16780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187685 , [Content] ='Yes'
 WHERE id=201637537


   --row number: 16781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187685 , [Content] ='2 - Professionals'
 WHERE id=201637538


   --row number: 16782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187685 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201637539


   --row number: 16783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187685 , [Content] ='Technical'
 WHERE id=201637540


   --row number: 16784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187685 , [Content] ='09/05/18'
 WHERE id=201637541


   --row number: 16785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187685 , [Content] ='5183 NLD'
 WHERE id=201637524


   --row number: 16786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187685 , [Content] ='NLD'
 WHERE id=201637525


   --row number: 16787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187685 , [Content] ='EMEA'
 WHERE id=201637526


   --row number: 16788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187685 , [Content] ='NETHERLANDS'
 WHERE id=201637527


   --row number: 16789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187685 , [Content] ='Engineering'
 WHERE id=201637528


   --row number: 16790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187685 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=201637529


   --row number: 16791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187685 , [Content] ='Quality'
 WHERE id=201637530


   --row number: 16792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187685 , [Content] ='IC3'
 WHERE id=201637531


   --row number: 16793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187685 , [Content] ='EUR'
 WHERE id=201637533


   --row number: 16794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3187685 , [Content] ='47,700 / 56,300 / 64,900 / 73,450 / 82,000'
 WHERE id=201637534


   --row number: 16795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3187685 , [Content] ='54,900 / 64,750 / 74,600 / 84,450 / 94,300'
 WHERE id=201637535


   --row number: 16796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3187685 , [Content] ='15%'
 WHERE id=201637536


   --row number: 16797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3187688 , [Content] ='50/50'
 WHERE id=201638037


   --row number: 16798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187688 , [Content] ='Yes'
 WHERE id=201638038


   --row number: 16799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187688 , [Content] ='4 - Sales Workers'
 WHERE id=201638039


   --row number: 16800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187688 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201638040


   --row number: 16801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187688 , [Content] ='Technical'
 WHERE id=201638041


   --row number: 16802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187688 , [Content] ='09/05/18'
 WHERE id=201638042


   --row number: 16803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187688 , [Content] ='R3613B ISR'
 WHERE id=201638024


   --row number: 16804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187688 , [Content] ='ISR'
 WHERE id=201638025


   --row number: 16805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187688 , [Content] ='EMEA'
 WHERE id=201638026


   --row number: 16806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187688 , [Content] ='ISRAEL'
 WHERE id=201638027


   --row number: 16807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187688 , [Content] ='Sales'
 WHERE id=201638028


   --row number: 16808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187688 , [Content] ='R3613B - Commercial Account Exec IC3'
 WHERE id=201638029


   --row number: 16809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187688 , [Content] ='Commercial Accounts'
 WHERE id=201638030


   --row number: 16810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187688 , [Content] ='IC3'
 WHERE id=201638031


   --row number: 16811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187688 , [Content] ='ILS'
 WHERE id=201638033


   --row number: 16812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3187688 , [Content] ='224,613 / 244,431 / 264,250 / 284,069 / 303,888'
 WHERE id=201638034


   --row number: 16813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187688 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=201638035


   --row number: 16814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3187688 , [Content] ='449,225 / 488,863 / 528,500 / 568,138 / 607,775'
 WHERE id=201638036


   --row number: 16815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3187704 , [Content] ='2 - Professionals'
 WHERE id=201639585


   --row number: 16816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3187704 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201639586


   --row number: 16817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3187704 , [Content] ='Non Technical'
 WHERE id=201639587


   --row number: 16818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3187704 , [Content] ='09/05/18'
 WHERE id=201639588


   --row number: 16819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3187704 , [Content] ='6394 NLD'
 WHERE id=201639570


   --row number: 16820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3187704 , [Content] ='NLD'
 WHERE id=201639571


   --row number: 16821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3187704 , [Content] ='EMEA'
 WHERE id=201639572


   --row number: 16822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3187704 , [Content] ='NETHERLANDS'
 WHERE id=201639573


   --row number: 16823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3187704 , [Content] ='Legal'
 WHERE id=201639574


   --row number: 16824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3187704 , [Content] ='6394 - Legal Counsel IC4'
 WHERE id=201639575


   --row number: 16825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3187704 , [Content] ='Legal Counsel'
 WHERE id=201639576


   --row number: 16826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3187704 , [Content] ='IC4'
 WHERE id=201639577


   --row number: 16827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3187704 , [Content] ='EUR'
 WHERE id=201639579


   --row number: 16828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3187704 , [Content] ='89,500 / 109,650 / 129,800 / 149,950 / 170,100'
 WHERE id=201639580


   --row number: 16829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3187704 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=201639581


   --row number: 16830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3187704 , [Content] ='111,900 / 137,100 / 162,300 / 187,450 / 212,600'
 WHERE id=201639582


   --row number: 16831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3187704 , [Content] ='25%'
 WHERE id=201639583


   --row number: 16832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3187704 , [Content] ='Yes'
 WHERE id=201639584


   --row number: 16833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188241 , [Content] ='20%'
 WHERE id=201685410


   --row number: 16834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188241 , [Content] ='Yes'
 WHERE id=201685411


   --row number: 16835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188241 , [Content] ='EXEMPT'
 WHERE id=201685412


   --row number: 16836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188241 , [Content] ='NO'
 WHERE id=201685413


   --row number: 16837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188241 , [Content] ='2 - Professionals'
 WHERE id=201685414


   --row number: 16838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188241 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201685415


   --row number: 16839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188241 , [Content] ='Technical'
 WHERE id=201685416


   --row number: 16840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188241 , [Content] ='09/05/18'
 WHERE id=201685417


   --row number: 16841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188241 , [Content] ='5144 US - MRKT 1'
 WHERE id=201685397


   --row number: 16842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188241 , [Content] ='US - MRKT 1'
 WHERE id=201685398


   --row number: 16843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188241 , [Content] ='AMS'
 WHERE id=201685399


   --row number: 16844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188241 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201685400


   --row number: 16845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188241 , [Content] ='Engineering'
 WHERE id=201685401


   --row number: 16846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188241 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=201685402


   --row number: 16847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188241 , [Content] ='Software'
 WHERE id=201685403


   --row number: 16848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188241 , [Content] ='IC4'
 WHERE id=201685404


   --row number: 16849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188241 , [Content] ='USD'
 WHERE id=201685406


   --row number: 16850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188241 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=201685407


   --row number: 16851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188241 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=201685408


   --row number: 16852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188241 , [Content] ='148,200 / 179,200 / 210,200 / 241,300 / 272,400'
 WHERE id=201685409


   --row number: 16853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188249 , [Content] ='EXEMPT'
 WHERE id=201686434


   --row number: 16854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188249 , [Content] ='NO'
 WHERE id=201686435


   --row number: 16855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188249 , [Content] ='2 - Professionals'
 WHERE id=201686436


   --row number: 16856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188249 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201686437


   --row number: 16857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188249 , [Content] ='Technical'
 WHERE id=201686438


   --row number: 16858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188249 , [Content] ='09/05/18'
 WHERE id=201686439


   --row number: 16859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188249 , [Content] ='6493 US - MRKT 1'
 WHERE id=201686419


   --row number: 16860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188249 , [Content] ='US - MRKT 1'
 WHERE id=201686420


   --row number: 16861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188249 , [Content] ='AMS'
 WHERE id=201686421


   --row number: 16862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188249 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201686422


   --row number: 16863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188249 , [Content] ='Info Systems/Technology'
 WHERE id=201686423


   --row number: 16864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188249 , [Content] ='6493 - Data Informatics Analyst IC3'
 WHERE id=201686424


   --row number: 16865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188249 , [Content] ='Data Informatics'
 WHERE id=201686425


   --row number: 16866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188249 , [Content] ='IC3'
 WHERE id=201686426


   --row number: 16867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188249 , [Content] ='USD'
 WHERE id=201686428


   --row number: 16868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188249 , [Content] ='99,600 / 117,550 / 135,500 / 153,400 / 171,300'
 WHERE id=201686429


   --row number: 16869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188249 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201686430


   --row number: 16870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188249 , [Content] ='114,500 / 135,150 / 155,800 / 176,400 / 197,000'
 WHERE id=201686431


   --row number: 16871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188249 , [Content] ='15%'
 WHERE id=201686432


   --row number: 16872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188249 , [Content] ='Yes'
 WHERE id=201686433


   --row number: 16873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188294 , [Content] ='Yes'
 WHERE id=201691860


   --row number: 16874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188294 , [Content] ='EXEMPT'
 WHERE id=201691861


   --row number: 16875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188294 , [Content] ='NO'
 WHERE id=201691862


   --row number: 16876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188294 , [Content] ='2 - Professionals'
 WHERE id=201691863


   --row number: 16877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188294 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201691864


   --row number: 16878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188294 , [Content] ='Technical'
 WHERE id=201691865


   --row number: 16879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188294 , [Content] ='09/05/18'
 WHERE id=201691866


   --row number: 16880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188294 , [Content] ='5884 US - MRKT 1'
 WHERE id=201691846


   --row number: 16881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188294 , [Content] ='US - MRKT 1'
 WHERE id=201691847


   --row number: 16882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188294 , [Content] ='AMS'
 WHERE id=201691848


   --row number: 16883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188294 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201691849


   --row number: 16884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188294 , [Content] ='Professional Services'
 WHERE id=201691850


   --row number: 16885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188294 , [Content] ='5884 - Customer/Technical Trainer IC4'
 WHERE id=201691851


   --row number: 16886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188294 , [Content] ='Customer/Tech Training'
 WHERE id=201691852


   --row number: 16887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188294 , [Content] ='IC4'
 WHERE id=201691853


   --row number: 16888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188294 , [Content] ='USD'
 WHERE id=201691855


   --row number: 16889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188294 , [Content] ='93,400 / 110,200 / 127,000 / 143,800 / 160,600'
 WHERE id=201691856


   --row number: 16890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188294 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201691857


   --row number: 16891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188294 , [Content] ='107,400 / 126,750 / 146,100 / 165,400 / 184,700'
 WHERE id=201691858


   --row number: 16892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188294 , [Content] ='15%'
 WHERE id=201691859


   --row number: 16893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188321 , [Content] ='20%'
 WHERE id=201693115


   --row number: 16894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188321 , [Content] ='Yes'
 WHERE id=201693116


   --row number: 16895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188321 , [Content] ='EXEMPT'
 WHERE id=201693117


   --row number: 16896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188321 , [Content] ='2 - Professionals'
 WHERE id=201693118


   --row number: 16897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188321 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201693119


   --row number: 16898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188321 , [Content] ='Technical'
 WHERE id=201693120


   --row number: 16899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188321 , [Content] ='09/05/18'
 WHERE id=201693121


   --row number: 16900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188321 , [Content] ='5764 US - MRKT 3'
 WHERE id=201693102


   --row number: 16901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188321 , [Content] ='US - MRKT 3'
 WHERE id=201693103


   --row number: 16902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188321 , [Content] ='AMS'
 WHERE id=201693104


   --row number: 16903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188321 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201693105


   --row number: 16904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188321 , [Content] ='Professional Services'
 WHERE id=201693106


   --row number: 16905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188321 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=201693107


   --row number: 16906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188321 , [Content] ='Technology Consultant'
 WHERE id=201693108


   --row number: 16907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188321 , [Content] ='IC4'
 WHERE id=201693109


   --row number: 16908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188321 , [Content] ='USD'
 WHERE id=201693111


   --row number: 16909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188321 , [Content] ='88,100 / 106,550 / 125,000 / 143,450 / 161,900'
 WHERE id=201693112


   --row number: 16910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188321 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=201693113


   --row number: 16911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188321 , [Content] ='105,700 / 127,850 / 150,000 / 172,150 / 194,300'
 WHERE id=201693114


   --row number: 16912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188334 , [Content] ='Yes'
 WHERE id=201694201


   --row number: 16913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188334 , [Content] ='EXEMPT'
 WHERE id=201694202


   --row number: 16914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188334 , [Content] ='NO'
 WHERE id=201694203


   --row number: 16915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188334 , [Content] ='2 - Professionals'
 WHERE id=201694204


   --row number: 16916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188334 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201694205


   --row number: 16917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188334 , [Content] ='Technical'
 WHERE id=201694206


   --row number: 16918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188334 , [Content] ='09/05/18'
 WHERE id=201694207


   --row number: 16919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188334 , [Content] ='5705 US - MRKT 1'
 WHERE id=201694187


   --row number: 16920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188334 , [Content] ='US - MRKT 1'
 WHERE id=201694188


   --row number: 16921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188334 , [Content] ='AMS'
 WHERE id=201694189


   --row number: 16922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188334 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201694190


   --row number: 16923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188334 , [Content] ='Professional Services'
 WHERE id=201694191


   --row number: 16924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188334 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=201694192


   --row number: 16925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188334 , [Content] ='Partner Support'
 WHERE id=201694193


   --row number: 16926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188334 , [Content] ='IC5'
 WHERE id=201694194


   --row number: 16927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188334 , [Content] ='USD'
 WHERE id=201694196


   --row number: 16928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188334 , [Content] ='109,700 / 134,400 / 159,100 / 183,750 / 208,400'
 WHERE id=201694197


   --row number: 16929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188334 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201694198


   --row number: 16930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188334 , [Content] ='137,100 / 168,000 / 198,900 / 229,700 / 260,500'
 WHERE id=201694199


   --row number: 16931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188334 , [Content] ='25%'
 WHERE id=201694200


   --row number: 16932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188341 , [Content] ='EXEMPT'
 WHERE id=201694695


   --row number: 16933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188341 , [Content] ='NO'
 WHERE id=201694696


   --row number: 16934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188341 , [Content] ='4 - Sales Workers'
 WHERE id=201694697


   --row number: 16935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188341 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201694698


   --row number: 16936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188341 , [Content] ='Technical'
 WHERE id=201694699


   --row number: 16937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188341 , [Content] ='09/05/18'
 WHERE id=201694700


   --row number: 16938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188341 , [Content] ='S1413 US - MRKT 2'
 WHERE id=201694680


   --row number: 16939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188341 , [Content] ='US - MRKT 2'
 WHERE id=201694681


   --row number: 16940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188341 , [Content] ='AMS'
 WHERE id=201694682


   --row number: 16941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188341 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201694683


   --row number: 16942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188341 , [Content] ='Solution Consulting'
 WHERE id=201694684


   --row number: 16943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188341 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=201694685


   --row number: 16944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188341 , [Content] ='Solution Consultant Core'
 WHERE id=201694686


   --row number: 16945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188341 , [Content] ='IC3'
 WHERE id=201694687


   --row number: 16946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188341 , [Content] ='USD'
 WHERE id=201694689


   --row number: 16947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188341 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=201694690


   --row number: 16948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188341 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=201694691


   --row number: 16949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188341 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=201694692


   --row number: 16950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3188341 , [Content] ='75/25'
 WHERE id=201694693


   --row number: 16951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188341 , [Content] ='Yes'
 WHERE id=201694694


   --row number: 16952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188363 , [Content] ='Yes'
 WHERE id=201696387


   --row number: 16953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188363 , [Content] ='EXEMPT'
 WHERE id=201696388


   --row number: 16954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188363 , [Content] ='NO'
 WHERE id=201696389


   --row number: 16955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188363 , [Content] ='2 - Professionals'
 WHERE id=201696390


   --row number: 16956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188363 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201696391


   --row number: 16957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188363 , [Content] ='Technical'
 WHERE id=201696392


   --row number: 16958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188363 , [Content] ='09/05/18'
 WHERE id=201696393


   --row number: 16959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188363 , [Content] ='S1832 US - MRKT 2'
 WHERE id=201696373


   --row number: 16960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188363 , [Content] ='US - MRKT 2'
 WHERE id=201696374


   --row number: 16961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188363 , [Content] ='AMS'
 WHERE id=201696375


   --row number: 16962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188363 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201696376


   --row number: 16963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188363 , [Content] ='Sales Operations'
 WHERE id=201696377


   --row number: 16964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188363 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=201696378


   --row number: 16965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188363 , [Content] ='Sales Operations'
 WHERE id=201696379


   --row number: 16966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188363 , [Content] ='IC2'
 WHERE id=201696380


   --row number: 16967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188363 , [Content] ='USD'
 WHERE id=201696382


   --row number: 16968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188363 , [Content] ='52,900 / 60,450 / 68,000 / 75,550 / 83,100'
 WHERE id=201696383


   --row number: 16969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188363 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=201696384


   --row number: 16970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188363 , [Content] ='58,200 / 66,500 / 74,800 / 83,100 / 91,400'
 WHERE id=201696385


   --row number: 16971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188363 , [Content] ='10%'
 WHERE id=201696386


   --row number: 16972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3188414 , [Content] ='75/25'
 WHERE id=201699326


   --row number: 16973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188414 , [Content] ='Yes'
 WHERE id=201699327


   --row number: 16974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188414 , [Content] ='4 - Sales Workers'
 WHERE id=201699328


   --row number: 16975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188414 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201699329


   --row number: 16976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188414 , [Content] ='Technical'
 WHERE id=201699330


   --row number: 16977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188414 , [Content] ='09/05/18'
 WHERE id=201699331


   --row number: 16978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188414 , [Content] ='S1414 CAN'
 WHERE id=201699313


   --row number: 16979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188414 , [Content] ='CAN'
 WHERE id=201699314


   --row number: 16980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188414 , [Content] ='AMS'
 WHERE id=201699315


   --row number: 16981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188414 , [Content] ='CANADA'
 WHERE id=201699316


   --row number: 16982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188414 , [Content] ='Solution Consulting'
 WHERE id=201699317


   --row number: 16983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188414 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=201699318


   --row number: 16984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188414 , [Content] ='Solution Consultant Core'
 WHERE id=201699319


   --row number: 16985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188414 , [Content] ='IC4'
 WHERE id=201699320


   --row number: 16986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188414 , [Content] ='CAD'
 WHERE id=201699322


   --row number: 16987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188414 , [Content] ='126,225 / 137,363 / 148,500 / 159,638 / 170,775'
 WHERE id=201699323


   --row number: 16988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188414 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=201699324


   --row number: 16989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188414 , [Content] ='168,300 / 183,150 / 198,000 / 212,850 / 227,700'
 WHERE id=201699325


   --row number: 16990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188539 , [Content] ='Yes'
 WHERE id=201711458


   --row number: 16991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188539 , [Content] ='EXEMPT'
 WHERE id=201711459


   --row number: 16992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188539 , [Content] ='NO'
 WHERE id=201711460


   --row number: 16993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188539 , [Content] ='4 - Sales Workers'
 WHERE id=201711461


   --row number: 16994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188539 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201711462


   --row number: 16995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188539 , [Content] ='Technical'
 WHERE id=201711463


   --row number: 16996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188539 , [Content] ='09/05/18'
 WHERE id=201711464


   --row number: 16997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188539 , [Content] ='S1414A US - MRKT 2'
 WHERE id=201711444


   --row number: 16998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188539 , [Content] ='US - MRKT 2'
 WHERE id=201711445


   --row number: 16999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188539 , [Content] ='AMS'
 WHERE id=201711446


   --row number: 17000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188539 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201711447


   --row number: 17001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188539 , [Content] ='Solution Consulting'
 WHERE id=201711448


   --row number: 17002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188539 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=201711449


   --row number: 17003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188539 , [Content] ='Solution Consultant Architect'
 WHERE id=201711450


   --row number: 17004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188539 , [Content] ='IC4'
 WHERE id=201711451


   --row number: 17005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188539 , [Content] ='USD'
 WHERE id=201711453


   --row number: 17006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188539 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=201711454


   --row number: 17007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188539 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=201711455


   --row number: 17008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188539 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=201711456


   --row number: 17009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3188539 , [Content] ='75/25'
 WHERE id=201711457


   --row number: 17010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188550 , [Content] ='Yes'
 WHERE id=201712849


   --row number: 17011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188550 , [Content] ='EXEMPT'
 WHERE id=201712850


   --row number: 17012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188550 , [Content] ='NO'
 WHERE id=201712851


   --row number: 17013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188550 , [Content] ='4 - Sales Workers'
 WHERE id=201712852


   --row number: 17014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188550 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201712853


   --row number: 17015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188550 , [Content] ='Technical'
 WHERE id=201712854


   --row number: 17016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188550 , [Content] ='09/05/18'
 WHERE id=201712855


   --row number: 17017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188550 , [Content] ='S665 US - MRKT 1'
 WHERE id=201712835


   --row number: 17018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188550 , [Content] ='US - MRKT 1'
 WHERE id=201712836


   --row number: 17019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188550 , [Content] ='AMS'
 WHERE id=201712837


   --row number: 17020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188550 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201712838


   --row number: 17021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188550 , [Content] ='Sales'
 WHERE id=201712839


   --row number: 17022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188550 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=201712840


   --row number: 17023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188550 , [Content] ='Product Line Sales'
 WHERE id=201712841


   --row number: 17024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188550 , [Content] ='IC5'
 WHERE id=201712842


   --row number: 17025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188550 , [Content] ='USD'
 WHERE id=201712844


   --row number: 17026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188550 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=201712845


   --row number: 17027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188550 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201712846


   --row number: 17028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188550 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=201712847


   --row number: 17029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3188550 , [Content] ='60/40'
 WHERE id=201712848


   --row number: 17030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188604 , [Content] ='Yes'
 WHERE id=201720123


   --row number: 17031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188604 , [Content] ='EXEMPT'
 WHERE id=201720124


   --row number: 17032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188604 , [Content] ='NO'
 WHERE id=201720125


   --row number: 17033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188604 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201720126


   --row number: 17034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188604 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201720127


   --row number: 17035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188604 , [Content] ='Technical'
 WHERE id=201720128


   --row number: 17036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188604 , [Content] ='09/05/18'
 WHERE id=201720129


   --row number: 17037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188604 , [Content] ='2545 US - MRKT 1'
 WHERE id=201720109


   --row number: 17038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188604 , [Content] ='US - MRKT 1'
 WHERE id=201720110


   --row number: 17039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188604 , [Content] ='AMS'
 WHERE id=201720111


   --row number: 17040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188604 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201720112


   --row number: 17041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188604 , [Content] ='Marketing'
 WHERE id=201720113


   --row number: 17042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188604 , [Content] ='2545 - Dir, Product Marketing Mgmt M5'
 WHERE id=201720114


   --row number: 17043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188604 , [Content] ='Product Marketing'
 WHERE id=201720115


   --row number: 17044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188604 , [Content] ='M5'
 WHERE id=201720116


   --row number: 17045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188604 , [Content] ='USD'
 WHERE id=201720118


   --row number: 17046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188604 , [Content] ='158,000 / 193,550 / 229,100 / 264,650 / 300,200'
 WHERE id=201720119


   --row number: 17047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188604 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=201720120


   --row number: 17048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188604 , [Content] ='197,500 / 241,950 / 286,400 / 330,850 / 375,300'
 WHERE id=201720121


   --row number: 17049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188604 , [Content] ='25%'
 WHERE id=201720122


   --row number: 17050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188614 , [Content] ='EXEMPT'
 WHERE id=201721319


   --row number: 17051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188655 , [Content] ='6593 US - MRKT 1'
 WHERE id=201725251


   --row number: 17052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188655 , [Content] ='US - MRKT 1'
 WHERE id=201725252


   --row number: 17053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188655 , [Content] ='AMS'
 WHERE id=201725253


   --row number: 17054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188655 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201725254


   --row number: 17055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188655 , [Content] ='Info Systems/Technology'
 WHERE id=201725255


   --row number: 17056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188655 , [Content] ='6593 - Sr Database Engineer IC3'
 WHERE id=201725256


   --row number: 17057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188655 , [Content] ='Database Engineer'
 WHERE id=201725257


   --row number: 17058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188655 , [Content] ='IC3'
 WHERE id=201725258


   --row number: 17059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188655 , [Content] ='USD'
 WHERE id=201725260


   --row number: 17060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188655 , [Content] ='103,100 / 121,650 / 140,200 / 158,750 / 177,300'
 WHERE id=201725261


   --row number: 17061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188655 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201725262


   --row number: 17062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188655 , [Content] ='118,600 / 139,900 / 161,200 / 182,550 / 203,900'
 WHERE id=201725263


   --row number: 17063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188655 , [Content] ='15%'
 WHERE id=201725264


   --row number: 17064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3188655 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=201725265


   --row number: 17065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188655 , [Content] ='Yes'
 WHERE id=201725266


   --row number: 17066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188655 , [Content] ='EXEMPT'
 WHERE id=201725267


   --row number: 17067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188655 , [Content] ='YES'
 WHERE id=201725268


   --row number: 17068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188655 , [Content] ='2 - Professionals'
 WHERE id=201725269


   --row number: 17069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188655 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201725270


   --row number: 17070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188655 , [Content] ='Technical'
 WHERE id=201725271


   --row number: 17071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188614 , [Content] ='NO'
 WHERE id=201721320


   --row number: 17072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188614 , [Content] ='2 - Professionals'
 WHERE id=201721321


   --row number: 17073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188614 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201721322


   --row number: 17074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188614 , [Content] ='09/05/18'
 WHERE id=201721323


   --row number: 17075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188614 , [Content] ='5526 US - MRKT 1'
 WHERE id=201721304


   --row number: 17076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188614 , [Content] ='US - MRKT 1'
 WHERE id=201721305


   --row number: 17077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188614 , [Content] ='AMS'
 WHERE id=201721306


   --row number: 17078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188614 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201721307


   --row number: 17079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188614 , [Content] ='Marketing'
 WHERE id=201721308


   --row number: 17080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188614 , [Content] ='5526 - Pricing Analyst IC6'
 WHERE id=201721309


   --row number: 17081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188614 , [Content] ='Pricing'
 WHERE id=201721310


   --row number: 17082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188614 , [Content] ='IC6'
 WHERE id=201721311


   --row number: 17083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188614 , [Content] ='USD'
 WHERE id=201721313


   --row number: 17084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188614 , [Content] ='130,300 / 159,650 / 189,000 / 218,300 / 247,600'
 WHERE id=201721314


   --row number: 17085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188614 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201721315


   --row number: 17086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188614 , [Content] ='162,900 / 199,600 / 236,300 / 272,900 / 309,500'
 WHERE id=201721316


   --row number: 17087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188614 , [Content] ='25%'
 WHERE id=201721317


   --row number: 17088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188614 , [Content] ='Yes'
 WHERE id=201721318


   --row number: 17089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188655 , [Content] ='09/05/18'
 WHERE id=201725272


   --row number: 17090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188668 , [Content] ='5144 US - MRKT 2'
 WHERE id=201726544


   --row number: 17091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188668 , [Content] ='US - MRKT 2'
 WHERE id=201726545


   --row number: 17092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188668 , [Content] ='AMS'
 WHERE id=201726546


   --row number: 17093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188668 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201726547


   --row number: 17094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188668 , [Content] ='Engineering'
 WHERE id=201726548


   --row number: 17095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188668 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=201726549


   --row number: 17096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188668 , [Content] ='Software'
 WHERE id=201726550


   --row number: 17097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188668 , [Content] ='IC4'
 WHERE id=201726551


   --row number: 17098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188668 , [Content] ='USD'
 WHERE id=201726553


   --row number: 17099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188668 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=201726554


   --row number: 17100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188668 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=201726555


   --row number: 17101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188668 , [Content] ='128,500 / 155,450 / 182,400 / 209,350 / 236,300'
 WHERE id=201726556


   --row number: 17102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188668 , [Content] ='20%'
 WHERE id=201726557


   --row number: 17103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188668 , [Content] ='Yes'
 WHERE id=201726558


   --row number: 17104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188668 , [Content] ='EXEMPT'
 WHERE id=201726559


   --row number: 17105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188668 , [Content] ='NO'
 WHERE id=201726560


   --row number: 17106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188668 , [Content] ='2 - Professionals'
 WHERE id=201726561


   --row number: 17107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188668 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201726562


   --row number: 17108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188668 , [Content] ='Technical'
 WHERE id=201726563


   --row number: 17109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188668 , [Content] ='10/05/18'
 WHERE id=201726564


   --row number: 17110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188672 , [Content] ='5673 US - MRKT 1'
 WHERE id=201727104


   --row number: 17111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188672 , [Content] ='US - MRKT 1'
 WHERE id=201727105


   --row number: 17112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188672 , [Content] ='AMS'
 WHERE id=201727106


   --row number: 17113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188672 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201727107


   --row number: 17114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188672 , [Content] ='Business Strategy'
 WHERE id=201727108


   --row number: 17115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188672 , [Content] ='5673 - Business Strategy Mgr IC3'
 WHERE id=201727109


   --row number: 17116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188672 , [Content] ='Business Strategy'
 WHERE id=201727110


   --row number: 17117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188672 , [Content] ='IC3'
 WHERE id=201727111


   --row number: 17118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188672 , [Content] ='USD'
 WHERE id=201727113


   --row number: 17119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188672 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=201727114


   --row number: 17120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188672 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201727115


   --row number: 17121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188672 , [Content] ='107,000 / 126,250 / 145,500 / 164,750 / 184,000'
 WHERE id=201727116


   --row number: 17122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188672 , [Content] ='15%'
 WHERE id=201727117


   --row number: 17123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188672 , [Content] ='Yes'
 WHERE id=201727118


   --row number: 17124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188672 , [Content] ='EXEMPT'
 WHERE id=201727119


   --row number: 17125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188672 , [Content] ='NO'
 WHERE id=201727120


   --row number: 17126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188672 , [Content] ='2 - Professionals'
 WHERE id=201727121


   --row number: 17127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188672 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201727122


   --row number: 17128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188672 , [Content] ='Non Technical'
 WHERE id=201727123


   --row number: 17129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188672 , [Content] ='09/05/18'
 WHERE id=201727124


   --row number: 17130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188675 , [Content] ='5145 US - MRKT 2'
 WHERE id=201727510


   --row number: 17131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188675 , [Content] ='US - MRKT 2'
 WHERE id=201727511


   --row number: 17132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188675 , [Content] ='AMS'
 WHERE id=201727512


   --row number: 17133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188675 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201727513


   --row number: 17134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188675 , [Content] ='Engineering'
 WHERE id=201727514


   --row number: 17135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188675 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=201727515


   --row number: 17136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188675 , [Content] ='Software'
 WHERE id=201727516


   --row number: 17137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188675 , [Content] ='IC5'
 WHERE id=201727517


   --row number: 17138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188675 , [Content] ='USD'
 WHERE id=201727519


   --row number: 17139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188675 , [Content] ='123,400 / 151,200 / 179,000 / 206,750 / 234,500'
 WHERE id=201727520


   --row number: 17140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188675 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=201727521


   --row number: 17141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188675 , [Content] ='154,300 / 189,050 / 223,800 / 258,450 / 293,100'
 WHERE id=201727522


   --row number: 17142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188675 , [Content] ='25%'
 WHERE id=201727523


   --row number: 17143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188675 , [Content] ='Yes'
 WHERE id=201727524


   --row number: 17144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188675 , [Content] ='EXEMPT'
 WHERE id=201727525


   --row number: 17145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188675 , [Content] ='NO'
 WHERE id=201727526


   --row number: 17146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188675 , [Content] ='2 - Professionals'
 WHERE id=201727527


   --row number: 17147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188675 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201727528


   --row number: 17148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188675 , [Content] ='Technical'
 WHERE id=201727529


   --row number: 17149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188675 , [Content] ='09/05/18'
 WHERE id=201727530


   --row number: 17150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188679 , [Content] ='5526 US - MRKT 1'
 WHERE id=201727912


   --row number: 17151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188679 , [Content] ='US - MRKT 1'
 WHERE id=201727913


   --row number: 17152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188679 , [Content] ='AMS'
 WHERE id=201727914


   --row number: 17153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188679 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201727915


   --row number: 17154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188679 , [Content] ='Marketing'
 WHERE id=201727916


   --row number: 17155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188679 , [Content] ='5526 - Pricing Analyst IC6'
 WHERE id=201727917


   --row number: 17156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188679 , [Content] ='Pricing'
 WHERE id=201727918


   --row number: 17157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188679 , [Content] ='IC6'
 WHERE id=201727919


   --row number: 17158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188679 , [Content] ='USD'
 WHERE id=201727921


   --row number: 17159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188679 , [Content] ='130,300 / 159,650 / 189,000 / 218,300 / 247,600'
 WHERE id=201727922


   --row number: 17160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188679 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201727923


   --row number: 17161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188679 , [Content] ='162,900 / 199,600 / 236,300 / 272,900 / 309,500'
 WHERE id=201727924


   --row number: 17162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188679 , [Content] ='25%'
 WHERE id=201727925


   --row number: 17163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188679 , [Content] ='Yes'
 WHERE id=201727926


   --row number: 17164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188679 , [Content] ='EXEMPT'
 WHERE id=201727927


   --row number: 17165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188679 , [Content] ='NO'
 WHERE id=201727928


   --row number: 17166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188679 , [Content] ='2 - Professionals'
 WHERE id=201727929


   --row number: 17167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188679 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201727930


   --row number: 17168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188679 , [Content] ='09/05/18'
 WHERE id=201727931


   --row number: 17169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188699 , [Content] ='2696 US - MRKT 1'
 WHERE id=201729597


   --row number: 17170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188699 , [Content] ='US - MRKT 1'
 WHERE id=201729598


   --row number: 17171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188699 , [Content] ='AMS'
 WHERE id=201729599


   --row number: 17172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188699 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201729600


   --row number: 17173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188699 , [Content] ='Marketing'
 WHERE id=201729601


   --row number: 17174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188699 , [Content] ='2696 - Sr Dir, Pricing Mgmt M6'
 WHERE id=201729602


   --row number: 17175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188699 , [Content] ='Pricing'
 WHERE id=201729603


   --row number: 17176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188699 , [Content] ='M6'
 WHERE id=201729604


   --row number: 17177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188699 , [Content] ='USD'
 WHERE id=201729606


   --row number: 17178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188699 , [Content] ='143,400 / 175,700 / 208,000 / 240,250 / 272,500'
 WHERE id=201729607


   --row number: 17179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188699 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=201729608


   --row number: 17180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188699 , [Content] ='186,400 / 228,400 / 270,400 / 312,350 / 354,300'
 WHERE id=201729609


   --row number: 17181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188699 , [Content] ='30%'
 WHERE id=201729610


   --row number: 17182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188699 , [Content] ='Yes'
 WHERE id=201729611


   --row number: 17183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188699 , [Content] ='EXEMPT'
 WHERE id=201729612


   --row number: 17184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188699 , [Content] ='NO'
 WHERE id=201729613


   --row number: 17185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188699 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201729614


   --row number: 17186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188699 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201729615


   --row number: 17187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188699 , [Content] ='09/05/18'
 WHERE id=201729616


   --row number: 17188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188716 , [Content] ='2696 US - MRKT 1'
 WHERE id=201730964


   --row number: 17189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188716 , [Content] ='US - MRKT 1'
 WHERE id=201730965


   --row number: 17190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188716 , [Content] ='AMS'
 WHERE id=201730966


   --row number: 17191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188716 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201730967


   --row number: 17192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188716 , [Content] ='Marketing'
 WHERE id=201730968


   --row number: 17193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188716 , [Content] ='2696 - Sr Dir, Pricing Mgmt M6'
 WHERE id=201730969


   --row number: 17194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188716 , [Content] ='Pricing'
 WHERE id=201730970


   --row number: 17195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188716 , [Content] ='M6'
 WHERE id=201730971


   --row number: 17196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188716 , [Content] ='USD'
 WHERE id=201730973


   --row number: 17197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188716 , [Content] ='143,400 / 175,700 / 208,000 / 240,250 / 272,500'
 WHERE id=201730974


   --row number: 17198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188716 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=201730975


   --row number: 17199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188716 , [Content] ='186,400 / 228,400 / 270,400 / 312,350 / 354,300'
 WHERE id=201730976


   --row number: 17200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188716 , [Content] ='30%'
 WHERE id=201730977


   --row number: 17201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188716 , [Content] ='Yes'
 WHERE id=201730978


   --row number: 17202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188716 , [Content] ='EXEMPT'
 WHERE id=201730979


   --row number: 17203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188716 , [Content] ='NO'
 WHERE id=201730980


   --row number: 17204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188716 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201730981


   --row number: 17205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188716 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201730982


   --row number: 17206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188716 , [Content] ='09/05/18'
 WHERE id=201730983


   --row number: 17207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188756 , [Content] ='6014 US - MRKT 1'
 WHERE id=201733210


   --row number: 17208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188756 , [Content] ='US - MRKT 1'
 WHERE id=201733211


   --row number: 17209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188756 , [Content] ='AMS'
 WHERE id=201733212


   --row number: 17210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188756 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201733213


   --row number: 17211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188756 , [Content] ='Business Strategy'
 WHERE id=201733214


   --row number: 17212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188756 , [Content] ='6014 - Business Analytics IC4'
 WHERE id=201733215


   --row number: 17213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188756 , [Content] ='Business Analytics'
 WHERE id=201733216


   --row number: 17214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188756 , [Content] ='IC4'
 WHERE id=201733217


   --row number: 17215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188756 , [Content] ='USD'
 WHERE id=201733219


   --row number: 17216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188756 , [Content] ='103,900 / 122,600 / 141,300 / 160,000 / 178,700'
 WHERE id=201733220


   --row number: 17217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188756 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201733221


   --row number: 17218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188756 , [Content] ='119,500 / 141,000 / 162,500 / 184,000 / 205,500'
 WHERE id=201733222


   --row number: 17219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188756 , [Content] ='15%'
 WHERE id=201733223


   --row number: 17220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188756 , [Content] ='Yes'
 WHERE id=201733224


   --row number: 17221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188756 , [Content] ='EXEMPT'
 WHERE id=201733225


   --row number: 17222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188756 , [Content] ='NO'
 WHERE id=201733226


   --row number: 17223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188756 , [Content] ='2 - Professionals'
 WHERE id=201733227


   --row number: 17224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188756 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201733228


   --row number: 17225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188756 , [Content] ='Non Technical'
 WHERE id=201733229


   --row number: 17226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188756 , [Content] ='09/05/18'
 WHERE id=201733230


   --row number: 17227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188872 , [Content] ='6654 US - MRKT 1'
 WHERE id=201742877


   --row number: 17228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188872 , [Content] ='US - MRKT 1'
 WHERE id=201742878


   --row number: 17229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188872 , [Content] ='AMS'
 WHERE id=201742879


   --row number: 17230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188872 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201742880


   --row number: 17231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188872 , [Content] ='Info Systems/Technology'
 WHERE id=201742881


   --row number: 17232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188872 , [Content] ='6654 - Enterprisewide Applications Analyst IC4'
 WHERE id=201742882


   --row number: 17233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188872 , [Content] ='Enterprise Applications'
 WHERE id=201742883


   --row number: 17234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188872 , [Content] ='IC4'
 WHERE id=201742884


   --row number: 17235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188872 , [Content] ='USD'
 WHERE id=201742886


   --row number: 17236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188872 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201742887


   --row number: 17237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188872 , [Content] ='15%'
 WHERE id=201742888


   --row number: 17238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=3188872 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=201742889


   --row number: 17239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188872 , [Content] ='Yes'
 WHERE id=201742890


   --row number: 17240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188872 , [Content] ='EXEMPT'
 WHERE id=201742891


   --row number: 17241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188872 , [Content] ='YES'
 WHERE id=201742892


   --row number: 17242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188872 , [Content] ='2 - Professionals'
 WHERE id=201742893


   --row number: 17243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188872 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201742894


   --row number: 17244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188872 , [Content] ='Technical'
 WHERE id=201742895


   --row number: 17245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188872 , [Content] ='09/05/18'
 WHERE id=201742896


   --row number: 17246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188875 , [Content] ='5375 US - MRKT 1'
 WHERE id=201743071


   --row number: 17247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188875 , [Content] ='US - MRKT 1'
 WHERE id=201743072


   --row number: 17248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188875 , [Content] ='AMS'
 WHERE id=201743073


   --row number: 17249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188875 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201743074


   --row number: 17250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188875 , [Content] ='Engineering'
 WHERE id=201743075


   --row number: 17251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188875 , [Content] ='5375 - Project (Design) Manager IC5'
 WHERE id=201743076


   --row number: 17252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188875 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=201743077


   --row number: 17253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188875 , [Content] ='IC5'
 WHERE id=201743078


   --row number: 17254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188875 , [Content] ='USD'
 WHERE id=201743080


   --row number: 17255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188875 , [Content] ='132,200 / 161,950 / 191,700 / 221,450 / 251,200'
 WHERE id=201743081


   --row number: 17256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188875 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201743082


   --row number: 17257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188875 , [Content] ='165,300 / 202,450 / 239,600 / 276,800 / 314,000'
 WHERE id=201743083


   --row number: 17258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188875 , [Content] ='25%'
 WHERE id=201743084


   --row number: 17259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188875 , [Content] ='Yes'
 WHERE id=201743085


   --row number: 17260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188875 , [Content] ='EXEMPT'
 WHERE id=201743086


   --row number: 17261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188875 , [Content] ='NO'
 WHERE id=201743087


   --row number: 17262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188875 , [Content] ='2 - Professionals'
 WHERE id=201743088


   --row number: 17263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188875 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201743089


   --row number: 17264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188875 , [Content] ='Technical'
 WHERE id=201743090


   --row number: 17265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188875 , [Content] ='09/05/18'
 WHERE id=201743091


   --row number: 17266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3188880 , [Content] ='5593 US - MRKT 1'
 WHERE id=201743418


   --row number: 17267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3188880 , [Content] ='US - MRKT 1'
 WHERE id=201743419


   --row number: 17268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3188880 , [Content] ='AMS'
 WHERE id=201743420


   --row number: 17269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3188880 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201743421


   --row number: 17270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3188880 , [Content] ='Marketing'
 WHERE id=201743422


   --row number: 17271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3188880 , [Content] ='5593 - Product Marketing Mgr IC3'
 WHERE id=201743423


   --row number: 17272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3188880 , [Content] ='Product Marketing'
 WHERE id=201743424


   --row number: 17273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3188880 , [Content] ='IC3'
 WHERE id=201743425


   --row number: 17274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3188880 , [Content] ='USD'
 WHERE id=201743427


   --row number: 17275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3188880 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=201743428


   --row number: 17276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3188880 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201743429


   --row number: 17277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3188880 , [Content] ='107,000 / 126,250 / 145,500 / 164,750 / 184,000'
 WHERE id=201743430


   --row number: 17278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3188880 , [Content] ='15%'
 WHERE id=201743431


   --row number: 17279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3188880 , [Content] ='Yes'
 WHERE id=201743432


   --row number: 17280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3188880 , [Content] ='EXEMPT'
 WHERE id=201743433


   --row number: 17281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3188880 , [Content] ='NO'
 WHERE id=201743434


   --row number: 17282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3188880 , [Content] ='2 - Professionals'
 WHERE id=201743435


   --row number: 17283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3188880 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201743436


   --row number: 17284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3188880 , [Content] ='Technical'
 WHERE id=201743437


   --row number: 17285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3188880 , [Content] ='09/05/18'
 WHERE id=201743438


   --row number: 17286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189074 , [Content] ='5226 US - MRKT 1'
 WHERE id=201762405


   --row number: 17287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189074 , [Content] ='US - MRKT 1'
 WHERE id=201762406


   --row number: 17288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189074 , [Content] ='AMS'
 WHERE id=201762407


   --row number: 17289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189074 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201762408


   --row number: 17290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189074 , [Content] ='Engineering'
 WHERE id=201762409


   --row number: 17291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189074 , [Content] ='5226 - Principal Product Mgmt Mgr IC6'
 WHERE id=201762410


   --row number: 17292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189074 , [Content] ='Product Mgmt Mgr'
 WHERE id=201762411


   --row number: 17293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189074 , [Content] ='IC6'
 WHERE id=201762412


   --row number: 17294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189074 , [Content] ='USD'
 WHERE id=201762414


   --row number: 17295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189074 , [Content] ='142,400 / 174,450 / 206,500 / 238,550 / 270,600'
 WHERE id=201762415


   --row number: 17296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189074 , [Content] ='312,000 / 468,000 / 624,000 / 780,000 / 936,000'
 WHERE id=201762416


   --row number: 17297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189074 , [Content] ='178,000 / 218,050 / 258,100 / 298,200 / 338,300'
 WHERE id=201762417


   --row number: 17298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189074 , [Content] ='25%'
 WHERE id=201762418


   --row number: 17299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189074 , [Content] ='Yes'
 WHERE id=201762419


   --row number: 17300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189074 , [Content] ='EXEMPT'
 WHERE id=201762420


   --row number: 17301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189074 , [Content] ='NO'
 WHERE id=201762421


   --row number: 17302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189074 , [Content] ='2 - Professionals'
 WHERE id=201762422


   --row number: 17303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189074 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201762423


   --row number: 17304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189074 , [Content] ='Technical'
 WHERE id=201762424


   --row number: 17305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189074 , [Content] ='09/05/18'
 WHERE id=201762425


   --row number: 17306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189082 , [Content] ='2245 US - MRKT 1'
 WHERE id=201763235


   --row number: 17307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189082 , [Content] ='US - MRKT 1'
 WHERE id=201763236


   --row number: 17308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189082 , [Content] ='AMS'
 WHERE id=201763237


   --row number: 17309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189082 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201763238


   --row number: 17310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189082 , [Content] ='Engineering'
 WHERE id=201763239


   --row number: 17311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189082 , [Content] ='2245 - Dir, Product Mgmt M5'
 WHERE id=201763240


   --row number: 17312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189082 , [Content] ='Product Mgmt Mgr'
 WHERE id=201763241


   --row number: 17313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189082 , [Content] ='M5'
 WHERE id=201763242


   --row number: 17314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189082 , [Content] ='USD'
 WHERE id=201763244


   --row number: 17315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189082 , [Content] ='149,300 / 182,900 / 216,500 / 250,100 / 283,700'
 WHERE id=201763245


   --row number: 17316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189082 , [Content] ='312,000 / 468,000 / 624,000 / 780,000 / 936,000'
 WHERE id=201763246


   --row number: 17317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189082 , [Content] ='186,600 / 228,600 / 270,600 / 312,600 / 354,600'
 WHERE id=201763247


   --row number: 17318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189082 , [Content] ='25%'
 WHERE id=201763248


   --row number: 17319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189082 , [Content] ='Yes'
 WHERE id=201763249


   --row number: 17320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189082 , [Content] ='EXEMPT'
 WHERE id=201763250


   --row number: 17321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189082 , [Content] ='NO'
 WHERE id=201763251


   --row number: 17322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189082 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201763252


   --row number: 17323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189082 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201763253


   --row number: 17324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189082 , [Content] ='Technical'
 WHERE id=201763254


   --row number: 17325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189082 , [Content] ='09/05/18'
 WHERE id=201763255


   --row number: 17326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189202 , [Content] ='4684 US - MRKT 2'
 WHERE id=201780833


   --row number: 17327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189202 , [Content] ='US - MRKT 2'
 WHERE id=201780834


   --row number: 17328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189202 , [Content] ='AMS'
 WHERE id=201780835


   --row number: 17329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189202 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201780836


   --row number: 17330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189202 , [Content] ='Business Strategy'
 WHERE id=201780837


   --row number: 17331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189202 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=201780838


   --row number: 17332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189202 , [Content] ='Business Process'
 WHERE id=201780839


   --row number: 17333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189202 , [Content] ='IC4'
 WHERE id=201780840


   --row number: 17334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189202 , [Content] ='USD'
 WHERE id=201780842


   --row number: 17335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189202 , [Content] ='87,300 / 103,000 / 118,700 / 134,450 / 150,200'
 WHERE id=201780843


   --row number: 17336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189202 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201780844


   --row number: 17337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189202 , [Content] ='100,400 / 118,450 / 136,500 / 154,600 / 172,700'
 WHERE id=201780845


   --row number: 17338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189202 , [Content] ='15%'
 WHERE id=201780846


   --row number: 17339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189202 , [Content] ='Yes'
 WHERE id=201780847


   --row number: 17340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189202 , [Content] ='EXEMPT'
 WHERE id=201780848


   --row number: 17341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189202 , [Content] ='NO'
 WHERE id=201780849


   --row number: 17342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189202 , [Content] ='2 - Professionals'
 WHERE id=201780850


   --row number: 17343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189202 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201780851


   --row number: 17344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189202 , [Content] ='Technical'
 WHERE id=201780852


   --row number: 17345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189202 , [Content] ='09/05/18'
 WHERE id=201780853


   --row number: 17346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189204 , [Content] ='4684 US - MRKT 2'
 WHERE id=201781114


   --row number: 17347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189204 , [Content] ='US - MRKT 2'
 WHERE id=201781115


   --row number: 17348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189204 , [Content] ='AMS'
 WHERE id=201781116


   --row number: 17349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189204 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201781117


   --row number: 17350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189204 , [Content] ='Business Strategy'
 WHERE id=201781118


   --row number: 17351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189204 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=201781119


   --row number: 17352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189204 , [Content] ='Business Process'
 WHERE id=201781120


   --row number: 17353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189204 , [Content] ='IC4'
 WHERE id=201781121


   --row number: 17354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189204 , [Content] ='USD'
 WHERE id=201781123


   --row number: 17355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189204 , [Content] ='87,300 / 103,000 / 118,700 / 134,450 / 150,200'
 WHERE id=201781124


   --row number: 17356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189204 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201781125


   --row number: 17357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189204 , [Content] ='100,400 / 118,450 / 136,500 / 154,600 / 172,700'
 WHERE id=201781126


   --row number: 17358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189204 , [Content] ='15%'
 WHERE id=201781127


   --row number: 17359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189204 , [Content] ='Yes'
 WHERE id=201781128


   --row number: 17360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189204 , [Content] ='EXEMPT'
 WHERE id=201781129


   --row number: 17361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189204 , [Content] ='NO'
 WHERE id=201781130


   --row number: 17362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189204 , [Content] ='2 - Professionals'
 WHERE id=201781131


   --row number: 17363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189204 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201781132


   --row number: 17364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189204 , [Content] ='Technical'
 WHERE id=201781133


   --row number: 17365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189204 , [Content] ='09/05/18'
 WHERE id=201781134


   --row number: 17366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189214 , [Content] ='5812 US - MRKT 3'
 WHERE id=201782840


   --row number: 17367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189214 , [Content] ='US - MRKT 3'
 WHERE id=201782841


   --row number: 17368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189214 , [Content] ='AMS'
 WHERE id=201782842


   --row number: 17369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189214 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201782843


   --row number: 17370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189214 , [Content] ='Customer Support'
 WHERE id=201782844


   --row number: 17371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189214 , [Content] ='5812 - Customer Support Rep IC2'
 WHERE id=201782845


   --row number: 17372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189214 , [Content] ='Customer Support'
 WHERE id=201782846


   --row number: 17373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189214 , [Content] ='IC2'
 WHERE id=201782847


   --row number: 17374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189214 , [Content] ='USD'
 WHERE id=201782849


   --row number: 17375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189214 , [Content] ='45,100 / 51,200 / 57,300 / 63,450 / 69,600'
 WHERE id=201782850


   --row number: 17376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189214 , [Content] ='49,600 / 56,300 / 63,000 / 69,800 / 76,600'
 WHERE id=201782851


   --row number: 17377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189214 , [Content] ='10%'
 WHERE id=201782852


   --row number: 17378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189214 , [Content] ='No'
 WHERE id=201782853


   --row number: 17379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189214 , [Content] ='NON-EXEMPT'
 WHERE id=201782854


   --row number: 17380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189214 , [Content] ='2 - Professionals'
 WHERE id=201782855


   --row number: 17381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189214 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201782856


   --row number: 17382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189214 , [Content] ='Technical'
 WHERE id=201782857


   --row number: 17383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189214 , [Content] ='09/05/18'
 WHERE id=201782858


   --row number: 17384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189215 , [Content] ='5812 US - MRKT 3'
 WHERE id=201782961


   --row number: 17385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189215 , [Content] ='US - MRKT 3'
 WHERE id=201782962


   --row number: 17386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189215 , [Content] ='AMS'
 WHERE id=201782963


   --row number: 17387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189215 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201782964


   --row number: 17388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189215 , [Content] ='Customer Support'
 WHERE id=201782965


   --row number: 17389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189215 , [Content] ='5812 - Customer Support Rep IC2'
 WHERE id=201782966


   --row number: 17390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189215 , [Content] ='Customer Support'
 WHERE id=201782967


   --row number: 17391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189215 , [Content] ='IC2'
 WHERE id=201782968


   --row number: 17392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189215 , [Content] ='USD'
 WHERE id=201782970


   --row number: 17393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189215 , [Content] ='45,100 / 51,200 / 57,300 / 63,450 / 69,600'
 WHERE id=201782971


   --row number: 17394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189215 , [Content] ='49,600 / 56,300 / 63,000 / 69,800 / 76,600'
 WHERE id=201782972


   --row number: 17395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189215 , [Content] ='10%'
 WHERE id=201782973


   --row number: 17396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189215 , [Content] ='No'
 WHERE id=201782974


   --row number: 17397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189215 , [Content] ='NON-EXEMPT'
 WHERE id=201782975


   --row number: 17398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189215 , [Content] ='2 - Professionals'
 WHERE id=201782976


   --row number: 17399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189215 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201782977


   --row number: 17400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189215 , [Content] ='Technical'
 WHERE id=201782978


   --row number: 17401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189215 , [Content] ='09/05/18'
 WHERE id=201782979


   --row number: 17402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189219 , [Content] ='2816 US - MRKT 1'
 WHERE id=201783784


   --row number: 17403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189219 , [Content] ='US - MRKT 1'
 WHERE id=201783785


   --row number: 17404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189219 , [Content] ='AMS'
 WHERE id=201783786


   --row number: 17405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189219 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201783787


   --row number: 17406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189219 , [Content] ='Customer Support'
 WHERE id=201783788


   --row number: 17407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189219 , [Content] ='2816 - Sr Dir, Customer Support Mgmt M6'
 WHERE id=201783789


   --row number: 17408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189219 , [Content] ='Customer Support'
 WHERE id=201783790


   --row number: 17409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189219 , [Content] ='M6'
 WHERE id=201783791


   --row number: 17410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189219 , [Content] ='USD'
 WHERE id=201783793


   --row number: 17411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189219 , [Content] ='150,800 / 184,700 / 218,600 / 252,550 / 286,500'
 WHERE id=201783794


   --row number: 17412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189219 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=201783795


   --row number: 17413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189219 , [Content] ='30%'
 WHERE id=201783797


   --row number: 17414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189219 , [Content] ='Yes'
 WHERE id=201783798


   --row number: 17415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189219 , [Content] ='EXEMPT'
 WHERE id=201783799


   --row number: 17416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189219 , [Content] ='NO'
 WHERE id=201783800


   --row number: 17417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189219 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201783801


   --row number: 17418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189219 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201783802


   --row number: 17419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189219 , [Content] ='Technical'
 WHERE id=201783803


   --row number: 17420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189219 , [Content] ='10/24/2018'
 WHERE id=201783804


   --row number: 17421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189222 , [Content] ='5143 US - MRKT 1'
 WHERE id=201784312


   --row number: 17422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189222 , [Content] ='US - MRKT 1'
 WHERE id=201784313


   --row number: 17423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189222 , [Content] ='AMS'
 WHERE id=201784314


   --row number: 17424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189222 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201784315


   --row number: 17425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189222 , [Content] ='Engineering'
 WHERE id=201784316


   --row number: 17426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189222 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201784317


   --row number: 17427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189222 , [Content] ='Software'
 WHERE id=201784318


   --row number: 17428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189222 , [Content] ='IC3'
 WHERE id=201784319


   --row number: 17429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189222 , [Content] ='USD'
 WHERE id=201784321


   --row number: 17430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189222 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=201784322


   --row number: 17431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189222 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201784323


   --row number: 17432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189222 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=201784324


   --row number: 17433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189222 , [Content] ='15%'
 WHERE id=201784325


   --row number: 17434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189222 , [Content] ='Yes'
 WHERE id=201784326


   --row number: 17435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189222 , [Content] ='EXEMPT'
 WHERE id=201784327


   --row number: 17436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189222 , [Content] ='NO'
 WHERE id=201784328


   --row number: 17437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189222 , [Content] ='2 - Professionals'
 WHERE id=201784329


   --row number: 17438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189222 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201784330


   --row number: 17439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189222 , [Content] ='Technical'
 WHERE id=201784331


   --row number: 17440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189222 , [Content] ='09/05/18'
 WHERE id=201784332


   --row number: 17441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189224 , [Content] ='5143 US - MRKT 1'
 WHERE id=201784793


   --row number: 17442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189224 , [Content] ='US - MRKT 1'
 WHERE id=201784794


   --row number: 17443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189224 , [Content] ='AMS'
 WHERE id=201784795


   --row number: 17444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189224 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201784796


   --row number: 17445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189224 , [Content] ='Engineering'
 WHERE id=201784797


   --row number: 17446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189224 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201784798


   --row number: 17447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189224 , [Content] ='Software'
 WHERE id=201784799


   --row number: 17448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189224 , [Content] ='IC3'
 WHERE id=201784800


   --row number: 17449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189224 , [Content] ='USD'
 WHERE id=201784802


   --row number: 17450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189224 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=201784803


   --row number: 17451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189224 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201784804


   --row number: 17452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189224 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=201784805


   --row number: 17453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189224 , [Content] ='15%'
 WHERE id=201784806


   --row number: 17454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189224 , [Content] ='Yes'
 WHERE id=201784807


   --row number: 17455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189224 , [Content] ='EXEMPT'
 WHERE id=201784808


   --row number: 17456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189224 , [Content] ='NO'
 WHERE id=201784809


   --row number: 17457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189224 , [Content] ='2 - Professionals'
 WHERE id=201784810


   --row number: 17458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189224 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201784811


   --row number: 17459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189224 , [Content] ='Technical'
 WHERE id=201784812


   --row number: 17460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189224 , [Content] ='09/05/18'
 WHERE id=201784813


   --row number: 17461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189227 , [Content] ='5464 US - MRKT 1'
 WHERE id=201785523


   --row number: 17462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189227 , [Content] ='US - MRKT 1'
 WHERE id=201785524


   --row number: 17463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189227 , [Content] ='AMS'
 WHERE id=201785525


   --row number: 17464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189227 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201785526


   --row number: 17465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189227 , [Content] ='Marketing'
 WHERE id=201785527


   --row number: 17466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189227 , [Content] ='5464 - Product Portfolio Mgr IC4'
 WHERE id=201785528


   --row number: 17467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189227 , [Content] ='Product Mgrs'
 WHERE id=201785529


   --row number: 17468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189227 , [Content] ='IC4'
 WHERE id=201785530


   --row number: 17469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189227 , [Content] ='USD'
 WHERE id=201785532


   --row number: 17470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189227 , [Content] ='113,300 / 137,050 / 160,800 / 184,550 / 208,300'
 WHERE id=201785533


   --row number: 17471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189227 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=201785534


   --row number: 17472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189227 , [Content] ='136,000 / 164,500 / 193,000 / 221,500 / 250,000'
 WHERE id=201785535


   --row number: 17473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189227 , [Content] ='20%'
 WHERE id=201785536


   --row number: 17474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189227 , [Content] ='Yes'
 WHERE id=201785537


   --row number: 17475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189227 , [Content] ='EXEMPT'
 WHERE id=201785538


   --row number: 17476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189227 , [Content] ='NO'
 WHERE id=201785539


   --row number: 17477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189227 , [Content] ='2 - Professionals'
 WHERE id=201785540


   --row number: 17478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189227 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201785541


   --row number: 17479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189227 , [Content] ='Technical'
 WHERE id=201785542


   --row number: 17480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189227 , [Content] ='09/05/18'
 WHERE id=201785543


   --row number: 17481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189271 , [Content] ='3075 US - MRKT 1'
 WHERE id=201796775


   --row number: 17482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189271 , [Content] ='US - MRKT 1'
 WHERE id=201796776


   --row number: 17483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189271 , [Content] ='AMS'
 WHERE id=201796777


   --row number: 17484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189271 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201796778


   --row number: 17485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189271 , [Content] ='Finance'
 WHERE id=201796779


   --row number: 17486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189271 , [Content] ='3075 - Dir, Investor Relations Mgmt M5'
 WHERE id=201796780


   --row number: 17487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189271 , [Content] ='Investor Relations'
 WHERE id=201796781


   --row number: 17488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189271 , [Content] ='M5'
 WHERE id=201796782


   --row number: 17489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189271 , [Content] ='USD'
 WHERE id=201796784


   --row number: 17490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189271 , [Content] ='144,800 / 177,400 / 210,000 / 242,550 / 275,100'
 WHERE id=201796785


   --row number: 17491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189271 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=201796786


   --row number: 17492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189271 , [Content] ='181,000 / 221,750 / 262,500 / 303,200 / 343,900'
 WHERE id=201796787


   --row number: 17493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189271 , [Content] ='25%'
 WHERE id=201796788


   --row number: 17494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189271 , [Content] ='Yes'
 WHERE id=201796789


   --row number: 17495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189271 , [Content] ='EXEMPT'
 WHERE id=201796790


   --row number: 17496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189271 , [Content] ='NO'
 WHERE id=201796791


   --row number: 17497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189271 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201796792


   --row number: 17498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189271 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201796793


   --row number: 17499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189271 , [Content] ='Non Technical'
 WHERE id=201796794


   --row number: 17500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189271 , [Content] ='09/05/18'
 WHERE id=201796795


   --row number: 17501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189275 , [Content] ='6625 US - MRKT 1'
 WHERE id=201797417


   --row number: 17502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189275 , [Content] ='US - MRKT 1'
 WHERE id=201797418


   --row number: 17503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189275 , [Content] ='AMS'
 WHERE id=201797419


   --row number: 17504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189275 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201797420


   --row number: 17505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189275 , [Content] ='Info Systems/Technology'
 WHERE id=201797421


   --row number: 17506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189275 , [Content] ='6625 - Project (Information Systems) Mgr IC5'
 WHERE id=201797422


   --row number: 17507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189275 , [Content] ='IT Project/Program Mgrs'
 WHERE id=201797423


   --row number: 17508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189275 , [Content] ='IC5'
 WHERE id=201797424


   --row number: 17509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189275 , [Content] ='USD'
 WHERE id=201797426


   --row number: 17510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189275 , [Content] ='116,200 / 142,350 / 168,500 / 194,650 / 220,800'
 WHERE id=201797427


   --row number: 17511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189275 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201797428


   --row number: 17512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189275 , [Content] ='145,300 / 177,950 / 210,600 / 243,300 / 276,000'
 WHERE id=201797429


   --row number: 17513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189275 , [Content] ='25%'
 WHERE id=201797430


   --row number: 17514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189275 , [Content] ='Yes'
 WHERE id=201797431


   --row number: 17515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189275 , [Content] ='EXEMPT'
 WHERE id=201797432


   --row number: 17516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189275 , [Content] ='NO'
 WHERE id=201797433


   --row number: 17517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189275 , [Content] ='2 - Professionals'
 WHERE id=201797434


   --row number: 17518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189275 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201797435


   --row number: 17519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189275 , [Content] ='Technical'
 WHERE id=201797436


   --row number: 17520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189275 , [Content] ='09/05/18'
 WHERE id=201797437


   --row number: 17521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189467 , [Content] ='S1806 SGP'
 WHERE id=201840087


   --row number: 17522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189467 , [Content] ='SGP'
 WHERE id=201840088


   --row number: 17523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189467 , [Content] ='APAC'
 WHERE id=201840089


   --row number: 17524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189467 , [Content] ='SINGAPORE'
 WHERE id=201840090


   --row number: 17525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189467 , [Content] ='Sales Operations'
 WHERE id=201840091


   --row number: 17526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189467 , [Content] ='S1806 - Sr Dir, Sales Operations Mgmt M6'
 WHERE id=201840092


   --row number: 17527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189467 , [Content] ='Sales Operations'
 WHERE id=201840093


   --row number: 17528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189467 , [Content] ='M6'
 WHERE id=201840094


   --row number: 17529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189467 , [Content] ='SGD'
 WHERE id=201840096


   --row number: 17530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189467 , [Content] ='205,000 / 251,150 / 297,300 / 343,400 / 389,500'
 WHERE id=201840097


   --row number: 17531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189467 , [Content] ='240,000 / 360,000 / 480,000 / 600,000 / 720,000'
 WHERE id=201840098


   --row number: 17532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189467 , [Content] ='266,500 / 326,500 / 386,500 / 446,450 / 506,400'
 WHERE id=201840099


   --row number: 17533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189467 , [Content] ='30%'
 WHERE id=201840100


   --row number: 17534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189467 , [Content] ='Yes'
 WHERE id=201840101


   --row number: 17535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189467 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201840102


   --row number: 17536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189467 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201840103


   --row number: 17537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189467 , [Content] ='Technical'
 WHERE id=201840104


   --row number: 17538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189467 , [Content] ='09/05/18'
 WHERE id=201840105


   --row number: 17539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189580 , [Content] ='5142 IND'
 WHERE id=201849819


   --row number: 17540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189580 , [Content] ='IND'
 WHERE id=201849820


   --row number: 17541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189580 , [Content] ='APAC'
 WHERE id=201849821


   --row number: 17542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189580 , [Content] ='INDIA'
 WHERE id=201849822


   --row number: 17543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189580 , [Content] ='Engineering'
 WHERE id=201849823


   --row number: 17544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189580 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=201849824


   --row number: 17545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189580 , [Content] ='Software'
 WHERE id=201849825


   --row number: 17546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189580 , [Content] ='IC2'
 WHERE id=201849826


   --row number: 17547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189580 , [Content] ='INR'
 WHERE id=201849828


   --row number: 17548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189580 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=201849829


   --row number: 17549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189580 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=201849830


   --row number: 17550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189580 , [Content] ='10%'
 WHERE id=201849831


   --row number: 17551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189580 , [Content] ='No'
 WHERE id=201849832


   --row number: 17552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189580 , [Content] ='2 - Professionals'
 WHERE id=201849833


   --row number: 17553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189580 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201849834


   --row number: 17554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189580 , [Content] ='Technical'
 WHERE id=201849835


   --row number: 17555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189580 , [Content] ='09/05/18'
 WHERE id=201849836


   --row number: 17556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189913 , [Content] ='2845 US - MRKT 1'
 WHERE id=201884016


   --row number: 17557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189913 , [Content] ='US - MRKT 1'
 WHERE id=201884017


   --row number: 17558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189913 , [Content] ='AMS'
 WHERE id=201884018


   --row number: 17559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189913 , [Content] ='US'
 WHERE id=201884019


   --row number: 17560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189913 , [Content] ='Professional Services'
 WHERE id=201884020


   --row number: 17561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189913 , [Content] ='2845 - Dir, Customer/Technical Training Mgmt M5'
 WHERE id=201884021


   --row number: 17562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189913 , [Content] ='Customer/Tech Training'
 WHERE id=201884022


   --row number: 17563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189913 , [Content] ='M5'
 WHERE id=201884023


   --row number: 17564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189913 , [Content] ='USD'
 WHERE id=201884025


   --row number: 17565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189913 , [Content] ='128,000 / 156,800 / 185,600 / 214,400 / 243,200'
 WHERE id=201884026


   --row number: 17566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189913 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=201884027


   --row number: 17567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189913 , [Content] ='25%'
 WHERE id=201884028


   --row number: 17568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189913 , [Content] ='Yes'
 WHERE id=201884029


   --row number: 17569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189913 , [Content] ='EXEMPT'
 WHERE id=201884030


   --row number: 17570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189913 , [Content] ='NO'
 WHERE id=201884031


   --row number: 17571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189913 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201884032


   --row number: 17572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189913 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201884033


   --row number: 17573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189913 , [Content] ='Technical'
 WHERE id=201884034


   --row number: 17574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189913 , [Content] ='1/29/2018'
 WHERE id=201884035


   --row number: 17575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189926 , [Content] ='5525 US - MRKT 1'
 WHERE id=201884839


   --row number: 17576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189926 , [Content] ='US - MRKT 1'
 WHERE id=201884840


   --row number: 17577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189926 , [Content] ='AMS'
 WHERE id=201884841


   --row number: 17578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189926 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201884842


   --row number: 17579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189926 , [Content] ='Marketing'
 WHERE id=201884843


   --row number: 17580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189926 , [Content] ='5525 - Pricing Analyst IC5'
 WHERE id=201884844


   --row number: 17581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189926 , [Content] ='Pricing'
 WHERE id=201884845


   --row number: 17582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189926 , [Content] ='IC5'
 WHERE id=201884846


   --row number: 17583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189926 , [Content] ='USD'
 WHERE id=201884848


   --row number: 17584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189926 , [Content] ='111,300 / 134,650 / 158,000 / 181,300 / 204,600'
 WHERE id=201884849


   --row number: 17585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189926 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=201884850


   --row number: 17586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189926 , [Content] ='133,600 / 161,600 / 189,600 / 217,550 / 245,500'
 WHERE id=201884851


   --row number: 17587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189926 , [Content] ='20%'
 WHERE id=201884852


   --row number: 17588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189926 , [Content] ='Yes'
 WHERE id=201884853


   --row number: 17589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189926 , [Content] ='EXEMPT'
 WHERE id=201884854


   --row number: 17590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189926 , [Content] ='NO'
 WHERE id=201884855


   --row number: 17591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189926 , [Content] ='2 - Professionals'
 WHERE id=201884856


   --row number: 17592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189926 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201884857


   --row number: 17593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189926 , [Content] ='09/05/18'
 WHERE id=201884858


   --row number: 17594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189937 , [Content] ='5526 US - MRKT 1'
 WHERE id=201885564


   --row number: 17595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189937 , [Content] ='US - MRKT 1'
 WHERE id=201885565


   --row number: 17596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189937 , [Content] ='AMS'
 WHERE id=201885566


   --row number: 17597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189937 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201885567


   --row number: 17598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189937 , [Content] ='Marketing'
 WHERE id=201885568


   --row number: 17599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189937 , [Content] ='5526 - Pricing Analyst IC6'
 WHERE id=201885569


   --row number: 17600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189937 , [Content] ='Pricing'
 WHERE id=201885570


   --row number: 17601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189937 , [Content] ='IC6'
 WHERE id=201885571


   --row number: 17602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189937 , [Content] ='USD'
 WHERE id=201885573


   --row number: 17603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189937 , [Content] ='130,300 / 159,650 / 189,000 / 218,300 / 247,600'
 WHERE id=201885574


   --row number: 17604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189937 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201885575


   --row number: 17605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189937 , [Content] ='162,900 / 199,600 / 236,300 / 272,900 / 309,500'
 WHERE id=201885576


   --row number: 17606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189937 , [Content] ='25%'
 WHERE id=201885577


   --row number: 17607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189937 , [Content] ='Yes'
 WHERE id=201885578


   --row number: 17608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189937 , [Content] ='EXEMPT'
 WHERE id=201885579


   --row number: 17609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189937 , [Content] ='NO'
 WHERE id=201885580


   --row number: 17610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189937 , [Content] ='2 - Professionals'
 WHERE id=201885581


   --row number: 17611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189937 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201885582


   --row number: 17612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189937 , [Content] ='09/05/18'
 WHERE id=201885583


   --row number: 17613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189944 , [Content] ='5526 US - MRKT 1'
 WHERE id=201886317


   --row number: 17614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189944 , [Content] ='US - MRKT 1'
 WHERE id=201886318


   --row number: 17615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189944 , [Content] ='AMS'
 WHERE id=201886319


   --row number: 17616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189944 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201886320


   --row number: 17617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189944 , [Content] ='Marketing'
 WHERE id=201886321


   --row number: 17618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189944 , [Content] ='5526 - Pricing Analyst IC6'
 WHERE id=201886322


   --row number: 17619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189944 , [Content] ='Pricing'
 WHERE id=201886323


   --row number: 17620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189944 , [Content] ='IC6'
 WHERE id=201886324


   --row number: 17621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189944 , [Content] ='USD'
 WHERE id=201886326


   --row number: 17622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189944 , [Content] ='130,300 / 159,650 / 189,000 / 218,300 / 247,600'
 WHERE id=201886327


   --row number: 17623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189944 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201886328


   --row number: 17624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189944 , [Content] ='162,900 / 199,600 / 236,300 / 272,900 / 309,500'
 WHERE id=201886329


   --row number: 17625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189944 , [Content] ='25%'
 WHERE id=201886330


   --row number: 17626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189944 , [Content] ='Yes'
 WHERE id=201886331


   --row number: 17627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189944 , [Content] ='EXEMPT'
 WHERE id=201886332


   --row number: 17628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189944 , [Content] ='NO'
 WHERE id=201886333


   --row number: 17629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189944 , [Content] ='2 - Professionals'
 WHERE id=201886334


   --row number: 17630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189944 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201886335


   --row number: 17631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189944 , [Content] ='09/05/18'
 WHERE id=201886336


   --row number: 17632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3189976 , [Content] ='2505 US - MRKT 1'
 WHERE id=201888532


   --row number: 17633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3189976 , [Content] ='US - MRKT 1'
 WHERE id=201888533


   --row number: 17634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3189976 , [Content] ='AMS'
 WHERE id=201888534


   --row number: 17635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3189976 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201888535


   --row number: 17636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3189976 , [Content] ='Marketing'
 WHERE id=201888536


   --row number: 17637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3189976 , [Content] ='2505 - Dir, Marketing Mgmt M5'
 WHERE id=201888537


   --row number: 17638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3189976 , [Content] ='Marketing'
 WHERE id=201888538


   --row number: 17639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3189976 , [Content] ='M5'
 WHERE id=201888539


   --row number: 17640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3189976 , [Content] ='USD'
 WHERE id=201888541


   --row number: 17641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3189976 , [Content] ='140,600 / 172,250 / 203,900 / 235,500 / 267,100'
 WHERE id=201888542


   --row number: 17642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3189976 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=201888543


   --row number: 17643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3189976 , [Content] ='175,800 / 215,350 / 254,900 / 294,400 / 333,900'
 WHERE id=201888544


   --row number: 17644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3189976 , [Content] ='25%'
 WHERE id=201888545


   --row number: 17645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3189976 , [Content] ='Yes'
 WHERE id=201888546


   --row number: 17646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3189976 , [Content] ='EXEMPT'
 WHERE id=201888547


   --row number: 17647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3189976 , [Content] ='NO'
 WHERE id=201888548


   --row number: 17648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3189976 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201888549


   --row number: 17649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3189976 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201888550


   --row number: 17650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3189976 , [Content] ='Non Technical'
 WHERE id=201888551


   --row number: 17651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3189976 , [Content] ='09/05/18'
 WHERE id=201888552


   --row number: 17652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190312 , [Content] ='5526 US - MRKT 1'
 WHERE id=201918522


   --row number: 17653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190312 , [Content] ='US - MRKT 1'
 WHERE id=201918523


   --row number: 17654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190312 , [Content] ='AMS'
 WHERE id=201918524


   --row number: 17655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190312 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201918525


   --row number: 17656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190312 , [Content] ='Marketing'
 WHERE id=201918526


   --row number: 17657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190312 , [Content] ='5526 - Pricing Analyst IC6'
 WHERE id=201918527


   --row number: 17658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190312 , [Content] ='Pricing'
 WHERE id=201918528


   --row number: 17659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190312 , [Content] ='IC6'
 WHERE id=201918529


   --row number: 17660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190312 , [Content] ='USD'
 WHERE id=201918531


   --row number: 17661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190312 , [Content] ='130,300 / 159,650 / 189,000 / 218,300 / 247,600'
 WHERE id=201918532


   --row number: 17662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190312 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201918533


   --row number: 17663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190312 , [Content] ='162,900 / 199,600 / 236,300 / 272,900 / 309,500'
 WHERE id=201918534


   --row number: 17664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190312 , [Content] ='25%'
 WHERE id=201918535


   --row number: 17665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190312 , [Content] ='Yes'
 WHERE id=201918536


   --row number: 17666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190312 , [Content] ='EXEMPT'
 WHERE id=201918537


   --row number: 17667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190312 , [Content] ='NO'
 WHERE id=201918538


   --row number: 17668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190312 , [Content] ='2 - Professionals'
 WHERE id=201918539


   --row number: 17669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190312 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201918540


   --row number: 17670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190312 , [Content] ='09/05/18'
 WHERE id=201918541


   --row number: 17671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190326 , [Content] ='5526 US - MRKT 1'
 WHERE id=201919196


   --row number: 17672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190326 , [Content] ='US - MRKT 1'
 WHERE id=201919197


   --row number: 17673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190326 , [Content] ='AMS'
 WHERE id=201919198


   --row number: 17674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190326 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201919199


   --row number: 17675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190326 , [Content] ='Marketing'
 WHERE id=201919200


   --row number: 17676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190326 , [Content] ='5526 - Pricing Analyst IC6'
 WHERE id=201919201


   --row number: 17677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190326 , [Content] ='Pricing'
 WHERE id=201919202


   --row number: 17678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190326 , [Content] ='IC6'
 WHERE id=201919203


   --row number: 17679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190326 , [Content] ='USD'
 WHERE id=201919205


   --row number: 17680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190326 , [Content] ='130,300 / 159,650 / 189,000 / 218,300 / 247,600'
 WHERE id=201919206


   --row number: 17681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190326 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201919207


   --row number: 17682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190326 , [Content] ='162,900 / 199,600 / 236,300 / 272,900 / 309,500'
 WHERE id=201919208


   --row number: 17683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190326 , [Content] ='25%'
 WHERE id=201919209


   --row number: 17684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190326 , [Content] ='Yes'
 WHERE id=201919210


   --row number: 17685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190326 , [Content] ='EXEMPT'
 WHERE id=201919211


   --row number: 17686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190326 , [Content] ='NO'
 WHERE id=201919212


   --row number: 17687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190326 , [Content] ='2 - Professionals'
 WHERE id=201919213


   --row number: 17688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190326 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201919214


   --row number: 17689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190326 , [Content] ='09/05/18'
 WHERE id=201919215


   --row number: 17690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190514 , [Content] ='S1615 US - MRKT 2'
 WHERE id=201934242


   --row number: 17691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190514 , [Content] ='US - MRKT 2'
 WHERE id=201934243


   --row number: 17692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190514 , [Content] ='AMS'
 WHERE id=201934244


   --row number: 17693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190514 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201934245


   --row number: 17694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190514 , [Content] ='Sales'
 WHERE id=201934246


   --row number: 17695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190514 , [Content] ='S1615 - Regional Partner Mgr IC5'
 WHERE id=201934247


   --row number: 17696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190514 , [Content] ='Partner Sales'
 WHERE id=201934248


   --row number: 17697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190514 , [Content] ='IC5'
 WHERE id=201934249


   --row number: 17698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190514 , [Content] ='USD'
 WHERE id=201934251


   --row number: 17699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190514 , [Content] ='145,775 / 158,638 / 171,500 / 184,363 / 197,225'
 WHERE id=201934252


   --row number: 17700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190514 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=201934253


   --row number: 17701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190514 , [Content] ='208,250 / 226,625 / 245,000 / 263,375 / 281,750'
 WHERE id=201934254


   --row number: 17702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3190514 , [Content] ='70/30'
 WHERE id=201934255


   --row number: 17703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190514 , [Content] ='Yes'
 WHERE id=201934256


   --row number: 17704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190514 , [Content] ='EXEMPT'
 WHERE id=201934257


   --row number: 17705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190514 , [Content] ='NO'
 WHERE id=201934258


   --row number: 17706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190514 , [Content] ='4 - Sales Workers'
 WHERE id=201934259


   --row number: 17707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190514 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201934260


   --row number: 17708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190514 , [Content] ='Technical'
 WHERE id=201934261


   --row number: 17709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190514 , [Content] ='09/05/18'
 WHERE id=201934262


   --row number: 17710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190571 , [Content] ='5143 US - MRKT 2'
 WHERE id=201941386


   --row number: 17711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190571 , [Content] ='US - MRKT 2'
 WHERE id=201941387


   --row number: 17712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190571 , [Content] ='AMS'
 WHERE id=201941388


   --row number: 17713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190571 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201941389


   --row number: 17714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190571 , [Content] ='Engineering'
 WHERE id=201941390


   --row number: 17715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190571 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201941391


   --row number: 17716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190571 , [Content] ='Software'
 WHERE id=201941392


   --row number: 17717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190571 , [Content] ='IC3'
 WHERE id=201941393


   --row number: 17718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190571 , [Content] ='USD'
 WHERE id=201941395


   --row number: 17719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190571 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=201941396


   --row number: 17720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190571 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201941397


   --row number: 17721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190571 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=201941398


   --row number: 17722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190571 , [Content] ='15%'
 WHERE id=201941399


   --row number: 17723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190571 , [Content] ='Yes'
 WHERE id=201941400


   --row number: 17724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190571 , [Content] ='EXEMPT'
 WHERE id=201941401


   --row number: 17725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190571 , [Content] ='NO'
 WHERE id=201941402


   --row number: 17726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190571 , [Content] ='2 - Professionals'
 WHERE id=201941403


   --row number: 17727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190571 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201941404


   --row number: 17728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190571 , [Content] ='Technical'
 WHERE id=201941405


   --row number: 17729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190571 , [Content] ='09/05/18'
 WHERE id=201941406


   --row number: 17730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190576 , [Content] ='5143 US - MRKT 2'
 WHERE id=201941496


   --row number: 17731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190576 , [Content] ='US - MRKT 2'
 WHERE id=201941497


   --row number: 17732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190576 , [Content] ='AMS'
 WHERE id=201941498


   --row number: 17733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190576 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201941499


   --row number: 17734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190576 , [Content] ='Engineering'
 WHERE id=201941500


   --row number: 17735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190576 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201941501


   --row number: 17736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190576 , [Content] ='Software'
 WHERE id=201941502


   --row number: 17737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190576 , [Content] ='IC3'
 WHERE id=201941503


   --row number: 17738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190576 , [Content] ='USD'
 WHERE id=201941505


   --row number: 17739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190576 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=201941506


   --row number: 17740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190576 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201941507


   --row number: 17741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190576 , [Content] ='104,900 / 123,750 / 142,600 / 161,500 / 180,400'
 WHERE id=201941508


   --row number: 17742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190576 , [Content] ='15%'
 WHERE id=201941509


   --row number: 17743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190576 , [Content] ='Yes'
 WHERE id=201941510


   --row number: 17744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190576 , [Content] ='EXEMPT'
 WHERE id=201941511


   --row number: 17745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190576 , [Content] ='NO'
 WHERE id=201941512


   --row number: 17746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190576 , [Content] ='2 - Professionals'
 WHERE id=201941513


   --row number: 17747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190576 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201941514


   --row number: 17748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190576 , [Content] ='Technical'
 WHERE id=201941515


   --row number: 17749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190576 , [Content] ='09/05/18'
 WHERE id=201941516


   --row number: 17750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190617 , [Content] ='S1332-SC US - MRKT 2'
 WHERE id=201944237


   --row number: 17751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190617 , [Content] ='US - MRKT 2'
 WHERE id=201944238


   --row number: 17752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190617 , [Content] ='AMS'
 WHERE id=201944239


   --row number: 17753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190617 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201944240


   --row number: 17754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190617 , [Content] ='Solution Consulting'
 WHERE id=201944241


   --row number: 17755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190617 , [Content] ='S1332-SC - Associate Solution Consultant A2'
 WHERE id=201944242


   --row number: 17756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190617 , [Content] ='Solution Consultant Core'
 WHERE id=201944243


   --row number: 17757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190617 , [Content] ='A2'
 WHERE id=201944244


   --row number: 17758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190617 , [Content] ='USD'
 WHERE id=201944246


   --row number: 17759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190617 , [Content] ='49,406 / 53,766 / 58,125 / 62,484 / 66,844'
 WHERE id=201944247


   --row number: 17760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190617 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=201944248


   --row number: 17761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3190617 , [Content] ='75/25'
 WHERE id=201944249


   --row number: 17762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190617 , [Content] ='No'
 WHERE id=201944250


   --row number: 17763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190617 , [Content] ='NON-EXEMPT'
 WHERE id=201944251


   --row number: 17764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190617 , [Content] ='NO'
 WHERE id=201944252


   --row number: 17765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190617 , [Content] ='4 - Sales Workers'
 WHERE id=201944253


   --row number: 17766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190617 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201944254


   --row number: 17767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190617 , [Content] ='Technical'
 WHERE id=201944255


   --row number: 17768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190617 , [Content] ='09/05/18'
 WHERE id=201944256


   --row number: 17769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190653 , [Content] ='5143 US - MRKT 1'
 WHERE id=201947466


   --row number: 17770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190653 , [Content] ='US - MRKT 1'
 WHERE id=201947467


   --row number: 17771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190653 , [Content] ='AMS'
 WHERE id=201947468


   --row number: 17772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190653 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201947469


   --row number: 17773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190653 , [Content] ='Engineering'
 WHERE id=201947470


   --row number: 17774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190653 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201947471


   --row number: 17775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190653 , [Content] ='Software'
 WHERE id=201947472


   --row number: 17776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190653 , [Content] ='IC3'
 WHERE id=201947473


   --row number: 17777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190653 , [Content] ='USD'
 WHERE id=201947475


   --row number: 17778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190653 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=201947476


   --row number: 17779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190653 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201947477


   --row number: 17780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190653 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=201947478


   --row number: 17781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190653 , [Content] ='15%'
 WHERE id=201947479


   --row number: 17782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190653 , [Content] ='Yes'
 WHERE id=201947480


   --row number: 17783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190653 , [Content] ='EXEMPT'
 WHERE id=201947481


   --row number: 17784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190653 , [Content] ='NO'
 WHERE id=201947482


   --row number: 17785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190653 , [Content] ='2 - Professionals'
 WHERE id=201947483


   --row number: 17786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190653 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201947484


   --row number: 17787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190653 , [Content] ='Technical'
 WHERE id=201947485


   --row number: 17788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190653 , [Content] ='09/05/18'
 WHERE id=201947486


   --row number: 17789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190670 , [Content] ='5143 US - MRKT 1'
 WHERE id=201948431


   --row number: 17790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190670 , [Content] ='US - MRKT 1'
 WHERE id=201948432


   --row number: 17791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190670 , [Content] ='AMS'
 WHERE id=201948433


   --row number: 17792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190670 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201948434


   --row number: 17793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190670 , [Content] ='Engineering'
 WHERE id=201948435


   --row number: 17794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190670 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201948436


   --row number: 17795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190670 , [Content] ='Software'
 WHERE id=201948437


   --row number: 17796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190670 , [Content] ='IC3'
 WHERE id=201948438


   --row number: 17797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190670 , [Content] ='USD'
 WHERE id=201948440


   --row number: 17798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190670 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=201948441


   --row number: 17799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190670 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201948442


   --row number: 17800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190670 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=201948443


   --row number: 17801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190670 , [Content] ='15%'
 WHERE id=201948444


   --row number: 17802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190670 , [Content] ='Yes'
 WHERE id=201948445


   --row number: 17803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190670 , [Content] ='EXEMPT'
 WHERE id=201948446


   --row number: 17804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190670 , [Content] ='NO'
 WHERE id=201948447


   --row number: 17805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190670 , [Content] ='2 - Professionals'
 WHERE id=201948448


   --row number: 17806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190670 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201948449


   --row number: 17807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190670 , [Content] ='Technical'
 WHERE id=201948450


   --row number: 17808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190670 , [Content] ='09/05/18'
 WHERE id=201948451


   --row number: 17809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190676 , [Content] ='5143 US - MRKT 1'
 WHERE id=201949032


   --row number: 17810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190676 , [Content] ='US - MRKT 1'
 WHERE id=201949033


   --row number: 17811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190676 , [Content] ='AMS'
 WHERE id=201949034


   --row number: 17812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190676 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201949035


   --row number: 17813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190676 , [Content] ='Engineering'
 WHERE id=201949036


   --row number: 17814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190676 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=201949037


   --row number: 17815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190676 , [Content] ='Software'
 WHERE id=201949038


   --row number: 17816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190676 , [Content] ='IC3'
 WHERE id=201949039


   --row number: 17817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190676 , [Content] ='USD'
 WHERE id=201949041


   --row number: 17818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190676 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=201949042


   --row number: 17819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190676 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=201949043


   --row number: 17820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190676 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=201949044


   --row number: 17821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190676 , [Content] ='15%'
 WHERE id=201949045


   --row number: 17822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190676 , [Content] ='Yes'
 WHERE id=201949046


   --row number: 17823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190676 , [Content] ='EXEMPT'
 WHERE id=201949047


   --row number: 17824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190676 , [Content] ='NO'
 WHERE id=201949048


   --row number: 17825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190676 , [Content] ='2 - Professionals'
 WHERE id=201949049


   --row number: 17826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190676 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201949050


   --row number: 17827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190676 , [Content] ='Technical'
 WHERE id=201949051


   --row number: 17828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190676 , [Content] ='09/05/18'
 WHERE id=201949052


   --row number: 17829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190829 , [Content] ='6194 US - MRKT 1'
 WHERE id=201962666


   --row number: 17830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190829 , [Content] ='US - MRKT 1'
 WHERE id=201962667


   --row number: 17831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190829 , [Content] ='AMS'
 WHERE id=201962668


   --row number: 17832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190829 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201962669


   --row number: 17833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190829 , [Content] ='Finance'
 WHERE id=201962670


   --row number: 17834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190829 , [Content] ='6194 - Sr. Financial Reporting Analyst IC4'
 WHERE id=201962671


   --row number: 17835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190829 , [Content] ='Financial Reporting'
 WHERE id=201962672


   --row number: 17836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190829 , [Content] ='IC4'
 WHERE id=201962673


   --row number: 17837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190829 , [Content] ='USD'
 WHERE id=201962675


   --row number: 17838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190829 , [Content] ='101,300 / 119,500 / 137,700 / 155,950 / 174,200'
 WHERE id=201962676


   --row number: 17839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190829 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201962677


   --row number: 17840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190829 , [Content] ='15%'
 WHERE id=201962679


   --row number: 17841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190829 , [Content] ='Yes'
 WHERE id=201962680


   --row number: 17842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190829 , [Content] ='EXEMPT'
 WHERE id=201962681


   --row number: 17843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190829 , [Content] ='NO'
 WHERE id=201962682


   --row number: 17844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190829 , [Content] ='2 - Professionals'
 WHERE id=201962683


   --row number: 17845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190829 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201962684


   --row number: 17846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190829 , [Content] ='Non Technical'
 WHERE id=201962685


   --row number: 17847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190829 , [Content] ='10/05/18'
 WHERE id=201962686


   --row number: 17848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190912 , [Content] ='5894 US - MRKT 2'
 WHERE id=201967653


   --row number: 17849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190912 , [Content] ='US - MRKT 2'
 WHERE id=201967654


   --row number: 17850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190912 , [Content] ='AMS'
 WHERE id=201967655


   --row number: 17851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190912 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201967656


   --row number: 17852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190912 , [Content] ='Professional Services'
 WHERE id=201967657


   --row number: 17853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190912 , [Content] ='5894 - Technical Curriculum Developer IC4'
 WHERE id=201967658


   --row number: 17854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190912 , [Content] ='Technical Curriculum'
 WHERE id=201967659


   --row number: 17855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190912 , [Content] ='IC4'
 WHERE id=201967660


   --row number: 17856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190912 , [Content] ='USD'
 WHERE id=201967662


   --row number: 17857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190912 , [Content] ='82,400 / 97,250 / 112,100 / 126,900 / 141,700'
 WHERE id=201967663


   --row number: 17858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190912 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201967664


   --row number: 17859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190912 , [Content] ='15%'
 WHERE id=201967666


   --row number: 17860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190912 , [Content] ='Yes'
 WHERE id=201967667


   --row number: 17861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190912 , [Content] ='EXEMPT'
 WHERE id=201967668


   --row number: 17862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190912 , [Content] ='NO'
 WHERE id=201967669


   --row number: 17863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190912 , [Content] ='2 - Professionals'
 WHERE id=201967670


   --row number: 17864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190912 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201967671


   --row number: 17865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190912 , [Content] ='Technical'
 WHERE id=201967672


   --row number: 17866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190912 , [Content] ='10/05/18'
 WHERE id=201967673


   --row number: 17867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190928 , [Content] ='4962 US - MRKT 1'
 WHERE id=201969128


   --row number: 17868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190928 , [Content] ='US - MRKT 1'
 WHERE id=201969129


   --row number: 17869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190928 , [Content] ='AMS'
 WHERE id=201969130


   --row number: 17870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190928 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201969131


   --row number: 17871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190928 , [Content] ='Marketing'
 WHERE id=201969132


   --row number: 17872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190928 , [Content] ='4962 - Content Producer IC2'
 WHERE id=201969133


   --row number: 17873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190928 , [Content] ='Content Development'
 WHERE id=201969134


   --row number: 17874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190928 , [Content] ='IC2'
 WHERE id=201969135


   --row number: 17875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190928 , [Content] ='USD'
 WHERE id=201969137


   --row number: 17876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190928 , [Content] ='56,000 / 64,000 / 72,000 / 79,950 / 87,900'
 WHERE id=201969138


   --row number: 17877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190928 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=201969139


   --row number: 17878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190928 , [Content] ='61,600 / 70,400 / 79,200 / 87,950 / 96,700'
 WHERE id=201969140


   --row number: 17879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190928 , [Content] ='10%'
 WHERE id=201969141


   --row number: 17880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190928 , [Content] ='Yes'
 WHERE id=201969142


   --row number: 17881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190928 , [Content] ='EXEMPT'
 WHERE id=201969143


   --row number: 17882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190928 , [Content] ='NO'
 WHERE id=201969144


   --row number: 17883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190928 , [Content] ='2 - Professionals'
 WHERE id=201969145


   --row number: 17884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190928 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201969146


   --row number: 17885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190928 , [Content] ='Non Technical'
 WHERE id=201969147


   --row number: 17886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190928 , [Content] ='09/05/18'
 WHERE id=201969148


   --row number: 17887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190936 , [Content] ='Yes'
 WHERE id=201970473


   --row number: 17888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190936 , [Content] ='EXEMPT'
 WHERE id=201970474


   --row number: 17889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190936 , [Content] ='NO'
 WHERE id=201970475


   --row number: 17890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190936 , [Content] ='2 - Professionals'
 WHERE id=201970476


   --row number: 17891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190936 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201970477


   --row number: 17892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190936 , [Content] ='Technical'
 WHERE id=201970478


   --row number: 17893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190936 , [Content] ='09/05/18'
 WHERE id=201970479


   --row number: 17894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190936 , [Content] ='15%'
 WHERE id=201970472


   --row number: 17895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190936 , [Content] ='114,500 / 135,150 / 155,800 / 176,400 / 197,000'
 WHERE id=201970471


   --row number: 17896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190936 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=201970470


   --row number: 17897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190936 , [Content] ='99,600 / 117,550 / 135,500 / 153,400 / 171,300'
 WHERE id=201970469


   --row number: 17898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190936 , [Content] ='USD'
 WHERE id=201970468


   --row number: 17899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190936 , [Content] ='IC3'
 WHERE id=201970466


   --row number: 17900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190936 , [Content] ='Data Informatics'
 WHERE id=201970465


   --row number: 17901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190936 , [Content] ='6493 - Data Informatics Analyst IC3'
 WHERE id=201970464


   --row number: 17902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190936 , [Content] ='Info Systems/Technology'
 WHERE id=201970463


   --row number: 17903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190936 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201970462


   --row number: 17904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190936 , [Content] ='AMS'
 WHERE id=201970461


   --row number: 17905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190936 , [Content] ='US - MRKT 1'
 WHERE id=201970460


   --row number: 17906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190936 , [Content] ='6493 US - MRKT 1'
 WHERE id=201970459


   --row number: 17907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190938 , [Content] ='EXEMPT'
 WHERE id=201970734


   --row number: 17908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190938 , [Content] ='NO'
 WHERE id=201970735


   --row number: 17909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190938 , [Content] ='2 - Professionals'
 WHERE id=201970736


   --row number: 17910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190938 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201970737


   --row number: 17911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190938 , [Content] ='Technical'
 WHERE id=201970738


   --row number: 17912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190938 , [Content] ='09/05/18'
 WHERE id=201970739


   --row number: 17913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190938 , [Content] ='5312 US - MRKT 1'
 WHERE id=201970719


   --row number: 17914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190938 , [Content] ='US - MRKT 1'
 WHERE id=201970720


   --row number: 17915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190938 , [Content] ='AMS'
 WHERE id=201970721


   --row number: 17916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190938 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201970722


   --row number: 17917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190938 , [Content] ='Engineering Operations'
 WHERE id=201970723


   --row number: 17918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190938 , [Content] ='5312 - Technical Writer IC2'
 WHERE id=201970724


   --row number: 17919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190938 , [Content] ='Technical Writer'
 WHERE id=201970725


   --row number: 17920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190938 , [Content] ='IC2'
 WHERE id=201970726


   --row number: 17921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190938 , [Content] ='USD'
 WHERE id=201970728


   --row number: 17922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190938 , [Content] ='74,300 / 84,900 / 95,500 / 106,100 / 116,700'
 WHERE id=201970729


   --row number: 17923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190938 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=201970730


   --row number: 17924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190938 , [Content] ='81,700 / 93,400 / 105,100 / 116,750 / 128,400'
 WHERE id=201970731


   --row number: 17925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190938 , [Content] ='10%'
 WHERE id=201970732


   --row number: 17926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190938 , [Content] ='Yes'
 WHERE id=201970733


   --row number: 17927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190940 , [Content] ='EXEMPT'
 WHERE id=201970893


   --row number: 17928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190940 , [Content] ='NO'
 WHERE id=201970894


   --row number: 17929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190940 , [Content] ='2 - Professionals'
 WHERE id=201970895


   --row number: 17930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190940 , [Content] ='8810-Clerical Office Employees'
 WHERE id=201970896


   --row number: 17931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190940 , [Content] ='Technical'
 WHERE id=201970897


   --row number: 17932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190940 , [Content] ='09/05/18'
 WHERE id=201970898


   --row number: 17933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190940 , [Content] ='5465 US - MRKT 1'
 WHERE id=201970878


   --row number: 17934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190940 , [Content] ='US - MRKT 1'
 WHERE id=201970879


   --row number: 17935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190940 , [Content] ='AMS'
 WHERE id=201970880


   --row number: 17936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190940 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201970881


   --row number: 17937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190940 , [Content] ='Marketing'
 WHERE id=201970882


   --row number: 17938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190940 , [Content] ='5465 - Product Portfolio Mgr IC5'
 WHERE id=201970883


   --row number: 17939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190940 , [Content] ='Product Mgrs'
 WHERE id=201970884


   --row number: 17940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190940 , [Content] ='IC5'
 WHERE id=201970885


   --row number: 17941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190940 , [Content] ='USD'
 WHERE id=201970887


   --row number: 17942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190940 , [Content] ='130,700 / 160,100 / 189,500 / 218,900 / 248,300'
 WHERE id=201970888


   --row number: 17943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190940 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=201970889


   --row number: 17944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190940 , [Content] ='163,400 / 200,150 / 236,900 / 273,650 / 310,400'
 WHERE id=201970890


   --row number: 17945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190940 , [Content] ='25%'
 WHERE id=201970891


   --row number: 17946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190940 , [Content] ='Yes'
 WHERE id=201970892


   --row number: 17947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190947 , [Content] ='Yes'
 WHERE id=201972055


   --row number: 17948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190947 , [Content] ='EXEMPT'
 WHERE id=201972056


   --row number: 17949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190947 , [Content] ='NO'
 WHERE id=201972057


   --row number: 17950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190947 , [Content] ='2 - Professionals'
 WHERE id=201972058


   --row number: 17951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190947 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201972059


   --row number: 17952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190947 , [Content] ='Technical'
 WHERE id=201972060


   --row number: 17953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190947 , [Content] ='09/05/18'
 WHERE id=201972061


   --row number: 17954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190947 , [Content] ='5182 US - MRKT 2'
 WHERE id=201972041


   --row number: 17955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190947 , [Content] ='US - MRKT 2'
 WHERE id=201972042


   --row number: 17956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190947 , [Content] ='AMS'
 WHERE id=201972043


   --row number: 17957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190947 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201972044


   --row number: 17958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190947 , [Content] ='Engineering'
 WHERE id=201972045


   --row number: 17959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190947 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=201972046


   --row number: 17960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190947 , [Content] ='Quality'
 WHERE id=201972047


   --row number: 17961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190947 , [Content] ='IC2'
 WHERE id=201972048


   --row number: 17962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190947 , [Content] ='USD'
 WHERE id=201972050


   --row number: 17963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190947 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=201972051


   --row number: 17964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190947 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=201972052


   --row number: 17965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190947 , [Content] ='72,800 / 84,800 / 96,800 / 108,850 / 120,900'
 WHERE id=201972053


   --row number: 17966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190947 , [Content] ='10%'
 WHERE id=201972054


   --row number: 17967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3190950 , [Content] ='Yes'
 WHERE id=201972529


   --row number: 17968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3190950 , [Content] ='EXEMPT'
 WHERE id=201972530


   --row number: 17969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3190950 , [Content] ='NO'
 WHERE id=201972531


   --row number: 17970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3190950 , [Content] ='2 - Professionals'
 WHERE id=201972532


   --row number: 17971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3190950 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=201972533


   --row number: 17972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3190950 , [Content] ='Technical'
 WHERE id=201972534


   --row number: 17973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3190950 , [Content] ='09/05/18'
 WHERE id=201972535


   --row number: 17974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3190950 , [Content] ='5182 US - MRKT 2'
 WHERE id=201972515


   --row number: 17975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3190950 , [Content] ='US - MRKT 2'
 WHERE id=201972516


   --row number: 17976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3190950 , [Content] ='AMS'
 WHERE id=201972517


   --row number: 17977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3190950 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=201972518


   --row number: 17978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3190950 , [Content] ='Engineering'
 WHERE id=201972519


   --row number: 17979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3190950 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=201972520


   --row number: 17980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3190950 , [Content] ='Quality'
 WHERE id=201972521


   --row number: 17981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3190950 , [Content] ='IC2'
 WHERE id=201972522


   --row number: 17982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3190950 , [Content] ='USD'
 WHERE id=201972524


   --row number: 17983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3190950 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=201972525


   --row number: 17984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3190950 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=201972526


   --row number: 17985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3190950 , [Content] ='72,800 / 84,800 / 96,800 / 108,850 / 120,900'
 WHERE id=201972527


   --row number: 17986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3190950 , [Content] ='10%'
 WHERE id=201972528


   --row number: 17987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3191070 , [Content] ='Yes'
 WHERE id=201987530


   --row number: 17988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3191070 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=201987531


   --row number: 17989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3191070 , [Content] ='8742-Salespersons - Outside'
 WHERE id=201987532


   --row number: 17990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3191070 , [Content] ='Technical'
 WHERE id=201987533


   --row number: 17991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3191070 , [Content] ='09/05/18'
 WHERE id=201987534


   --row number: 17992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3191070 , [Content] ='S1404 CAN'
 WHERE id=201987516


   --row number: 17993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3191070 , [Content] ='CAN'
 WHERE id=201987517


   --row number: 17994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3191070 , [Content] ='AMS'
 WHERE id=201987518


   --row number: 17995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3191070 , [Content] ='CANADA'
 WHERE id=201987519


   --row number: 17996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3191070 , [Content] ='Solution Consulting'
 WHERE id=201987520


   --row number: 17997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3191070 , [Content] ='S1404 - Sr Mgr, Solution Consulting M4'
 WHERE id=201987521


   --row number: 17998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3191070 , [Content] ='Solution Consultant Core'
 WHERE id=201987522


   --row number: 17999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3191070 , [Content] ='M4'
 WHERE id=201987523


   --row number: 18000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3191070 , [Content] ='CAD'
 WHERE id=201987525

