--total=3000 rows
--Total (21152 row(s) affected) + 625 rows=21777 rows




   --row number: 1

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2668571 , [Content] ='5824 US - MRKT 1'
 WHERE id=143432993


   --row number: 2

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=2668571 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=143432994


   --row number: 3

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2668571 , [Content] ='Customer Support'
 WHERE id=143432995


   --row number: 4

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2668571 , [Content] ='Technical Support'
 WHERE id=143432996


   --row number: 5

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2668571 , [Content] ='5824 - Staff Tech Support Engineer IC4'
 WHERE id=143432997


   --row number: 6

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2668571 , [Content] ='IC4'
 WHERE id=143432998


   --row number: 7

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2668571 , [Content] ='US - MRKT 1'
 WHERE id=143433000


   --row number: 8

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2668571 , [Content] ='86,700 / 104,850 / 123,000 / 141,200 / 159,400'
 WHERE id=143433001


   --row number: 9

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2668571 , [Content] ='20%'
 WHERE id=143433003


   --row number: 10

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2668571 , [Content] ='Yes'
 WHERE id=143433004


   --row number: 11

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2668571 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=143433005


   --row number: 12

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2668571 , [Content] ='EXEMPT'
 WHERE id=143433006


   --row number: 13

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2668571 , [Content] ='YES'
 WHERE id=143433007


   --row number: 14

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2668571 , [Content] ='AMS'
 WHERE id=143433010


   --row number: 15

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2668571 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=143433011


   --row number: 16

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2668571 , [Content] ='Technical'
 WHERE id=143433012


   --row number: 17

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2668571 , [Content] ='8810-Clerical Office Employees'
 WHERE id=143433013


   --row number: 18

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2668571 , [Content] ='2 - Professionals'
 WHERE id=143433014


   --row number: 19

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2668339 , [Content] ='AMS'
 WHERE id=143425887


   --row number: 20

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2668339 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=143425888


   --row number: 21

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2668339 , [Content] ='Technical'
 WHERE id=143425889


   --row number: 22

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2668339 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=143425890


   --row number: 23

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2668339 , [Content] ='2 - Professionals'
 WHERE id=143425891


   --row number: 24

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2668339 , [Content] ='NO'
 WHERE id=143425884


   --row number: 25

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2668339 , [Content] ='EXEMPT'
 WHERE id=143425883


   --row number: 26

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2668339 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=143425882


   --row number: 27

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2668339 , [Content] ='Yes'
 WHERE id=143425881


   --row number: 28

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2668339 , [Content] ='15%'
 WHERE id=143425880


   --row number: 29

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2668339 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=143425878


   --row number: 30

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2668339 , [Content] ='US - MRKT 1'
 WHERE id=143425877


   --row number: 31

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2668339 , [Content] ='IC3'
 WHERE id=143425875


   --row number: 32

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2668339 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=143425874


   --row number: 33

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2668339 , [Content] ='Software'
 WHERE id=143425873


   --row number: 34

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2668339 , [Content] ='Engineering'
 WHERE id=143425872


   --row number: 35

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2668339 , [Content] ='5143 US - MRKT 1'
 WHERE id=143425871


   --row number: 36

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2668339 , [Content] ='4/25/2018'
 WHERE id=172101458


   --row number: 37

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2668339 , [Content] ='USD'
 WHERE id=172101463


   --row number: 38

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2668571 , [Content] ='USD'
 WHERE id=172109853


   --row number: 39

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2668571 , [Content] ='04/05/18'
 WHERE id=172109848


   --row number: 40

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2666711 , [Content] ='GBP'
 WHERE id=169347449


   --row number: 41

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2666711 , [Content] ='25%'
 WHERE id=143328672


   --row number: 42

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2666711 , [Content] ='Yes'
 WHERE id=143328673


   --row number: 43

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2666711 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=143328674


   --row number: 44

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2666711 , [Content] ='EMEA'
 WHERE id=143328677


   --row number: 45

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2666711 , [Content] ='S1515 UK'
 WHERE id=143328663


   --row number: 46

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2666711 , [Content] ='Professional Services'
 WHERE id=143328664


   --row number: 47

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2666711 , [Content] ='Solution Architect'
 WHERE id=143328665


   --row number: 48

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2666711 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=143328666


   --row number: 49

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2666711 , [Content] ='IC5'
 WHERE id=143328667


   --row number: 50

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2666711 , [Content] ='UK'
 WHERE id=143328669


   --row number: 51

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2666711 , [Content] ='63,000 / 77,200 / 91,400 / 105,550 / 119,700'
 WHERE id=143328670


   --row number: 52

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2666711 , [Content] ='UNITED KINGDOM'
 WHERE id=143328678


   --row number: 53

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2666711 , [Content] ='Technical'
 WHERE id=143328679


   --row number: 54

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2666711 , [Content] ='8810-Clerical Office Employees'
 WHERE id=143328681


   --row number: 55

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2666711 , [Content] ='4 - Sales Workers'
 WHERE id=143328682


   --row number: 56

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2666711 , [Content] ='04/05/18'
 WHERE id=169347448


   --row number: 57

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2656405 , [Content] ='8810-Clerical Office Employees'
 WHERE id=142322355


   --row number: 58

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2656405 , [Content] ='4 - Sales Workers'
 WHERE id=142322356


   --row number: 59

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2656405 , [Content] ='S1331 US - MRKT 2'
 WHERE id=142322338


   --row number: 60

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2656405 , [Content] ='Sales'
 WHERE id=142322339


   --row number: 61

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2656405 , [Content] ='Inside Sales'
 WHERE id=142322340


   --row number: 62

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2656405 , [Content] ='S1331 - Account Development Rep A1'
 WHERE id=142322341


   --row number: 63

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2656405 , [Content] ='A1'
 WHERE id=142322342


   --row number: 64

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2656405 , [Content] ='US - MRKT 2'
 WHERE id=142322344


   --row number: 65

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2656405 , [Content] ='No'
 WHERE id=142322346


   --row number: 66

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2656405 , [Content] ='60/40'
 WHERE id=142322347


   --row number: 67

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2656405 , [Content] ='NON-EXEMPT'
 WHERE id=142322348


   --row number: 68

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2656405 , [Content] ='NO'
 WHERE id=142322349


   --row number: 69

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2656405 , [Content] ='Non Technical'
 WHERE id=142322354


   --row number: 70

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2656405 , [Content] ='AMS'
 WHERE id=142322352


   --row number: 71

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2656405 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=142322353


   --row number: 72

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2656405 , [Content] ='04/05/18'
 WHERE id=172109230


   --row number: 73

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2656405 , [Content] ='57,375 / 62,438 / 67,500 / 72,563 / 77,625'
 WHERE id=172109231


   --row number: 74

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2656405 , [Content] ='34,425 / 37,463 / 40,500 / 43,538 / 46,575'
 WHERE id=172109234


   --row number: 75

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2586877 , [Content] ='Solution Consulting'
 WHERE id=134661027


   --row number: 76

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2586877 , [Content] ='APAC'
 WHERE id=134661039


   --row number: 77

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2586877 , [Content] ='AUSTRALIA'
 WHERE id=134661040


   --row number: 78

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2586877 , [Content] ='Technical'
 WHERE id=134661041


   --row number: 79

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2586877 , [Content] ='8742-Salespersons - Outside'
 WHERE id=134661043


   --row number: 80

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2586877 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=134661044


   --row number: 81

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2586877 , [Content] ='Solution Consultant Core'
 WHERE id=134661028


   --row number: 82

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2586877 , [Content] ='S1403 - Mgr, Solution Consulting M3'
 WHERE id=134661029


   --row number: 83

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2586877 , [Content] ='M3'
 WHERE id=134661030


   --row number: 84

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2586877 , [Content] ='AUS'
 WHERE id=134661032


   --row number: 85

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2586877 , [Content] ='Yes'
 WHERE id=134661034


   --row number: 86

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2586877 , [Content] ='455 / 910 / 1,365'
 WHERE id=134661035


   --row number: 87

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2586877 , [Content] ='75/25'
 WHERE id=134661036


   --row number: 88

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2578329 , [Content] ='2993 NLD'
 WHERE id=133918078


   --row number: 89

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2578329 , [Content] ='Finance'
 WHERE id=133918079


   --row number: 90

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2578329 , [Content] ='Revenue Accounting'
 WHERE id=133918080


   --row number: 91

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=2622150 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=138754034


   --row number: 92

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2622150 , [Content] ='Info Systems/Technology'
 WHERE id=138754035


   --row number: 93

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2622150 , [Content] ='Programmer'
 WHERE id=138754036


   --row number: 94

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2622150 , [Content] ='6454 - Programmer/Analyst IC4'
 WHERE id=138754037


   --row number: 95

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2622150 , [Content] ='IC4'
 WHERE id=138754038


   --row number: 96

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2622150 , [Content] ='US - MRKT 1'
 WHERE id=138754040


   --row number: 97

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2622150 , [Content] ='95,500 / 112,700 / 129,900 / 147,100 / 164,300'
 WHERE id=138754041


   --row number: 98

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2622150 , [Content] ='15%'
 WHERE id=138754043


   --row number: 99

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2622150 , [Content] ='Yes'
 WHERE id=138754044


   --row number: 100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2622150 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=138754045


   --row number: 101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2622150 , [Content] ='EXEMPT'
 WHERE id=138754046


   --row number: 102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2622150 , [Content] ='YES'
 WHERE id=138754047


   --row number: 103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2622150 , [Content] ='AMS'
 WHERE id=138754050


   --row number: 104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2622150 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=138754051


   --row number: 105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2622150 , [Content] ='Technical'
 WHERE id=138754052


   --row number: 106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2622150 , [Content] ='8810-Clerical Office Employees'
 WHERE id=138754053


   --row number: 107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2622150 , [Content] ='2 - Professionals'
 WHERE id=138754054


   --row number: 108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2578329 , [Content] ='2993 - Mgr, Revenue Mgmt M3'
 WHERE id=133918081


   --row number: 109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2578329 , [Content] ='M3'
 WHERE id=133918082


   --row number: 110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2578329 , [Content] ='NLD'
 WHERE id=133918084


   --row number: 111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2578329 , [Content] ='55,700 / 67,400 / 79,100 / 90,750 / 102,400'
 WHERE id=133918085


   --row number: 112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2578329 , [Content] ='20%'
 WHERE id=133918087


   --row number: 113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2578329 , [Content] ='Yes'
 WHERE id=133918088


   --row number: 114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2578329 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=133918089


   --row number: 115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2586877 , [Content] ='S1403 AUS'
 WHERE id=134661026


   --row number: 116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2614462 , [Content] ='9999 US - MRKT 1'
 WHERE id=137276400


   --row number: 117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2614462 , [Content] ='9999 - Intern'
 WHERE id=137276401


   --row number: 118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2614462 , [Content] ='Intern'
 WHERE id=137276402


   --row number: 119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2614462 , [Content] ='US - MRKT 1'
 WHERE id=137276403


   --row number: 120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2614462 , [Content] ='No'
 WHERE id=137276405


   --row number: 121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2614462 , [Content] ='NON-EXEMPT'
 WHERE id=137276406


   --row number: 122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2614462 , [Content] ='AMS'
 WHERE id=137276409


   --row number: 123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2614462 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=137276410


   --row number: 124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2622150 , [Content] ='6454 US - MRKT 1'
 WHERE id=138754033


   --row number: 125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2631862 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=139644564


   --row number: 126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2631862 , [Content] ='EXEMPT'
 WHERE id=139644565


   --row number: 127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2636662 , [Content] ='Engagement Mgrs'
 WHERE id=140212104


   --row number: 128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2636662 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=140212105


   --row number: 129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2636662 , [Content] ='IC4'
 WHERE id=140212106


   --row number: 130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2636662 , [Content] ='US - MRKT 1'
 WHERE id=140212108


   --row number: 131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2636662 , [Content] ='97,200 / 117,600 / 138,000 / 158,350 / 178,700'
 WHERE id=140212109


   --row number: 132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2636662 , [Content] ='20%'
 WHERE id=140212111


   --row number: 133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2636662 , [Content] ='Yes'
 WHERE id=140212112


   --row number: 134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2636662 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=140212113


   --row number: 135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2636662 , [Content] ='EXEMPT'
 WHERE id=140212114


   --row number: 136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2631862 , [Content] ='NO'
 WHERE id=139644566


   --row number: 137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2631862 , [Content] ='AMS'
 WHERE id=139644569


   --row number: 138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2631862 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=139644570


   --row number: 139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2631862 , [Content] ='Non Technical'
 WHERE id=139644571


   --row number: 140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2631862 , [Content] ='8810-Clerical Office Employees'
 WHERE id=139644572


   --row number: 141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2631862 , [Content] ='2 - Professionals'
 WHERE id=139644573


   --row number: 142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2631862 , [Content] ='6634 US - MRKT 1'
 WHERE id=139644553


   --row number: 143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2631862 , [Content] ='Administration'
 WHERE id=139644554


   --row number: 144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2631862 , [Content] ='Project/Program Mgrs'
 WHERE id=139644555


   --row number: 145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2631862 , [Content] ='6634 - Project/Program Manager IC4'
 WHERE id=139644556


   --row number: 146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2631862 , [Content] ='IC4'
 WHERE id=139644557


   --row number: 147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2631862 , [Content] ='US - MRKT 1'
 WHERE id=139644559


   --row number: 148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2631862 , [Content] ='104,600 / 123,450 / 142,300 / 161,100 / 179,900'
 WHERE id=139644560


   --row number: 149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2631862 , [Content] ='15%'
 WHERE id=139644562


   --row number: 150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2631862 , [Content] ='Yes'
 WHERE id=139644563


   --row number: 151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2636662 , [Content] ='Professional Services'
 WHERE id=140212103


   --row number: 152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2636662 , [Content] ='5874 US - MRKT 1'
 WHERE id=140212102


   --row number: 153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2636662 , [Content] ='NO'
 WHERE id=140212115


   --row number: 154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2636662 , [Content] ='AMS'
 WHERE id=140212118


   --row number: 155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2636662 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=140212119


   --row number: 156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2636662 , [Content] ='Technical'
 WHERE id=140212120


   --row number: 157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2636662 , [Content] ='8810-Clerical Office Employees'
 WHERE id=140212122


   --row number: 158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2636662 , [Content] ='2 - Professionals'
 WHERE id=140212123


   --row number: 159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2647613 , [Content] ='APAC'
 WHERE id=141441833


   --row number: 160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2647613 , [Content] ='INDIA'
 WHERE id=141441834


   --row number: 161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2647613 , [Content] ='Technical'
 WHERE id=141441835


   --row number: 162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2647613 , [Content] ='Engineering'
 WHERE id=141441820


   --row number: 163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2647613 , [Content] ='Software'
 WHERE id=141441821


   --row number: 164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2647613 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=141441822


   --row number: 165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2647613 , [Content] ='IC4'
 WHERE id=141441823


   --row number: 166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2647613 , [Content] ='IND'
 WHERE id=141441825


   --row number: 167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2647613 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=141441826


   --row number: 168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2647613 , [Content] ='20%'
 WHERE id=141441828


   --row number: 169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2647613 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=141441829


   --row number: 170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2655350 , [Content] ='149,200 / 182,750 / 216,300 / 249,900 / 283,500'
 WHERE id=142239261


   --row number: 171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2655350 , [Content] ='2706 US - MRKT 2'
 WHERE id=142239254


   --row number: 172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2655350 , [Content] ='Marketing'
 WHERE id=142239255


   --row number: 173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2655350 , [Content] ='Product Mgrs'
 WHERE id=142239256


   --row number: 174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2655350 , [Content] ='2706 - Sr Dir, Product Portfolio Mgmt M6'
 WHERE id=142239257


   --row number: 175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2655350 , [Content] ='M6'
 WHERE id=142239258


   --row number: 176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2655350 , [Content] ='US - MRKT 2'
 WHERE id=142239260


   --row number: 177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2655350 , [Content] ='30%'
 WHERE id=142239263


   --row number: 178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2655350 , [Content] ='Yes'
 WHERE id=142239264


   --row number: 179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2655350 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=142239265


   --row number: 180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2655350 , [Content] ='EXEMPT'
 WHERE id=142239266


   --row number: 181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2655350 , [Content] ='NO'
 WHERE id=142239267


   --row number: 182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2655350 , [Content] ='AMS'
 WHERE id=142239270


   --row number: 183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2655350 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=142239271


   --row number: 184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2655350 , [Content] ='Technical'
 WHERE id=142239272


   --row number: 185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2655350 , [Content] ='8810-Clerical Office Employees'
 WHERE id=142239273


   --row number: 186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2655350 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=142239274


   --row number: 187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2682962 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=144811670


   --row number: 188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2682962 , [Content] ='6484 IRL'
 WHERE id=144811669


   --row number: 189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2682962 , [Content] ='Production service'
 WHERE id=144811671


   --row number: 190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2682962 , [Content] ='6484 - Staff Production Service Engineer IC4'
 WHERE id=144811672


   --row number: 191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2682962 , [Content] ='IC4'
 WHERE id=144811673


   --row number: 192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2682962 , [Content] ='IRL'
 WHERE id=144811675


   --row number: 193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2682962 , [Content] ='20%'
 WHERE id=144811676


   --row number: 194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2682962 , [Content] ='Yes'
 WHERE id=144811677


   --row number: 195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2682962 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=144811678


   --row number: 196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2682962 , [Content] ='EMEA'
 WHERE id=144811681


   --row number: 197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2682962 , [Content] ='IRELAND'
 WHERE id=144811682


   --row number: 198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2682962 , [Content] ='Technical'
 WHERE id=144811683


   --row number: 199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2682962 , [Content] ='8810-Clerical Office Employees'
 WHERE id=144811684


   --row number: 200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2682962 , [Content] ='2 - Professionals'
 WHERE id=144811685


   --row number: 201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2682962 , [Content] ='60,600 / 73,300 / 86,000 / 98,700 / 111,400'
 WHERE id=155165938


   --row number: 202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2656405 , [Content] ='USD'
 WHERE id=172109236


   --row number: 203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2622150 , [Content] ='04/05/18'
 WHERE id=172105286


   --row number: 204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2622150 , [Content] ='USD'
 WHERE id=172105290


   --row number: 205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2631862 , [Content] ='04/05/18'
 WHERE id=172105640


   --row number: 206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2631862 , [Content] ='USD'
 WHERE id=172105644


   --row number: 207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2655350 , [Content] ='USD'
 WHERE id=172108817


   --row number: 208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2655350 , [Content] ='04/05/18'
 WHERE id=172108812


   --row number: 209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2636662 , [Content] ='04/05/18'
 WHERE id=167993059


   --row number: 210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2636662 , [Content] ='USD'
 WHERE id=167993060


   --row number: 211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2682962 , [Content] ='EUR'
 WHERE id=172109584


   --row number: 212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2682962 , [Content] ='06/08/18'
 WHERE id=172109579


   --row number: 213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2647613 , [Content] ='Yes'
 WHERE id=173834546


   --row number: 214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2647613 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=173834547


   --row number: 215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2647613 , [Content] ='2 - Professionals'
 WHERE id=173834548


   --row number: 216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2647613 , [Content] ='04/05/18'
 WHERE id=173834549


   --row number: 217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2647613 , [Content] ='5144 IND'
 WHERE id=173834550


   --row number: 218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2647613 , [Content] ='INR'
 WHERE id=173834551


   --row number: 219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2265417 , [Content] ='S1413 DEU'
 WHERE id=103916143


   --row number: 220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2265417 , [Content] ='Solution Consulting'
 WHERE id=103916144


   --row number: 221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2265417 , [Content] ='Solution Consultant Core'
 WHERE id=103916145


   --row number: 222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2265417 , [Content] ='4 - Sales Workers'
 WHERE id=103916160


   --row number: 223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2265417 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=103916146


   --row number: 224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2265417 , [Content] ='IC3'
 WHERE id=103916147


   --row number: 225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2265417 , [Content] ='DEU'
 WHERE id=103916149


   --row number: 226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2265417 , [Content] ='Yes'
 WHERE id=103916151


   --row number: 227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2265417 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=103916152


   --row number: 228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2265417 , [Content] ='75/25'
 WHERE id=103916153


   --row number: 229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2265417 , [Content] ='EMEA'
 WHERE id=103916156


   --row number: 230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2265417 , [Content] ='GERMANY'
 WHERE id=103916157


   --row number: 231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2265417 , [Content] ='Technical'
 WHERE id=103916158


   --row number: 232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2265417 , [Content] ='8742-Salespersons - Outside'
 WHERE id=103916159


   --row number: 233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2308967 , [Content] ='5204 UK'
 WHERE id=107997372


   --row number: 234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2308967 , [Content] ='Engineering'
 WHERE id=107997373


   --row number: 235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2308967 , [Content] ='Systems Design'
 WHERE id=107997374


   --row number: 236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2308967 , [Content] ='5204 - Staff Systems Design Engineer IC4'
 WHERE id=107997375


   --row number: 237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2308967 , [Content] ='IC4'
 WHERE id=107997376


   --row number: 238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2308967 , [Content] ='20%'
 WHERE id=107997381


   --row number: 239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2308967 , [Content] ='UK'
 WHERE id=107997378


   --row number: 240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2308967 , [Content] ='52,400 / 63,350 / 74,300 / 85,300 / 96,300'
 WHERE id=107997379


   --row number: 241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2308967 , [Content] ='Yes'
 WHERE id=107997382


   --row number: 242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2308967 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=107997383


   --row number: 243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2308967 , [Content] ='EMEA'
 WHERE id=107997386


   --row number: 244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2308967 , [Content] ='UNITED KINGDOM'
 WHERE id=107997387


   --row number: 245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2308967 , [Content] ='Technical'
 WHERE id=107997388


   --row number: 246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2308967 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=107997390


   --row number: 247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2308967 , [Content] ='2 - Professionals'
 WHERE id=107997391


   --row number: 248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2397693 , [Content] ='Technology Consultant'
 WHERE id=118792144


   --row number: 249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2397693 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=118792145


   --row number: 250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2397693 , [Content] ='IC4'
 WHERE id=118792146


   --row number: 251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2397693 , [Content] ='HKG'
 WHERE id=118792148


   --row number: 252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2397693 , [Content] ='669,500 / 950,000 / 1,230,600'
 WHERE id=118792149


   --row number: 253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2397693 , [Content] ='20%'
 WHERE id=118792151


   --row number: 254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2397693 , [Content] ='Yes'
 WHERE id=118792152


   --row number: 255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2397693 , [Content] ='575 / 1,150 / 1,725'
 WHERE id=118792153


   --row number: 256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2397693 , [Content] ='APAC'
 WHERE id=118792156


   --row number: 257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2397693 , [Content] ='Hong Kong'
 WHERE id=118792157


   --row number: 258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2397693 , [Content] ='Technical'
 WHERE id=118792158


   --row number: 259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2397693 , [Content] ='8810-Clerical Office Employees'
 WHERE id=118792159


   --row number: 260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2397693 , [Content] ='2 - Professionals'
 WHERE id=118792160


   --row number: 261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2397693 , [Content] ='5764 HKG'
 WHERE id=118792142


   --row number: 262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2397693 , [Content] ='Professional Services'
 WHERE id=118792143


   --row number: 263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2401377 , [Content] ='2894 - Sr Mgr, Delivery Mgmt M4'
 WHERE id=119053509


   --row number: 264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2401377 , [Content] ='M4'
 WHERE id=119053510


   --row number: 265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2401377 , [Content] ='JPN'
 WHERE id=119053512


   --row number: 266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2401377 , [Content] ='25%'
 WHERE id=119053513


   --row number: 267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2401377 , [Content] ='Yes'
 WHERE id=119053514


   --row number: 268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2401377 , [Content] ='815 / 1,625 / 2,435'
 WHERE id=119053515


   --row number: 269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2401377 , [Content] ='APAC'
 WHERE id=119053518


   --row number: 270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2401377 , [Content] ='Japan'
 WHERE id=119053519


   --row number: 271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2401377 , [Content] ='Technical'
 WHERE id=119053520


   --row number: 272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2401377 , [Content] ='8810-Clerical Office Employees'
 WHERE id=119053522


   --row number: 273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2401377 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=119053523


   --row number: 274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2401377 , [Content] ='2894 JPN'
 WHERE id=119053506


   --row number: 275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2401377 , [Content] ='Professional Services'
 WHERE id=119053507


   --row number: 276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2401377 , [Content] ='Delivery Mgrs'
 WHERE id=119053508


   --row number: 277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2408937 , [Content] ='EMEA'
 WHERE id=119870946


   --row number: 278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2408937 , [Content] ='Spain'
 WHERE id=119870947


   --row number: 279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2408937 , [Content] ='8810-Clerical Office Employees'
 WHERE id=119870948


   --row number: 280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2408937 , [Content] ='9999 ESP'
 WHERE id=119870940


   --row number: 281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2408937 , [Content] ='9999 - Intern'
 WHERE id=119870941


   --row number: 282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2408937 , [Content] ='ESP'
 WHERE id=119870942


   --row number: 283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2408937 , [Content] ='No'
 WHERE id=119870943


   --row number: 284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2445539 , [Content] ='APAC'
 WHERE id=122700600


   --row number: 285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2445539 , [Content] ='JAPAN'
 WHERE id=122700601


   --row number: 286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2445539 , [Content] ='Technical'
 WHERE id=122700602


   --row number: 287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2445539 , [Content] ='8810-Clerical Office Employees'
 WHERE id=122700603


   --row number: 288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2445539 , [Content] ='2 - Professionals'
 WHERE id=122700604


   --row number: 289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2445539 , [Content] ='5764 JPN'
 WHERE id=122700586


   --row number: 290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2445539 , [Content] ='Professional Services'
 WHERE id=122700587


   --row number: 291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2445539 , [Content] ='Technology Consultant'
 WHERE id=122700588


   --row number: 292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2445539 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=122700589


   --row number: 293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2445539 , [Content] ='IC4'
 WHERE id=122700590


   --row number: 294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2445539 , [Content] ='JPN'
 WHERE id=122700592


   --row number: 295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2445539 , [Content] ='8,295,800 / 10,034,000 / 11,772,200 / 13,510,350 / 15,248,500'
 WHERE id=122700593


   --row number: 296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2445539 , [Content] ='20%'
 WHERE id=122700595


   --row number: 297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2445539 , [Content] ='Yes'
 WHERE id=122700596


   --row number: 298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2445539 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=122700597


   --row number: 299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2476184 , [Content] ='IC4'
 WHERE id=124651719


   --row number: 300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2476184 , [Content] ='US - MRKT 1'
 WHERE id=124651721


   --row number: 301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2476184 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=124651722


   --row number: 302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2476184 , [Content] ='20%'
 WHERE id=124651724


   --row number: 303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2476184 , [Content] ='Yes'
 WHERE id=124651725


   --row number: 304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2476184 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=124651726


   --row number: 305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2476184 , [Content] ='EXEMPT'
 WHERE id=124651727


   --row number: 306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2476184 , [Content] ='NO'
 WHERE id=124651728


   --row number: 307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2476184 , [Content] ='AMS'
 WHERE id=124651731


   --row number: 308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2476184 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=124651732


   --row number: 309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2476184 , [Content] ='Technical'
 WHERE id=124651733


   --row number: 310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2476184 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=124651734


   --row number: 311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2476184 , [Content] ='2 - Professionals'
 WHERE id=124651735


   --row number: 312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2476184 , [Content] ='5144 US - MRKT 1'
 WHERE id=124651715


   --row number: 313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2476184 , [Content] ='Engineering'
 WHERE id=124651716


   --row number: 314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2476184 , [Content] ='Software'
 WHERE id=124651717


   --row number: 315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2476184 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=124651718


   --row number: 316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2477230 , [Content] ='Engineering'
 WHERE id=124726966


   --row number: 317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2477230 , [Content] ='Software'
 WHERE id=124726967


   --row number: 318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2477230 , [Content] ='2124 - Sr Mgr, Software Engrg Mgmt M4'
 WHERE id=124726968


   --row number: 319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2477230 , [Content] ='M4'
 WHERE id=124726969


   --row number: 320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2477230 , [Content] ='US - MRKT 1'
 WHERE id=124726971


   --row number: 321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2477230 , [Content] ='142,100 / 206,000 / 270,000'
 WHERE id=124726972


   --row number: 322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2477230 , [Content] ='25%'
 WHERE id=124726974


   --row number: 323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2477230 , [Content] ='Yes'
 WHERE id=124726975


   --row number: 324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2477230 , [Content] ='1,500 / 2,500 / 3,500'
 WHERE id=124726976


   --row number: 325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2477230 , [Content] ='EXEMPT'
 WHERE id=124726977


   --row number: 326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2477230 , [Content] ='NO'
 WHERE id=124726978


   --row number: 327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2477230 , [Content] ='AMS'
 WHERE id=124726981


   --row number: 328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2477230 , [Content] ='United States of America'
 WHERE id=124726982


   --row number: 329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2477230 , [Content] ='Technical'
 WHERE id=124726983


   --row number: 330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2477230 , [Content] ='2124 US - MRKT 1'
 WHERE id=124726965


   --row number: 331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2495299 , [Content] ='6475 - Sr Staff Network Engineer IC5'
 WHERE id=126491185


   --row number: 332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2495299 , [Content] ='IC5'
 WHERE id=126491186


   --row number: 333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2495299 , [Content] ='AUS'
 WHERE id=126491188


   --row number: 334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2495299 , [Content] ='109,000 / 158,000 / 207,100'
 WHERE id=126491189


   --row number: 335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2495299 , [Content] ='25%'
 WHERE id=126491191


   --row number: 336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2495299 , [Content] ='Yes'
 WHERE id=126491192


   --row number: 337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2495299 , [Content] ='815 / 1,625 / 2,435'
 WHERE id=126491193


   --row number: 338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2495299 , [Content] ='APAC'
 WHERE id=126491196


   --row number: 339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2495299 , [Content] ='Australia'
 WHERE id=126491197


   --row number: 340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2495299 , [Content] ='Technical'
 WHERE id=126491198


   --row number: 341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2495299 , [Content] ='8810-Clerical Office Employees'
 WHERE id=126491201


   --row number: 342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2495299 , [Content] ='2 - Professionals'
 WHERE id=126491202


   --row number: 343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2495299 , [Content] ='6475 AUS'
 WHERE id=126491182


   --row number: 344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2495299 , [Content] ='Info Systems/Technology'
 WHERE id=126491183


   --row number: 345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2495299 , [Content] ='Network Engineer'
 WHERE id=126491184


   --row number: 346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2408937 , [Content] ='Intern'
 WHERE id=130778659


   --row number: 347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2567514 , [Content] ='Info Systems/Technology'
 WHERE id=132669966


   --row number: 348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2567514 , [Content] ='Security'
 WHERE id=132669967


   --row number: 349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2567514 , [Content] ='6583 - Sr Information Security Engineer IC3'
 WHERE id=132669968


   --row number: 350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2567514 , [Content] ='IC3'
 WHERE id=132669969


   --row number: 351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2567514 , [Content] ='US - MRKT 1'
 WHERE id=132669971


   --row number: 352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2567514 , [Content] ='101,500 / 119,750 / 138,000 / 156,300 / 174,600'
 WHERE id=132669972


   --row number: 353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2567514 , [Content] ='15%'
 WHERE id=132669974


   --row number: 354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2567514 , [Content] ='Yes'
 WHERE id=132669975


   --row number: 355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2567514 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=132669976


   --row number: 356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2567514 , [Content] ='EXEMPT'
 WHERE id=132669977


   --row number: 357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2567514 , [Content] ='YES'
 WHERE id=132669978


   --row number: 358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2567514 , [Content] ='AMS'
 WHERE id=132669981


   --row number: 359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2567514 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=132669982


   --row number: 360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2567514 , [Content] ='Technical'
 WHERE id=132669983


   --row number: 361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2578329 , [Content] ='EMEA'
 WHERE id=133918092


   --row number: 362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2578329 , [Content] ='NETHERLANDS'
 WHERE id=133918093


   --row number: 363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2578329 , [Content] ='Non Technical'
 WHERE id=133918094


   --row number: 364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2578329 , [Content] ='8810-Clerical Office Employees'
 WHERE id=133918098


   --row number: 365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2578329 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=133918100


   --row number: 366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2567514 , [Content] ='6583 US - MRKT 1'
 WHERE id=132669964


   --row number: 367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2567514 , [Content] ='8810-Clerical Office Employees'
 WHERE id=132669985


   --row number: 368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2567514 , [Content] ='2 - Professionals'
 WHERE id=132669986


   --row number: 369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2568746 , [Content] ='Info Systems/Technology'
 WHERE id=132788765


   --row number: 370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2568746 , [Content] ='UI/UX Designer'
 WHERE id=132788766


   --row number: 371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2568746 , [Content] ='6803 - UI/ UX Designer IC3'
 WHERE id=132788767


   --row number: 372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2568746 , [Content] ='IC3'
 WHERE id=132788768


   --row number: 373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2568746 , [Content] ='IND'
 WHERE id=132788770


   --row number: 374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2568746 , [Content] ='965,500 / 1,182,750 / 1,400,000 / 1,617,250 / 1,834,500'
 WHERE id=132788771


   --row number: 375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2568746 , [Content] ='15%'
 WHERE id=132788773


   --row number: 376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2568746 , [Content] ='Yes'
 WHERE id=132788774


   --row number: 377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2568746 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=132788775


   --row number: 378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2568746 , [Content] ='APAC'
 WHERE id=132788778


   --row number: 379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2568746 , [Content] ='INDIA'
 WHERE id=132788779


   --row number: 380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2568746 , [Content] ='Technical'
 WHERE id=132788780


   --row number: 381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2568746 , [Content] ='8810-Clerical Office Employees'
 WHERE id=132788781


   --row number: 382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2568746 , [Content] ='2 - Professionals'
 WHERE id=132788782


   --row number: 383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2568746 , [Content] ='6803 IND'
 WHERE id=132788764


   --row number: 384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2673950 , [Content] ='IC4'
 WHERE id=143967821


   --row number: 385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2673950 , [Content] ='US - MRKT 3'
 WHERE id=143967823


   --row number: 386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2673950 , [Content] ='77,300 / 91,200 / 105,100 / 119,050 / 133,000'
 WHERE id=143967824


   --row number: 387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2673950 , [Content] ='15%'
 WHERE id=143967826


   --row number: 388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2673950 , [Content] ='Yes'
 WHERE id=143967827


   --row number: 389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2673950 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=143967828


   --row number: 390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2673950 , [Content] ='EXEMPT'
 WHERE id=143967829


   --row number: 391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2673950 , [Content] ='AMS'
 WHERE id=143967832


   --row number: 392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2673950 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=143967833


   --row number: 393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2673950 , [Content] ='Technical'
 WHERE id=143967834


   --row number: 394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2673950 , [Content] ='8810-Clerical Office Employees'
 WHERE id=143967835


   --row number: 395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2673950 , [Content] ='2 - Professionals'
 WHERE id=143967836


   --row number: 396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2673950 , [Content] ='5894 US - MRKT 3'
 WHERE id=143967817


   --row number: 397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2673950 , [Content] ='Professional Services'
 WHERE id=143967818


   --row number: 398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2673950 , [Content] ='Technical Curriculum'
 WHERE id=143967819


   --row number: 399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2673950 , [Content] ='5894 - Technical Curriculum Developer IC4'
 WHERE id=143967820


   --row number: 400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2677442 , [Content] ='IC3'
 WHERE id=144279623


   --row number: 401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2677442 , [Content] ='US - MRKT 1'
 WHERE id=144279625


   --row number: 402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2677442 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=144279626


   --row number: 403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2677442 , [Content] ='15%'
 WHERE id=144279628


   --row number: 404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2677442 , [Content] ='Yes'
 WHERE id=144279629


   --row number: 405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2677442 , [Content] ='Engineering'
 WHERE id=144279620


   --row number: 406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2677442 , [Content] ='Software'
 WHERE id=144279621


   --row number: 407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2677442 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=144279622


   --row number: 408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2682172 , [Content] ='IT Systems/Support'
 WHERE id=144755312


   --row number: 409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2682172 , [Content] ='NO'
 WHERE id=144755323


   --row number: 410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2682172 , [Content] ='AMS'
 WHERE id=144755326


   --row number: 411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2682172 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=144755327


   --row number: 412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2682172 , [Content] ='Technical'
 WHERE id=144755328


   --row number: 413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2682172 , [Content] ='8810-Clerical Office Employees'
 WHERE id=144755330


   --row number: 414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2682172 , [Content] ='2 - Professionals'
 WHERE id=144755331


   --row number: 415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2682172 , [Content] ='6572 - IT Systems/Support Analyst IC2'
 WHERE id=144755313


   --row number: 416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2682172 , [Content] ='IC2'
 WHERE id=144755314


   --row number: 417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2682172 , [Content] ='US - MRKT 2'
 WHERE id=144755316


   --row number: 418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2682172 , [Content] ='52,000 / 59,400 / 66,800 / 74,200 / 81,600'
 WHERE id=144755317


   --row number: 419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2682172 , [Content] ='10%'
 WHERE id=144755319


   --row number: 420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2682172 , [Content] ='Yes'
 WHERE id=144755320


   --row number: 421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2682172 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=144755321


   --row number: 422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2682172 , [Content] ='6572 US - MRKT 2'
 WHERE id=144755310


   --row number: 423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2682172 , [Content] ='Info Systems/Technology'
 WHERE id=144755311


   --row number: 424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2682172 , [Content] ='NON-EXEMPT'
 WHERE id=144755322


   --row number: 425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2677442 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=144279630


   --row number: 426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2677442 , [Content] ='EXEMPT'
 WHERE id=144279631


   --row number: 427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2677442 , [Content] ='NO'
 WHERE id=144279632


   --row number: 428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2677442 , [Content] ='AMS'
 WHERE id=144279635


   --row number: 429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2677442 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=144279636


   --row number: 430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2677442 , [Content] ='Technical'
 WHERE id=144279637


   --row number: 431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2677442 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=144279639


   --row number: 432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2677442 , [Content] ='2 - Professionals'
 WHERE id=144279640


   --row number: 433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2683667 , [Content] ='S1415 CHE'
 WHERE id=144879733


   --row number: 434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2683667 , [Content] ='Solution Consulting'
 WHERE id=144879734


   --row number: 435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2683667 , [Content] ='Solution Consultant Core'
 WHERE id=144879735


   --row number: 436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2683667 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=144879736


   --row number: 437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2683667 , [Content] ='IC5'
 WHERE id=144879737


   --row number: 438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2683667 , [Content] ='EMEA'
 WHERE id=144879746


   --row number: 439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2683667 , [Content] ='SWITZERLAND'
 WHERE id=144879747


   --row number: 440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2683667 , [Content] ='Technical'
 WHERE id=144879748


   --row number: 441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2683667 , [Content] ='8742-Salespersons - Outside'
 WHERE id=144879749


   --row number: 442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2683667 , [Content] ='4 - Sales Workers'
 WHERE id=144879750


   --row number: 443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2683667 , [Content] ='CHE'
 WHERE id=144879739


   --row number: 444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2683667 , [Content] ='Yes'
 WHERE id=144879741


   --row number: 445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2683667 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=144879742


   --row number: 446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2683667 , [Content] ='75/25'
 WHERE id=144879743


   --row number: 447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2684900 , [Content] ='AUS'
 WHERE id=144969927


   --row number: 448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2684900 , [Content] ='78,200 / 92,250 / 106,300 / 120,400 / 134,500'
 WHERE id=144969928


   --row number: 449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2684900 , [Content] ='15%'
 WHERE id=144969930


   --row number: 450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2684900 , [Content] ='Yes'
 WHERE id=144969931


   --row number: 451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2684900 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=144969932


   --row number: 452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=2705173 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=146404799


   --row number: 453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2705173 , [Content] ='10%'
 WHERE id=146404800


   --row number: 454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2705173 , [Content] ='AMS'
 WHERE id=146404801


   --row number: 455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2705173 , [Content] ='Yes'
 WHERE id=146404802


   --row number: 456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2705173 , [Content] ='6482NE US - MRKT 2'
 WHERE id=146404803


   --row number: 457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2705173 , [Content] ='8810-Clerical Office Employees'
 WHERE id=146404804


   --row number: 458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2705173 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=146404805


   --row number: 459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2705173 , [Content] ='2 - Professionals'
 WHERE id=146404806


   --row number: 460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2705173 , [Content] ='6482NE - Production Service Engineer IC2 - (NE)'
 WHERE id=146404807


   --row number: 461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2705173 , [Content] ='IC2'
 WHERE id=146404808


   --row number: 462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2705173 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=146404809


   --row number: 463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2705173 , [Content] ='Technical'
 WHERE id=146404810


   --row number: 464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2684900 , [Content] ='APAC'
 WHERE id=144969935


   --row number: 465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2684900 , [Content] ='AUSTRALIA'
 WHERE id=144969936


   --row number: 466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2684900 , [Content] ='Technical'
 WHERE id=144969937


   --row number: 467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2684900 , [Content] ='5823 AUS'
 WHERE id=144969921


   --row number: 468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2684900 , [Content] ='Customer Support'
 WHERE id=144969922


   --row number: 469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2684900 , [Content] ='Technical Support'
 WHERE id=144969923


   --row number: 470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2684900 , [Content] ='8810-Clerical Office Employees'
 WHERE id=144969939


   --row number: 471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2684900 , [Content] ='2 - Professionals'
 WHERE id=144969940


   --row number: 472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2684900 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=144969924


   --row number: 473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2684900 , [Content] ='IC3'
 WHERE id=144969925


   --row number: 474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2705173 , [Content] ='NON-EXEMPT'
 WHERE id=146404794


   --row number: 475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2705173 , [Content] ='YES'
 WHERE id=146404795


   --row number: 476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2705173 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=146404796


   --row number: 477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2705173 , [Content] ='65,000 / 75,700 / 86,400 / 97,150 / 107,900'
 WHERE id=146404797


   --row number: 478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2705173 , [Content] ='Production service'
 WHERE id=146404790


   --row number: 479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2705173 , [Content] ='US - MRKT 2'
 WHERE id=146404792


   --row number: 480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2445539 , [Content] ='04/05/18'
 WHERE id=172098850


   --row number: 481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2445539 , [Content] ='JPY'
 WHERE id=172098851


   --row number: 482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2568746 , [Content] ='04/05/18'
 WHERE id=172099816


   --row number: 483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2308967 , [Content] ='GBP'
 WHERE id=172102395


   --row number: 484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2568746 , [Content] ='INR'
 WHERE id=172099820


   --row number: 485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2308967 , [Content] ='04/05/18'
 WHERE id=172102390


   --row number: 486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2567514 , [Content] ='4/25/2018'
 WHERE id=172103993


   --row number: 487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2567514 , [Content] ='USD'
 WHERE id=172103997


   --row number: 488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2578329 , [Content] ='04/05/18'
 WHERE id=172105191


   --row number: 489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2677442 , [Content] ='5/16/2018'
 WHERE id=164944520


   --row number: 490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2677442 , [Content] ='5143 US - MRKT 1'
 WHERE id=164944521


   --row number: 491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2677442 , [Content] ='USD'
 WHERE id=164944522


   --row number: 492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2578329 , [Content] ='EUR'
 WHERE id=172105195


   --row number: 493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2684900 , [Content] ='04/05/18'
 WHERE id=172106501


   --row number: 494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2673950 , [Content] ='04/05/18'
 WHERE id=172110267


   --row number: 495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2673950 , [Content] ='USD'
 WHERE id=172110272


   --row number: 496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2705173 , [Content] ='04/05/18'
 WHERE id=172112027


   --row number: 497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2705173 , [Content] ='USD'
 WHERE id=172112032


   --row number: 498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2682172 , [Content] ='04/05/18'
 WHERE id=172110656


   --row number: 499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2682172 , [Content] ='USD'
 WHERE id=172110660


   --row number: 500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2683667 , [Content] ='04/05/18'
 WHERE id=172116714


   --row number: 501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2683667 , [Content] ='199,750 / 217,375 / 235,000 / 252,625 / 270,250'
 WHERE id=172116715


   --row number: 502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2683667 , [Content] ='149,813 / 163,031 / 176,250 / 189,469 / 202,688'
 WHERE id=172116718


   --row number: 503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=2567514 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=179138615


   --row number: 504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2683667 , [Content] ='CHF'
 WHERE id=172116721


   --row number: 505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2476184 , [Content] ='USD'
 WHERE id=174497319


   --row number: 506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2476184 , [Content] ='5/22/2018'
 WHERE id=174497314


   --row number: 507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2265417 , [Content] ='EUR'
 WHERE id=172335706


   --row number: 508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2265417 , [Content] ='04/05/18'
 WHERE id=172335699


   --row number: 509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2265417 , [Content] ='85,000 / 92,500 / 100,000 / 107,500 / 115,000'
 WHERE id=172335700


   --row number: 510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2265417 , [Content] ='63,750 / 69,375 / 75,000 / 80,625 / 86,250'
 WHERE id=172335703


   --row number: 511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2620072 , [Content] ='S1516 US - MRKT 1'
 WHERE id=138558974


   --row number: 512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2620072 , [Content] ='Solution Architect'
 WHERE id=138558976


   --row number: 513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2620072 , [Content] ='S1516 - PS, Solution Architect IC6'
 WHERE id=138558977


   --row number: 514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2620072 , [Content] ='IC6'
 WHERE id=138558978


   --row number: 515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2620072 , [Content] ='US - MRKT 1'
 WHERE id=138558980


   --row number: 516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2620072 , [Content] ='144,800 / 177,400 / 210,000 / 242,550 / 275,100'
 WHERE id=138558981


   --row number: 517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2620072 , [Content] ='25%'
 WHERE id=138558983


   --row number: 518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2620072 , [Content] ='Yes'
 WHERE id=138558984


   --row number: 519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2620072 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=138558985


   --row number: 520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2620072 , [Content] ='EXEMPT'
 WHERE id=138558986


   --row number: 521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2620072 , [Content] ='NO'
 WHERE id=138558987


   --row number: 522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2620072 , [Content] ='AMS'
 WHERE id=138558990


   --row number: 523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2620072 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=138558991


   --row number: 524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2620072 , [Content] ='Technical'
 WHERE id=138558992


   --row number: 525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2620072 , [Content] ='8810-Clerical Office Employees'
 WHERE id=138558994


   --row number: 526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2620072 , [Content] ='4 - Sales Workers'
 WHERE id=138558995


   --row number: 527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2620072 , [Content] ='Professional Services'
 WHERE id=138558975


   --row number: 528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2684930 , [Content] ='Security'
 WHERE id=144975287


   --row number: 529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2684930 , [Content] ='6582 - Information Security Engineer IC2'
 WHERE id=144975288


   --row number: 530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2684930 , [Content] ='IC2'
 WHERE id=144975289


   --row number: 531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2684930 , [Content] ='IND'
 WHERE id=144975291


   --row number: 532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2684930 , [Content] ='748,300 / 916,650 / 1,085,000 / 1,253,400 / 1,421,800'
 WHERE id=144975292


   --row number: 533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2684930 , [Content] ='10%'
 WHERE id=144975294


   --row number: 534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2684930 , [Content] ='No'
 WHERE id=144975295


   --row number: 535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2684930 , [Content] ='APAC'
 WHERE id=144975299


   --row number: 536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2684930 , [Content] ='INDIA'
 WHERE id=144975300


   --row number: 537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2684930 , [Content] ='Technical'
 WHERE id=144975301


   --row number: 538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2684930 , [Content] ='8810-Clerical Office Employees'
 WHERE id=144975302


   --row number: 539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2684930 , [Content] ='2 - Professionals'
 WHERE id=144975303


   --row number: 540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2684930 , [Content] ='6582 IND'
 WHERE id=144975285


   --row number: 541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2684930 , [Content] ='Info Systems/Technology'
 WHERE id=144975286


   --row number: 542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2685710 , [Content] ='UI/UX Designer'
 WHERE id=145025536


   --row number: 543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2685710 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=145025537


   --row number: 544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2685710 , [Content] ='IC4'
 WHERE id=145025538


   --row number: 545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2685710 , [Content] ='US - MRKT 1'
 WHERE id=145025540


   --row number: 546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2685710 , [Content] ='110,800 / 134,000 / 157,200 / 180,450 / 203,700'
 WHERE id=145025541


   --row number: 547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2685710 , [Content] ='20%'
 WHERE id=145025543


   --row number: 548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2685710 , [Content] ='Yes'
 WHERE id=145025544


   --row number: 549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2685710 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=145025545


   --row number: 550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2685710 , [Content] ='EXEMPT'
 WHERE id=145025546


   --row number: 551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2685710 , [Content] ='NO'
 WHERE id=145025547


   --row number: 552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2685710 , [Content] ='AMS'
 WHERE id=145025550


   --row number: 553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2685710 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=145025551


   --row number: 554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2685710 , [Content] ='Technical'
 WHERE id=145025552


   --row number: 555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2685710 , [Content] ='8810-Clerical Office Employees'
 WHERE id=145025554


   --row number: 556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2685710 , [Content] ='2 - Professionals'
 WHERE id=145025555


   --row number: 557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2685710 , [Content] ='6804 US - MRKT 1'
 WHERE id=145025534


   --row number: 558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2584097 , [Content] ='US - MRKT 1'
 WHERE id=134291406


   --row number: 559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2584097 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=134291407


   --row number: 560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2584097 , [Content] ='20%'
 WHERE id=134291409


   --row number: 561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2584097 , [Content] ='Yes'
 WHERE id=134291410


   --row number: 562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2584097 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=134291411


   --row number: 563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2584097 , [Content] ='EXEMPT'
 WHERE id=134291412


   --row number: 564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2584097 , [Content] ='NO'
 WHERE id=134291413


   --row number: 565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2584097 , [Content] ='AMS'
 WHERE id=134291416


   --row number: 566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2584097 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=134291417


   --row number: 567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2584097 , [Content] ='Technical'
 WHERE id=134291418


   --row number: 568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2584097 , [Content] ='8810-Clerical Office Employees'
 WHERE id=134291419


   --row number: 569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2584097 , [Content] ='2 - Professionals'
 WHERE id=134291420


   --row number: 570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2685710 , [Content] ='Info Systems/Technology'
 WHERE id=145025535


   --row number: 571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2584097 , [Content] ='5764 US - MRKT 1'
 WHERE id=134291400


   --row number: 572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2584097 , [Content] ='Professional Services'
 WHERE id=134291401


   --row number: 573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2584097 , [Content] ='Technology Consultant'
 WHERE id=134291402


   --row number: 574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2584097 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=134291403


   --row number: 575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2584097 , [Content] ='IC4'
 WHERE id=134291404


   --row number: 576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2690533 , [Content] ='Business Strategy'
 WHERE id=145590402


   --row number: 577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2690533 , [Content] ='Business Strategy'
 WHERE id=145590403


   --row number: 578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2690533 , [Content] ='5673 - Business Strategy Mgr IC3'
 WHERE id=145590404


   --row number: 579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2690533 , [Content] ='IC3'
 WHERE id=145590405


   --row number: 580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2690533 , [Content] ='US - MRKT 1'
 WHERE id=145590407


   --row number: 581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2690533 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=145590408


   --row number: 582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2690533 , [Content] ='15%'
 WHERE id=145590410


   --row number: 583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2690533 , [Content] ='Yes'
 WHERE id=145590411


   --row number: 584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2690533 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=145590412


   --row number: 585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2690533 , [Content] ='EXEMPT'
 WHERE id=145590413


   --row number: 586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2690533 , [Content] ='NO'
 WHERE id=145590414


   --row number: 587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2690533 , [Content] ='AMS'
 WHERE id=145590417


   --row number: 588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2690533 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=145590418


   --row number: 589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2690533 , [Content] ='Non Technical'
 WHERE id=145590419


   --row number: 590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2690533 , [Content] ='8810-Clerical Office Employees'
 WHERE id=145590420


   --row number: 591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2690533 , [Content] ='2 - Professionals'
 WHERE id=145590421


   --row number: 592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2691507 , [Content] ='5224 IND'
 WHERE id=145677091


   --row number: 593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2691507 , [Content] ='Engineering'
 WHERE id=145677092


   --row number: 594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2691507 , [Content] ='Product Mgmt Mgr'
 WHERE id=145677093


   --row number: 595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2691507 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=145677094


   --row number: 596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2691507 , [Content] ='IC4'
 WHERE id=145677095


   --row number: 597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2691507 , [Content] ='IND'
 WHERE id=145677097


   --row number: 598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2691507 , [Content] ='2,310,300 / 2,830,150 / 3,350,000 / 3,869,800 / 4,389,600'
 WHERE id=145677098


   --row number: 599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2691507 , [Content] ='20%'
 WHERE id=145677100


   --row number: 600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2691507 , [Content] ='Yes'
 WHERE id=145677101


   --row number: 601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2691507 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=145677102


   --row number: 602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2691507 , [Content] ='APAC'
 WHERE id=145677105


   --row number: 603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2691507 , [Content] ='INDIA'
 WHERE id=145677106


   --row number: 604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2691507 , [Content] ='Technical'
 WHERE id=145677107


   --row number: 605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2691507 , [Content] ='8810-Clerical Office Employees'
 WHERE id=145677108


   --row number: 606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2691507 , [Content] ='2 - Professionals'
 WHERE id=145677109


   --row number: 607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2704765 , [Content] ='S1414 DEU'
 WHERE id=146168928


   --row number: 608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2704765 , [Content] ='Solution Consulting'
 WHERE id=146168929


   --row number: 609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2704765 , [Content] ='Solution Consultant Core'
 WHERE id=146168930


   --row number: 610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2704765 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=146168931


   --row number: 611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2704765 , [Content] ='IC4'
 WHERE id=146168932


   --row number: 612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2704765 , [Content] ='DEU'
 WHERE id=146168934


   --row number: 613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2704765 , [Content] ='Yes'
 WHERE id=146168936


   --row number: 614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2704765 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=146168937


   --row number: 615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2704765 , [Content] ='75/25'
 WHERE id=146168938


   --row number: 616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2704765 , [Content] ='EMEA'
 WHERE id=146168941


   --row number: 617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2704765 , [Content] ='GERMANY'
 WHERE id=146168942


   --row number: 618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2704765 , [Content] ='Technical'
 WHERE id=146168943


   --row number: 619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2704765 , [Content] ='8742-Salespersons - Outside'
 WHERE id=146168944


   --row number: 620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2704765 , [Content] ='4 - Sales Workers'
 WHERE id=146168945


   --row number: 621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2708835 , [Content] ='Production service'
 WHERE id=146394400


   --row number: 622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2708835 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=146394401


   --row number: 623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2708835 , [Content] ='IC3'
 WHERE id=146394402


   --row number: 624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2708835 , [Content] ='AUS'
 WHERE id=146394404


   --row number: 625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2708835 , [Content] ='101,200 / 119,400 / 137,600 / 155,850 / 174,100'
 WHERE id=146394405


   --row number: 626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2708835 , [Content] ='15%'
 WHERE id=146394407


   --row number: 627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2708835 , [Content] ='Yes'
 WHERE id=146394408


   --row number: 628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2708835 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=146394409


   --row number: 629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2708835 , [Content] ='APAC'
 WHERE id=146394412


   --row number: 630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2708835 , [Content] ='AUSTRALIA'
 WHERE id=146394413


   --row number: 631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2708835 , [Content] ='Technical'
 WHERE id=146394414


   --row number: 632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2708835 , [Content] ='8810-Clerical Office Employees'
 WHERE id=146394415


   --row number: 633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2708835 , [Content] ='2 - Professionals'
 WHERE id=146394416


   --row number: 634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2690533 , [Content] ='5673 US - MRKT 1'
 WHERE id=146286901


   --row number: 635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2710368 , [Content] ='6482NE US - MRKT 2'
 WHERE id=146525270


   --row number: 636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=2710368 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=146525271


   --row number: 637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2710368 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=146525272


   --row number: 638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2710368 , [Content] ='Production service'
 WHERE id=146525273


   --row number: 639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2710368 , [Content] ='6482NE - Production Service Engineer IC2 - (NE)'
 WHERE id=146525274


   --row number: 640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2710368 , [Content] ='IC2'
 WHERE id=146525275


   --row number: 641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2710368 , [Content] ='US - MRKT 2'
 WHERE id=146525277


   --row number: 642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2710368 , [Content] ='65,000 / 75,700 / 86,400 / 97,150 / 107,900'
 WHERE id=146525278


   --row number: 643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2710368 , [Content] ='10%'
 WHERE id=146525280


   --row number: 644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2710368 , [Content] ='Yes'
 WHERE id=146525281


   --row number: 645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2710368 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=146525282


   --row number: 646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2710368 , [Content] ='NON-EXEMPT'
 WHERE id=146525283


   --row number: 647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2710368 , [Content] ='YES'
 WHERE id=146525284


   --row number: 648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2710368 , [Content] ='AMS'
 WHERE id=146525287


   --row number: 649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2710368 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=146525288


   --row number: 650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2710368 , [Content] ='Technical'
 WHERE id=146525289


   --row number: 651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2710368 , [Content] ='8810-Clerical Office Employees'
 WHERE id=146525290


   --row number: 652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2708835 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=146394399


   --row number: 653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2709500 , [Content] ='5204 - Staff Systems Design Engineer IC4'
 WHERE id=146461180


   --row number: 654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2709500 , [Content] ='IC4'
 WHERE id=146461181


   --row number: 655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2709500 , [Content] ='UK'
 WHERE id=146461183


   --row number: 656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2709500 , [Content] ='52,400 / 63,350 / 74,300 / 85,300 / 96,300'
 WHERE id=146461184


   --row number: 657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2709500 , [Content] ='20%'
 WHERE id=146461186


   --row number: 658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2709500 , [Content] ='Yes'
 WHERE id=146461187


   --row number: 659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2709500 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=146461188


   --row number: 660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2709500 , [Content] ='EMEA'
 WHERE id=146461191


   --row number: 661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2709500 , [Content] ='UNITED KINGDOM'
 WHERE id=146461192


   --row number: 662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2709500 , [Content] ='Technical'
 WHERE id=146461193


   --row number: 663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2709500 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=146461195


   --row number: 664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2709500 , [Content] ='2 - Professionals'
 WHERE id=146461196


   --row number: 665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2709500 , [Content] ='5204 UK'
 WHERE id=146461177


   --row number: 666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2709500 , [Content] ='Engineering'
 WHERE id=146461178


   --row number: 667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2709500 , [Content] ='Systems Design'
 WHERE id=146461179


   --row number: 668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2710368 , [Content] ='2 - Professionals'
 WHERE id=146525291


   --row number: 669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2716658 , [Content] ='5823 AUS'
 WHERE id=153507056


   --row number: 670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2716658 , [Content] ='Customer Support'
 WHERE id=153507057


   --row number: 671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2716658 , [Content] ='Technical Support'
 WHERE id=153507058


   --row number: 672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2716658 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=153507059


   --row number: 673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2716658 , [Content] ='IC3'
 WHERE id=153507060


   --row number: 674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2716658 , [Content] ='AUS'
 WHERE id=153507062


   --row number: 675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2716658 , [Content] ='78,200 / 92,250 / 106,300 / 120,400 / 134,500'
 WHERE id=153507063


   --row number: 676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2716658 , [Content] ='Yes'
 WHERE id=153507066


   --row number: 677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2716658 , [Content] ='APAC'
 WHERE id=153507070


   --row number: 678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2716658 , [Content] ='AUSTRALIA'
 WHERE id=153507071


   --row number: 679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2716658 , [Content] ='Technical'
 WHERE id=153507072


   --row number: 680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2716658 , [Content] ='8810-Clerical Office Employees'
 WHERE id=153507073


   --row number: 681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2716658 , [Content] ='2 - Professionals'
 WHERE id=153507074


   --row number: 682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2716706 , [Content] ='IC4'
 WHERE id=153514986


   --row number: 683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2716706 , [Content] ='5144 IND'
 WHERE id=153514982


   --row number: 684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2716706 , [Content] ='Engineering'
 WHERE id=153514983


   --row number: 685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2716706 , [Content] ='Software'
 WHERE id=153514984


   --row number: 686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2716706 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=153514985


   --row number: 687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2732449 , [Content] ='Technical'
 WHERE id=154733659


   --row number: 688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2732449 , [Content] ='S635 US - MRKT 1'
 WHERE id=154733642


   --row number: 689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2732449 , [Content] ='Sales'
 WHERE id=154733643


   --row number: 690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2732449 , [Content] ='Enterprise Accounts'
 WHERE id=154733644


   --row number: 691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2732449 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=154733645


   --row number: 692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2732449 , [Content] ='IC5'
 WHERE id=154733646


   --row number: 693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2732449 , [Content] ='US - MRKT 1'
 WHERE id=154733648


   --row number: 694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2732449 , [Content] ='Yes'
 WHERE id=154733650


   --row number: 695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2732449 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=154733651


   --row number: 696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2732449 , [Content] ='50/50'
 WHERE id=154733652


   --row number: 697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2732449 , [Content] ='EXEMPT'
 WHERE id=154733653


   --row number: 698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2732449 , [Content] ='NO'
 WHERE id=154733654


   --row number: 699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2732449 , [Content] ='8742-Salespersons - Outside'
 WHERE id=154733661


   --row number: 700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2732449 , [Content] ='AMS'
 WHERE id=154733657


   --row number: 701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2732449 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=154733658


   --row number: 702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2732449 , [Content] ='4 - Sales Workers'
 WHERE id=154733662


   --row number: 703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2732695 , [Content] ='Partner Support'
 WHERE id=154753555


   --row number: 704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2732695 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=154753556


   --row number: 705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2732695 , [Content] ='IC5'
 WHERE id=154753557


   --row number: 706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2732695 , [Content] ='AUS'
 WHERE id=154753559


   --row number: 707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2732695 , [Content] ='120,800 / 148,000 / 175,200 / 202,350 / 229,500'
 WHERE id=154753560


   --row number: 708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2732695 , [Content] ='25%'
 WHERE id=154753562


   --row number: 709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2732695 , [Content] ='Yes'
 WHERE id=154753563


   --row number: 710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2732695 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=154753564


   --row number: 711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2732695 , [Content] ='APAC'
 WHERE id=154753567


   --row number: 712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2732695 , [Content] ='AUSTRALIA'
 WHERE id=154753568


   --row number: 713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2732695 , [Content] ='Technical'
 WHERE id=154753569


   --row number: 714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2732695 , [Content] ='8810-Clerical Office Employees'
 WHERE id=154753570


   --row number: 715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2732695 , [Content] ='2 - Professionals'
 WHERE id=154753571


   --row number: 716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2732695 , [Content] ='5705 AUS'
 WHERE id=154753553


   --row number: 717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2732695 , [Content] ='Professional Services'
 WHERE id=154753554


   --row number: 718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2732699 , [Content] ='IC5'
 WHERE id=154754100


   --row number: 719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2732699 , [Content] ='JPN'
 WHERE id=154754102


   --row number: 720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2732699 , [Content] ='9,964,800 / 12,206,900 / 14,449,000 / 16,691,050 / 18,933,100'
 WHERE id=154754103


   --row number: 721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2732699 , [Content] ='25%'
 WHERE id=154754105


   --row number: 722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2732699 , [Content] ='Yes'
 WHERE id=154754106


   --row number: 723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2732699 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=154754107


   --row number: 724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2732699 , [Content] ='APAC'
 WHERE id=154754110


   --row number: 725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2732699 , [Content] ='JAPAN'
 WHERE id=154754111


   --row number: 726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2732699 , [Content] ='Technical'
 WHERE id=154754112


   --row number: 727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2732699 , [Content] ='8810-Clerical Office Employees'
 WHERE id=154754113


   --row number: 728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2732699 , [Content] ='2 - Professionals'
 WHERE id=154754114


   --row number: 729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2732699 , [Content] ='5705 JPN'
 WHERE id=154754096


   --row number: 730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2732699 , [Content] ='Professional Services'
 WHERE id=154754097


   --row number: 731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2732699 , [Content] ='Partner Support'
 WHERE id=154754098


   --row number: 732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2732699 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=154754099


   --row number: 733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2691503 , [Content] ='2,917,200 / 3,573,600 / 4,230,000 / 4,886,350 / 5,542,700'
 WHERE id=155149688


   --row number: 734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2691503 , [Content] ='25%'
 WHERE id=155149689


   --row number: 735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2691503 , [Content] ='APAC'
 WHERE id=155149690


   --row number: 736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2691503 , [Content] ='Yes'
 WHERE id=155149691


   --row number: 737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2691503 , [Content] ='5225 IND'
 WHERE id=155149692


   --row number: 738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2691503 , [Content] ='8810-Clerical Office Employees'
 WHERE id=155149693


   --row number: 739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2691503 , [Content] ='Engineering'
 WHERE id=155149694


   --row number: 740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2691503 , [Content] ='2 - Professionals'
 WHERE id=155149695


   --row number: 741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2691503 , [Content] ='Product Mgmt Mgr'
 WHERE id=155149683


   --row number: 742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2691503 , [Content] ='IND'
 WHERE id=155149685


   --row number: 743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2691503 , [Content] ='117,000 / 163,500 / 210,000 / 256,500 / 303,000'
 WHERE id=155149687


   --row number: 744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2691503 , [Content] ='5225 - Sr. Staff Product Mgmt Mgr IC5'
 WHERE id=155149696


   --row number: 745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2691503 , [Content] ='IC5'
 WHERE id=155149697


   --row number: 746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2691503 , [Content] ='INDIA'
 WHERE id=155149698


   --row number: 747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2691503 , [Content] ='Technical'
 WHERE id=155149699


   --row number: 748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2716658 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=155156887


   --row number: 749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2716658 , [Content] ='15%'
 WHERE id=155156888


   --row number: 750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2743672 , [Content] ='US - MRKT 2'
 WHERE id=155881400


   --row number: 751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2743672 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=155881401


   --row number: 752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2743672 , [Content] ='20%'
 WHERE id=155881403


   --row number: 753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2743672 , [Content] ='Yes'
 WHERE id=155881404


   --row number: 754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2743672 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=155881405


   --row number: 755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2743672 , [Content] ='EXEMPT'
 WHERE id=155881406


   --row number: 756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2743672 , [Content] ='Technical'
 WHERE id=155881412


   --row number: 757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2743672 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=155881413


   --row number: 758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2743672 , [Content] ='2 - Professionals'
 WHERE id=155881414


   --row number: 759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2743672 , [Content] ='NO'
 WHERE id=155881407


   --row number: 760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2743672 , [Content] ='5144 US - MRKT 2'
 WHERE id=155881394


   --row number: 761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2743672 , [Content] ='Engineering'
 WHERE id=155881395


   --row number: 762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2743672 , [Content] ='Software'
 WHERE id=155881396


   --row number: 763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2743672 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=155881397


   --row number: 764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2743672 , [Content] ='IC4'
 WHERE id=155881398


   --row number: 765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2743672 , [Content] ='AMS'
 WHERE id=155881410


   --row number: 766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2743672 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=155881411


   --row number: 767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2747639 , [Content] ='Software'
 WHERE id=156269899


   --row number: 768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2747639 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=156269900


   --row number: 769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2747639 , [Content] ='IC4'
 WHERE id=156269901


   --row number: 770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2747639 , [Content] ='IND'
 WHERE id=156269903


   --row number: 771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2747639 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=156269904


   --row number: 772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2747639 , [Content] ='20%'
 WHERE id=156269906


   --row number: 773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2747639 , [Content] ='Yes'
 WHERE id=156269907


   --row number: 774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2747639 , [Content] ='5144 IND'
 WHERE id=156269897


   --row number: 775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2747639 , [Content] ='Engineering'
 WHERE id=156269898


   --row number: 776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2747639 , [Content] ='APAC'
 WHERE id=156269910


   --row number: 777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2747639 , [Content] ='INDIA'
 WHERE id=156269911


   --row number: 778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2747639 , [Content] ='Technical'
 WHERE id=156269912


   --row number: 779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2747639 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=156269913


   --row number: 780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2747639 , [Content] ='2 - Professionals'
 WHERE id=156269914


   --row number: 781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2752837 , [Content] ='UK'
 WHERE id=156856634


   --row number: 782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2752837 , [Content] ='35,100 / 41,400 / 47,700 / 54,050 / 60,400'
 WHERE id=156856635


   --row number: 783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2752837 , [Content] ='15%'
 WHERE id=156856637


   --row number: 784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2752837 , [Content] ='Yes'
 WHERE id=156856638


   --row number: 785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2752837 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=156856639


   --row number: 786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2752837 , [Content] ='EMEA'
 WHERE id=156856642


   --row number: 787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2752837 , [Content] ='UNITED KINGDOM'
 WHERE id=156856643


   --row number: 788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2752837 , [Content] ='Technical'
 WHERE id=156856644


   --row number: 789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2752837 , [Content] ='8810-Clerical Office Employees'
 WHERE id=156856646


   --row number: 790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2752837 , [Content] ='2 - Professionals'
 WHERE id=156856647


   --row number: 791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2752837 , [Content] ='5823 UK'
 WHERE id=156856628


   --row number: 792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2752837 , [Content] ='Customer Support'
 WHERE id=156856629


   --row number: 793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2752837 , [Content] ='Technical Support'
 WHERE id=156856630


   --row number: 794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2752837 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=156856631


   --row number: 795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2752837 , [Content] ='IC3'
 WHERE id=156856632


   --row number: 796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2756326 , [Content] ='6483 IND'
 WHERE id=157011703


   --row number: 797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2756326 , [Content] ='Cloud Operations/Infrastructure'
 WHERE id=157011704


   --row number: 798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2756326 , [Content] ='Production service'
 WHERE id=157011705


   --row number: 799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2756326 , [Content] ='6483 - Sr Production Service Engineer IC3'
 WHERE id=157011706


   --row number: 800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2756326 , [Content] ='IC3'
 WHERE id=157011707


   --row number: 801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2756326 , [Content] ='IND'
 WHERE id=157011709


   --row number: 802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2756326 , [Content] ='1,206,900 / 1,478,450 / 1,750,000 / 2,021,550 / 2,293,100'
 WHERE id=157011710


   --row number: 803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2756326 , [Content] ='15%'
 WHERE id=157011712


   --row number: 804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2756326 , [Content] ='Yes'
 WHERE id=157011713


   --row number: 805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2756326 , [Content] ='APAC'
 WHERE id=157011716


   --row number: 806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2756326 , [Content] ='INDIA'
 WHERE id=157011717


   --row number: 807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2756326 , [Content] ='Technical'
 WHERE id=157011718


   --row number: 808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2756326 , [Content] ='8810-Clerical Office Employees'
 WHERE id=157011719


   --row number: 809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2756326 , [Content] ='2 - Professionals'
 WHERE id=157011720


   --row number: 810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2758925 , [Content] ='Software'
 WHERE id=157221042


   --row number: 811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2758925 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=157221043


   --row number: 812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2758925 , [Content] ='IC4'
 WHERE id=157221044


   --row number: 813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2758925 , [Content] ='IND'
 WHERE id=157221046


   --row number: 814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2758925 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=157221047


   --row number: 815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2758925 , [Content] ='20%'
 WHERE id=157221049


   --row number: 816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2758925 , [Content] ='Yes'
 WHERE id=157221050


   --row number: 817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2758925 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=157221051


   --row number: 818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2758925 , [Content] ='APAC'
 WHERE id=157221054


   --row number: 819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2758925 , [Content] ='INDIA'
 WHERE id=157221055


   --row number: 820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2758925 , [Content] ='Technical'
 WHERE id=157221056


   --row number: 821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2758925 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=157221057


   --row number: 822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2758925 , [Content] ='2 - Professionals'
 WHERE id=157221058


   --row number: 823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2758925 , [Content] ='5144 IND'
 WHERE id=157221040


   --row number: 824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2758925 , [Content] ='Engineering'
 WHERE id=157221041


   --row number: 825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2760837 , [Content] ='IC4'
 WHERE id=157423629


   --row number: 826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2760837 , [Content] ='IND'
 WHERE id=157423631


   --row number: 827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2760837 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=157423632


   --row number: 828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2760837 , [Content] ='20%'
 WHERE id=157423634


   --row number: 829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2760837 , [Content] ='Yes'
 WHERE id=157423635


   --row number: 830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2760837 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=157423636


   --row number: 831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2760837 , [Content] ='APAC'
 WHERE id=157423639


   --row number: 832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2760837 , [Content] ='INDIA'
 WHERE id=157423640


   --row number: 833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2760837 , [Content] ='Technical'
 WHERE id=157423641


   --row number: 834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2760837 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=157423642


   --row number: 835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2760837 , [Content] ='2 - Professionals'
 WHERE id=157423643


   --row number: 836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2760837 , [Content] ='Engineering'
 WHERE id=157423626


   --row number: 837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2760837 , [Content] ='Software'
 WHERE id=157423627


   --row number: 838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2760837 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=157423628


   --row number: 839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2760837 , [Content] ='5144 IND'
 WHERE id=157423625


   --row number: 840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2762571 , [Content] ='M4'
 WHERE id=157678218


   --row number: 841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2762571 , [Content] ='IND'
 WHERE id=157678220


   --row number: 842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2762571 , [Content] ='3,557,900 / 4,358,450 / 5,159,000 / 5,959,500 / 6,760,000'
 WHERE id=157678221


   --row number: 843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2762571 , [Content] ='25%'
 WHERE id=157678223


   --row number: 844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2762571 , [Content] ='Yes'
 WHERE id=157678224


   --row number: 845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2762571 , [Content] ='117,000 / 163,500 / 210,000 / 256,500 / 303,000'
 WHERE id=157678225


   --row number: 846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2762575 , [Content] ='APAC'
 WHERE id=157680831


   --row number: 847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2762575 , [Content] ='INDIA'
 WHERE id=157680832


   --row number: 848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2762575 , [Content] ='Technical'
 WHERE id=157680833


   --row number: 849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2762575 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=157680834


   --row number: 850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2762575 , [Content] ='2 - Professionals'
 WHERE id=157680835


   --row number: 851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2762571 , [Content] ='APAC'
 WHERE id=157678228


   --row number: 852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2762571 , [Content] ='INDIA'
 WHERE id=157678229


   --row number: 853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2762571 , [Content] ='Technical'
 WHERE id=157678230


   --row number: 854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2762571 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=157678231


   --row number: 855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2762571 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=157678232


   --row number: 856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2762571 , [Content] ='2144 IND'
 WHERE id=157678214


   --row number: 857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2762571 , [Content] ='Engineering'
 WHERE id=157678215


   --row number: 858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2762571 , [Content] ='Software'
 WHERE id=157678216


   --row number: 859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2762571 , [Content] ='2144 - Sr Mgr, Software Engrg Mgmt M4'
 WHERE id=157678217


   --row number: 860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2762575 , [Content] ='IC2'
 WHERE id=157680821


   --row number: 861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2762575 , [Content] ='IND'
 WHERE id=157680823


   --row number: 862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2762575 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=157680824


   --row number: 863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2762575 , [Content] ='10%'
 WHERE id=157680826


   --row number: 864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2762575 , [Content] ='No'
 WHERE id=157680827


   --row number: 865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2762575 , [Content] ='5142 IND'
 WHERE id=157680817


   --row number: 866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2762575 , [Content] ='Engineering'
 WHERE id=157680818


   --row number: 867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2762575 , [Content] ='Software'
 WHERE id=157680819


   --row number: 868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2762575 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=157680820


   --row number: 869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2764825 , [Content] ='IND'
 WHERE id=157935354


   --row number: 870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2764825 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=157935355


   --row number: 871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2764825 , [Content] ='15%'
 WHERE id=157935357


   --row number: 872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2764825 , [Content] ='Yes'
 WHERE id=157935358


   --row number: 873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2764825 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=157935359


   --row number: 874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2764825 , [Content] ='APAC'
 WHERE id=157935362


   --row number: 875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2764825 , [Content] ='INDIA'
 WHERE id=157935363


   --row number: 876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2764825 , [Content] ='Technical'
 WHERE id=157935364


   --row number: 877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2764825 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=157935365


   --row number: 878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2764825 , [Content] ='2 - Professionals'
 WHERE id=157935366


   --row number: 879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2764552 , [Content] ='APAC'
 WHERE id=157909710


   --row number: 880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2764552 , [Content] ='INDIA'
 WHERE id=157909711


   --row number: 881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2764552 , [Content] ='Technical'
 WHERE id=157909712


   --row number: 882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2764552 , [Content] ='8810-Clerical Office Employees'
 WHERE id=157909713


   --row number: 883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2764552 , [Content] ='2 - Professionals'
 WHERE id=157909714


   --row number: 884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2764552 , [Content] ='Information Systems'
 WHERE id=157909698


   --row number: 885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2764552 , [Content] ='6401 - Assoc Information Systems Engineer IC1'
 WHERE id=157909699


   --row number: 886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2764552 , [Content] ='IC1'
 WHERE id=157909700


   --row number: 887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2764552 , [Content] ='IND'
 WHERE id=157909702


   --row number: 888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2764825 , [Content] ='5143 IND'
 WHERE id=157935348


   --row number: 889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2764825 , [Content] ='Engineering'
 WHERE id=157935349


   --row number: 890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2764825 , [Content] ='Software'
 WHERE id=157935350


   --row number: 891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2764552 , [Content] ='534,500 / 654,750 / 775,000 / 895,300 / 1,015,600'
 WHERE id=157909703


   --row number: 892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2764825 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=157935351


   --row number: 893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2764825 , [Content] ='IC3'
 WHERE id=157935352


   --row number: 894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2764552 , [Content] ='10%'
 WHERE id=157909705


   --row number: 895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2764552 , [Content] ='No'
 WHERE id=157909706


   --row number: 896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2764552 , [Content] ='6401 IND'
 WHERE id=157909696


   --row number: 897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2764552 , [Content] ='Info Systems/Technology'
 WHERE id=157909697


   --row number: 898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2766495 , [Content] ='5144 US - MRKT 1'
 WHERE id=158074783


   --row number: 899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2766495 , [Content] ='Engineering'
 WHERE id=158074784


   --row number: 900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2766495 , [Content] ='Software'
 WHERE id=158074785


   --row number: 901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2766495 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=158074786


   --row number: 902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2766495 , [Content] ='IC4'
 WHERE id=158074787


   --row number: 903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2773989 , [Content] ='68,900 / 84,400 / 99,900 / 115,400 / 130,900'
 WHERE id=158850222


   --row number: 904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2773989 , [Content] ='25%'
 WHERE id=158850224


   --row number: 905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2773989 , [Content] ='Yes'
 WHERE id=158850225


   --row number: 906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2766495 , [Content] ='US - MRKT 1'
 WHERE id=158074789


   --row number: 907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2766495 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=158074790


   --row number: 908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2766495 , [Content] ='20%'
 WHERE id=158074792


   --row number: 909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2766495 , [Content] ='Yes'
 WHERE id=158074793


   --row number: 910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2766495 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=158074794


   --row number: 911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2766495 , [Content] ='EXEMPT'
 WHERE id=158074795


   --row number: 912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2766495 , [Content] ='NO'
 WHERE id=158074796


   --row number: 913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2766495 , [Content] ='AMS'
 WHERE id=158074799


   --row number: 914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2766495 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=158074800


   --row number: 915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2766495 , [Content] ='Technical'
 WHERE id=158074801


   --row number: 916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2766495 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=158074802


   --row number: 917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2766495 , [Content] ='2 - Professionals'
 WHERE id=158074803


   --row number: 918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2773989 , [Content] ='Professional Services'
 WHERE id=158850216


   --row number: 919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2773989 , [Content] ='Partner Support'
 WHERE id=158850217


   --row number: 920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2773989 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=158850218


   --row number: 921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2773989 , [Content] ='IC5'
 WHERE id=158850219


   --row number: 922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2773989 , [Content] ='DEU'
 WHERE id=158850221


   --row number: 923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2773989 , [Content] ='5705 DEU'
 WHERE id=158850215


   --row number: 924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2774002 , [Content] ='EMEA'
 WHERE id=158851079


   --row number: 925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2774002 , [Content] ='SWITZERLAND'
 WHERE id=158851080


   --row number: 926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2774002 , [Content] ='Technical'
 WHERE id=158851081


   --row number: 927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2774002 , [Content] ='8810-Clerical Office Employees'
 WHERE id=158851083


   --row number: 928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2774002 , [Content] ='2 - Professionals'
 WHERE id=158851084


   --row number: 929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2774002 , [Content] ='CHE'
 WHERE id=158851071


   --row number: 930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2774002 , [Content] ='141,400 / 173,200 / 205,000 / 236,850 / 268,700'
 WHERE id=158851072


   --row number: 931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2774002 , [Content] ='25%'
 WHERE id=158851074


   --row number: 932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2774002 , [Content] ='Yes'
 WHERE id=158851075


   --row number: 933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2773989 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=158850226


   --row number: 934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2774002 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=158851076


   --row number: 935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2773989 , [Content] ='EMEA'
 WHERE id=158850229


   --row number: 936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2773989 , [Content] ='GERMANY'
 WHERE id=158850230


   --row number: 937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2773989 , [Content] ='Technical'
 WHERE id=158850231


   --row number: 938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2773989 , [Content] ='8810-Clerical Office Employees'
 WHERE id=158850233


   --row number: 939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2773989 , [Content] ='2 - Professionals'
 WHERE id=158850234


   --row number: 940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2774002 , [Content] ='5706 CHE'
 WHERE id=158851065


   --row number: 941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2774002 , [Content] ='Professional Services'
 WHERE id=158851066


   --row number: 942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2774002 , [Content] ='Partner Support'
 WHERE id=158851067


   --row number: 943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2774002 , [Content] ='5706 - Client Relationship Manager IC6'
 WHERE id=158851068


   --row number: 944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2774002 , [Content] ='IC6'
 WHERE id=158851069


   --row number: 945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2775482 , [Content] ='5204 US - MRKT 2'
 WHERE id=158977163


   --row number: 946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2775482 , [Content] ='Engineering'
 WHERE id=158977164


   --row number: 947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2775482 , [Content] ='Systems Design'
 WHERE id=158977165


   --row number: 948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2775482 , [Content] ='5204 - Staff Systems Design Engineer IC4'
 WHERE id=158977166


   --row number: 949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2775482 , [Content] ='IC4'
 WHERE id=158977167


   --row number: 950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2775482 , [Content] ='US - MRKT 2'
 WHERE id=158977169


   --row number: 951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2775482 , [Content] ='99,900 / 120,850 / 141,800 / 162,700 / 183,600'
 WHERE id=158977170


   --row number: 952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2775482 , [Content] ='20%'
 WHERE id=158977172


   --row number: 953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2775482 , [Content] ='Yes'
 WHERE id=158977173


   --row number: 954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2775482 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=158977174


   --row number: 955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2775482 , [Content] ='EXEMPT'
 WHERE id=158977175


   --row number: 956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2775482 , [Content] ='NO'
 WHERE id=158977176


   --row number: 957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2775482 , [Content] ='AMS'
 WHERE id=158977179


   --row number: 958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2775482 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=158977180


   --row number: 959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2775482 , [Content] ='Technical'
 WHERE id=158977181


   --row number: 960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2775482 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=158977182


   --row number: 961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2775482 , [Content] ='2 - Professionals'
 WHERE id=158977183


   --row number: 962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2777563 , [Content] ='Product Mgrs'
 WHERE id=159181218


   --row number: 963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2777563 , [Content] ='5464 - Product Portfolio Mgr IC4'
 WHERE id=159181219


   --row number: 964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2777563 , [Content] ='IC4'
 WHERE id=159181220


   --row number: 965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2777563 , [Content] ='US - MRKT 1'
 WHERE id=159181222


   --row number: 966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2777563 , [Content] ='113,300 / 137,050 / 160,800 / 184,550 / 208,300'
 WHERE id=159181223


   --row number: 967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2777563 , [Content] ='20%'
 WHERE id=159181225


   --row number: 968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2777563 , [Content] ='Yes'
 WHERE id=159181226


   --row number: 969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2777563 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=159181227


   --row number: 970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2777563 , [Content] ='EXEMPT'
 WHERE id=159181228


   --row number: 971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2777563 , [Content] ='NO'
 WHERE id=159181229


   --row number: 972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2777563 , [Content] ='AMS'
 WHERE id=159181232


   --row number: 973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2777563 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159181233


   --row number: 974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2777563 , [Content] ='Technical'
 WHERE id=159181234


   --row number: 975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2777563 , [Content] ='8810-Clerical Office Employees'
 WHERE id=159181236


   --row number: 976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2777563 , [Content] ='2 - Professionals'
 WHERE id=159181237


   --row number: 977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2777563 , [Content] ='5464 US - MRKT 1'
 WHERE id=159181216


   --row number: 978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2777563 , [Content] ='Marketing'
 WHERE id=159181217


   --row number: 979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2708835 , [Content] ='AUD'
 WHERE id=160519387


   --row number: 980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2764552 , [Content] ='INR'
 WHERE id=160526502


   --row number: 981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2708835 , [Content] ='6483 AUS'
 WHERE id=160519386


   --row number: 982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2754114 , [Content] ='Yes'
 WHERE id=167475849


   --row number: 983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2754114 , [Content] ='8810-Clerical Office Employees'
 WHERE id=167475850


   --row number: 984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2754114 , [Content] ='Info Systems/Technology'
 WHERE id=167475851


   --row number: 985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2754114 , [Content] ='2 - Professionals'
 WHERE id=167475852


   --row number: 986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2754114 , [Content] ='6592 - Database Engineer IC2'
 WHERE id=167475853


   --row number: 987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2754114 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=167475854


   --row number: 988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2754114 , [Content] ='IC2'
 WHERE id=167475855


   --row number: 989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2754114 , [Content] ='Technical'
 WHERE id=167475856


   --row number: 990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2754114 , [Content] ='04/05/18'
 WHERE id=167475858


   --row number: 991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2754114 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=167475860


   --row number: 992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2754114 , [Content] ='71,400 / 83,200 / 95,000 / 106,750 / 118,500'
 WHERE id=167475861


   --row number: 993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2754114 , [Content] ='10%'
 WHERE id=167475862


   --row number: 994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=85933 , itemid=2754114 , [Content] ='If EE in CA and Base < $90,791, use NE job code and Hourly Rate'
 WHERE id=167475863


   --row number: 995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2754114 , [Content] ='6592 US - MRKT 2'
 WHERE id=167475864


   --row number: 996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2754114 , [Content] ='USD'
 WHERE id=167475865


   --row number: 997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2756326 , [Content] ='02/09/18'
 WHERE id=164117753


   --row number: 998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2756326 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=164117754


   --row number: 999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2756326 , [Content] ='INR'
 WHERE id=164117755


   --row number: 1000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2754114 , [Content] ='EXEMPT'
 WHERE id=167475845


   --row number: 1001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2754114 , [Content] ='YES'
 WHERE id=167475846


   --row number: 1002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2754114 , [Content] ='Database Engineer'
 WHERE id=167475843


   --row number: 1003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2754114 , [Content] ='US - MRKT 2'
 WHERE id=167475844


   --row number: 1004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2754114 , [Content] ='AMS'
 WHERE id=167475848


   --row number: 1005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2762571 , [Content] ='INR'
 WHERE id=172102220


   --row number: 1006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2620072 , [Content] ='04/05/18'
 WHERE id=167992218


   --row number: 1007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2620072 , [Content] ='USD'
 WHERE id=167992219


   --row number: 1008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2762571 , [Content] ='09/05/18'
 WHERE id=172102215


   --row number: 1009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2747639 , [Content] ='4/25/2018'
 WHERE id=172097622


   --row number: 1010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2747639 , [Content] ='INR'
 WHERE id=172097627


   --row number: 1011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2691503 , [Content] ='4/25/2018'
 WHERE id=171922353


   --row number: 1012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2691503 , [Content] ='INR'
 WHERE id=171922357


   --row number: 1013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2775482 , [Content] ='04/05/18'
 WHERE id=172102243


   --row number: 1014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2684900 , [Content] ='AUD'
 WHERE id=172106506


   --row number: 1015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2775482 , [Content] ='USD'
 WHERE id=172102248


   --row number: 1016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2764552 , [Content] ='04/05/18'
 WHERE id=172103921


   --row number: 1017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2732449 , [Content] ='USD'
 WHERE id=172104085


   --row number: 1018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2732449 , [Content] ='04/05/18'
 WHERE id=172104078


   --row number: 1019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2732449 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=172104079


   --row number: 1020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2732449 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=172104082


   --row number: 1021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2584097 , [Content] ='04/05/18'
 WHERE id=172104221


   --row number: 1022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2584097 , [Content] ='USD'
 WHERE id=172104222


   --row number: 1023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2716658 , [Content] ='04/05/18'
 WHERE id=172107751


   --row number: 1024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2716658 , [Content] ='AUD'
 WHERE id=172107756


   --row number: 1025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2764825 , [Content] ='INR'
 WHERE id=172104353


   --row number: 1026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2710368 , [Content] ='04/05/18'
 WHERE id=172106611


   --row number: 1027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2710368 , [Content] ='USD'
 WHERE id=172106616


   --row number: 1028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2684930 , [Content] ='7/20/2018'
 WHERE id=172106753


   --row number: 1029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2684930 , [Content] ='INR'
 WHERE id=172106757


   --row number: 1030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2764825 , [Content] ='7/20/2018'
 WHERE id=172104348


   --row number: 1031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2760837 , [Content] ='04/05/18'
 WHERE id=172106809


   --row number: 1032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2760837 , [Content] ='INR'
 WHERE id=172106814


   --row number: 1033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2732695 , [Content] ='04/05/18'
 WHERE id=172108889


   --row number: 1034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2732695 , [Content] ='AUD'
 WHERE id=172108893


   --row number: 1035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2732699 , [Content] ='04/05/18'
 WHERE id=172109032


   --row number: 1036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2732699 , [Content] ='JPY'
 WHERE id=172109036


   --row number: 1037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2685710 , [Content] ='04/05/18'
 WHERE id=172111015


   --row number: 1038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2704765 , [Content] ='EUR'
 WHERE id=172117758


   --row number: 1039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2685710 , [Content] ='USD'
 WHERE id=172111019


   --row number: 1040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2690533 , [Content] ='10/24/2018'
 WHERE id=172111595


   --row number: 1041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2690533 , [Content] ='USD'
 WHERE id=172111599


   --row number: 1042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2704765 , [Content] ='04/05/18'
 WHERE id=172117751


   --row number: 1043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2704765 , [Content] ='102,000 / 111,000 / 120,000 / 129,000 / 138,000'
 WHERE id=172117752


   --row number: 1044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2704765 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=172117755


   --row number: 1045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2709500 , [Content] ='04/05/18'
 WHERE id=172118049


   --row number: 1046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2709500 , [Content] ='GBP'
 WHERE id=172118054


   --row number: 1047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2752837 , [Content] ='04/05/18'
 WHERE id=172120376


   --row number: 1048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2752837 , [Content] ='GBP'
 WHERE id=172120381


   --row number: 1049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2773989 , [Content] ='4/25/2018'
 WHERE id=172121323


   --row number: 1050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2773989 , [Content] ='EUR'
 WHERE id=172121328


   --row number: 1051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2774002 , [Content] ='04/05/18'
 WHERE id=172121374


   --row number: 1052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2774002 , [Content] ='CHF'
 WHERE id=172121379


   --row number: 1053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2766495 , [Content] ='USD'
 WHERE id=172179332


   --row number: 1054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2766495 , [Content] ='10/24/2018'
 WHERE id=172179327


   --row number: 1055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2777563 , [Content] ='4/25/2018'
 WHERE id=175451371


   --row number: 1056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2777563 , [Content] ='USD'
 WHERE id=175451376


   --row number: 1057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2747639 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=178378629


   --row number: 1058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2691507 , [Content] ='INR'
 WHERE id=188348853


   --row number: 1059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2691507 , [Content] ='6/27/2018'
 WHERE id=188348851


   --row number: 1060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2762575 , [Content] ='6/27/2018'
 WHERE id=189318731


   --row number: 1061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2762575 , [Content] ='INR'
 WHERE id=189318732


   --row number: 1062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2762571 , [Content] ='4,447,400 / 5,448,100 / 6,448,800 / 7,449,400 / 8,450,000'
 WHERE id=199170620


   --row number: 1063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2716706 , [Content] ='IND'
 WHERE id=153514988


   --row number: 1064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2716706 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=153514989


   --row number: 1065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2716706 , [Content] ='20%'
 WHERE id=153514991


   --row number: 1066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2716706 , [Content] ='Yes'
 WHERE id=153514992


   --row number: 1067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2716706 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=153514993


   --row number: 1068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2716706 , [Content] ='APAC'
 WHERE id=153514996


   --row number: 1069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2716706 , [Content] ='INDIA'
 WHERE id=153514997


   --row number: 1070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2716706 , [Content] ='Technical'
 WHERE id=153514998


   --row number: 1071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2716706 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=153514999


   --row number: 1072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2716706 , [Content] ='2 - Professionals'
 WHERE id=153515000


   --row number: 1073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2725546 , [Content] ='AMS'
 WHERE id=154260529


   --row number: 1074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2725546 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=154260530


   --row number: 1075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2725546 , [Content] ='Non Technical'
 WHERE id=154260531


   --row number: 1076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2725546 , [Content] ='8810-Clerical Office Employees'
 WHERE id=154260533


   --row number: 1077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2725546 , [Content] ='Legal'
 WHERE id=154260514


   --row number: 1078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2725546 , [Content] ='Contracts Mgmt'
 WHERE id=154260515


   --row number: 1079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2725546 , [Content] ='6075 - Contracts Manager IC5'
 WHERE id=154260516


   --row number: 1080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2725546 , [Content] ='IC5'
 WHERE id=154260517


   --row number: 1081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2725546 , [Content] ='US - MRKT 2'
 WHERE id=154260519


   --row number: 1082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2725546 , [Content] ='96,900 / 117,200 / 137,500 / 157,800 / 178,100'
 WHERE id=154260520


   --row number: 1083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2725546 , [Content] ='20%'
 WHERE id=154260522


   --row number: 1084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2725546 , [Content] ='Yes'
 WHERE id=154260523


   --row number: 1085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2725546 , [Content] ='2 - Professionals'
 WHERE id=154260534


   --row number: 1086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2725546 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=154260524


   --row number: 1087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2725546 , [Content] ='EXEMPT'
 WHERE id=154260525


   --row number: 1088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2725546 , [Content] ='NO'
 WHERE id=154260526


   --row number: 1089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2728681 , [Content] ='Software'
 WHERE id=154447190


   --row number: 1090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2728681 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=154447191


   --row number: 1091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2728681 , [Content] ='IC3'
 WHERE id=154447192


   --row number: 1092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2728681 , [Content] ='US - MRKT 1'
 WHERE id=154447194


   --row number: 1093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2728681 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=154447195


   --row number: 1094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2728681 , [Content] ='15%'
 WHERE id=154447197


   --row number: 1095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2728681 , [Content] ='Yes'
 WHERE id=154447198


   --row number: 1096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2728681 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=154447199


   --row number: 1097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2728681 , [Content] ='EXEMPT'
 WHERE id=154447200


   --row number: 1098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2728681 , [Content] ='NO'
 WHERE id=154447201


   --row number: 1099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2728681 , [Content] ='AMS'
 WHERE id=154447204


   --row number: 1100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2728681 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=154447205


   --row number: 1101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2728681 , [Content] ='Technical'
 WHERE id=154447206


   --row number: 1102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2728681 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=154447207


   --row number: 1103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2728681 , [Content] ='5143 US - MRKT 1'
 WHERE id=154447188


   --row number: 1104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2728681 , [Content] ='Engineering'
 WHERE id=154447189


   --row number: 1105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2728681 , [Content] ='2 - Professionals'
 WHERE id=154447208


   --row number: 1106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2729094 , [Content] ='Product Mgrs'
 WHERE id=154479443


   --row number: 1107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2729094 , [Content] ='5464 - Product Portfolio Mgr IC4'
 WHERE id=154479444


   --row number: 1108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2729094 , [Content] ='IC4'
 WHERE id=154479445


   --row number: 1109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2729094 , [Content] ='US - MRKT 1'
 WHERE id=154479447


   --row number: 1110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2729094 , [Content] ='113,300 / 137,050 / 160,800 / 184,550 / 208,300'
 WHERE id=154479448


   --row number: 1111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2729094 , [Content] ='20%'
 WHERE id=154479450


   --row number: 1112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2729094 , [Content] ='Yes'
 WHERE id=154479451


   --row number: 1113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2729094 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=154479452


   --row number: 1114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2729094 , [Content] ='EXEMPT'
 WHERE id=154479453


   --row number: 1115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2729094 , [Content] ='NO'
 WHERE id=154479454


   --row number: 1116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2729094 , [Content] ='AMS'
 WHERE id=154479457


   --row number: 1117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2729094 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=154479458


   --row number: 1118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2729094 , [Content] ='Technical'
 WHERE id=154479459


   --row number: 1119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2729094 , [Content] ='8810-Clerical Office Employees'
 WHERE id=154479460


   --row number: 1120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2729094 , [Content] ='2 - Professionals'
 WHERE id=154479461


   --row number: 1121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2729094 , [Content] ='5464 US - MRKT 1'
 WHERE id=154479441


   --row number: 1122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2729094 , [Content] ='Marketing'
 WHERE id=154479442


   --row number: 1123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2729553 , [Content] ='Software'
 WHERE id=154531973


   --row number: 1124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2729570 , [Content] ='IC2'
 WHERE id=154533387


   --row number: 1125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2729570 , [Content] ='IND'
 WHERE id=154533389


   --row number: 1126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2729570 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=154533390


   --row number: 1127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2729570 , [Content] ='10%'
 WHERE id=154533392


   --row number: 1128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2729570 , [Content] ='No'
 WHERE id=154533393


   --row number: 1129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2729570 , [Content] ='APAC'
 WHERE id=154533397


   --row number: 1130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2729570 , [Content] ='INDIA'
 WHERE id=154533398


   --row number: 1131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2729570 , [Content] ='Technical'
 WHERE id=154533399


   --row number: 1132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2729570 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=154533400


   --row number: 1133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2729570 , [Content] ='2 - Professionals'
 WHERE id=154533401


   --row number: 1134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2729553 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=154531974


   --row number: 1135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2729553 , [Content] ='IC5'
 WHERE id=154531975


   --row number: 1136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2729553 , [Content] ='IND'
 WHERE id=154531977


   --row number: 1137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2729553 , [Content] ='3,393,100 / 4,156,550 / 4,920,000 / 5,683,450 / 6,446,900'
 WHERE id=154531978


   --row number: 1138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2729553 , [Content] ='25%'
 WHERE id=154531980


   --row number: 1139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2729553 , [Content] ='Yes'
 WHERE id=154531981


   --row number: 1140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2729553 , [Content] ='117,000 / 163,500 / 210,000 / 256,500 / 303,000'
 WHERE id=154531982


   --row number: 1141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2729553 , [Content] ='APAC'
 WHERE id=154531985


   --row number: 1142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2729553 , [Content] ='INDIA'
 WHERE id=154531986


   --row number: 1143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2729553 , [Content] ='Technical'
 WHERE id=154531987


   --row number: 1144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2729553 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=154531988


   --row number: 1145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2729553 , [Content] ='2 - Professionals'
 WHERE id=154531989


   --row number: 1146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2729570 , [Content] ='5142 IND'
 WHERE id=154533383


   --row number: 1147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2729553 , [Content] ='5145 IND'
 WHERE id=154531971


   --row number: 1148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2729553 , [Content] ='Engineering'
 WHERE id=154531972


   --row number: 1149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2729570 , [Content] ='Engineering'
 WHERE id=154533384


   --row number: 1150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2729570 , [Content] ='Software'
 WHERE id=154533385


   --row number: 1151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2729570 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=154533386


   --row number: 1152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2729574 , [Content] ='5144 IND'
 WHERE id=154533701


   --row number: 1153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2729574 , [Content] ='Engineering'
 WHERE id=154533702


   --row number: 1154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2729574 , [Content] ='Software'
 WHERE id=154533703


   --row number: 1155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2729574 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=154533704


   --row number: 1156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2729574 , [Content] ='IC4'
 WHERE id=154533705


   --row number: 1157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2729574 , [Content] ='IND'
 WHERE id=154533707


   --row number: 1158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2729574 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=154533708


   --row number: 1159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2729574 , [Content] ='20%'
 WHERE id=154533710


   --row number: 1160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2729574 , [Content] ='Yes'
 WHERE id=154533711


   --row number: 1161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2729574 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=154533712


   --row number: 1162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2729574 , [Content] ='APAC'
 WHERE id=154533715


   --row number: 1163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2729574 , [Content] ='INDIA'
 WHERE id=154533716


   --row number: 1164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2729574 , [Content] ='Technical'
 WHERE id=154533717


   --row number: 1165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2729574 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=154533718


   --row number: 1166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2729574 , [Content] ='2 - Professionals'
 WHERE id=154533719


   --row number: 1167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2731037 , [Content] ='IC3'
 WHERE id=154651701


   --row number: 1168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2731037 , [Content] ='IND'
 WHERE id=154651703


   --row number: 1169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2731037 , [Content] ='1,531,000 / 2,220,000 / 2,908,900'
 WHERE id=154651704


   --row number: 1170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2731037 , [Content] ='15%'
 WHERE id=154651706


   --row number: 1171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2731037 , [Content] ='Yes'
 WHERE id=154651707


   --row number: 1172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2731037 , [Content] ='420 / 750 / 1,085'
 WHERE id=154651708


   --row number: 1173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2731037 , [Content] ='APAC'
 WHERE id=154651711


   --row number: 1174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2731037 , [Content] ='INDIA'
 WHERE id=154651712


   --row number: 1175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2731037 , [Content] ='Technical'
 WHERE id=154651713


   --row number: 1176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2731037 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=154651714


   --row number: 1177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2731037 , [Content] ='2 - Professionals'
 WHERE id=154651715


   --row number: 1178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2731037 , [Content] ='5143 IND'
 WHERE id=154651697


   --row number: 1179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2731037 , [Content] ='Engineering'
 WHERE id=154651698


   --row number: 1180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2731037 , [Content] ='Software'
 WHERE id=154651699


   --row number: 1181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2731037 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=154651700


   --row number: 1182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2781548 , [Content] ='IC3'
 WHERE id=159544293


   --row number: 1183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2781548 , [Content] ='US - MRKT 1'
 WHERE id=159544295


   --row number: 1184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2781548 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=159544296


   --row number: 1185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2781548 , [Content] ='15%'
 WHERE id=159544298


   --row number: 1186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2781548 , [Content] ='Yes'
 WHERE id=159544299


   --row number: 1187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2781548 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=159544300


   --row number: 1188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2781548 , [Content] ='EXEMPT'
 WHERE id=159544301


   --row number: 1189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2781548 , [Content] ='NO'
 WHERE id=159544302


   --row number: 1190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2781548 , [Content] ='AMS'
 WHERE id=159544305


   --row number: 1191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2781548 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159544306


   --row number: 1192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2781548 , [Content] ='Technical'
 WHERE id=159544307


   --row number: 1193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2781548 , [Content] ='5143 US - MRKT 1'
 WHERE id=159544289


   --row number: 1194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2781548 , [Content] ='Engineering'
 WHERE id=159544290


   --row number: 1195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2781548 , [Content] ='Software'
 WHERE id=159544291


   --row number: 1196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2781548 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=159544292


   --row number: 1197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2781548 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159544308


   --row number: 1198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2781548 , [Content] ='2 - Professionals'
 WHERE id=159544309


   --row number: 1199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2781735 , [Content] ='Software'
 WHERE id=159580684


   --row number: 1200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2781735 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=159580685


   --row number: 1201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2781735 , [Content] ='IC4'
 WHERE id=159580686


   --row number: 1202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2781735 , [Content] ='US - MRKT 2'
 WHERE id=159580688


   --row number: 1203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2781735 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=159580689


   --row number: 1204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2781735 , [Content] ='20%'
 WHERE id=159580691


   --row number: 1205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2781735 , [Content] ='Yes'
 WHERE id=159580692


   --row number: 1206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2781735 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=159580693


   --row number: 1207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2781735 , [Content] ='EXEMPT'
 WHERE id=159580694


   --row number: 1208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2781735 , [Content] ='NO'
 WHERE id=159580695


   --row number: 1209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2781735 , [Content] ='AMS'
 WHERE id=159580698


   --row number: 1210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2781735 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159580699


   --row number: 1211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2781735 , [Content] ='Technical'
 WHERE id=159580700


   --row number: 1212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2781735 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159580702


   --row number: 1213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2781735 , [Content] ='2 - Professionals'
 WHERE id=159580703


   --row number: 1214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2781735 , [Content] ='5144 US - MRKT 2'
 WHERE id=159580682


   --row number: 1215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2781735 , [Content] ='Engineering'
 WHERE id=159580683


   --row number: 1216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2781737 , [Content] ='Engineering'
 WHERE id=159581270


   --row number: 1217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2781737 , [Content] ='Software'
 WHERE id=159581271


   --row number: 1218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2781737 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=159581272


   --row number: 1219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2781737 , [Content] ='IC3'
 WHERE id=159581273


   --row number: 1220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2781737 , [Content] ='US - MRKT 2'
 WHERE id=159581275


   --row number: 1221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2781737 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=159581276


   --row number: 1222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2781737 , [Content] ='15%'
 WHERE id=159581278


   --row number: 1223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2781737 , [Content] ='Yes'
 WHERE id=159581279


   --row number: 1224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2781737 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=159581280


   --row number: 1225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2781737 , [Content] ='EXEMPT'
 WHERE id=159581281


   --row number: 1226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2781737 , [Content] ='NO'
 WHERE id=159581282


   --row number: 1227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2781737 , [Content] ='AMS'
 WHERE id=159581285


   --row number: 1228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2781737 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159581286


   --row number: 1229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2781737 , [Content] ='Technical'
 WHERE id=159581287


   --row number: 1230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2781737 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159581289


   --row number: 1231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2781737 , [Content] ='5143 US - MRKT 2'
 WHERE id=159581269


   --row number: 1232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2781737 , [Content] ='2 - Professionals'
 WHERE id=159581290


   --row number: 1233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2783326 , [Content] ='Info Systems/Technology'
 WHERE id=159702200


   --row number: 1234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2783326 , [Content] ='UI/UX Designer'
 WHERE id=159702201


   --row number: 1235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2783326 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=159702202


   --row number: 1236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2783326 , [Content] ='IC4'
 WHERE id=159702203


   --row number: 1237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2783326 , [Content] ='US - MRKT 1'
 WHERE id=159702205


   --row number: 1238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2783326 , [Content] ='110,800 / 134,000 / 157,200 / 180,450 / 203,700'
 WHERE id=159702206


   --row number: 1239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2783326 , [Content] ='20%'
 WHERE id=159702208


   --row number: 1240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2783326 , [Content] ='Yes'
 WHERE id=159702209


   --row number: 1241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2783326 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=159702210


   --row number: 1242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2783326 , [Content] ='EXEMPT'
 WHERE id=159702211


   --row number: 1243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2783326 , [Content] ='NO'
 WHERE id=159702212


   --row number: 1244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2783326 , [Content] ='AMS'
 WHERE id=159702215


   --row number: 1245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2783326 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159702216


   --row number: 1246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2783326 , [Content] ='Technical'
 WHERE id=159702217


   --row number: 1247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2783326 , [Content] ='8810-Clerical Office Employees'
 WHERE id=159702220


   --row number: 1248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2783326 , [Content] ='2 - Professionals'
 WHERE id=159702221


   --row number: 1249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2783326 , [Content] ='6804 US - MRKT 1'
 WHERE id=159702199


   --row number: 1250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2783730 , [Content] ='5143 US - MRKT 1'
 WHERE id=159803262


   --row number: 1251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2783730 , [Content] ='Engineering'
 WHERE id=159803263


   --row number: 1252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2783730 , [Content] ='Software'
 WHERE id=159803264


   --row number: 1253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2783730 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=159803265


   --row number: 1254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2783730 , [Content] ='IC3'
 WHERE id=159803266


   --row number: 1255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2783730 , [Content] ='US - MRKT 1'
 WHERE id=159803268


   --row number: 1256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2783730 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=159803269


   --row number: 1257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2783730 , [Content] ='15%'
 WHERE id=159803271


   --row number: 1258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2783730 , [Content] ='Yes'
 WHERE id=159803272


   --row number: 1259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2783730 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=159803273


   --row number: 1260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2783730 , [Content] ='EXEMPT'
 WHERE id=159803274


   --row number: 1261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2783730 , [Content] ='NO'
 WHERE id=159803275


   --row number: 1262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2783730 , [Content] ='AMS'
 WHERE id=159803278


   --row number: 1263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2783732 , [Content] ='Technical'
 WHERE id=159804263


   --row number: 1264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2783732 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159804264


   --row number: 1265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2783732 , [Content] ='2 - Professionals'
 WHERE id=159804265


   --row number: 1266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2783730 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159803279


   --row number: 1267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2783730 , [Content] ='Technical'
 WHERE id=159803280


   --row number: 1268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2783730 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159803281


   --row number: 1269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2783730 , [Content] ='2 - Professionals'
 WHERE id=159803282


   --row number: 1270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2783732 , [Content] ='Engineering'
 WHERE id=159804246


   --row number: 1271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2783732 , [Content] ='Software'
 WHERE id=159804247


   --row number: 1272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2783732 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=159804248


   --row number: 1273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2783732 , [Content] ='IC4'
 WHERE id=159804249


   --row number: 1274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2783732 , [Content] ='US - MRKT 2'
 WHERE id=159804251


   --row number: 1275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2783732 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=159804252


   --row number: 1276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2783732 , [Content] ='20%'
 WHERE id=159804254


   --row number: 1277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2783732 , [Content] ='Yes'
 WHERE id=159804255


   --row number: 1278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2783732 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=159804256


   --row number: 1279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2783732 , [Content] ='EXEMPT'
 WHERE id=159804257


   --row number: 1280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2783732 , [Content] ='NO'
 WHERE id=159804258


   --row number: 1281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2783732 , [Content] ='AMS'
 WHERE id=159804261


   --row number: 1282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2783732 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159804262


   --row number: 1283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2783732 , [Content] ='5144 US - MRKT 2'
 WHERE id=159804245


   --row number: 1284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2783733 , [Content] ='IC2'
 WHERE id=159805239


   --row number: 1285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2783733 , [Content] ='US - MRKT 1'
 WHERE id=159805241


   --row number: 1286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2783733 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=159805242


   --row number: 1287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2783733 , [Content] ='10%'
 WHERE id=159805244


   --row number: 1288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2783733 , [Content] ='Yes'
 WHERE id=159805245


   --row number: 1289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2783733 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=159805246


   --row number: 1290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2783733 , [Content] ='EXEMPT'
 WHERE id=159805247


   --row number: 1291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2783733 , [Content] ='NO'
 WHERE id=159805248


   --row number: 1292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2783733 , [Content] ='AMS'
 WHERE id=159805251


   --row number: 1293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2783736 , [Content] ='NO'
 WHERE id=159806974


   --row number: 1294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2783736 , [Content] ='AMS'
 WHERE id=159806977


   --row number: 1295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2783736 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159806978


   --row number: 1296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2783736 , [Content] ='Technical'
 WHERE id=159806979


   --row number: 1297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2783736 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159806980


   --row number: 1298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2783736 , [Content] ='2 - Professionals'
 WHERE id=159806981


   --row number: 1299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2783733 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=159805252


   --row number: 1300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2783733 , [Content] ='Technical'
 WHERE id=159805253


   --row number: 1301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2783733 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=159805254


   --row number: 1302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2783733 , [Content] ='2 - Professionals'
 WHERE id=159805255


   --row number: 1303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2783733 , [Content] ='5142 US - MRKT 1'
 WHERE id=159805235


   --row number: 1304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2783733 , [Content] ='Engineering'
 WHERE id=159805236


   --row number: 1305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2783733 , [Content] ='Software'
 WHERE id=159805237


   --row number: 1306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2783733 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=159805238


   --row number: 1307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2783736 , [Content] ='Engineering'
 WHERE id=159806962


   --row number: 1308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2783736 , [Content] ='Software'
 WHERE id=159806963


   --row number: 1309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2783736 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=159806964


   --row number: 1310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2783736 , [Content] ='IC2'
 WHERE id=159806965


   --row number: 1311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2783736 , [Content] ='US - MRKT 1'
 WHERE id=159806967


   --row number: 1312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2783736 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=159806968


   --row number: 1313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2783736 , [Content] ='10%'
 WHERE id=159806970


   --row number: 1314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2783736 , [Content] ='Yes'
 WHERE id=159806971


   --row number: 1315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2783736 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=159806972


   --row number: 1316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2783736 , [Content] ='EXEMPT'
 WHERE id=159806973


   --row number: 1317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2783736 , [Content] ='5142 US - MRKT 1'
 WHERE id=159806961


   --row number: 1318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2785668 , [Content] ='Yes'
 WHERE id=160060230


   --row number: 1319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2785668 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=160060231


   --row number: 1320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2785668 , [Content] ='EXEMPT'
 WHERE id=160060232


   --row number: 1321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2785668 , [Content] ='NO'
 WHERE id=160060233


   --row number: 1322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2785668 , [Content] ='AMS'
 WHERE id=160060236


   --row number: 1323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2785668 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=160060237


   --row number: 1324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2785668 , [Content] ='Technical'
 WHERE id=160060238


   --row number: 1325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2785668 , [Content] ='8810-Clerical Office Employees'
 WHERE id=160060240


   --row number: 1326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2785668 , [Content] ='2 - Professionals'
 WHERE id=160060241


   --row number: 1327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2785668 , [Content] ='6494 US - MRKT 1'
 WHERE id=160060220


   --row number: 1328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2785668 , [Content] ='Info Systems/Technology'
 WHERE id=160060221


   --row number: 1329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2785668 , [Content] ='Data Informatics'
 WHERE id=160060222


   --row number: 1330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2785668 , [Content] ='6494 - Data Informatics Analyst IC4'
 WHERE id=160060223


   --row number: 1331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2785668 , [Content] ='IC4'
 WHERE id=160060224


   --row number: 1332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2785668 , [Content] ='US - MRKT 1'
 WHERE id=160060226


   --row number: 1333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2785668 , [Content] ='110,600 / 133,800 / 157,000 / 180,150 / 203,300'
 WHERE id=160060227


   --row number: 1334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2785668 , [Content] ='20%'
 WHERE id=160060229


   --row number: 1335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2788336 , [Content] ='APJ'
 WHERE id=160340024


   --row number: 1336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2788336 , [Content] ='Human Resources'
 WHERE id=160340021


   --row number: 1337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2790450 , [Content] ='2 - Professionals'
 WHERE id=160524473


   --row number: 1338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2790450 , [Content] ='6583 IND'
 WHERE id=160524454


   --row number: 1339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2790450 , [Content] ='INR'
 WHERE id=160524455


   --row number: 1340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2790450 , [Content] ='Info Systems/Technology'
 WHERE id=160524456


   --row number: 1341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2790450 , [Content] ='Security'
 WHERE id=160524457


   --row number: 1342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2790450 , [Content] ='6583 - Sr Information Security Engineer IC3'
 WHERE id=160524458


   --row number: 1343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2790450 , [Content] ='IC3'
 WHERE id=160524459


   --row number: 1344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2790450 , [Content] ='IND'
 WHERE id=160524461


   --row number: 1345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2790450 , [Content] ='1,027,600 / 1,258,800 / 1,490,000 / 1,721,200 / 1,952,400'
 WHERE id=160524462


   --row number: 1346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2790450 , [Content] ='15%'
 WHERE id=160524464


   --row number: 1347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2790450 , [Content] ='Yes'
 WHERE id=160524465


   --row number: 1348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2790450 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=160524466


   --row number: 1349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2790450 , [Content] ='APAC'
 WHERE id=160524469


   --row number: 1350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2790450 , [Content] ='INDIA'
 WHERE id=160524470


   --row number: 1351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2790450 , [Content] ='Technical'
 WHERE id=160524471


   --row number: 1352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2790450 , [Content] ='8810-Clerical Office Employees'
 WHERE id=160524472


   --row number: 1353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2792234 , [Content] ='APJ'
 WHERE id=160688463


   --row number: 1354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2792234 , [Content] ='Human Resources'
 WHERE id=160688460


   --row number: 1355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2792288 , [Content] ='2 - Professionals'
 WHERE id=160693246


   --row number: 1356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2792288 , [Content] ='Engineering'
 WHERE id=160693227


   --row number: 1357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2792288 , [Content] ='Software'
 WHERE id=160693228


   --row number: 1358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2792288 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=160693229


   --row number: 1359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2792288 , [Content] ='IC3'
 WHERE id=160693230


   --row number: 1360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2792288 , [Content] ='US - MRKT 2'
 WHERE id=160693232


   --row number: 1361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2792288 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=160693233


   --row number: 1362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2792288 , [Content] ='15%'
 WHERE id=160693235


   --row number: 1363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2792288 , [Content] ='Yes'
 WHERE id=160693236


   --row number: 1364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2792288 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=160693237


   --row number: 1365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2792288 , [Content] ='EXEMPT'
 WHERE id=160693238


   --row number: 1366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2792288 , [Content] ='NO'
 WHERE id=160693239


   --row number: 1367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2792288 , [Content] ='AMS'
 WHERE id=160693242


   --row number: 1368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2792288 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=160693243


   --row number: 1369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2792288 , [Content] ='Technical'
 WHERE id=160693244


   --row number: 1370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2792288 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=160693245


   --row number: 1371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2795702 , [Content] ='6704 US - MRKT 1'
 WHERE id=161091798


   --row number: 1372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2795702 , [Content] ='2 - Professionals'
 WHERE id=161091825


   --row number: 1373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2795702 , [Content] ='USD'
 WHERE id=161091802


   --row number: 1374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2795702 , [Content] ='Engineering Operations'
 WHERE id=161091805


   --row number: 1375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2795702 , [Content] ='Data Scientist'
 WHERE id=161091806


   --row number: 1376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2795702 , [Content] ='6704 - Data Scientist IC4'
 WHERE id=161091807


   --row number: 1377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2795702 , [Content] ='IC4'
 WHERE id=161091808


   --row number: 1378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2795702 , [Content] ='US - MRKT 1'
 WHERE id=161091810


   --row number: 1379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2795702 , [Content] ='119,300 / 144,300 / 169,300 / 194,300 / 219,300'
 WHERE id=161091811


   --row number: 1380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2795702 , [Content] ='20%'
 WHERE id=161091813


   --row number: 1381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2795702 , [Content] ='Yes'
 WHERE id=161091814


   --row number: 1382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2795702 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=161091815


   --row number: 1383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2795702 , [Content] ='EXEMPT'
 WHERE id=161091816


   --row number: 1384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2795702 , [Content] ='NO'
 WHERE id=161091817


   --row number: 1385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2795702 , [Content] ='AMS'
 WHERE id=161091820


   --row number: 1386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2795702 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=161091822


   --row number: 1387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2795702 , [Content] ='Technical'
 WHERE id=161091823


   --row number: 1388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2795702 , [Content] ='8810-Clerical Office Employees'
 WHERE id=161091824


   --row number: 1389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2798440 , [Content] ='8810-Clerical Office Employees'
 WHERE id=161332761


   --row number: 1390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2798440 , [Content] ='5874 US - MRKT 2'
 WHERE id=161332740


   --row number: 1391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2798440 , [Content] ='USD'
 WHERE id=161332741


   --row number: 1392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2798440 , [Content] ='Professional Services'
 WHERE id=161332742


   --row number: 1393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2798440 , [Content] ='Engagement Mgrs'
 WHERE id=161332743


   --row number: 1394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2798440 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=161332744


   --row number: 1395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2798440 , [Content] ='IC4'
 WHERE id=161332745


   --row number: 1396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2798440 , [Content] ='US - MRKT 2'
 WHERE id=161332747


   --row number: 1397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2798440 , [Content] ='93,400 / 113,000 / 132,600 / 152,150 / 171,700'
 WHERE id=161332748


   --row number: 1398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2798440 , [Content] ='20%'
 WHERE id=161332750


   --row number: 1399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2798440 , [Content] ='Yes'
 WHERE id=161332751


   --row number: 1400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2798440 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=161332752


   --row number: 1401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2798440 , [Content] ='EXEMPT'
 WHERE id=161332753


   --row number: 1402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2798440 , [Content] ='NO'
 WHERE id=161332754


   --row number: 1403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2798440 , [Content] ='AMS'
 WHERE id=161332757


   --row number: 1404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2798440 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=161332758


   --row number: 1405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2798440 , [Content] ='2 - Professionals'
 WHERE id=161332762


   --row number: 1406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2798440 , [Content] ='Technical'
 WHERE id=161332759


   --row number: 1407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2799124 , [Content] ='2313 US - MRKT 2'
 WHERE id=161408155


   --row number: 1408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2799124 , [Content] ='USD'
 WHERE id=161408156


   --row number: 1409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2799124 , [Content] ='Engineering Operations'
 WHERE id=161408157


   --row number: 1410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2799124 , [Content] ='Technical Writer'
 WHERE id=161408158


   --row number: 1411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2799124 , [Content] ='2313 - Mgr, Technical Writing Mgmt M3'
 WHERE id=161408159


   --row number: 1412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2799124 , [Content] ='M3'
 WHERE id=161408160


   --row number: 1413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2799124 , [Content] ='US - MRKT 2'
 WHERE id=161408162


   --row number: 1414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2799124 , [Content] ='88,600 / 107,150 / 125,700 / 144,300 / 162,900'
 WHERE id=161408163


   --row number: 1415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2799124 , [Content] ='20%'
 WHERE id=161408165


   --row number: 1416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2799124 , [Content] ='Yes'
 WHERE id=161408166


   --row number: 1417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2799124 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=161408167


   --row number: 1418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2799124 , [Content] ='EXEMPT'
 WHERE id=161408168


   --row number: 1419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2799124 , [Content] ='NO'
 WHERE id=161408169


   --row number: 1420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2799124 , [Content] ='AMS'
 WHERE id=161408172


   --row number: 1421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2799124 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=161408173


   --row number: 1422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2799124 , [Content] ='Technical'
 WHERE id=161408174


   --row number: 1423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2799124 , [Content] ='8810-Clerical Office Employees'
 WHERE id=161408175


   --row number: 1424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2799124 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=161408176


   --row number: 1425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2807018 , [Content] ='GBP'
 WHERE id=161989001


   --row number: 1426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2807018 , [Content] ='Sales'
 WHERE id=161989002


   --row number: 1427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2807018 , [Content] ='Partner Sales'
 WHERE id=161989003


   --row number: 1428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2807018 , [Content] ='S1615 - Regional Partner Mgr IC5'
 WHERE id=161989004


   --row number: 1429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2807018 , [Content] ='IC5'
 WHERE id=161989005


   --row number: 1430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2807018 , [Content] ='UK'
 WHERE id=161989007


   --row number: 1431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2807018 , [Content] ='Yes'
 WHERE id=161989009


   --row number: 1432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2807018 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=161989010


   --row number: 1433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2807018 , [Content] ='60/40'
 WHERE id=161989011


   --row number: 1434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2807018 , [Content] ='EMEA'
 WHERE id=161989014


   --row number: 1435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2807018 , [Content] ='UNITED KINGDOM'
 WHERE id=161989015


   --row number: 1436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2807018 , [Content] ='Technical'
 WHERE id=161989016


   --row number: 1437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2807018 , [Content] ='8742-Salespersons - Outside'
 WHERE id=161989017


   --row number: 1438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2807018 , [Content] ='4 - Sales Workers'
 WHERE id=161989018


   --row number: 1439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2807018 , [Content] ='S1615 UK'
 WHERE id=161989000


   --row number: 1440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2808380 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=162098819


   --row number: 1441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2808380 , [Content] ='IC4'
 WHERE id=162098820


   --row number: 1442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2808380 , [Content] ='US - MRKT 2'
 WHERE id=162098822


   --row number: 1443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2808380 , [Content] ='Yes'
 WHERE id=162098824


   --row number: 1444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2808380 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=162098825


   --row number: 1445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2808380 , [Content] ='75/25'
 WHERE id=162098826


   --row number: 1446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2808380 , [Content] ='EXEMPT'
 WHERE id=162098827


   --row number: 1447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2808380 , [Content] ='NO'
 WHERE id=162098828


   --row number: 1448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2808380 , [Content] ='AMS'
 WHERE id=162098831


   --row number: 1449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2808380 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=162098832


   --row number: 1450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2808380 , [Content] ='Technical'
 WHERE id=162098833


   --row number: 1451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2808380 , [Content] ='8742-Salespersons - Outside'
 WHERE id=162098834


   --row number: 1452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2808380 , [Content] ='4 - Sales Workers'
 WHERE id=162098835


   --row number: 1453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2808380 , [Content] ='S1414A US - MRKT 2'
 WHERE id=162098815


   --row number: 1454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2808380 , [Content] ='USD'
 WHERE id=162098816


   --row number: 1455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2808380 , [Content] ='Solution Consulting'
 WHERE id=162098817


   --row number: 1456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2808380 , [Content] ='Solution Consultant Architect'
 WHERE id=162098818


   --row number: 1457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2811219 , [Content] ='5764 DEU'
 WHERE id=162832107


   --row number: 1458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2811219 , [Content] ='DEU'
 WHERE id=162832108


   --row number: 1459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2811219 , [Content] ='EMEA'
 WHERE id=162832109


   --row number: 1460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2811219 , [Content] ='GERMANY'
 WHERE id=162832110


   --row number: 1461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2811219 , [Content] ='Professional Services'
 WHERE id=162832111


   --row number: 1462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2811219 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=162832112


   --row number: 1463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2811219 , [Content] ='Technology Consultant'
 WHERE id=162832113


   --row number: 1464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2811219 , [Content] ='IC4'
 WHERE id=162832114


   --row number: 1465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2811219 , [Content] ='EUR'
 WHERE id=162832116


   --row number: 1466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2811219 , [Content] ='59,200 / 71,600 / 84,000 / 96,400 / 108,800'
 WHERE id=162832117


   --row number: 1467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2811219 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=162832119


   --row number: 1468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2811219 , [Content] ='20%'
 WHERE id=162832120


   --row number: 1469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2811219 , [Content] ='Yes'
 WHERE id=162832121


   --row number: 1470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2811219 , [Content] ='2 - Professionals'
 WHERE id=162832122


   --row number: 1471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2811219 , [Content] ='8810-Clerical Office Employees'
 WHERE id=162832123


   --row number: 1472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2811219 , [Content] ='Technical'
 WHERE id=162832124


   --row number: 1473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2811219 , [Content] ='04/05/18'
 WHERE id=162832125


   --row number: 1474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2812617 , [Content] ='R3613B AUS'
 WHERE id=162950009


   --row number: 1475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2812617 , [Content] ='AUS'
 WHERE id=162950010


   --row number: 1476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2812617 , [Content] ='APAC'
 WHERE id=162950011


   --row number: 1477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2812617 , [Content] ='AUSTRALIA'
 WHERE id=162950012


   --row number: 1478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2812617 , [Content] ='Sales'
 WHERE id=162950013


   --row number: 1479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2812617 , [Content] ='R3613B - Commercial Account Exec IC3'
 WHERE id=162950014


   --row number: 1480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2812617 , [Content] ='Commercial Accounts'
 WHERE id=162950015


   --row number: 1481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2812617 , [Content] ='IC3'
 WHERE id=162950016


   --row number: 1482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2812617 , [Content] ='AUD'
 WHERE id=162950018


   --row number: 1483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2812617 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=162950020


   --row number: 1484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2812617 , [Content] ='50/50'
 WHERE id=162950021


   --row number: 1485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2812617 , [Content] ='Yes'
 WHERE id=162950022


   --row number: 1486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2812617 , [Content] ='4 - Sales Workers'
 WHERE id=162950023


   --row number: 1487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2812617 , [Content] ='8742-Salespersons - Outside'
 WHERE id=162950024


   --row number: 1488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2812617 , [Content] ='Technical'
 WHERE id=162950025


   --row number: 1489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2812617 , [Content] ='04/05/18'
 WHERE id=162950026


   --row number: 1490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2812749 , [Content] ='2245 US - MRKT 2'
 WHERE id=162963833


   --row number: 1491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2812749 , [Content] ='US - MRKT 2'
 WHERE id=162963834


   --row number: 1492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2812749 , [Content] ='AMS'
 WHERE id=162963835


   --row number: 1493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2812749 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=162963836


   --row number: 1494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2812749 , [Content] ='Engineering'
 WHERE id=162963837


   --row number: 1495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2812749 , [Content] ='2245 - Dir, Product Mgmt M5'
 WHERE id=162963838


   --row number: 1496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2812749 , [Content] ='Product Mgmt Mgr'
 WHERE id=162963839


   --row number: 1497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2812749 , [Content] ='M5'
 WHERE id=162963840


   --row number: 1498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2812749 , [Content] ='USD'
 WHERE id=162963842


   --row number: 1499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2812749 , [Content] ='130,400 / 159,750 / 189,100 / 218,450 / 247,800'
 WHERE id=162963843


   --row number: 1500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2812749 , [Content] ='312,000 / 468,000 / 624,000 / 780,000 / 936,000'
 WHERE id=162963845


   --row number: 1501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2812749 , [Content] ='25%'
 WHERE id=162963846


   --row number: 1502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2812749 , [Content] ='Yes'
 WHERE id=162963847


   --row number: 1503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2812749 , [Content] ='EXEMPT'
 WHERE id=162963848


   --row number: 1504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2812749 , [Content] ='NO'
 WHERE id=162963849


   --row number: 1505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2812749 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=162963850


   --row number: 1506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2812749 , [Content] ='8810-Clerical Office Employees'
 WHERE id=162963851


   --row number: 1507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2812749 , [Content] ='Technical'
 WHERE id=162963852


   --row number: 1508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2812749 , [Content] ='04/05/18'
 WHERE id=162963853


   --row number: 1509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2812789 , [Content] ='2266 US - MRKT 1'
 WHERE id=162969943


   --row number: 1510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2812789 , [Content] ='US - MRKT 1'
 WHERE id=162969944


   --row number: 1511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2812789 , [Content] ='AMS'
 WHERE id=162969945


   --row number: 1512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2812789 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=162969946


   --row number: 1513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2812789 , [Content] ='Engineering'
 WHERE id=162969947


   --row number: 1514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2812789 , [Content] ='2266 - Sr Dir, Project/Program (Design) Mgmt M6'
 WHERE id=162969948


   --row number: 1515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2812789 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=162969949


   --row number: 1516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2812789 , [Content] ='M6'
 WHERE id=162969950


   --row number: 1517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2812789 , [Content] ='USD'
 WHERE id=162969952


   --row number: 1518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2812789 , [Content] ='170,400 / 208,750 / 247,100 / 285,450 / 323,800'
 WHERE id=162969953


   --row number: 1519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2812789 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=162969955


   --row number: 1520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2812789 , [Content] ='30%'
 WHERE id=162969956


   --row number: 1521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2812789 , [Content] ='Yes'
 WHERE id=162969957


   --row number: 1522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2812789 , [Content] ='EXEMPT'
 WHERE id=162969958


   --row number: 1523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2812789 , [Content] ='NO'
 WHERE id=162969959


   --row number: 1524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2812789 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=162969960


   --row number: 1525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2812789 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=162969961


   --row number: 1526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2812789 , [Content] ='Technical'
 WHERE id=162969962


   --row number: 1527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2812789 , [Content] ='04/05/18'
 WHERE id=162969963


   --row number: 1528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2814253 , [Content] ='3396 US - MRKT 1'
 WHERE id=163131022


   --row number: 1529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2814253 , [Content] ='US - MRKT 1'
 WHERE id=163131023


   --row number: 1530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2814253 , [Content] ='AMS'
 WHERE id=163131024


   --row number: 1531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2814253 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=163131025


   --row number: 1532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2814253 , [Content] ='Legal'
 WHERE id=163131026


   --row number: 1533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2814253 , [Content] ='3396 - Sr Dir, Corporate Counsel Mgmt M6'
 WHERE id=163131027


   --row number: 1534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2814253 , [Content] ='Legal Counsel'
 WHERE id=163131028


   --row number: 1535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2814253 , [Content] ='M6'
 WHERE id=163131029


   --row number: 1536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2814253 , [Content] ='USD'
 WHERE id=163131031


   --row number: 1537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2814253 , [Content] ='188,600 / 231,000 / 273,400 / 315,850 / 358,300'
 WHERE id=163131032


   --row number: 1538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2814253 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=163131034


   --row number: 1539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2814253 , [Content] ='30%'
 WHERE id=163131035


   --row number: 1540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2814253 , [Content] ='Yes'
 WHERE id=163131036


   --row number: 1541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2814253 , [Content] ='EXEMPT'
 WHERE id=163131037


   --row number: 1542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2814253 , [Content] ='NO'
 WHERE id=163131038


   --row number: 1543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2814253 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=163131039


   --row number: 1544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2814253 , [Content] ='8810-Clerical Office Employees'
 WHERE id=163131040


   --row number: 1545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2814253 , [Content] ='Non Technical'
 WHERE id=163131041


   --row number: 1546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2814253 , [Content] ='04/05/18'
 WHERE id=163131042


   --row number: 1547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2819360 , [Content] ='Yes'
 WHERE id=163623933


   --row number: 1548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2819360 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=163623935


   --row number: 1549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2819360 , [Content] ='Technical'
 WHERE id=163623936


   --row number: 1550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2819360 , [Content] ='04/05/18'
 WHERE id=163623937


   --row number: 1551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2819360 , [Content] ='2 - Professionals'
 WHERE id=163623934


   --row number: 1552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2819360 , [Content] ='5144 IND'
 WHERE id=163623919


   --row number: 1553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2819360 , [Content] ='IND'
 WHERE id=163623920


   --row number: 1554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2819360 , [Content] ='APAC'
 WHERE id=163623921


   --row number: 1555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2819360 , [Content] ='INDIA'
 WHERE id=163623922


   --row number: 1556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2819360 , [Content] ='Engineering'
 WHERE id=163623923


   --row number: 1557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2819360 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=163623924


   --row number: 1558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2819360 , [Content] ='Software'
 WHERE id=163623925


   --row number: 1559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2819360 , [Content] ='IC4'
 WHERE id=163623926


   --row number: 1560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2819360 , [Content] ='INR'
 WHERE id=163623928


   --row number: 1561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2819360 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=163623929


   --row number: 1562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2819360 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=163623931


   --row number: 1563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2819360 , [Content] ='20%'
 WHERE id=163623932


   --row number: 1564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2716706 , [Content] ='04/05/18'
 WHERE id=163402671


   --row number: 1565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2716706 , [Content] ='INR'
 WHERE id=163402672


   --row number: 1566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2819923 , [Content] ='8810-Clerical Office Employees'
 WHERE id=163751457


   --row number: 1567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2819923 , [Content] ='Non Technical'
 WHERE id=163751458


   --row number: 1568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2819923 , [Content] ='04/05/18'
 WHERE id=163751459


   --row number: 1569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2819923 , [Content] ='5615 NLD'
 WHERE id=163751441


   --row number: 1570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2819923 , [Content] ='NLD'
 WHERE id=163751442


   --row number: 1571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2819923 , [Content] ='EMEA'
 WHERE id=163751443


   --row number: 1572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2819923 , [Content] ='NETHERLANDS'
 WHERE id=163751444


   --row number: 1573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2819923 , [Content] ='Marketing'
 WHERE id=163751445


   --row number: 1574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2819923 , [Content] ='5615 - Marketing Mgr IC5'
 WHERE id=163751446


   --row number: 1575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2819923 , [Content] ='Marketing'
 WHERE id=163751447


   --row number: 1576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2819923 , [Content] ='IC5'
 WHERE id=163751448


   --row number: 1577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2819923 , [Content] ='EUR'
 WHERE id=163751450


   --row number: 1578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2819923 , [Content] ='75,000 / 90,700 / 106,400 / 122,150 / 137,900'
 WHERE id=163751451


   --row number: 1579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2819923 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=163751453


   --row number: 1580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2819923 , [Content] ='20%'
 WHERE id=163751454


   --row number: 1581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2819923 , [Content] ='Yes'
 WHERE id=163751455


   --row number: 1582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2819923 , [Content] ='2 - Professionals'
 WHERE id=163751456


   --row number: 1583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2820692 , [Content] ='5705 CHE'
 WHERE id=163906317


   --row number: 1584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2820692 , [Content] ='CHE'
 WHERE id=163906318


   --row number: 1585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2820692 , [Content] ='EMEA'
 WHERE id=163906319


   --row number: 1586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2820692 , [Content] ='SWITZERLAND'
 WHERE id=163906320


   --row number: 1587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2820692 , [Content] ='Professional Services'
 WHERE id=163906321


   --row number: 1588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2820692 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=163906322


   --row number: 1589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2820692 , [Content] ='Partner Support'
 WHERE id=163906323


   --row number: 1590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2820692 , [Content] ='IC5'
 WHERE id=163906324


   --row number: 1591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2820692 , [Content] ='CHF'
 WHERE id=163906326


   --row number: 1592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2820692 , [Content] ='124,100 / 152,050 / 180,000 / 207,900 / 235,800'
 WHERE id=163906327


   --row number: 1593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2820692 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=163906329


   --row number: 1594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2820692 , [Content] ='25%'
 WHERE id=163906330


   --row number: 1595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2820692 , [Content] ='Yes'
 WHERE id=163906331


   --row number: 1596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2820692 , [Content] ='2 - Professionals'
 WHERE id=163906332


   --row number: 1597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2820692 , [Content] ='8810-Clerical Office Employees'
 WHERE id=163906333


   --row number: 1598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2820692 , [Content] ='Technical'
 WHERE id=163906334


   --row number: 1599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2820692 , [Content] ='09/05/18'
 WHERE id=163906335


   --row number: 1600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2820485 , [Content] ='6212 IND'
 WHERE id=163871648


   --row number: 1601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2820485 , [Content] ='IND'
 WHERE id=163871649


   --row number: 1602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2820485 , [Content] ='APAC'
 WHERE id=163871650


   --row number: 1603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2820485 , [Content] ='INDIA'
 WHERE id=163871651


   --row number: 1604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2820485 , [Content] ='Human Resources'
 WHERE id=163871652


   --row number: 1605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2820485 , [Content] ='6212 - Shared Services Representative IC2'
 WHERE id=163871653


   --row number: 1606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2820485 , [Content] ='HR Shared Srvcs'
 WHERE id=163871654


   --row number: 1607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2820485 , [Content] ='IC2'
 WHERE id=163871655


   --row number: 1608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2820485 , [Content] ='INR'
 WHERE id=163871657


   --row number: 1609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2820485 , [Content] ='10%'
 WHERE id=163871658


   --row number: 1610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2820485 , [Content] ='No'
 WHERE id=163871659


   --row number: 1611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2820485 , [Content] ='2 - Professionals'
 WHERE id=163871660


   --row number: 1612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2820485 , [Content] ='8810-Clerical Office Employees'
 WHERE id=163871661


   --row number: 1613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2820485 , [Content] ='Non Technical'
 WHERE id=163871662


   --row number: 1614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2820485 , [Content] ='5/22/2018'
 WHERE id=163871663


   --row number: 1615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2821098 , [Content] ='S1515 FRA'
 WHERE id=163953663


   --row number: 1616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2821098 , [Content] ='FRA'
 WHERE id=163953664


   --row number: 1617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2821098 , [Content] ='EMEA'
 WHERE id=163953665


   --row number: 1618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2821098 , [Content] ='FRANCE'
 WHERE id=163953666


   --row number: 1619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2821098 , [Content] ='Professional Services'
 WHERE id=163953667


   --row number: 1620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2821098 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=163953668


   --row number: 1621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2821098 , [Content] ='Solution Architect'
 WHERE id=163953669


   --row number: 1622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2821098 , [Content] ='IC5'
 WHERE id=163953670


   --row number: 1623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2821098 , [Content] ='EUR'
 WHERE id=163953672


   --row number: 1624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2821098 , [Content] ='73,100 / 89,550 / 106,000 / 122,450 / 138,900'
 WHERE id=163953673


   --row number: 1625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2821098 , [Content] ='25%'
 WHERE id=163953675


   --row number: 1626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2821098 , [Content] ='No'
 WHERE id=163953676


   --row number: 1627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2821098 , [Content] ='4 - Sales Workers'
 WHERE id=163953677


   --row number: 1628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2821098 , [Content] ='8810-Clerical Office Employees'
 WHERE id=163953678


   --row number: 1629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2821098 , [Content] ='Technical'
 WHERE id=163953679


   --row number: 1630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2821098 , [Content] ='04/05/18'
 WHERE id=163953680


   --row number: 1631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2821072 , [Content] ='S1515 DEU'
 WHERE id=163950601


   --row number: 1632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2821072 , [Content] ='DEU'
 WHERE id=163950602


   --row number: 1633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2821072 , [Content] ='EMEA'
 WHERE id=163950603


   --row number: 1634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2821072 , [Content] ='GERMANY'
 WHERE id=163950604


   --row number: 1635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2821072 , [Content] ='Professional Services'
 WHERE id=163950605


   --row number: 1636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2821072 , [Content] ='S1515 - PS, Solution Architect IC5'
 WHERE id=163950606


   --row number: 1637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2821072 , [Content] ='Solution Architect'
 WHERE id=163950607


   --row number: 1638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2821072 , [Content] ='IC5'
 WHERE id=163950608


   --row number: 1639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2821072 , [Content] ='EUR'
 WHERE id=163950610


   --row number: 1640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2821072 , [Content] ='106,800 / 149,400 / 192,000 / 234,000 / 276,000'
 WHERE id=163950611


   --row number: 1641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2821072 , [Content] ='25%'
 WHERE id=163950612


   --row number: 1642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2821072 , [Content] ='Yes'
 WHERE id=163950613


   --row number: 1643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2821072 , [Content] ='4 - Sales Workers'
 WHERE id=163950614


   --row number: 1644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2821072 , [Content] ='8810-Clerical Office Employees'
 WHERE id=163950615


   --row number: 1645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2821072 , [Content] ='Technical'
 WHERE id=163950616


   --row number: 1646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2821072 , [Content] ='04/05/18'
 WHERE id=163950617


   --row number: 1647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2822623 , [Content] ='5704 - Client Relationship Manager IC4'
 WHERE id=164122923


   --row number: 1648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2822623 , [Content] ='EUR'
 WHERE id=164122927


   --row number: 1649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2822623 , [Content] ='56,400 / 68,200 / 80,000 / 91,850 / 103,700'
 WHERE id=164122928


   --row number: 1650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2822623 , [Content] ='20%'
 WHERE id=164122930


   --row number: 1651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2822623 , [Content] ='No'
 WHERE id=164122931


   --row number: 1652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2822623 , [Content] ='2 - Professionals'
 WHERE id=164122932


   --row number: 1653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2822623 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164122933


   --row number: 1654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2822623 , [Content] ='Technical'
 WHERE id=164122934


   --row number: 1655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2822623 , [Content] ='4/25/2018'
 WHERE id=164122935


   --row number: 1656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2822623 , [Content] ='Partner Support'
 WHERE id=164122924


   --row number: 1657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2822623 , [Content] ='IC4'
 WHERE id=164122925


   --row number: 1658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2822623 , [Content] ='5704 FRA'
 WHERE id=164122918


   --row number: 1659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2822623 , [Content] ='FRA'
 WHERE id=164122919


   --row number: 1660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2822623 , [Content] ='EMEA'
 WHERE id=164122920


   --row number: 1661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2822623 , [Content] ='FRANCE'
 WHERE id=164122921


   --row number: 1662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2822623 , [Content] ='Professional Services'
 WHERE id=164122922


   --row number: 1663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2822062 , [Content] ='9999 US - MRKT 1'
 WHERE id=164046592


   --row number: 1664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2822062 , [Content] ='US - MRKT 1'
 WHERE id=164046593


   --row number: 1665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2822062 , [Content] ='AMS'
 WHERE id=164046594


   --row number: 1666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2822062 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=164046595


   --row number: 1667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2822062 , [Content] ='9999 - Intern'
 WHERE id=164046597


   --row number: 1668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2822062 , [Content] ='USD'
 WHERE id=164046601


   --row number: 1669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2822062 , [Content] ='No'
 WHERE id=164046606


   --row number: 1670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2822062 , [Content] ='NON-EXEMPT'
 WHERE id=164046607


   --row number: 1671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2822062 , [Content] ='04/05/18'
 WHERE id=164046612


   --row number: 1672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2824512 , [Content] ='5141 IND'
 WHERE id=164332912


   --row number: 1673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2824512 , [Content] ='IND'
 WHERE id=164332913


   --row number: 1674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2824512 , [Content] ='APAC'
 WHERE id=164332914


   --row number: 1675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2824512 , [Content] ='INDIA'
 WHERE id=164332915


   --row number: 1676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2824512 , [Content] ='Engineering'
 WHERE id=164332916


   --row number: 1677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2824512 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=164332917


   --row number: 1678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2824512 , [Content] ='Software'
 WHERE id=164332918


   --row number: 1679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2824512 , [Content] ='IC1'
 WHERE id=164332919


   --row number: 1680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2824512 , [Content] ='INR'
 WHERE id=164332921


   --row number: 1681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2824512 , [Content] ='703,500 / 861,800 / 1,020,100 / 1,178,400 / 1,336,700'
 WHERE id=164332922


   --row number: 1682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2824512 , [Content] ='10%'
 WHERE id=164332924


   --row number: 1683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2824512 , [Content] ='No'
 WHERE id=164332925


   --row number: 1684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2824512 , [Content] ='2 - Professionals'
 WHERE id=164332926


   --row number: 1685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2824512 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=164332927


   --row number: 1686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2824512 , [Content] ='Technical'
 WHERE id=164332928


   --row number: 1687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2824512 , [Content] ='02/09/18'
 WHERE id=164332929


   --row number: 1688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2824770 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=164356101


   --row number: 1689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2824770 , [Content] ='60/40'
 WHERE id=164356102


   --row number: 1690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2824770 , [Content] ='Yes'
 WHERE id=164356103


   --row number: 1691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2824770 , [Content] ='4 - Sales Workers'
 WHERE id=164356104


   --row number: 1692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2824770 , [Content] ='8742-Salespersons - Outside'
 WHERE id=164356105


   --row number: 1693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2824770 , [Content] ='Technical'
 WHERE id=164356106


   --row number: 1694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2824770 , [Content] ='04/05/18'
 WHERE id=164356107


   --row number: 1695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2824770 , [Content] ='S665 NLD'
 WHERE id=164356090


   --row number: 1696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2824770 , [Content] ='NLD'
 WHERE id=164356091


   --row number: 1697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2824770 , [Content] ='EMEA'
 WHERE id=164356092


   --row number: 1698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2824770 , [Content] ='NETHERLANDS'
 WHERE id=164356093


   --row number: 1699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2824770 , [Content] ='Sales'
 WHERE id=164356094


   --row number: 1700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2824770 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=164356095


   --row number: 1701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2824770 , [Content] ='Product Line Sales'
 WHERE id=164356096


   --row number: 1702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2824770 , [Content] ='IC5'
 WHERE id=164356097


   --row number: 1703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2824770 , [Content] ='EUR'
 WHERE id=164356099


   --row number: 1704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2825657 , [Content] ='5142 US - MRKT 1'
 WHERE id=164435261


   --row number: 1705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2825657 , [Content] ='US - MRKT 1'
 WHERE id=164435262


   --row number: 1706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2825657 , [Content] ='AMS'
 WHERE id=164435263


   --row number: 1707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2825657 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=164435264


   --row number: 1708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2825657 , [Content] ='Engineering'
 WHERE id=164435265


   --row number: 1709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2825657 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=164435266


   --row number: 1710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2825657 , [Content] ='Software'
 WHERE id=164435267


   --row number: 1711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2825657 , [Content] ='IC2'
 WHERE id=164435268


   --row number: 1712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2825657 , [Content] ='USD'
 WHERE id=164435270


   --row number: 1713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2825657 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=164435271


   --row number: 1714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2825657 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=164435273


   --row number: 1715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2825657 , [Content] ='10%'
 WHERE id=164435274


   --row number: 1716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2825657 , [Content] ='Yes'
 WHERE id=164435275


   --row number: 1717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2825657 , [Content] ='EXEMPT'
 WHERE id=164435276


   --row number: 1718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2825657 , [Content] ='NO'
 WHERE id=164435277


   --row number: 1719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2825657 , [Content] ='2 - Professionals'
 WHERE id=164435278


   --row number: 1720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2825657 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=164435279


   --row number: 1721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2825657 , [Content] ='Technical'
 WHERE id=164435280


   --row number: 1722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2825657 , [Content] ='04/05/18'
 WHERE id=164435281


   --row number: 1723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2826010 , [Content] ='15%'
 WHERE id=164487073


   --row number: 1724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826010 , [Content] ='04/05/18'
 WHERE id=164487081


   --row number: 1725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826010 , [Content] ='6803 US - MRKT 2'
 WHERE id=164487060


   --row number: 1726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826010 , [Content] ='US - MRKT 2'
 WHERE id=164487061


   --row number: 1727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826010 , [Content] ='AMS'
 WHERE id=164487062


   --row number: 1728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826010 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=164487063


   --row number: 1729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826010 , [Content] ='Info Systems/Technology'
 WHERE id=164487064


   --row number: 1730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826010 , [Content] ='6803 - UI/ UX Designer IC3'
 WHERE id=164487065


   --row number: 1731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826010 , [Content] ='UI/UX Designer'
 WHERE id=164487066


   --row number: 1732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826010 , [Content] ='IC3'
 WHERE id=164487067


   --row number: 1733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826010 , [Content] ='USD'
 WHERE id=164487069


   --row number: 1734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826010 , [Content] ='85,800 / 101,250 / 116,700 / 132,150 / 147,600'
 WHERE id=164487070


   --row number: 1735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2826010 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=164487072


   --row number: 1736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826010 , [Content] ='Yes'
 WHERE id=164487074


   --row number: 1737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2826010 , [Content] ='EXEMPT'
 WHERE id=164487075


   --row number: 1738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2826010 , [Content] ='NO'
 WHERE id=164487076


   --row number: 1739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826010 , [Content] ='2 - Professionals'
 WHERE id=164487077


   --row number: 1740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826010 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164487078


   --row number: 1741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826010 , [Content] ='Technical'
 WHERE id=164487079


   --row number: 1742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826522 , [Content] ='5764 NLD'
 WHERE id=164528361


   --row number: 1743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826522 , [Content] ='NLD'
 WHERE id=164528362


   --row number: 1744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826522 , [Content] ='EMEA'
 WHERE id=164528363


   --row number: 1745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826522 , [Content] ='NETHERLANDS'
 WHERE id=164528364


   --row number: 1746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826522 , [Content] ='Professional Services'
 WHERE id=164528365


   --row number: 1747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826522 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=164528366


   --row number: 1748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826522 , [Content] ='Technology Consultant'
 WHERE id=164528367


   --row number: 1749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826522 , [Content] ='IC4'
 WHERE id=164528368


   --row number: 1750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826522 , [Content] ='EUR'
 WHERE id=164528370


   --row number: 1751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826522 , [Content] ='59,500 / 72,000 / 84,500 / 96,950 / 109,400'
 WHERE id=164528371


   --row number: 1752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2826522 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=164528373


   --row number: 1753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2826522 , [Content] ='20%'
 WHERE id=164528374


   --row number: 1754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826522 , [Content] ='Yes'
 WHERE id=164528375


   --row number: 1755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826522 , [Content] ='2 - Professionals'
 WHERE id=164528376


   --row number: 1756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826522 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164528377


   --row number: 1757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826522 , [Content] ='Technical'
 WHERE id=164528378


   --row number: 1758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826522 , [Content] ='04/05/18'
 WHERE id=164528379


   --row number: 1759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826149 , [Content] ='S1606 ESP'
 WHERE id=164506049


   --row number: 1760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826149 , [Content] ='ESP'
 WHERE id=164506050


   --row number: 1761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826149 , [Content] ='EMEA'
 WHERE id=164506051


   --row number: 1762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826149 , [Content] ='SPAIN'
 WHERE id=164506052


   --row number: 1763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826149 , [Content] ='Sales'
 WHERE id=164506053


   --row number: 1764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826149 , [Content] ='S1606 - Sr Dir, Partner Sales M6'
 WHERE id=164506054


   --row number: 1765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826149 , [Content] ='Partner Sales'
 WHERE id=164506055


   --row number: 1766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826149 , [Content] ='M6'
 WHERE id=164506056


   --row number: 1767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826149 , [Content] ='EUR'
 WHERE id=164506058


   --row number: 1768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826149 , [Content] ='119,595 / 130,148 / 140,700 / 151,253 / 161,805'
 WHERE id=164506059


   --row number: 1769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2826149 , [Content] ='60/40'
 WHERE id=164506061


   --row number: 1770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826149 , [Content] ='Yes'
 WHERE id=164506062


   --row number: 1771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826149 , [Content] ='4 - Sales Workers'
 WHERE id=164506063


   --row number: 1772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826149 , [Content] ='8742-Salespersons - Outside'
 WHERE id=164506064


   --row number: 1773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826149 , [Content] ='Technical'
 WHERE id=164506065


   --row number: 1774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826149 , [Content] ='04/05/18'
 WHERE id=164506066


   --row number: 1775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2826149 , [Content] ='120,000 / 180,000 / 240,000 / 300,000 / 360,000'
 WHERE id=164509540


   --row number: 1776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826530 , [Content] ='5764 SWE'
 WHERE id=164529067


   --row number: 1777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826530 , [Content] ='SWE'
 WHERE id=164529068


   --row number: 1778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826530 , [Content] ='EMEA'
 WHERE id=164529069


   --row number: 1779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826530 , [Content] ='SWEDEN'
 WHERE id=164529070


   --row number: 1780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826530 , [Content] ='Professional Services'
 WHERE id=164529071


   --row number: 1781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826530 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=164529072


   --row number: 1782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826530 , [Content] ='Technology Consultant'
 WHERE id=164529073


   --row number: 1783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826530 , [Content] ='IC4'
 WHERE id=164529074


   --row number: 1784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826530 , [Content] ='SEK'
 WHERE id=164529076


   --row number: 1785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826530 , [Content] ='518,000 / 626,500 / 735,000 / 843,550 / 952,100'
 WHERE id=164529077


   --row number: 1786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2826530 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=164529079


   --row number: 1787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2826530 , [Content] ='20%'
 WHERE id=164529080


   --row number: 1788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826530 , [Content] ='Yes'
 WHERE id=164529081


   --row number: 1789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826530 , [Content] ='2 - Professionals'
 WHERE id=164529082


   --row number: 1790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826530 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164529083


   --row number: 1791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826530 , [Content] ='Technical'
 WHERE id=164529084


   --row number: 1792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826530 , [Content] ='04/05/18'
 WHERE id=164529085


   --row number: 1793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826879 , [Content] ='5874A UK'
 WHERE id=164552250


   --row number: 1794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826879 , [Content] ='UK'
 WHERE id=164552251


   --row number: 1795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826879 , [Content] ='EMEA'
 WHERE id=164552252


   --row number: 1796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826879 , [Content] ='UNITED KINGDOM'
 WHERE id=164552253


   --row number: 1797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826879 , [Content] ='Professional Services'
 WHERE id=164552254


   --row number: 1798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826879 , [Content] ='5874A - Services Program Mgr IC4'
 WHERE id=164552255


   --row number: 1799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826879 , [Content] ='Srvcs Program Mgrs'
 WHERE id=164552256


   --row number: 1800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826879 , [Content] ='IC4'
 WHERE id=164552257


   --row number: 1801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826879 , [Content] ='GBP'
 WHERE id=164552259


   --row number: 1802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826879 , [Content] ='49,800 / 60,200 / 70,600 / 81,050 / 91,500'
 WHERE id=164552260


   --row number: 1803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2826879 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=164552262


   --row number: 1804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2826879 , [Content] ='20%'
 WHERE id=164552263


   --row number: 1805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826879 , [Content] ='Yes'
 WHERE id=164552264


   --row number: 1806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826879 , [Content] ='2 - Professionals'
 WHERE id=164552265


   --row number: 1807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826879 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164552266


   --row number: 1808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826879 , [Content] ='Technical'
 WHERE id=164552267


   --row number: 1809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826879 , [Content] ='04/05/18'
 WHERE id=164552268


   --row number: 1810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826923 , [Content] ='5874A ESP'
 WHERE id=164556141


   --row number: 1811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826923 , [Content] ='ESP'
 WHERE id=164556142


   --row number: 1812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826923 , [Content] ='EMEA'
 WHERE id=164556143


   --row number: 1813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826923 , [Content] ='SPAIN'
 WHERE id=164556144


   --row number: 1814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826923 , [Content] ='Professional Services'
 WHERE id=164556145


   --row number: 1815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826923 , [Content] ='5874A - Services Program Mgr IC4'
 WHERE id=164556146


   --row number: 1816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2826952 , [Content] ='5874A - Services Program Mgr IC4'
 WHERE id=164558336


   --row number: 1817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826952 , [Content] ='Srvcs Program Mgrs'
 WHERE id=164558337


   --row number: 1818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826952 , [Content] ='IC4'
 WHERE id=164558338


   --row number: 1819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826952 , [Content] ='EUR'
 WHERE id=164558340


   --row number: 1820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826952 , [Content] ='52,900 / 63,950 / 75,000 / 86,100 / 97,200'
 WHERE id=164558341


   --row number: 1821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2826952 , [Content] ='20%'
 WHERE id=164558343


   --row number: 1822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826952 , [Content] ='No'
 WHERE id=164558344


   --row number: 1823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826952 , [Content] ='2 - Professionals'
 WHERE id=164558345


   --row number: 1824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826952 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164558346


   --row number: 1825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826952 , [Content] ='Technical'
 WHERE id=164558347


   --row number: 1826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826952 , [Content] ='04/05/18'
 WHERE id=164558348


   --row number: 1827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2826923 , [Content] ='Srvcs Program Mgrs'
 WHERE id=164556147


   --row number: 1828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2826923 , [Content] ='IC4'
 WHERE id=164556148


   --row number: 1829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2826923 , [Content] ='EUR'
 WHERE id=164556150


   --row number: 1830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2826923 , [Content] ='45,000 / 54,450 / 63,900 / 73,300 / 82,700'
 WHERE id=164556151


   --row number: 1831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2826952 , [Content] ='5874A FRA'
 WHERE id=164558331


   --row number: 1832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2826952 , [Content] ='FRA'
 WHERE id=164558332


   --row number: 1833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2826952 , [Content] ='EMEA'
 WHERE id=164558333


   --row number: 1834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2826952 , [Content] ='FRANCE'
 WHERE id=164558334


   --row number: 1835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2826952 , [Content] ='Professional Services'
 WHERE id=164558335


   --row number: 1836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2826923 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=164556153


   --row number: 1837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2826923 , [Content] ='20%'
 WHERE id=164556154


   --row number: 1838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2826923 , [Content] ='Yes'
 WHERE id=164556155


   --row number: 1839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2826923 , [Content] ='2 - Professionals'
 WHERE id=164556156


   --row number: 1840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2826923 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164556157


   --row number: 1841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2826923 , [Content] ='Technical'
 WHERE id=164556158


   --row number: 1842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2826923 , [Content] ='04/05/18'
 WHERE id=164556159


   --row number: 1843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2829650 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=164911442


   --row number: 1844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2829650 , [Content] ='Product Mgmt Mgr'
 WHERE id=164911443


   --row number: 1845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2829650 , [Content] ='IC4'
 WHERE id=164911444


   --row number: 1846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2829650 , [Content] ='USD'
 WHERE id=164911446


   --row number: 1847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2829650 , [Content] ='101,800 / 123,150 / 144,500 / 165,800 / 187,100'
 WHERE id=164911447


   --row number: 1848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2829650 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=164911449


   --row number: 1849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2829650 , [Content] ='5224 US - MRKT 2'
 WHERE id=164911437


   --row number: 1850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2829650 , [Content] ='US - MRKT 2'
 WHERE id=164911438


   --row number: 1851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2829650 , [Content] ='AMS'
 WHERE id=164911439


   --row number: 1852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2829650 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=164911440


   --row number: 1853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2829650 , [Content] ='20%'
 WHERE id=164911450


   --row number: 1854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2829650 , [Content] ='Yes'
 WHERE id=164911451


   --row number: 1855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2829650 , [Content] ='EXEMPT'
 WHERE id=164911452


   --row number: 1856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2829650 , [Content] ='NO'
 WHERE id=164911453


   --row number: 1857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2829650 , [Content] ='2 - Professionals'
 WHERE id=164911454


   --row number: 1858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2829650 , [Content] ='8810-Clerical Office Employees'
 WHERE id=164911455


   --row number: 1859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2829650 , [Content] ='Technical'
 WHERE id=164911456


   --row number: 1860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2829650 , [Content] ='04/05/18'
 WHERE id=164911457


   --row number: 1861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2829650 , [Content] ='Engineering'
 WHERE id=164911441


   --row number: 1862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2830817 , [Content] ='S1413 US - MRKT 3'
 WHERE id=165022009


   --row number: 1863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2830817 , [Content] ='US - MRKT 3'
 WHERE id=165022010


   --row number: 1864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2830817 , [Content] ='AMS'
 WHERE id=165022011


   --row number: 1865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2830817 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=165022012


   --row number: 1866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2830817 , [Content] ='Solution Consulting'
 WHERE id=165022013


   --row number: 1867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2830817 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=165022014


   --row number: 1868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2830817 , [Content] ='Solution Consultant Core'
 WHERE id=165022015


   --row number: 1869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2830817 , [Content] ='IC3'
 WHERE id=165022016


   --row number: 1870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2830817 , [Content] ='USD'
 WHERE id=165022018


   --row number: 1871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2830817 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=165022019


   --row number: 1872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2830817 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=165022021


   --row number: 1873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2830817 , [Content] ='75/25'
 WHERE id=165022022


   --row number: 1874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2830817 , [Content] ='Yes'
 WHERE id=165022023


   --row number: 1875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2830817 , [Content] ='EXEMPT'
 WHERE id=165022024


   --row number: 1876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2830817 , [Content] ='4 - Sales Workers'
 WHERE id=165022026


   --row number: 1877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2830817 , [Content] ='8742-Salespersons - Outside'
 WHERE id=165022027


   --row number: 1878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2830817 , [Content] ='Technical'
 WHERE id=165022028


   --row number: 1879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2830817 , [Content] ='09/05/18'
 WHERE id=165022029


   --row number: 1880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2833257 , [Content] ='2704 IND'
 WHERE id=165260874


   --row number: 1881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2833257 , [Content] ='IND'
 WHERE id=165260875


   --row number: 1882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2833257 , [Content] ='APAC'
 WHERE id=165260876


   --row number: 1883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2833257 , [Content] ='INDIA'
 WHERE id=165260877


   --row number: 1884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2833257 , [Content] ='Marketing'
 WHERE id=165260878


   --row number: 1885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2833257 , [Content] ='2704 - Sr Mgr, Product Portfolio Mgmt M4'
 WHERE id=165260879


   --row number: 1886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2833257 , [Content] ='Product Mgrs'
 WHERE id=165260880


   --row number: 1887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2833257 , [Content] ='M4'
 WHERE id=165260881


   --row number: 1888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2833257 , [Content] ='INR'
 WHERE id=165260883


   --row number: 1889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2833257 , [Content] ='2,965,500 / 3,632,750 / 4,300,000 / 4,967,250 / 5,634,500'
 WHERE id=165260884


   --row number: 1890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2833257 , [Content] ='67,200 / 93,600 / 120,000 / 147,000 / 174,000'
 WHERE id=165260886


   --row number: 1891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2833257 , [Content] ='25%'
 WHERE id=165260887


   --row number: 1892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2833257 , [Content] ='Yes'
 WHERE id=165260888


   --row number: 1893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2833257 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=165260889


   --row number: 1894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2833257 , [Content] ='8810-Clerical Office Employees'
 WHERE id=165260890


   --row number: 1895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2833257 , [Content] ='Technical'
 WHERE id=165260891


   --row number: 1896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2833257 , [Content] ='7/20/18'
 WHERE id=165260892


   --row number: 1897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2834692 , [Content] ='3535 US - MRKT 1'
 WHERE id=165377049


   --row number: 1898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2834692 , [Content] ='US - MRKT 1'
 WHERE id=165377050


   --row number: 1899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2834692 , [Content] ='AMS'
 WHERE id=165377051


   --row number: 1900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2834692 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=165377052


   --row number: 1901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2834692 , [Content] ='Marketing'
 WHERE id=165377053


   --row number: 1902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2834692 , [Content] ='3535 - Dir, Online Marketing Mgmt M5'
 WHERE id=165377054


   --row number: 1903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2834692 , [Content] ='Online Marketing'
 WHERE id=165377055


   --row number: 1904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2834692 , [Content] ='M5'
 WHERE id=165377056


   --row number: 1905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2834692 , [Content] ='USD'
 WHERE id=165377058


   --row number: 1906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2834692 , [Content] ='134,500 / 164,750 / 195,000 / 225,300 / 255,600'
 WHERE id=165377059


   --row number: 1907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2834692 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=165377061


   --row number: 1908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2834692 , [Content] ='25%'
 WHERE id=165377062


   --row number: 1909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2834692 , [Content] ='Yes'
 WHERE id=165377063


   --row number: 1910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2834692 , [Content] ='EXEMPT'
 WHERE id=165377064


   --row number: 1911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2834692 , [Content] ='NO'
 WHERE id=165377065


   --row number: 1912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2834692 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=165377066


   --row number: 1913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2834692 , [Content] ='8810-Clerical Office Employees'
 WHERE id=165377067


   --row number: 1914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2834692 , [Content] ='Non Technical'
 WHERE id=165377068


   --row number: 1915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2834692 , [Content] ='04/05/18'
 WHERE id=165377069


   --row number: 1916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2835865 , [Content] ='Info Systems/Technology'
 WHERE id=165479747


   --row number: 1917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2835865 , [Content] ='3595 - Dir, Data Informatics Mgmt M5'
 WHERE id=165479748


   --row number: 1918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2835865 , [Content] ='3595 IND'
 WHERE id=165479743


   --row number: 1919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2835865 , [Content] ='IND'
 WHERE id=165479744


   --row number: 1920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2835865 , [Content] ='APAC'
 WHERE id=165479745


   --row number: 1921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2835865 , [Content] ='Data Informatics'
 WHERE id=165479749


   --row number: 1922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2835865 , [Content] ='M5'
 WHERE id=165479750


   --row number: 1923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2835865 , [Content] ='INR'
 WHERE id=165479752


   --row number: 1924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2835865 , [Content] ='3,793,100 / 4,646,550 / 5,500,000 / 6,353,450 / 7,206,900'
 WHERE id=165479753


   --row number: 1925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2835865 , [Content] ='90,000 / 135,000 / 180,000 / 225,000 / 270,000'
 WHERE id=165479755


   --row number: 1926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2835865 , [Content] ='25%'
 WHERE id=165479756


   --row number: 1927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2835865 , [Content] ='Yes'
 WHERE id=165479757


   --row number: 1928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2835865 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=165479758


   --row number: 1929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2835865 , [Content] ='8810-Clerical Office Employees'
 WHERE id=165479759


   --row number: 1930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2835865 , [Content] ='Technical'
 WHERE id=165479760


   --row number: 1931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2835865 , [Content] ='1/29/18'
 WHERE id=165479761


   --row number: 1932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2835865 , [Content] ='INDIA'
 WHERE id=165479746


   --row number: 1933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2837647 , [Content] ='5203 IND'
 WHERE id=165657492


   --row number: 1934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2837647 , [Content] ='IND'
 WHERE id=165657493


   --row number: 1935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2837647 , [Content] ='APAC'
 WHERE id=165657494


   --row number: 1936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2837647 , [Content] ='INDIA'
 WHERE id=165657495


   --row number: 1937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2837647 , [Content] ='Engineering'
 WHERE id=165657496


   --row number: 1938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2837647 , [Content] ='5203 - Sr Systems Design Engineer IC3'
 WHERE id=165657497


   --row number: 1939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2837647 , [Content] ='Systems Design'
 WHERE id=165657498


   --row number: 1940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2837647 , [Content] ='IC3'
 WHERE id=165657499


   --row number: 1941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2837647 , [Content] ='INR'
 WHERE id=165657501


   --row number: 1942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2837647 , [Content] ='1,172,400 / 1,436,200 / 1,700,000 / 1,963,800 / 2,227,600'
 WHERE id=165657502


   --row number: 1943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2837647 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=165657504


   --row number: 1944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2837647 , [Content] ='15%'
 WHERE id=165657505


   --row number: 1945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2837647 , [Content] ='Yes'
 WHERE id=165657506


   --row number: 1946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2837647 , [Content] ='2 - Professionals'
 WHERE id=165657507


   --row number: 1947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2837647 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=165657508


   --row number: 1948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2837647 , [Content] ='Technical'
 WHERE id=165657509


   --row number: 1949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2837647 , [Content] ='1/29/18'
 WHERE id=165657510


   --row number: 1950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2841082 , [Content] ='6802 IND'
 WHERE id=166004217


   --row number: 1951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2841082 , [Content] ='IND'
 WHERE id=166004218


   --row number: 1952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2841082 , [Content] ='APAC'
 WHERE id=166004219


   --row number: 1953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2841082 , [Content] ='INDIA'
 WHERE id=166004220


   --row number: 1954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2841082 , [Content] ='Info Systems/Technology'
 WHERE id=166004221


   --row number: 1955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2841082 , [Content] ='6802 - UI/ UX Designer IC2'
 WHERE id=166004222


   --row number: 1956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2841082 , [Content] ='UI/UX Designer'
 WHERE id=166004223


   --row number: 1957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2841082 , [Content] ='IC2'
 WHERE id=166004224


   --row number: 1958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2841082 , [Content] ='INR'
 WHERE id=166004226


   --row number: 1959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2841082 , [Content] ='622,100 / 762,050 / 902,000 / 1,042,000 / 1,182,000'
 WHERE id=166004227


   --row number: 1960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2841082 , [Content] ='10%'
 WHERE id=166004229


   --row number: 1961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2841082 , [Content] ='No'
 WHERE id=166004230


   --row number: 1962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2841082 , [Content] ='2 - Professionals'
 WHERE id=166004231


   --row number: 1963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2841082 , [Content] ='8810-Clerical Office Employees'
 WHERE id=166004232


   --row number: 1964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2841082 , [Content] ='Technical'
 WHERE id=166004233


   --row number: 1965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2841082 , [Content] ='04/05/18'
 WHERE id=166004234


   --row number: 1966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2841073 , [Content] ='6804 IND'
 WHERE id=166004027


   --row number: 1967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2841073 , [Content] ='IND'
 WHERE id=166004028


   --row number: 1968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2841073 , [Content] ='APAC'
 WHERE id=166004029


   --row number: 1969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2841073 , [Content] ='INDIA'
 WHERE id=166004030


   --row number: 1970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2841073 , [Content] ='Info Systems/Technology'
 WHERE id=166004031


   --row number: 1971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2841073 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=166004032


   --row number: 1972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2841073 , [Content] ='UI/UX Designer'
 WHERE id=166004033


   --row number: 1973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2841073 , [Content] ='IC4'
 WHERE id=166004034


   --row number: 1974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2841073 , [Content] ='INR'
 WHERE id=166004036


   --row number: 1975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2841073 , [Content] ='1,448,300 / 1,774,150 / 2,100,000 / 2,425,900 / 2,751,800'
 WHERE id=166004037


   --row number: 1976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2841073 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=166004039


   --row number: 1977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2841073 , [Content] ='20%'
 WHERE id=166004040


   --row number: 1978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2841073 , [Content] ='Yes'
 WHERE id=166004041


   --row number: 1979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2841073 , [Content] ='2 - Professionals'
 WHERE id=166004042


   --row number: 1980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2841073 , [Content] ='8810-Clerical Office Employees'
 WHERE id=166004043


   --row number: 1981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2841073 , [Content] ='Technical'
 WHERE id=166004044


   --row number: 1982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2841073 , [Content] ='04/05/18'
 WHERE id=166004045


   --row number: 1983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2841767 , [Content] ='S1415A US - MRKT 1'
 WHERE id=166059566


   --row number: 1984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2841767 , [Content] ='US - MRKT 1'
 WHERE id=166059567


   --row number: 1985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2841767 , [Content] ='AMS'
 WHERE id=166059568


   --row number: 1986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2841767 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=166059569


   --row number: 1987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2841767 , [Content] ='Solution Consulting'
 WHERE id=166059570


   --row number: 1988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2841767 , [Content] ='S1415A - Sr Advisory Solution Architect IC5'
 WHERE id=166059571


   --row number: 1989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2841767 , [Content] ='Solution Consultant Architect'
 WHERE id=166059572


   --row number: 1990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2841767 , [Content] ='IC5'
 WHERE id=166059573


   --row number: 1991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2841767 , [Content] ='USD'
 WHERE id=166059575


   --row number: 1992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2841767 , [Content] ='147,900 / 160,950 / 174,000 / 187,050 / 200,100'
 WHERE id=166059576


   --row number: 1993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2841767 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=166059578


   --row number: 1994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2841767 , [Content] ='75/25'
 WHERE id=166059579


   --row number: 1995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2841767 , [Content] ='Yes'
 WHERE id=166059580


   --row number: 1996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2841767 , [Content] ='EXEMPT'
 WHERE id=166059581


   --row number: 1997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2841767 , [Content] ='NO'
 WHERE id=166059582


   --row number: 1998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2841767 , [Content] ='4 - Sales Workers'
 WHERE id=166059583


   --row number: 1999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2841767 , [Content] ='8742-Salespersons - Outside'
 WHERE id=166059584


   --row number: 2000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2841767 , [Content] ='Technical'
 WHERE id=166059585


   --row number: 2001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2841767 , [Content] ='04/05/18'
 WHERE id=166059586


   --row number: 2002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2842342 , [Content] ='5233 US - MRKT 2'
 WHERE id=166106659


   --row number: 2003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2842342 , [Content] ='US - MRKT 2'
 WHERE id=166106660


   --row number: 2004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2842342 , [Content] ='AMS'
 WHERE id=166106661


   --row number: 2005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2842342 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=166106662


   --row number: 2006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2842342 , [Content] ='Engineering'
 WHERE id=166106663


   --row number: 2007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2842342 , [Content] ='5233 - Sr UI Engineer IC3'
 WHERE id=166106664


   --row number: 2008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2842342 , [Content] ='UI'
 WHERE id=166106665


   --row number: 2009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2842342 , [Content] ='IC3'
 WHERE id=166106666


   --row number: 2010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2842342 , [Content] ='USD'
 WHERE id=166106668


   --row number: 2011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2842342 , [Content] ='85,800 / 101,250 / 116,700 / 132,150 / 147,600'
 WHERE id=166106669


   --row number: 2012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2842342 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=166106671


   --row number: 2013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2842342 , [Content] ='15%'
 WHERE id=166106674


   --row number: 2014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2842342 , [Content] ='Yes'
 WHERE id=166106675


   --row number: 2015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2842342 , [Content] ='EXEMPT'
 WHERE id=166106676


   --row number: 2016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2842342 , [Content] ='NO'
 WHERE id=166106677


   --row number: 2017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2842342 , [Content] ='2 - Professionals'
 WHERE id=166106678


   --row number: 2018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2842342 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=166106679


   --row number: 2019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2842342 , [Content] ='Technical'
 WHERE id=166106683


   --row number: 2020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2842342 , [Content] ='04/05/18'
 WHERE id=166106684


   --row number: 2021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2843028 , [Content] ='86,400 / 121,200 / 156,000 / 190,800 / 225,600'
 WHERE id=166188331


   --row number: 2022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2843028 , [Content] ='5765 JPN'
 WHERE id=166188319


   --row number: 2023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2843028 , [Content] ='JPN'
 WHERE id=166188320


   --row number: 2024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2843028 , [Content] ='APAC'
 WHERE id=166188321


   --row number: 2025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2843028 , [Content] ='JAPAN'
 WHERE id=166188322


   --row number: 2026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2843028 , [Content] ='Professional Services'
 WHERE id=166188323


   --row number: 2027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2843028 , [Content] ='5765 - Technology Consultant IC5'
 WHERE id=166188324


   --row number: 2028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2843028 , [Content] ='Technology Consultant'
 WHERE id=166188325


   --row number: 2029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2843028 , [Content] ='IC5'
 WHERE id=166188326


   --row number: 2030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2843028 , [Content] ='JPY'
 WHERE id=166188328


   --row number: 2031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2843028 , [Content] ='9,476,600 / 11,608,850 / 13,741,100 / 15,873,300 / 18,005,500'
 WHERE id=166188329


   --row number: 2032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2843028 , [Content] ='25%'
 WHERE id=166188332


   --row number: 2033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2843028 , [Content] ='Yes'
 WHERE id=166188333


   --row number: 2034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2843028 , [Content] ='2 - Professionals'
 WHERE id=166188334


   --row number: 2035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2843028 , [Content] ='8810-Clerical Office Employees'
 WHERE id=166188335


   --row number: 2036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2843028 , [Content] ='Technical'
 WHERE id=166188336


   --row number: 2037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2843028 , [Content] ='04/05/18'
 WHERE id=166188337


   --row number: 2038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2843411 , [Content] ='5812 NLD'
 WHERE id=166225107


   --row number: 2039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2843411 , [Content] ='NLD'
 WHERE id=166225108


   --row number: 2040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2843411 , [Content] ='EMEA'
 WHERE id=166225109


   --row number: 2041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2843411 , [Content] ='NETHERLANDS'
 WHERE id=166225110


   --row number: 2042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2843411 , [Content] ='Customer Support'
 WHERE id=166225111


   --row number: 2043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2843411 , [Content] ='5812 - Customer Support Rep IC2'
 WHERE id=166225112


   --row number: 2044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2843411 , [Content] ='Customer Support'
 WHERE id=166225113


   --row number: 2045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2843411 , [Content] ='IC2'
 WHERE id=166225114


   --row number: 2046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2843411 , [Content] ='EUR'
 WHERE id=166225116


   --row number: 2047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2843411 , [Content] ='36,700 / 41,700 / 46,700 / 51,650 / 56,600'
 WHERE id=166225117


   --row number: 2048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2843411 , [Content] ='10%'
 WHERE id=166225119


   --row number: 2049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2843411 , [Content] ='No'
 WHERE id=166225120


   --row number: 2050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2843411 , [Content] ='2 - Professionals'
 WHERE id=166225121


   --row number: 2051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2843411 , [Content] ='8810-Clerical Office Employees'
 WHERE id=166225122


   --row number: 2052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2843411 , [Content] ='Technical'
 WHERE id=166225123


   --row number: 2053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2843411 , [Content] ='04/05/18'
 WHERE id=166225124


   --row number: 2054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2846078 , [Content] ='5145 US - MRKT 1'
 WHERE id=166465016


   --row number: 2055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2846078 , [Content] ='US - MRKT 1'
 WHERE id=166465017


   --row number: 2056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2846078 , [Content] ='AMS'
 WHERE id=166465018


   --row number: 2057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2846078 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=166465019


   --row number: 2058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2846078 , [Content] ='Engineering'
 WHERE id=166465020


   --row number: 2059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2846078 , [Content] ='5145 - Sr Staff Software Engineer IC5'
 WHERE id=166465021


   --row number: 2060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2846078 , [Content] ='Software'
 WHERE id=166465022


   --row number: 2061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2846078 , [Content] ='IC5'
 WHERE id=166465023


   --row number: 2062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2846078 , [Content] ='USD'
 WHERE id=166465025


   --row number: 2063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2846078 , [Content] ='143,000 / 175,200 / 207,400 / 239,550 / 271,700'
 WHERE id=166465026


   --row number: 2064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2846078 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=166465028


   --row number: 2065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2846078 , [Content] ='25%'
 WHERE id=166465029


   --row number: 2066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2846078 , [Content] ='Yes'
 WHERE id=166465030


   --row number: 2067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2846078 , [Content] ='EXEMPT'
 WHERE id=166465031


   --row number: 2068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2846078 , [Content] ='NO'
 WHERE id=166465032


   --row number: 2069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2846078 , [Content] ='2 - Professionals'
 WHERE id=166465033


   --row number: 2070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2846078 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=166465034


   --row number: 2071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2846078 , [Content] ='Technical'
 WHERE id=166465035


   --row number: 2072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2846078 , [Content] ='10/05/18'
 WHERE id=166465036


   --row number: 2073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2792288 , [Content] ='04/05/18'
 WHERE id=166567504


   --row number: 2074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2792288 , [Content] ='5143 US - MRKT 2'
 WHERE id=166567505


   --row number: 2075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2792288 , [Content] ='USD'
 WHERE id=166567506


   --row number: 2076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2847086 , [Content] ='9999 IND'
 WHERE id=166570159


   --row number: 2077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2847086 , [Content] ='IND'
 WHERE id=166570160


   --row number: 2078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2847086 , [Content] ='APAC'
 WHERE id=166570161


   --row number: 2079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2847086 , [Content] ='India'
 WHERE id=166570162


   --row number: 2080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2847086 , [Content] ='9999 - Intern'
 WHERE id=166570163


   --row number: 2081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2847086 , [Content] ='INR'
 WHERE id=166570165


   --row number: 2082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2847086 , [Content] ='No'
 WHERE id=166570166


   --row number: 2083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2847086 , [Content] ='04/05/18'
 WHERE id=166570167


   --row number: 2084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2847124 , [Content] ='UI/UX Designer'
 WHERE id=166577544


   --row number: 2085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2847124 , [Content] ='IC2'
 WHERE id=166577545


   --row number: 2086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2847124 , [Content] ='6802 US - MRKT 1'
 WHERE id=166577538


   --row number: 2087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2847124 , [Content] ='US - MRKT 1'
 WHERE id=166577539


   --row number: 2088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2847124 , [Content] ='AMS'
 WHERE id=166577540


   --row number: 2089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2847124 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=166577541


   --row number: 2090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2847124 , [Content] ='Info Systems/Technology'
 WHERE id=166577542


   --row number: 2091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2847124 , [Content] ='6802 - UI/ UX Designer IC2'
 WHERE id=166577543


   --row number: 2092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2847124 , [Content] ='USD'
 WHERE id=166577547


   --row number: 2093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2847124 , [Content] ='85,700 / 99,850 / 114,000 / 128,150 / 142,300'
 WHERE id=166577548


   --row number: 2094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2847124 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=166577550


   --row number: 2095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2847124 , [Content] ='10%'
 WHERE id=166577551


   --row number: 2096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2847124 , [Content] ='Yes'
 WHERE id=166577552


   --row number: 2097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2847124 , [Content] ='EXEMPT'
 WHERE id=166577553


   --row number: 2098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2847124 , [Content] ='NO'
 WHERE id=166577554


   --row number: 2099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2847124 , [Content] ='2 - Professionals'
 WHERE id=166577555


   --row number: 2100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2847124 , [Content] ='8810-Clerical Office Employees'
 WHERE id=166577556


   --row number: 2101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2847124 , [Content] ='Technical'
 WHERE id=166577557


   --row number: 2102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2847124 , [Content] ='04/05/18'
 WHERE id=166577559


   --row number: 2103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2807018 , [Content] ='04/05/18'
 WHERE id=167466351


   --row number: 2104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2807018 , [Content] ='86,700 / 94,350 / 102,000 / 109,650 / 117,300'
 WHERE id=167466352


   --row number: 2105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2861290 , [Content] ='EXEMPT'
 WHERE id=168149441


   --row number: 2106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2861290 , [Content] ='NO'
 WHERE id=168149442


   --row number: 2107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2861290 , [Content] ='2 - Professionals'
 WHERE id=168149443


   --row number: 2108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2861290 , [Content] ='5144 US - MRKT 1'
 WHERE id=168149426


   --row number: 2109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2861290 , [Content] ='US - MRKT 1'
 WHERE id=168149427


   --row number: 2110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2861290 , [Content] ='AMS'
 WHERE id=168149428


   --row number: 2111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2861290 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168149429


   --row number: 2112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2861290 , [Content] ='Engineering'
 WHERE id=168149430


   --row number: 2113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2861290 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=168149431


   --row number: 2114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2861290 , [Content] ='Software'
 WHERE id=168149432


   --row number: 2115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2861290 , [Content] ='IC4'
 WHERE id=168149433


   --row number: 2116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2861290 , [Content] ='USD'
 WHERE id=168149435


   --row number: 2117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2861290 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=168149436


   --row number: 2118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2861290 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=168149444


   --row number: 2119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2861290 , [Content] ='Technical'
 WHERE id=168149445


   --row number: 2120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2861290 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=168149438


   --row number: 2121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2861290 , [Content] ='20%'
 WHERE id=168149439


   --row number: 2122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2861290 , [Content] ='Yes'
 WHERE id=168149440


   --row number: 2123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2861290 , [Content] ='04/05/18'
 WHERE id=168149446


   --row number: 2124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2793508 , [Content] ='3115 US - MRKT 1'
 WHERE id=170693603


   --row number: 2125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2793508 , [Content] ='USD'
 WHERE id=170693604


   --row number: 2126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2793508 , [Content] ='148,200 / 181,550 / 214,900 / 248,250 / 281,600'
 WHERE id=170693601


   --row number: 2127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2793508 , [Content] ='FP&A'
 WHERE id=170693583


   --row number: 2128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2793508 , [Content] ='US - MRKT 1'
 WHERE id=170693584


   --row number: 2129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2793508 , [Content] ='EXEMPT'
 WHERE id=170693585


   --row number: 2130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2793508 , [Content] ='NO'
 WHERE id=170693586


   --row number: 2131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2793508 , [Content] ='AMS'
 WHERE id=170693588


   --row number: 2132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2793508 , [Content] ='Yes'
 WHERE id=170693589


   --row number: 2133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2793508 , [Content] ='8810-Clerical Office Employees'
 WHERE id=170693590


   --row number: 2134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2793508 , [Content] ='Finance'
 WHERE id=170693591


   --row number: 2135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2793508 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=170693592


   --row number: 2136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2793508 , [Content] ='25%'
 WHERE id=170693602


   --row number: 2137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2793508 , [Content] ='3115 - Dir, FP&A Mgmt M5'
 WHERE id=170693593


   --row number: 2138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2793508 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170693594


   --row number: 2139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2793508 , [Content] ='M5'
 WHERE id=170693595


   --row number: 2140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2793508 , [Content] ='Non Technical'
 WHERE id=170693596


   --row number: 2141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2793508 , [Content] ='4/25/2018'
 WHERE id=170693598


   --row number: 2142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2793508 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=170693600


   --row number: 2143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2725546 , [Content] ='04/05/18'
 WHERE id=170699628


   --row number: 2144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2725546 , [Content] ='6075 US - MRKT 2'
 WHERE id=170699629


   --row number: 2145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2725546 , [Content] ='USD'
 WHERE id=170699630


   --row number: 2146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2795702 , [Content] ='04/05/18'
 WHERE id=172098262


   --row number: 2147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2808380 , [Content] ='04/05/18'
 WHERE id=172102184


   --row number: 2148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2808380 , [Content] ='174,250 / 189,625 / 205,000 / 220,375 / 235,750'
 WHERE id=172102185


   --row number: 2149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2808380 , [Content] ='130,688 / 142,219 / 153,750 / 165,281 / 176,813'
 WHERE id=172102188


   --row number: 2150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2824770 , [Content] ='148,750 / 161,875 / 175,000 / 188,125 / 201,250'
 WHERE id=172102296


   --row number: 2151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2824770 , [Content] ='89,250 / 97,125 / 105,000 / 112,875 / 120,750'
 WHERE id=172102299


   --row number: 2152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2798440 , [Content] ='04/05/18'
 WHERE id=172099394


   --row number: 2153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2799124 , [Content] ='04/05/18'
 WHERE id=172100108


   --row number: 2154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2785668 , [Content] ='04/05/18'
 WHERE id=172110544


   --row number: 2155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2785668 , [Content] ='USD'
 WHERE id=172110548


   --row number: 2156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2728681 , [Content] ='04/05/18'
 WHERE id=172110585


   --row number: 2157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2728681 , [Content] ='USD'
 WHERE id=172110590


   --row number: 2158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2783732 , [Content] ='4/25/2018'
 WHERE id=172110606


   --row number: 2159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2783732 , [Content] ='USD'
 WHERE id=172110611


   --row number: 2160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2807018 , [Content] ='144,500 / 157,250 / 170,000 / 182,750 / 195,500'
 WHERE id=172111004


   --row number: 2161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2826149 , [Content] ='199,325 / 216,913 / 234,500 / 252,088 / 269,675'
 WHERE id=172102722


   --row number: 2162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2790450 , [Content] ='04/05/18'
 WHERE id=172113063


   --row number: 2163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2830817 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=172113735


   --row number: 2164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2729094 , [Content] ='04/05/18'
 WHERE id=172114083


   --row number: 2165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2729094 , [Content] ='USD'
 WHERE id=172114088


   --row number: 2166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2841767 , [Content] ='197,200 / 214,600 / 232,000 / 249,400 / 266,800'
 WHERE id=172162676


   --row number: 2167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2781548 , [Content] ='04/05/18'
 WHERE id=172180707


   --row number: 2168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2781548 , [Content] ='USD'
 WHERE id=172180712


   --row number: 2169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2781737 , [Content] ='04/05/18'
 WHERE id=172181382


   --row number: 2170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2781737 , [Content] ='USD'
 WHERE id=172181387


   --row number: 2171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2783326 , [Content] ='04/05/18'
 WHERE id=172181697


   --row number: 2172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2783326 , [Content] ='USD'
 WHERE id=172181701


   --row number: 2173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2783733 , [Content] ='04/05/18'
 WHERE id=172182169


   --row number: 2174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2783733 , [Content] ='USD'
 WHERE id=172182174


   --row number: 2175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2783736 , [Content] ='04/05/18'
 WHERE id=172182211


   --row number: 2176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2783736 , [Content] ='USD'
 WHERE id=172182216


   --row number: 2177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2812617 , [Content] ='229,500 / 249,750 / 270,000 / 290,250 / 310,500'
 WHERE id=172325693


   --row number: 2178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2812617 , [Content] ='114,750 / 124,875 / 135,000 / 145,125 / 155,250'
 WHERE id=172325696


   --row number: 2179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2729553 , [Content] ='INR'
 WHERE id=180458986


   --row number: 2180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2729553 , [Content] ='5/16/2018'
 WHERE id=180458981


   --row number: 2181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2820485 , [Content] ='620,700 / 760,350 / 900,000 / 1,039,650 / 1,179,300'
 WHERE id=180800868


   --row number: 2182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2729574 , [Content] ='5/22/2018'
 WHERE id=181425279


   --row number: 2183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2729570 , [Content] ='7/20/18'
 WHERE id=181424159


   --row number: 2184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2729570 , [Content] ='INR'
 WHERE id=181424164


   --row number: 2185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2729574 , [Content] ='INR'
 WHERE id=181425284


   --row number: 2186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2820692 , [Content] ='155,100 / 190,050 / 225,000 / 259,900 / 294,800'
 WHERE id=201122159


   --row number: 2187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2846078 , [Content] ='178,800 / 219,050 / 259,300 / 299,450 / 339,600'
 WHERE id=205474534


   --row number: 2188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2781735 , [Content] ='10/26/2018'
 WHERE id=207558673


   --row number: 2189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2781735 , [Content] ='USD'
 WHERE id=207558674


   --row number: 2190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2849445 , [Content] ='5876 DEU'
 WHERE id=166792235


   --row number: 2191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2850631 , [Content] ='S1412 US - MRKT 2'
 WHERE id=166883586


   --row number: 2192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2850631 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=166883589


   --row number: 2193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2850631 , [Content] ='Solution Consulting'
 WHERE id=166883590


   --row number: 2194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2850631 , [Content] ='S1412 - Solution Consultant IC2'
 WHERE id=166883591


   --row number: 2195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2850631 , [Content] ='Solution Consultant Core'
 WHERE id=166883592


   --row number: 2196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2850631 , [Content] ='IC2'
 WHERE id=166883593


   --row number: 2197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2850631 , [Content] ='USD'
 WHERE id=166883595


   --row number: 2198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2850631 , [Content] ='82,875 / 90,188 / 97,500 / 104,813 / 112,125'
 WHERE id=166883596


   --row number: 2199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2850631 , [Content] ='45,000 / 53,700 / 62,400 / 71,400 / 80,400'
 WHERE id=166883598


   --row number: 2200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2850631 , [Content] ='75/25'
 WHERE id=166883599


   --row number: 2201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2850631 , [Content] ='Yes'
 WHERE id=166883600


   --row number: 2202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2850631 , [Content] ='EXEMPT'
 WHERE id=166883601


   --row number: 2203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2850631 , [Content] ='NO'
 WHERE id=166883602


   --row number: 2204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2850631 , [Content] ='4 - Sales Workers'
 WHERE id=166883603


   --row number: 2205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2850631 , [Content] ='8742-Salespersons - Outside'
 WHERE id=166883604


   --row number: 2206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2850631 , [Content] ='Technical'
 WHERE id=166883605


   --row number: 2207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2850631 , [Content] ='04/05/18'
 WHERE id=166883606


   --row number: 2208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2850631 , [Content] ='US - MRKT 2'
 WHERE id=166883587


   --row number: 2209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2850631 , [Content] ='AMS'
 WHERE id=166883588


   --row number: 2210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2849445 , [Content] ='DEU'
 WHERE id=166791594


   --row number: 2211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2849445 , [Content] ='EMEA'
 WHERE id=166791595


   --row number: 2212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2849445 , [Content] ='GERMANY'
 WHERE id=166791596


   --row number: 2213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2849445 , [Content] ='Professional Services'
 WHERE id=166791597


   --row number: 2214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2849445 , [Content] ='5876 - Engagement Mgr IC6'
 WHERE id=166791598


   --row number: 2215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2849445 , [Content] ='Engagement Mgrs'
 WHERE id=166791599


   --row number: 2216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2849445 , [Content] ='IC6'
 WHERE id=166791600


   --row number: 2217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2849445 , [Content] ='EUR'
 WHERE id=166791602


   --row number: 2218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2849445 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=166791605


   --row number: 2219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2849445 , [Content] ='25%'
 WHERE id=166791606


   --row number: 2220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2849445 , [Content] ='Yes'
 WHERE id=166791607


   --row number: 2221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2849445 , [Content] ='2 - Professionals'
 WHERE id=166791608


   --row number: 2222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2849445 , [Content] ='8810-Clerical Office Employees'
 WHERE id=166791609


   --row number: 2223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2849445 , [Content] ='Technical'
 WHERE id=166791610


   --row number: 2224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2849445 , [Content] ='7/20/18'
 WHERE id=166791611


   --row number: 2225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2853013 , [Content] ='S665 US - MRKT 1'
 WHERE id=167325644


   --row number: 2226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2853013 , [Content] ='US - MRKT 1'
 WHERE id=167325645


   --row number: 2227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2853013 , [Content] ='AMS'
 WHERE id=167325646


   --row number: 2228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2853013 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=167325647


   --row number: 2229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2853013 , [Content] ='Sales'
 WHERE id=167325648


   --row number: 2230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2853013 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=167325649


   --row number: 2231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2853013 , [Content] ='Product Line Sales'
 WHERE id=167325650


   --row number: 2232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2853013 , [Content] ='IC5'
 WHERE id=167325651


   --row number: 2233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2853013 , [Content] ='USD'
 WHERE id=167325653


   --row number: 2234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2853013 , [Content] ='150,450 / 163,725 / 177,000 / 190,275 / 203,550'
 WHERE id=167325654


   --row number: 2235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2853013 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=167325656


   --row number: 2236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2853013 , [Content] ='60/40'
 WHERE id=167325657


   --row number: 2237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2853013 , [Content] ='Yes'
 WHERE id=167325658


   --row number: 2238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2853013 , [Content] ='EXEMPT'
 WHERE id=167325659


   --row number: 2239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2853013 , [Content] ='NO'
 WHERE id=167325660


   --row number: 2240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2853013 , [Content] ='4 - Sales Workers'
 WHERE id=167325661


   --row number: 2241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2853013 , [Content] ='8742-Salespersons - Outside'
 WHERE id=167325662


   --row number: 2242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2853013 , [Content] ='Technical'
 WHERE id=167325663


   --row number: 2243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2853013 , [Content] ='04/05/18'
 WHERE id=167325664


   --row number: 2244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2853032 , [Content] ='S665 JPN'
 WHERE id=167326953


   --row number: 2245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2853032 , [Content] ='JPN'
 WHERE id=167326954


   --row number: 2246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2853032 , [Content] ='APAC'
 WHERE id=167326955


   --row number: 2247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2853032 , [Content] ='JAPAN'
 WHERE id=167326956


   --row number: 2248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2853032 , [Content] ='Sales'
 WHERE id=167326957


   --row number: 2249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2853032 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=167326958


   --row number: 2250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2853032 , [Content] ='Product Line Sales'
 WHERE id=167326959


   --row number: 2251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2853032 , [Content] ='IC5'
 WHERE id=167326960


   --row number: 2252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2853032 , [Content] ='JPY'
 WHERE id=167326962


   --row number: 2253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2853032 , [Content] ='10,251,255 / 11,155,778 / 12,060,300 / 12,964,823 / 13,869,345'
 WHERE id=167326963


   --row number: 2254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2853032 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=167326965


   --row number: 2255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2853032 , [Content] ='60/40'
 WHERE id=167326966


   --row number: 2256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2853032 , [Content] ='Yes'
 WHERE id=167326967


   --row number: 2257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2853032 , [Content] ='4 - Sales Workers'
 WHERE id=167326968


   --row number: 2258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2853032 , [Content] ='8742-Salespersons - Outside'
 WHERE id=167326969


   --row number: 2259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2853032 , [Content] ='Technical'
 WHERE id=167326970


   --row number: 2260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2853032 , [Content] ='04/05/18'
 WHERE id=167326971


   --row number: 2261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2853565 , [Content] ='S635 UK'
 WHERE id=167414834


   --row number: 2262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2853565 , [Content] ='UK'
 WHERE id=167414835


   --row number: 2263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2853565 , [Content] ='EMEA'
 WHERE id=167414836


   --row number: 2264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2853565 , [Content] ='UNITED KINGDOM'
 WHERE id=167414837


   --row number: 2265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2853565 , [Content] ='Sales'
 WHERE id=167414838


   --row number: 2266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2853565 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=167414839


   --row number: 2267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2853565 , [Content] ='Enterprise Accounts'
 WHERE id=167414840


   --row number: 2268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2853565 , [Content] ='IC5'
 WHERE id=167414841


   --row number: 2269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2853565 , [Content] ='GBP'
 WHERE id=167414843


   --row number: 2270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2853565 , [Content] ='80,750 / 87,875 / 95,000 / 102,125 / 109,250'
 WHERE id=167414844


   --row number: 2271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2853565 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=167414846


   --row number: 2272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2853565 , [Content] ='50/50'
 WHERE id=167414847


   --row number: 2273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2853565 , [Content] ='Yes'
 WHERE id=167414848


   --row number: 2274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2853565 , [Content] ='4 - Sales Workers'
 WHERE id=167414849


   --row number: 2275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2853565 , [Content] ='8742-Salespersons - Outside'
 WHERE id=167414850


   --row number: 2276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2853565 , [Content] ='Technical'
 WHERE id=167414851


   --row number: 2277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2853565 , [Content] ='09/05/18'
 WHERE id=167414852


   --row number: 2278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2853963 , [Content] ='6402 IND'
 WHERE id=167445280


   --row number: 2279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2853963 , [Content] ='IND'
 WHERE id=167445281


   --row number: 2280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2853963 , [Content] ='APAC'
 WHERE id=167445282


   --row number: 2281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2853963 , [Content] ='INDIA'
 WHERE id=167445283


   --row number: 2282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2853963 , [Content] ='Info Systems/Technology'
 WHERE id=167445284


   --row number: 2283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2853963 , [Content] ='6402 - Information Systems Engineer IC2'
 WHERE id=167445285


   --row number: 2284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2853963 , [Content] ='Information Systems'
 WHERE id=167445286


   --row number: 2285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2853963 , [Content] ='IC2'
 WHERE id=167445287


   --row number: 2286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2853963 , [Content] ='INR'
 WHERE id=167445289


   --row number: 2287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2853963 , [Content] ='758,600 / 929,300 / 1,100,000 / 1,270,650 / 1,441,300'
 WHERE id=167445290


   --row number: 2288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2853963 , [Content] ='10%'
 WHERE id=167445292


   --row number: 2289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2853963 , [Content] ='No'
 WHERE id=167445293


   --row number: 2290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2853963 , [Content] ='2 - Professionals'
 WHERE id=167445294


   --row number: 2291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2853963 , [Content] ='8810-Clerical Office Employees'
 WHERE id=167445295


   --row number: 2292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2853963 , [Content] ='Technical'
 WHERE id=167445296


   --row number: 2293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2853963 , [Content] ='6/27/2018'
 WHERE id=167445297


   --row number: 2294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2854441 , [Content] ='04/05/18'
 WHERE id=167489711


   --row number: 2295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2854441 , [Content] ='5374 US - MRKT 1'
 WHERE id=167489691


   --row number: 2296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2854441 , [Content] ='US - MRKT 1'
 WHERE id=167489692


   --row number: 2297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2854441 , [Content] ='AMS'
 WHERE id=167489693


   --row number: 2298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2854441 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=167489694


   --row number: 2299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2854441 , [Content] ='Engineering'
 WHERE id=167489695


   --row number: 2300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2854441 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=167489696


   --row number: 2301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2854441 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=167489697


   --row number: 2302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2854441 , [Content] ='IC4'
 WHERE id=167489698


   --row number: 2303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2854441 , [Content] ='USD'
 WHERE id=167489700


   --row number: 2304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2854441 , [Content] ='115,200 / 139,350 / 163,500 / 187,600 / 211,700'
 WHERE id=167489701


   --row number: 2305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2854441 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=167489703


   --row number: 2306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2854441 , [Content] ='20%'
 WHERE id=167489704


   --row number: 2307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2854441 , [Content] ='Yes'
 WHERE id=167489705


   --row number: 2308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2854441 , [Content] ='EXEMPT'
 WHERE id=167489706


   --row number: 2309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2854441 , [Content] ='NO'
 WHERE id=167489707


   --row number: 2310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2854441 , [Content] ='2 - Professionals'
 WHERE id=167489708


   --row number: 2311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2854441 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=167489709


   --row number: 2312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2854441 , [Content] ='Technical'
 WHERE id=167489710


   --row number: 2313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2854907 , [Content] ='S1451 US - MRKT 2'
 WHERE id=167533372


   --row number: 2314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2854907 , [Content] ='US - MRKT 2'
 WHERE id=167533373


   --row number: 2315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2854907 , [Content] ='AMS'
 WHERE id=167533374


   --row number: 2316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2854907 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=167533375


   --row number: 2317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2854907 , [Content] ='Solution Consulting'
 WHERE id=167533376


   --row number: 2318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2854907 , [Content] ='S1451 - Assoc Solution Consultant Demo Center IC1'
 WHERE id=167533377


   --row number: 2319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2854907 , [Content] ='Solution Consultant Demo Center'
 WHERE id=167533378


   --row number: 2320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2854907 , [Content] ='IC1'
 WHERE id=167533379


   --row number: 2321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2854907 , [Content] ='USD'
 WHERE id=167533381


   --row number: 2322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2854907 , [Content] ='57,375 / 62,438 / 67,500 / 72,563 / 77,625'
 WHERE id=167533382


   --row number: 2323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2854907 , [Content] ='24,600 / 29,100 / 33,600 / 38,400 / 43,200'
 WHERE id=167533384


   --row number: 2324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2854907 , [Content] ='75/25'
 WHERE id=167533385


   --row number: 2325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2854907 , [Content] ='Yes'
 WHERE id=167533386


   --row number: 2326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2854907 , [Content] ='NON-EXEMPT'
 WHERE id=167533387


   --row number: 2327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2854907 , [Content] ='NO'
 WHERE id=167533388


   --row number: 2328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2854907 , [Content] ='4 - Sales Workers'
 WHERE id=167533389


   --row number: 2329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2854907 , [Content] ='8810-Clerical Office Employees'
 WHERE id=167533390


   --row number: 2330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2854907 , [Content] ='Technical'
 WHERE id=167533391


   --row number: 2331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2854907 , [Content] ='04/05/18'
 WHERE id=167533392


   --row number: 2332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2855194 , [Content] ='5883 AUS'
 WHERE id=167585508


   --row number: 2333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2855194 , [Content] ='AUS'
 WHERE id=167585509


   --row number: 2334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2855194 , [Content] ='APAC'
 WHERE id=167585510


   --row number: 2335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2855194 , [Content] ='AUSTRALIA'
 WHERE id=167585511


   --row number: 2336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2855194 , [Content] ='Professional Services'
 WHERE id=167585512


   --row number: 2337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2855194 , [Content] ='5883 - Customer/Technical Trainer IC3'
 WHERE id=167585513


   --row number: 2338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2855194 , [Content] ='Customer/Tech Training'
 WHERE id=167585514


   --row number: 2339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2855194 , [Content] ='IC3'
 WHERE id=167585515


   --row number: 2340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2855194 , [Content] ='AUD'
 WHERE id=167585517


   --row number: 2341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2855194 , [Content] ='79,400 / 92,500 / 105,600 / 118,700 / 131,800'
 WHERE id=167585518


   --row number: 2342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2855194 , [Content] ='27,000 / 37,500 / 48,000 / 58,800 / 69,600'
 WHERE id=167585520


   --row number: 2343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2855194 , [Content] ='10%'
 WHERE id=167585521


   --row number: 2344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2855194 , [Content] ='Yes'
 WHERE id=167585522


   --row number: 2345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2855194 , [Content] ='2 - Professionals'
 WHERE id=167585523


   --row number: 2346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2855194 , [Content] ='8810-Clerical Office Employees'
 WHERE id=167585524


   --row number: 2347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2855194 , [Content] ='Technical'
 WHERE id=167585525


   --row number: 2348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2855194 , [Content] ='1/29/2018'
 WHERE id=167585526


   --row number: 2349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2855926 , [Content] ='2534 US - MRKT 1'
 WHERE id=167705158


   --row number: 2350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2855926 , [Content] ='US - MRKT 1'
 WHERE id=167705159


   --row number: 2351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2855926 , [Content] ='AMS'
 WHERE id=167705160


   --row number: 2352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2855926 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=167705161


   --row number: 2353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2855926 , [Content] ='Marketing'
 WHERE id=167705162


   --row number: 2354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2855926 , [Content] ='2534 - Sr Mgr, Public/Analyst Relations Mgmt M4'
 WHERE id=167705163


   --row number: 2355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2855926 , [Content] ='Public Relations'
 WHERE id=167705164


   --row number: 2356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2855926 , [Content] ='M4'
 WHERE id=167705165


   --row number: 2357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2855926 , [Content] ='USD'
 WHERE id=167705167


   --row number: 2358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2855926 , [Content] ='117,000 / 143,350 / 169,700 / 196,000 / 222,300'
 WHERE id=167705168


   --row number: 2359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2855926 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=167705170


   --row number: 2360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2855926 , [Content] ='25%'
 WHERE id=167705171


   --row number: 2361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2855926 , [Content] ='Yes'
 WHERE id=167705172


   --row number: 2362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2855926 , [Content] ='EXEMPT'
 WHERE id=167705173


   --row number: 2363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2855926 , [Content] ='NO'
 WHERE id=167705174


   --row number: 2364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2855926 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=167705175


   --row number: 2365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2855926 , [Content] ='8810-Clerical Office Employees'
 WHERE id=167705176


   --row number: 2366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2855926 , [Content] ='Non Technical'
 WHERE id=167705177


   --row number: 2367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2855926 , [Content] ='04/05/18'
 WHERE id=167705178


   --row number: 2368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2856311 , [Content] ='5143 US - MRKT 1'
 WHERE id=167735521


   --row number: 2369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2856311 , [Content] ='US - MRKT 1'
 WHERE id=167735522


   --row number: 2370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2856311 , [Content] ='AMS'
 WHERE id=167735523


   --row number: 2371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2856311 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=167735524


   --row number: 2372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2856311 , [Content] ='Engineering'
 WHERE id=167735525


   --row number: 2373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2856311 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=167735526


   --row number: 2374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2856311 , [Content] ='Software'
 WHERE id=167735527


   --row number: 2375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2856311 , [Content] ='IC3'
 WHERE id=167735528


   --row number: 2376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2856311 , [Content] ='USD'
 WHERE id=167735530


   --row number: 2377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2856311 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=167735531


   --row number: 2378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2856311 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=167735533


   --row number: 2379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2856311 , [Content] ='15%'
 WHERE id=167735534


   --row number: 2380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2856311 , [Content] ='Yes'
 WHERE id=167735535


   --row number: 2381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2856311 , [Content] ='EXEMPT'
 WHERE id=167735536


   --row number: 2382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2856311 , [Content] ='NO'
 WHERE id=167735537


   --row number: 2383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2856311 , [Content] ='2 - Professionals'
 WHERE id=167735538


   --row number: 2384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2856311 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=167735539


   --row number: 2385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2856311 , [Content] ='Technical'
 WHERE id=167735540


   --row number: 2386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2856311 , [Content] ='09/05/18'
 WHERE id=167735541


   --row number: 2387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2856665 , [Content] ='AUS'
 WHERE id=167768048


   --row number: 2388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2856665 , [Content] ='APAC'
 WHERE id=167768049


   --row number: 2389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2856665 , [Content] ='AUSTRALIA'
 WHERE id=167768050


   --row number: 2390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2856665 , [Content] ='Info Systems/Technology'
 WHERE id=167768051


   --row number: 2391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2856665 , [Content] ='6584 - Staff Information Security Engineer IC4'
 WHERE id=167768052


   --row number: 2392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2856665 , [Content] ='Security'
 WHERE id=167768053


   --row number: 2393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2856665 , [Content] ='IC4'
 WHERE id=167768054


   --row number: 2394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2856665 , [Content] ='AUD'
 WHERE id=167768056


   --row number: 2395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2856665 , [Content] ='102,700 / 124,250 / 145,800 / 167,300 / 188,800'
 WHERE id=167768057


   --row number: 2396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2856665 , [Content] ='110,400 / 154,200 / 198,000 / 243,000 / 288,000'
 WHERE id=167768059


   --row number: 2397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2856665 , [Content] ='20%'
 WHERE id=167768060


   --row number: 2398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2856665 , [Content] ='Yes'
 WHERE id=167768061


   --row number: 2399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2856665 , [Content] ='2 - Professionals'
 WHERE id=167768062


   --row number: 2400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2856665 , [Content] ='8810-Clerical Office Employees'
 WHERE id=167768063


   --row number: 2401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2856665 , [Content] ='Technical'
 WHERE id=167768064


   --row number: 2402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2856665 , [Content] ='4/25/2018'
 WHERE id=167768066


   --row number: 2403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2861681 , [Content] ='2706 US - MRKT 1'
 WHERE id=168171997


   --row number: 2404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2861681 , [Content] ='US - MRKT 1'
 WHERE id=168171998


   --row number: 2405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2861681 , [Content] ='AMS'
 WHERE id=168171999


   --row number: 2406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2861681 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168172000


   --row number: 2407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2861681 , [Content] ='Marketing'
 WHERE id=168172001


   --row number: 2408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2861681 , [Content] ='2706 - Sr Dir, Product Portfolio Mgmt M6'
 WHERE id=168172002


   --row number: 2409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2861681 , [Content] ='Product Mgrs'
 WHERE id=168172003


   --row number: 2410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2861681 , [Content] ='M6'
 WHERE id=168172004


   --row number: 2411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2861681 , [Content] ='USD'
 WHERE id=168172006


   --row number: 2412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2861681 , [Content] ='165,700 / 203,000 / 240,300 / 277,550 / 314,800'
 WHERE id=168172007


   --row number: 2413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2861681 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=168172009


   --row number: 2414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2861681 , [Content] ='30%'
 WHERE id=168172010


   --row number: 2415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2861681 , [Content] ='Yes'
 WHERE id=168172011


   --row number: 2416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2861681 , [Content] ='EXEMPT'
 WHERE id=168172012


   --row number: 2417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2861681 , [Content] ='NO'
 WHERE id=168172013


   --row number: 2418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2861681 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=168172014


   --row number: 2419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2861681 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168172015


   --row number: 2420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2861681 , [Content] ='Technical'
 WHERE id=168172016


   --row number: 2421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2861681 , [Content] ='04/05/18'
 WHERE id=168172017


   --row number: 2422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2865000 , [Content] ='6804 NLD'
 WHERE id=168431544


   --row number: 2423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2865000 , [Content] ='NLD'
 WHERE id=168431545


   --row number: 2424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2865000 , [Content] ='EMEA'
 WHERE id=168431546


   --row number: 2425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2865000 , [Content] ='NETHERLANDS'
 WHERE id=168431547


   --row number: 2426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2865000 , [Content] ='Info Systems/Technology'
 WHERE id=168431548


   --row number: 2427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2865000 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=168431549


   --row number: 2428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2865000 , [Content] ='UI/UX Designer'
 WHERE id=168431550


   --row number: 2429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2865000 , [Content] ='IC4'
 WHERE id=168431551


   --row number: 2430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2865000 , [Content] ='EUR'
 WHERE id=168431553


   --row number: 2431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2865000 , [Content] ='61,600 / 74,500 / 87,400 / 100,300 / 113,200'
 WHERE id=168431554


   --row number: 2432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2865000 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=168431556


   --row number: 2433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2865000 , [Content] ='20%'
 WHERE id=168431557


   --row number: 2434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2865000 , [Content] ='Yes'
 WHERE id=168431558


   --row number: 2435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2865000 , [Content] ='2 - Professionals'
 WHERE id=168431559


   --row number: 2436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2865000 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168431560


   --row number: 2437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2865000 , [Content] ='Technical'
 WHERE id=168431561


   --row number: 2438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2865000 , [Content] ='04/05/18'
 WHERE id=168431562


   --row number: 2439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2861700 , [Content] ='2247 US - MRKT 1'
 WHERE id=168175015


   --row number: 2440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2861700 , [Content] ='US - MRKT 1'
 WHERE id=168175016


   --row number: 2441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2861700 , [Content] ='AMS'
 WHERE id=168175017


   --row number: 2442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2861700 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168175018


   --row number: 2443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2861700 , [Content] ='Executive'
 WHERE id=168175019


   --row number: 2444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2861700 , [Content] ='2247 - VP, Product Mgmt M7'
 WHERE id=168175020


   --row number: 2445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2861700 , [Content] ='Vice President'
 WHERE id=168175021


   --row number: 2446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2861700 , [Content] ='M7'
 WHERE id=168175022


   --row number: 2447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2861700 , [Content] ='USD'
 WHERE id=168175024


   --row number: 2448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2861700 , [Content] ='Yes'
 WHERE id=168175029


   --row number: 2449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2861700 , [Content] ='EXEMPT'
 WHERE id=168175031


   --row number: 2450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2861700 , [Content] ='NO'
 WHERE id=168175032


   --row number: 2451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2861700 , [Content] ='1.1 - Executive/Senior Level Officials and Managers'
 WHERE id=168175033


   --row number: 2452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2861700 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168175034


   --row number: 2453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2861700 , [Content] ='Technical'
 WHERE id=168175035


   --row number: 2454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2861700 , [Content] ='04/05/18'
 WHERE id=168175036


   --row number: 2455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2865417 , [Content] ='04/05/18'
 WHERE id=168475323


   --row number: 2456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2865417 , [Content] ='2314 US - MRKT 1'
 WHERE id=168475303


   --row number: 2457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2865417 , [Content] ='US - MRKT 1'
 WHERE id=168475304


   --row number: 2458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2865417 , [Content] ='AMS'
 WHERE id=168475305


   --row number: 2459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2865417 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168475306


   --row number: 2460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2865417 , [Content] ='Engineering Operations'
 WHERE id=168475307


   --row number: 2461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2865417 , [Content] ='2314 - Sr Mgr, Technical Writing Mgmt M4'
 WHERE id=168475308


   --row number: 2462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2865417 , [Content] ='Technical Writer'
 WHERE id=168475309


   --row number: 2463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2865417 , [Content] ='M4'
 WHERE id=168475310


   --row number: 2464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2865417 , [Content] ='USD'
 WHERE id=168475312


   --row number: 2465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2865417 , [Content] ='113,200 / 138,650 / 164,100 / 189,600 / 215,100'
 WHERE id=168475313


   --row number: 2466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2865417 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=168475315


   --row number: 2467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2865417 , [Content] ='25%'
 WHERE id=168475316


   --row number: 2468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2865417 , [Content] ='Yes'
 WHERE id=168475317


   --row number: 2469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2865417 , [Content] ='EXEMPT'
 WHERE id=168475318


   --row number: 2470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2865417 , [Content] ='NO'
 WHERE id=168475319


   --row number: 2471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2865417 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=168475320


   --row number: 2472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2865417 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168475321


   --row number: 2473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2865417 , [Content] ='Technical'
 WHERE id=168475322


   --row number: 2474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2865596 , [Content] ='5142 US - MRKT 2'
 WHERE id=168491536


   --row number: 2475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2865596 , [Content] ='US - MRKT 2'
 WHERE id=168491537


   --row number: 2476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2865596 , [Content] ='AMS'
 WHERE id=168491538


   --row number: 2477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2865596 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168491539


   --row number: 2478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2865596 , [Content] ='Engineering'
 WHERE id=168491540


   --row number: 2479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2865596 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=168491541


   --row number: 2480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2865596 , [Content] ='Software'
 WHERE id=168491542


   --row number: 2481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2865596 , [Content] ='IC2'
 WHERE id=168491543


   --row number: 2482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2865596 , [Content] ='USD'
 WHERE id=168491545


   --row number: 2483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2865596 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=168491546


   --row number: 2484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2865596 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=168491548


   --row number: 2485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2865596 , [Content] ='10%'
 WHERE id=168491549


   --row number: 2486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2865596 , [Content] ='Yes'
 WHERE id=168491550


   --row number: 2487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2865596 , [Content] ='EXEMPT'
 WHERE id=168491551


   --row number: 2488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2865596 , [Content] ='NO'
 WHERE id=168491552


   --row number: 2489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2865596 , [Content] ='2 - Professionals'
 WHERE id=168491553


   --row number: 2490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2865596 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=168491554


   --row number: 2491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2865596 , [Content] ='Technical'
 WHERE id=168491555


   --row number: 2492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2865596 , [Content] ='04/05/18'
 WHERE id=168491556


   --row number: 2493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2869150 , [Content] ='5705 US - MRKT 3'
 WHERE id=168845262


   --row number: 2494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2868437 , [Content] ='5764 FRA'
 WHERE id=168782699


   --row number: 2495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2868437 , [Content] ='FRA'
 WHERE id=168782700


   --row number: 2496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2868437 , [Content] ='EMEA'
 WHERE id=168782701


   --row number: 2497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2868437 , [Content] ='FRANCE'
 WHERE id=168782702


   --row number: 2498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2868437 , [Content] ='Professional Services'
 WHERE id=168782703


   --row number: 2499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2868437 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=168782704


   --row number: 2500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2868437 , [Content] ='Technology Consultant'
 WHERE id=168782705


   --row number: 2501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2868437 , [Content] ='IC4'
 WHERE id=168782706


   --row number: 2502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2868437 , [Content] ='EUR'
 WHERE id=168782708


   --row number: 2503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2868437 , [Content] ='51,600 / 62,400 / 73,200 / 84,000 / 94,800'
 WHERE id=168782709


   --row number: 2504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2868437 , [Content] ='20%'
 WHERE id=168782711


   --row number: 2505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2868437 , [Content] ='No'
 WHERE id=168782712


   --row number: 2506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2868437 , [Content] ='2 - Professionals'
 WHERE id=168782713


   --row number: 2507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2868437 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168782714


   --row number: 2508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2868437 , [Content] ='Technical'
 WHERE id=168782715


   --row number: 2509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2868437 , [Content] ='04/05/18'
 WHERE id=168782716


   --row number: 2510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2869150 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168845265


   --row number: 2511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2869150 , [Content] ='Professional Services'
 WHERE id=168845266


   --row number: 2512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2869150 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=168845267


   --row number: 2513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2869150 , [Content] ='Partner Support'
 WHERE id=168845268


   --row number: 2514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2869150 , [Content] ='IC5'
 WHERE id=168845269


   --row number: 2515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2869150 , [Content] ='USD'
 WHERE id=168845271


   --row number: 2516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2869150 , [Content] ='93,300 / 114,300 / 135,300 / 156,300 / 177,300'
 WHERE id=168845272


   --row number: 2517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2869150 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=168845274


   --row number: 2518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2869150 , [Content] ='25%'
 WHERE id=168845275


   --row number: 2519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2869150 , [Content] ='Yes'
 WHERE id=168845276


   --row number: 2520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2869150 , [Content] ='EXEMPT'
 WHERE id=168845277


   --row number: 2521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2869150 , [Content] ='2 - Professionals'
 WHERE id=168845278


   --row number: 2522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2869150 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168845279


   --row number: 2523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2869150 , [Content] ='Technical'
 WHERE id=168845280


   --row number: 2524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2869150 , [Content] ='04/05/18'
 WHERE id=168845281


   --row number: 2525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2869150 , [Content] ='US - MRKT 3'
 WHERE id=168845263


   --row number: 2526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2869150 , [Content] ='AMS'
 WHERE id=168845264


   --row number: 2527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2869159 , [Content] ='US - MRKT 2'
 WHERE id=168846239


   --row number: 2528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2869159 , [Content] ='AMS'
 WHERE id=168846240


   --row number: 2529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2869159 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=168846241


   --row number: 2530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2869159 , [Content] ='Professional Services'
 WHERE id=168846244


   --row number: 2531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2869159 , [Content] ='5705 - Client Relationship Manager IC5'
 WHERE id=168846246


   --row number: 2532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2869159 , [Content] ='Partner Support'
 WHERE id=168846247


   --row number: 2533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2869159 , [Content] ='IC5'
 WHERE id=168846248


   --row number: 2534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2869159 , [Content] ='USD'
 WHERE id=168846250


   --row number: 2535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2869159 , [Content] ='101,400 / 124,200 / 147,000 / 169,850 / 192,700'
 WHERE id=168846251


   --row number: 2536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2869159 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=168846253


   --row number: 2537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2869159 , [Content] ='25%'
 WHERE id=168846254


   --row number: 2538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2869159 , [Content] ='Yes'
 WHERE id=168846255


   --row number: 2539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2869159 , [Content] ='EXEMPT'
 WHERE id=168846256


   --row number: 2540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2869159 , [Content] ='NO'
 WHERE id=168846257


   --row number: 2541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2869159 , [Content] ='2 - Professionals'
 WHERE id=168846258


   --row number: 2542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2869159 , [Content] ='8810-Clerical Office Employees'
 WHERE id=168846259


   --row number: 2543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2869159 , [Content] ='5705 US - MRKT 2'
 WHERE id=168846238


   --row number: 2544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2869159 , [Content] ='Technical'
 WHERE id=168846260


   --row number: 2545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2869159 , [Content] ='04/05/18'
 WHERE id=168846261


   --row number: 2546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2874321 , [Content] ='2714 US - MRKT 1'
 WHERE id=169455205


   --row number: 2547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2874321 , [Content] ='US - MRKT 1'
 WHERE id=169455206


   --row number: 2548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2874321 , [Content] ='AMS'
 WHERE id=169455207


   --row number: 2549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2874321 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=169455208


   --row number: 2550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2874321 , [Content] ='Business Strategy'
 WHERE id=169455209


   --row number: 2551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2874321 , [Content] ='2714 - Sr Mgr, Business Strategy Mgmt M4'
 WHERE id=169455210


   --row number: 2552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2874321 , [Content] ='Business Strategy'
 WHERE id=169455211


   --row number: 2553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2874321 , [Content] ='M4'
 WHERE id=169455212


   --row number: 2554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2874321 , [Content] ='USD'
 WHERE id=169455214


   --row number: 2555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2874321 , [Content] ='130,300 / 159,600 / 188,900 / 218,250 / 247,600'
 WHERE id=169455215


   --row number: 2556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2874321 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=169455217


   --row number: 2557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2874321 , [Content] ='25%'
 WHERE id=169455218


   --row number: 2558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2874321 , [Content] ='Yes'
 WHERE id=169455219


   --row number: 2559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2874321 , [Content] ='EXEMPT'
 WHERE id=169455220


   --row number: 2560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2874321 , [Content] ='NO'
 WHERE id=169455221


   --row number: 2561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2874321 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=169455222


   --row number: 2562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2874321 , [Content] ='8810-Clerical Office Employees'
 WHERE id=169455223


   --row number: 2563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2874321 , [Content] ='Non Technical'
 WHERE id=169455224


   --row number: 2564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2874321 , [Content] ='04/05/18'
 WHERE id=169455225


   --row number: 2565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2874792 , [Content] ='S1332 US - MRKT 2'
 WHERE id=169511610


   --row number: 2566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2874792 , [Content] ='US - MRKT 2'
 WHERE id=169511611


   --row number: 2567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2874792 , [Content] ='AMS'
 WHERE id=169511612


   --row number: 2568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2874792 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=169511613


   --row number: 2569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2874792 , [Content] ='Sales'
 WHERE id=169511614


   --row number: 2570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2874792 , [Content] ='S1332 - Account Development Rep A2'
 WHERE id=169511615


   --row number: 2571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2874792 , [Content] ='Inside Sales'
 WHERE id=169511616


   --row number: 2572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2874792 , [Content] ='A2'
 WHERE id=169511617


   --row number: 2573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2874792 , [Content] ='USD'
 WHERE id=169511619


   --row number: 2574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2874792 , [Content] ='39,525 / 43,013 / 46,500 / 49,988 / 53,475'
 WHERE id=169511620


   --row number: 2575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2874792 , [Content] ='60/40'
 WHERE id=169511622


   --row number: 2576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2874792 , [Content] ='No'
 WHERE id=169511623


   --row number: 2577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2874792 , [Content] ='NON-EXEMPT'
 WHERE id=169511624


   --row number: 2578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2874792 , [Content] ='NO'
 WHERE id=169511625


   --row number: 2579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2874792 , [Content] ='4 - Sales Workers'
 WHERE id=169511626


   --row number: 2580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2874792 , [Content] ='8810-Clerical Office Employees'
 WHERE id=169511627


   --row number: 2581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2874792 , [Content] ='Non Technical'
 WHERE id=169511628


   --row number: 2582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2874792 , [Content] ='04/05/18'
 WHERE id=169511629


   --row number: 2583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2875938 , [Content] ='5374 US - MRKT 2'
 WHERE id=169725523


   --row number: 2584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2875938 , [Content] ='US - MRKT 2'
 WHERE id=169725524


   --row number: 2585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2875938 , [Content] ='AMS'
 WHERE id=169725525


   --row number: 2586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2875938 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=169725526


   --row number: 2587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2875938 , [Content] ='Engineering'
 WHERE id=169725527


   --row number: 2588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2875938 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=169725528


   --row number: 2589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2875938 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=169725529


   --row number: 2590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2875938 , [Content] ='IC4'
 WHERE id=169725530


   --row number: 2591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2875938 , [Content] ='USD'
 WHERE id=169725532


   --row number: 2592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2875938 , [Content] ='96,100 / 116,250 / 136,400 / 156,500 / 176,600'
 WHERE id=169725533


   --row number: 2593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2875938 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=169725535


   --row number: 2594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2875938 , [Content] ='20%'
 WHERE id=169725536


   --row number: 2595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2875938 , [Content] ='Yes'
 WHERE id=169725537


   --row number: 2596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2875938 , [Content] ='EXEMPT'
 WHERE id=169725538


   --row number: 2597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2875938 , [Content] ='NO'
 WHERE id=169725539


   --row number: 2598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2875938 , [Content] ='2 - Professionals'
 WHERE id=169725540


   --row number: 2599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2875938 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=169725541


   --row number: 2600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2875938 , [Content] ='Technical'
 WHERE id=169725542


   --row number: 2601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2875938 , [Content] ='04/05/18'
 WHERE id=169725543


   --row number: 2602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2876247 , [Content] ='Technical'
 WHERE id=169751999


   --row number: 2603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2876247 , [Content] ='04/05/18'
 WHERE id=169752000


   --row number: 2604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2876247 , [Content] ='5144 US - MRKT 2'
 WHERE id=169751980


   --row number: 2605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2876247 , [Content] ='US - MRKT 2'
 WHERE id=169751981


   --row number: 2606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2876247 , [Content] ='AMS'
 WHERE id=169751982


   --row number: 2607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2876247 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=169751983


   --row number: 2608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2876247 , [Content] ='Engineering'
 WHERE id=169751984


   --row number: 2609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2876247 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=169751985


   --row number: 2610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2876247 , [Content] ='Software'
 WHERE id=169751986


   --row number: 2611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2876247 , [Content] ='IC4'
 WHERE id=169751987


   --row number: 2612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2876247 , [Content] ='USD'
 WHERE id=169751989


   --row number: 2613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2876247 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=169751990


   --row number: 2614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2876247 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=169751992


   --row number: 2615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2876247 , [Content] ='20%'
 WHERE id=169751993


   --row number: 2616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2876247 , [Content] ='Yes'
 WHERE id=169751994


   --row number: 2617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2876247 , [Content] ='EXEMPT'
 WHERE id=169751995


   --row number: 2618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2876247 , [Content] ='NO'
 WHERE id=169751996


   --row number: 2619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2876247 , [Content] ='2 - Professionals'
 WHERE id=169751997


   --row number: 2620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2876247 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=169751998


   --row number: 2621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2877146 , [Content] ='9914 US - MRKT 1'
 WHERE id=169833674


   --row number: 2622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2877146 , [Content] ='US - MRKT 1'
 WHERE id=169833675


   --row number: 2623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2877146 , [Content] ='AMS'
 WHERE id=169833676


   --row number: 2624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2877146 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=169833677


   --row number: 2625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2877146 , [Content] ='Administration'
 WHERE id=169833678


   --row number: 2626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2877146 , [Content] ='9914 - Administrative Assistant A4'
 WHERE id=169833679


   --row number: 2627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2877146 , [Content] ='Administrative Assistant'
 WHERE id=169833680


   --row number: 2628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2877146 , [Content] ='A4'
 WHERE id=169833681


   --row number: 2629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2877146 , [Content] ='USD'
 WHERE id=169833683


   --row number: 2630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2877146 , [Content] ='72,100 / 81,900 / 91,700 / 101,450 / 111,200'
 WHERE id=169833684


   --row number: 2631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2877146 , [Content] ='10%'
 WHERE id=169833686


   --row number: 2632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2877146 , [Content] ='No'
 WHERE id=169833687


   --row number: 2633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2877146 , [Content] ='NON-EXEMPT'
 WHERE id=169833688


   --row number: 2634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2877146 , [Content] ='NO'
 WHERE id=169833689


   --row number: 2635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2877146 , [Content] ='5 - Administrative Support Workers'
 WHERE id=169833690


   --row number: 2636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2877146 , [Content] ='8810-Clerical Office Employees'
 WHERE id=169833691


   --row number: 2637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2877146 , [Content] ='Non Technical'
 WHERE id=169833692


   --row number: 2638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2877146 , [Content] ='04/05/18'
 WHERE id=169833693


   --row number: 2639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2877735 , [Content] ='EUR'
 WHERE id=170044579


   --row number: 2640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2877735 , [Content] ='240,000 / 360,000 / 480,000 / 600,000 / 720,000'
 WHERE id=170044580


   --row number: 2641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2877735 , [Content] ='2506 NLD'
 WHERE id=170044570


   --row number: 2642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2877735 , [Content] ='NLD'
 WHERE id=170044571


   --row number: 2643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2877735 , [Content] ='EMEA'
 WHERE id=170044572


   --row number: 2644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2877735 , [Content] ='NETHERLANDS'
 WHERE id=170044573


   --row number: 2645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2877735 , [Content] ='Marketing'
 WHERE id=170044574


   --row number: 2646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2877735 , [Content] ='2506 - Sr Dir, Marketing Mgmt M6'
 WHERE id=170044575


   --row number: 2647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2877735 , [Content] ='Marketing'
 WHERE id=170044576


   --row number: 2648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2877735 , [Content] ='M6'
 WHERE id=170044577


   --row number: 2649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2877735 , [Content] ='30%'
 WHERE id=170044581


   --row number: 2650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2877735 , [Content] ='Yes'
 WHERE id=170044582


   --row number: 2651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2877735 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=170044583


   --row number: 2652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2877735 , [Content] ='8810-Clerical Office Employees'
 WHERE id=170044584


   --row number: 2653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2877735 , [Content] ='Non Technical'
 WHERE id=170044585


   --row number: 2654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2877735 , [Content] ='04/05/18'
 WHERE id=170044586


   --row number: 2655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2878553 , [Content] ='5143 US - MRKT 2'
 WHERE id=170125130


   --row number: 2656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2878553 , [Content] ='US - MRKT 2'
 WHERE id=170125131


   --row number: 2657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2878553 , [Content] ='AMS'
 WHERE id=170125132


   --row number: 2658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2878553 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170125133


   --row number: 2659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2878553 , [Content] ='Engineering'
 WHERE id=170125134


   --row number: 2660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2878553 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=170125135


   --row number: 2661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2878553 , [Content] ='Software'
 WHERE id=170125136


   --row number: 2662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2878553 , [Content] ='IC3'
 WHERE id=170125137


   --row number: 2663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2878553 , [Content] ='USD'
 WHERE id=170125139


   --row number: 2664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2878553 , [Content] ='91,200 / 107,600 / 124,000 / 140,450 / 156,900'
 WHERE id=170125140


   --row number: 2665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2878553 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=170125142


   --row number: 2666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2878553 , [Content] ='15%'
 WHERE id=170125143


   --row number: 2667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2878553 , [Content] ='Yes'
 WHERE id=170125144


   --row number: 2668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2878553 , [Content] ='EXEMPT'
 WHERE id=170125145


   --row number: 2669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2878553 , [Content] ='NO'
 WHERE id=170125146


   --row number: 2670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2878553 , [Content] ='2 - Professionals'
 WHERE id=170125147


   --row number: 2671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2878553 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=170125148


   --row number: 2672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2878553 , [Content] ='Technical'
 WHERE id=170125149


   --row number: 2673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2878553 , [Content] ='10/24/2018'
 WHERE id=170125150


   --row number: 2674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2879207 , [Content] ='5142 US - MRKT 2'
 WHERE id=170184481


   --row number: 2675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2879207 , [Content] ='US - MRKT 2'
 WHERE id=170184482


   --row number: 2676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2879207 , [Content] ='AMS'
 WHERE id=170184483


   --row number: 2677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2879207 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170184484


   --row number: 2678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2879207 , [Content] ='Engineering'
 WHERE id=170184485


   --row number: 2679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2879207 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=170184486


   --row number: 2680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2879207 , [Content] ='Software'
 WHERE id=170184487


   --row number: 2681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2879207 , [Content] ='IC2'
 WHERE id=170184488


   --row number: 2682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2879207 , [Content] ='USD'
 WHERE id=170184490


   --row number: 2683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2879207 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=170184491


   --row number: 2684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2879207 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=170184493


   --row number: 2685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2879207 , [Content] ='10%'
 WHERE id=170184494


   --row number: 2686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2879207 , [Content] ='Yes'
 WHERE id=170184495


   --row number: 2687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2879207 , [Content] ='EXEMPT'
 WHERE id=170184496


   --row number: 2688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2879207 , [Content] ='2 - Professionals'
 WHERE id=170184497


   --row number: 2689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2879207 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=170184498


   --row number: 2690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2879207 , [Content] ='Technical'
 WHERE id=170184499


   --row number: 2691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2879207 , [Content] ='7/20/2018'
 WHERE id=170184501


   --row number: 2692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2879220 , [Content] ='5142 US - MRKT 2'
 WHERE id=170186167


   --row number: 2693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2879220 , [Content] ='US - MRKT 2'
 WHERE id=170186168


   --row number: 2694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2879220 , [Content] ='AMS'
 WHERE id=170186169


   --row number: 2695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2879220 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170186170


   --row number: 2696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2879220 , [Content] ='Engineering'
 WHERE id=170186171


   --row number: 2697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2879220 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=170186172


   --row number: 2698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2879220 , [Content] ='Software'
 WHERE id=170186173


   --row number: 2699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2879220 , [Content] ='IC2'
 WHERE id=170186174


   --row number: 2700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2879220 , [Content] ='USD'
 WHERE id=170186176


   --row number: 2701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2879220 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=170186177


   --row number: 2702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2879220 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=170186179


   --row number: 2703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2879220 , [Content] ='10%'
 WHERE id=170186180


   --row number: 2704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2879220 , [Content] ='Yes'
 WHERE id=170186181


   --row number: 2705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2879220 , [Content] ='EXEMPT'
 WHERE id=170186182


   --row number: 2706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2879220 , [Content] ='2 - Professionals'
 WHERE id=170186183


   --row number: 2707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2879220 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=170186184


   --row number: 2708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2879220 , [Content] ='Technical'
 WHERE id=170186185


   --row number: 2709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2879220 , [Content] ='04/05/18'
 WHERE id=170186187


   --row number: 2710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2882636 , [Content] ='5142 US - MRKT 3'
 WHERE id=170624359


   --row number: 2711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2882636 , [Content] ='US - MRKT 3'
 WHERE id=170624360


   --row number: 2712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2882636 , [Content] ='AMS'
 WHERE id=170624361


   --row number: 2713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2882636 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170624362


   --row number: 2714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2882636 , [Content] ='Engineering'
 WHERE id=170624363


   --row number: 2715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2882636 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=170624364


   --row number: 2716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2882636 , [Content] ='Software'
 WHERE id=170624365


   --row number: 2717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2882636 , [Content] ='IC2'
 WHERE id=170624366


   --row number: 2718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2882636 , [Content] ='USD'
 WHERE id=170624368


   --row number: 2719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2882636 , [Content] ='70,600 / 82,250 / 93,900 / 105,550 / 117,200'
 WHERE id=170624369


   --row number: 2720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2882107 , [Content] ='S1414 UK'
 WHERE id=170592607


   --row number: 2721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2882107 , [Content] ='UK'
 WHERE id=170592608


   --row number: 2722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2882107 , [Content] ='EMEA'
 WHERE id=170592609


   --row number: 2723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2882107 , [Content] ='UNITED KINGDOM'
 WHERE id=170592610


   --row number: 2724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2882107 , [Content] ='Solution Consulting'
 WHERE id=170592611


   --row number: 2725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2882107 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=170592612


   --row number: 2726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2882107 , [Content] ='Solution Consultant Core'
 WHERE id=170592613


   --row number: 2727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2882107 , [Content] ='IC4'
 WHERE id=170592614


   --row number: 2728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2882107 , [Content] ='GBP'
 WHERE id=170592616


   --row number: 2729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2882107 , [Content] ='66,938 / 72,844 / 78,750 / 84,656 / 90,563'
 WHERE id=170592617


   --row number: 2730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2882107 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=170592619


   --row number: 2731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2882107 , [Content] ='75/25'
 WHERE id=170592620


   --row number: 2732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2882107 , [Content] ='Yes'
 WHERE id=170592621


   --row number: 2733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2882107 , [Content] ='4 - Sales Workers'
 WHERE id=170592622


   --row number: 2734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2882107 , [Content] ='8742-Salespersons - Outside'
 WHERE id=170592623


   --row number: 2735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2882107 , [Content] ='Technical'
 WHERE id=170592624


   --row number: 2736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2882107 , [Content] ='04/05/18'
 WHERE id=170592625


   --row number: 2737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2882636 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=170624371


   --row number: 2738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2882636 , [Content] ='10%'
 WHERE id=170624372


   --row number: 2739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2882636 , [Content] ='Yes'
 WHERE id=170624373


   --row number: 2740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2882636 , [Content] ='EXEMPT'
 WHERE id=170624374


   --row number: 2741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2882636 , [Content] ='2 - Professionals'
 WHERE id=170624375


   --row number: 2742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2882636 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=170624376


   --row number: 2743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2882636 , [Content] ='Technical'
 WHERE id=170624377


   --row number: 2744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2882636 , [Content] ='04/05/18'
 WHERE id=170624379


   --row number: 2745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2883387 , [Content] ='71,200 / 82,950 / 94,700 / 106,450 / 118,200'
 WHERE id=170680036


   --row number: 2746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2883387 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=170680038


   --row number: 2747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2883387 , [Content] ='10%'
 WHERE id=170680039


   --row number: 2748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2883387 , [Content] ='Yes'
 WHERE id=170680040


   --row number: 2749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2883387 , [Content] ='EXEMPT'
 WHERE id=170680041


   --row number: 2750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2883387 , [Content] ='NO'
 WHERE id=170680042


   --row number: 2751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2883387 , [Content] ='2 - Professionals'
 WHERE id=170680043


   --row number: 2752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2883387 , [Content] ='8810-Clerical Office Employees'
 WHERE id=170680044


   --row number: 2753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2883387 , [Content] ='Non Technical'
 WHERE id=170680045


   --row number: 2754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2883387 , [Content] ='04/05/18'
 WHERE id=170680046


   --row number: 2755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2883387 , [Content] ='6223 US - MRKT 2'
 WHERE id=170680026


   --row number: 2756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2883387 , [Content] ='US - MRKT 2'
 WHERE id=170680027


   --row number: 2757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2883387 , [Content] ='AMS'
 WHERE id=170680028


   --row number: 2758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2883387 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170680029


   --row number: 2759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2883387 , [Content] ='Human Resources'
 WHERE id=170680030


   --row number: 2760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2883387 , [Content] ='6223 - Recruiter/Staffing Representative IC3'
 WHERE id=170680031


   --row number: 2761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2883387 , [Content] ='Staffing'
 WHERE id=170680032


   --row number: 2762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2883387 , [Content] ='IC3'
 WHERE id=170680033


   --row number: 2763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2883387 , [Content] ='USD'
 WHERE id=170680035


   --row number: 2764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2884782 , [Content] ='2563 US - MRKT 2'
 WHERE id=170820465


   --row number: 2765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2884782 , [Content] ='US - MRKT 2'
 WHERE id=170820466


   --row number: 2766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2884782 , [Content] ='AMS'
 WHERE id=170820467


   --row number: 2767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2884782 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=170820468


   --row number: 2768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2884782 , [Content] ='Professional Services'
 WHERE id=170820469


   --row number: 2769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2884782 , [Content] ='2563 - Mgr, Technology Consulting Mgmt M3'
 WHERE id=170820470


   --row number: 2770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2884782 , [Content] ='Technology Consultant'
 WHERE id=170820471


   --row number: 2771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2884782 , [Content] ='M3'
 WHERE id=170820472


   --row number: 2772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2884782 , [Content] ='USD'
 WHERE id=170820474


   --row number: 2773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2884782 , [Content] ='100,100 / 121,050 / 142,000 / 163,000 / 184,000'
 WHERE id=170820475


   --row number: 2774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2884782 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=170820477


   --row number: 2775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2884782 , [Content] ='20%'
 WHERE id=170820478


   --row number: 2776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2884782 , [Content] ='Yes'
 WHERE id=170820479


   --row number: 2777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2884782 , [Content] ='EXEMPT'
 WHERE id=170820480


   --row number: 2778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2884782 , [Content] ='NO'
 WHERE id=170820481


   --row number: 2779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2884782 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=170820482


   --row number: 2780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2884782 , [Content] ='8810-Clerical Office Employees'
 WHERE id=170820483


   --row number: 2781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2884782 , [Content] ='Technical'
 WHERE id=170820484


   --row number: 2782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2884782 , [Content] ='04/05/18'
 WHERE id=170820485


   --row number: 2783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2885667 , [Content] ='9999 IND'
 WHERE id=171036914


   --row number: 2784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2885667 , [Content] ='IND'
 WHERE id=171036915


   --row number: 2785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2885667 , [Content] ='APAC'
 WHERE id=171036916


   --row number: 2786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2885667 , [Content] ='India'
 WHERE id=171036917


   --row number: 2787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2885667 , [Content] ='9999 - Intern'
 WHERE id=171036918


   --row number: 2788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2885667 , [Content] ='INR'
 WHERE id=171036919


   --row number: 2789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2885667 , [Content] ='No'
 WHERE id=171036920


   --row number: 2790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2885667 , [Content] ='1/29/2018'
 WHERE id=171036921


   --row number: 2791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2891805 , [Content] ='51,200 / 60,400 / 69,600 / 78,850 / 88,100'
 WHERE id=171723585


   --row number: 2792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2891805 , [Content] ='15%'
 WHERE id=171723588


   --row number: 2793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2891805 , [Content] ='Yes'
 WHERE id=171723589


   --row number: 2794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2891805 , [Content] ='2 - Professionals'
 WHERE id=171723590


   --row number: 2795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2891805 , [Content] ='8810-Clerical Office Employees'
 WHERE id=171723591


   --row number: 2796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2891805 , [Content] ='Technical'
 WHERE id=171723592


   --row number: 2797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2891805 , [Content] ='7/20/2018'
 WHERE id=171723593


   --row number: 2798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2891805 , [Content] ='5763 DEU'
 WHERE id=171723575


   --row number: 2799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2891805 , [Content] ='DEU'
 WHERE id=171723576


   --row number: 2800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2891805 , [Content] ='EMEA'
 WHERE id=171723577


   --row number: 2801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2891805 , [Content] ='GERMANY'
 WHERE id=171723578


   --row number: 2802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2891805 , [Content] ='Professional Services'
 WHERE id=171723579


   --row number: 2803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2891805 , [Content] ='5763 - Technology Consultant IC3'
 WHERE id=171723580


   --row number: 2804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2891805 , [Content] ='Technology Consultant'
 WHERE id=171723581


   --row number: 2805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2891805 , [Content] ='IC3'
 WHERE id=171723582


   --row number: 2806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2891805 , [Content] ='EUR'
 WHERE id=171723584


   --row number: 2807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2892377 , [Content] ='5764 FRA'
 WHERE id=171768536


   --row number: 2808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2892377 , [Content] ='FRA'
 WHERE id=171768537


   --row number: 2809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2892377 , [Content] ='EMEA'
 WHERE id=171768538


   --row number: 2810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2892377 , [Content] ='FRANCE'
 WHERE id=171768539


   --row number: 2811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2892377 , [Content] ='Professional Services'
 WHERE id=171768540


   --row number: 2812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2892377 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=171768541


   --row number: 2813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2892377 , [Content] ='Technology Consultant'
 WHERE id=171768542


   --row number: 2814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2892377 , [Content] ='IC4'
 WHERE id=171768543


   --row number: 2815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2892377 , [Content] ='EUR'
 WHERE id=171768545


   --row number: 2816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2892377 , [Content] ='51,600 / 62,400 / 73,200 / 84,000 / 94,800'
 WHERE id=171768546


   --row number: 2817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2892377 , [Content] ='20%'
 WHERE id=171768548


   --row number: 2818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2892377 , [Content] ='No'
 WHERE id=171768549


   --row number: 2819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2892377 , [Content] ='2 - Professionals'
 WHERE id=171768550


   --row number: 2820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2892377 , [Content] ='8810-Clerical Office Employees'
 WHERE id=171768551


   --row number: 2821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2892377 , [Content] ='Technical'
 WHERE id=171768552


   --row number: 2822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2892377 , [Content] ='04/05/18'
 WHERE id=171768553


   --row number: 2823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2877735 , [Content] ='103,400 / 126,700 / 150,000 / 173,250 / 196,500'
 WHERE id=172100812


   --row number: 2824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2882107 , [Content] ='89,250 / 97,125 / 105,000 / 112,875 / 120,750'
 WHERE id=172101078


   --row number: 2825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2850631 , [Content] ='110,500 / 120,250 / 130,000 / 139,750 / 149,500'
 WHERE id=172165670


   --row number: 2826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2879207 , [Content] ='NO'
 WHERE id=172200085


   --row number: 2827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2879220 , [Content] ='NO'
 WHERE id=172200167


   --row number: 2828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2896861 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=172232653


   --row number: 2829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2896861 , [Content] ='2 - Professionals'
 WHERE id=172232656


   --row number: 2830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2896861 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=172232657


   --row number: 2831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2896861 , [Content] ='Technical'
 WHERE id=172232658


   --row number: 2832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2896861 , [Content] ='04/05/18'
 WHERE id=172232659


   --row number: 2833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2896861 , [Content] ='20%'
 WHERE id=172232654


   --row number: 2834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2896861 , [Content] ='APAC'
 WHERE id=172232644


   --row number: 2835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2896861 , [Content] ='INDIA'
 WHERE id=172232645


   --row number: 2836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2896861 , [Content] ='Engineering'
 WHERE id=172232646


   --row number: 2837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2896861 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=172232647


   --row number: 2838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2896861 , [Content] ='Software'
 WHERE id=172232648


   --row number: 2839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2896861 , [Content] ='IC4'
 WHERE id=172232649


   --row number: 2840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2896861 , [Content] ='INR'
 WHERE id=172232651


   --row number: 2841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2896861 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=172232652


   --row number: 2842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2896861 , [Content] ='Yes'
 WHERE id=172232655


   --row number: 2843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2896861 , [Content] ='5144 IND'
 WHERE id=172232642


   --row number: 2844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2896861 , [Content] ='IND'
 WHERE id=172232643


   --row number: 2845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2896863 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=172232751


   --row number: 2846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2896863 , [Content] ='Technical'
 WHERE id=172232752


   --row number: 2847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2896863 , [Content] ='09/05/18'
 WHERE id=172232753


   --row number: 2848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2896863 , [Content] ='5142 IND'
 WHERE id=172232736


   --row number: 2849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2896863 , [Content] ='IND'
 WHERE id=172232737


   --row number: 2850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2896863 , [Content] ='APAC'
 WHERE id=172232738


   --row number: 2851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2896863 , [Content] ='INDIA'
 WHERE id=172232739


   --row number: 2852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2896863 , [Content] ='Engineering'
 WHERE id=172232740


   --row number: 2853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2896863 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=172232741


   --row number: 2854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2896863 , [Content] ='Software'
 WHERE id=172232742


   --row number: 2855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2896863 , [Content] ='IC2'
 WHERE id=172232743


   --row number: 2856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2896863 , [Content] ='INR'
 WHERE id=172232745


   --row number: 2857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2896863 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=172232746


   --row number: 2858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2896863 , [Content] ='10%'
 WHERE id=172232748


   --row number: 2859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2896863 , [Content] ='No'
 WHERE id=172232749


   --row number: 2860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2896863 , [Content] ='2 - Professionals'
 WHERE id=172232750


   --row number: 2861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2853013 , [Content] ='250,750 / 272,875 / 295,000 / 317,125 / 339,250'
 WHERE id=172236141


   --row number: 2862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2854907 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=172236349


   --row number: 2863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2874792 , [Content] ='65,875 / 71,688 / 77,500 / 83,313 / 89,125'
 WHERE id=172239534


   --row number: 2864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2853565 , [Content] ='161,500 / 175,750 / 190,000 / 204,250 / 218,500'
 WHERE id=172336460


   --row number: 2865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2853032 , [Content] ='17,085,425 / 18,592,963 / 20,100,500 / 21,608,038 / 23,115,575'
 WHERE id=172336689


   --row number: 2866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2897003 , [Content] ='6361 IND'
 WHERE id=172341698


   --row number: 2867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2897003 , [Content] ='IND'
 WHERE id=172341699


   --row number: 2868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2897003 , [Content] ='APAC'
 WHERE id=172341700


   --row number: 2869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2897003 , [Content] ='INDIA'
 WHERE id=172341701


   --row number: 2870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2897003 , [Content] ='Legal'
 WHERE id=172341702


   --row number: 2871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2897003 , [Content] ='6361 - Paralegal IC1'
 WHERE id=172341703


   --row number: 2872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2897003 , [Content] ='Paralegal'
 WHERE id=172341704


   --row number: 2873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2897003 , [Content] ='IC1'
 WHERE id=172341705


   --row number: 2874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2897003 , [Content] ='INR'
 WHERE id=172341707


   --row number: 2875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2897003 , [Content] ='10%'
 WHERE id=172341708


   --row number: 2876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2897003 , [Content] ='No'
 WHERE id=172341709


   --row number: 2877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2897003 , [Content] ='2 - Professionals'
 WHERE id=172341710


   --row number: 2878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2897003 , [Content] ='8810-Clerical Office Employees'
 WHERE id=172341711


   --row number: 2879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2897003 , [Content] ='Non Technical'
 WHERE id=172341712


   --row number: 2880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2897003 , [Content] ='04/05/18'
 WHERE id=172341713


   --row number: 2881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2897234 , [Content] ='04/05/18'
 WHERE id=172399005


   --row number: 2882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2897234 , [Content] ='5774 NLD'
 WHERE id=172398988


   --row number: 2883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2897234 , [Content] ='NLD'
 WHERE id=172398989


   --row number: 2884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2897234 , [Content] ='EMEA'
 WHERE id=172398990


   --row number: 2885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2897234 , [Content] ='NETHERLANDS'
 WHERE id=172398991


   --row number: 2886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2897234 , [Content] ='Professional Services'
 WHERE id=172398992


   --row number: 2887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2897234 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=172398993


   --row number: 2888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2897234 , [Content] ='Business Process Consulting'
 WHERE id=172398994


   --row number: 2889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2897234 , [Content] ='IC4'
 WHERE id=172398995


   --row number: 2890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2897234 , [Content] ='EUR'
 WHERE id=172398997


   --row number: 2891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2897234 , [Content] ='55,700 / 65,750 / 75,800 / 85,800 / 95,800'
 WHERE id=172398998


   --row number: 2892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2897234 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=172398999


   --row number: 2893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2897234 , [Content] ='15%'
 WHERE id=172399000


   --row number: 2894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2897234 , [Content] ='Yes'
 WHERE id=172399001


   --row number: 2895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2897234 , [Content] ='2 - Professionals'
 WHERE id=172399002


   --row number: 2896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2897234 , [Content] ='8810-Clerical Office Employees'
 WHERE id=172399003


   --row number: 2897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2897234 , [Content] ='Technical'
 WHERE id=172399004


   --row number: 2898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2899121 , [Content] ='Sales Operations'
 WHERE id=172589727


   --row number: 2899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2899121 , [Content] ='A2'
 WHERE id=172589728


   --row number: 2900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2899121 , [Content] ='EUR'
 WHERE id=172589730


   --row number: 2901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2899121 , [Content] ='30,700 / 34,550 / 38,400 / 42,250 / 46,100'
 WHERE id=172589731


   --row number: 2902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2899121 , [Content] ='5%'
 WHERE id=172589732


   --row number: 2903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2899121 , [Content] ='No'
 WHERE id=172589733


   --row number: 2904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2899121 , [Content] ='5 - Administrative Support Workers'
 WHERE id=172589734


   --row number: 2905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2899121 , [Content] ='8810-Clerical Office Employees'
 WHERE id=172589735


   --row number: 2906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2899121 , [Content] ='Technical'
 WHERE id=172589736


   --row number: 2907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2899121 , [Content] ='04/05/18'
 WHERE id=172589737


   --row number: 2908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2899121 , [Content] ='S1862 NLD'
 WHERE id=172589721


   --row number: 2909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2899121 , [Content] ='NLD'
 WHERE id=172589722


   --row number: 2910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2899121 , [Content] ='EMEA'
 WHERE id=172589723


   --row number: 2911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2899121 , [Content] ='NETHERLANDS'
 WHERE id=172589724


   --row number: 2912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2899121 , [Content] ='Sales Operations'
 WHERE id=172589725


   --row number: 2913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2899121 , [Content] ='S1862 - Sales Operations Specialist A2'
 WHERE id=172589726


   --row number: 2914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2899509 , [Content] ='Technical'
 WHERE id=172676684


   --row number: 2915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2899509 , [Content] ='04/05/18'
 WHERE id=172676685


   --row number: 2916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2899509 , [Content] ='R3614B DEU'
 WHERE id=172676667


   --row number: 2917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2899509 , [Content] ='DEU'
 WHERE id=172676668


   --row number: 2918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2899509 , [Content] ='EMEA'
 WHERE id=172676669


   --row number: 2919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2899509 , [Content] ='GERMANY'
 WHERE id=172676670


   --row number: 2920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2899509 , [Content] ='Sales'
 WHERE id=172676671


   --row number: 2921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2899509 , [Content] ='R3614B - Commercial Account Exec IC4'
 WHERE id=172676672


   --row number: 2922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2899509 , [Content] ='Commercial Accounts'
 WHERE id=172676673


   --row number: 2923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2899509 , [Content] ='IC4'
 WHERE id=172676674


   --row number: 2924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2899509 , [Content] ='EUR'
 WHERE id=172676676


   --row number: 2925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2899509 , [Content] ='70,125 / 76,313 / 82,500 / 88,688 / 94,875'
 WHERE id=172676677


   --row number: 2926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2899509 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=172676678


   --row number: 2927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2899509 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=172676679


   --row number: 2928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2899509 , [Content] ='50/50'
 WHERE id=172676680


   --row number: 2929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2899509 , [Content] ='Yes'
 WHERE id=172676681


   --row number: 2930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2899509 , [Content] ='4 - Sales Workers'
 WHERE id=172676682


   --row number: 2931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2899509 , [Content] ='8742-Salespersons - Outside'
 WHERE id=172676683


   --row number: 2932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2899523 , [Content] ='5823 NLD'
 WHERE id=172677712


   --row number: 2933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2899523 , [Content] ='NLD'
 WHERE id=172677713


   --row number: 2934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2899523 , [Content] ='EMEA'
 WHERE id=172677714


   --row number: 2935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2899523 , [Content] ='NETHERLANDS'
 WHERE id=172677715


   --row number: 2936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2899523 , [Content] ='Customer Support'
 WHERE id=172677716


   --row number: 2937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2899523 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=172677717


   --row number: 2938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2899523 , [Content] ='Technical Support'
 WHERE id=172677718


   --row number: 2939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2899523 , [Content] ='IC3'
 WHERE id=172677719


   --row number: 2940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2899523 , [Content] ='EUR'
 WHERE id=172677721


   --row number: 2941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2899523 , [Content] ='45,500 / 53,700 / 61,900 / 70,100 / 78,300'
 WHERE id=172677722


   --row number: 2942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2899523 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=172677723


   --row number: 2943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2899523 , [Content] ='15%'
 WHERE id=172677724


   --row number: 2944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2899523 , [Content] ='Yes'
 WHERE id=172677725


   --row number: 2945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2899523 , [Content] ='04/05/18'
 WHERE id=172677729


   --row number: 2946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2899523 , [Content] ='2 - Professionals'
 WHERE id=172677726


   --row number: 2947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2899523 , [Content] ='8810-Clerical Office Employees'
 WHERE id=172677727


   --row number: 2948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2899523 , [Content] ='Technical'
 WHERE id=172677728


   --row number: 2949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2901533 , [Content] ='20%'
 WHERE id=172752160


   --row number: 2950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2901533 , [Content] ='8810-Clerical Office Employees'
 WHERE id=172752165


   --row number: 2951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2901533 , [Content] ='Technical'
 WHERE id=172752166


   --row number: 2952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2901533 , [Content] ='04/05/18'
 WHERE id=172752167


   --row number: 2953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2901533 , [Content] ='Yes'
 WHERE id=172752161


   --row number: 2954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2901533 , [Content] ='5464 US - MRKT 2'
 WHERE id=172752148


   --row number: 2955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2901533 , [Content] ='US - MRKT 2'
 WHERE id=172752149


   --row number: 2956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2901533 , [Content] ='AMS'
 WHERE id=172752150


   --row number: 2957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2901533 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=172752151


   --row number: 2958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2901533 , [Content] ='Marketing'
 WHERE id=172752152


   --row number: 2959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2901533 , [Content] ='5464 - Product Portfolio Mgr IC4'
 WHERE id=172752153


   --row number: 2960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2901533 , [Content] ='Product Mgrs'
 WHERE id=172752154


   --row number: 2961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2901533 , [Content] ='IC4'
 WHERE id=172752155


   --row number: 2962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2901533 , [Content] ='USD'
 WHERE id=172752157


   --row number: 2963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2901533 , [Content] ='99,900 / 120,850 / 141,800 / 162,700 / 183,600'
 WHERE id=172752158


   --row number: 2964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2901533 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=172752159


   --row number: 2965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=2901533 , [Content] ='EXEMPT'
 WHERE id=172752162


   --row number: 2966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=2901533 , [Content] ='NO'
 WHERE id=172752163


   --row number: 2967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2901533 , [Content] ='2 - Professionals'
 WHERE id=172752164


   --row number: 2968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2901867 , [Content] ='6574 JPN'
 WHERE id=172786061


   --row number: 2969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2901867 , [Content] ='JPN'
 WHERE id=172786062


   --row number: 2970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2901867 , [Content] ='APAC'
 WHERE id=172786063


   --row number: 2971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=2901867 , [Content] ='JAPAN'
 WHERE id=172786064


   --row number: 2972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=2901867 , [Content] ='Info Systems/Technology'
 WHERE id=172786065


   --row number: 2973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2901867 , [Content] ='6574 - IT Systems/Support Analyst IC4'
 WHERE id=172786066


   --row number: 2974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2901867 , [Content] ='IT Systems/Support'
 WHERE id=172786067


   --row number: 2975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2901867 , [Content] ='IC4'
 WHERE id=172786068


   --row number: 2976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2901867 , [Content] ='JPY'
 WHERE id=172786070


   --row number: 2977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2901867 , [Content] ='37,200 / 51,600 / 66,000 / 81,000 / 96,000'
 WHERE id=172786071


   --row number: 2978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=2901867 , [Content] ='15%'
 WHERE id=172786072


   --row number: 2979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2901867 , [Content] ='Yes'
 WHERE id=172786073


   --row number: 2980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2901867 , [Content] ='2 - Professionals'
 WHERE id=172786074


   --row number: 2981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2901867 , [Content] ='8810-Clerical Office Employees'
 WHERE id=172786075


   --row number: 2982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2901867 , [Content] ='Technical'
 WHERE id=172786076


   --row number: 2983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2901867 , [Content] ='7/20/18'
 WHERE id=172786077


   --row number: 2984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2856665 , [Content] ='6584 AUS'
 WHERE id=172790670


   --row number: 2985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=2903851 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=173123151


   --row number: 2986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=2903851 , [Content] ='JPY'
 WHERE id=173123155


   --row number: 2987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=2903851 , [Content] ='11,475,000 / 12,487,500 / 13,500,000 / 14,512,500 / 15,525,000'
 WHERE id=173123156


   --row number: 2988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=2903851 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=173123157


   --row number: 2989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=2903851 , [Content] ='15,300,000 / 16,650,000 / 18,000,000 / 19,350,000 / 20,700,000'
 WHERE id=173123158


   --row number: 2990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=2903851 , [Content] ='75/25'
 WHERE id=173123159


   --row number: 2991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=2903851 , [Content] ='Yes'
 WHERE id=173123160


   --row number: 2992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=2903851 , [Content] ='4 - Sales Workers'
 WHERE id=173123161


   --row number: 2993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=2903851 , [Content] ='8742-Salespersons - Outside'
 WHERE id=173123162


   --row number: 2994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=2903851 , [Content] ='Technical'
 WHERE id=173123163


   --row number: 2995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=2903851 , [Content] ='09/05/18'
 WHERE id=173123164


   --row number: 2996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=2903851 , [Content] ='Solution Consultant Core'
 WHERE id=173123152


   --row number: 2997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=2903851 , [Content] ='IC5'
 WHERE id=173123153


   --row number: 2998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=2903851 , [Content] ='S1415 JPN'
 WHERE id=173123146


   --row number: 2999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=2903851 , [Content] ='JPN'
 WHERE id=173123147


   --row number: 3000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=2903851 , [Content] ='APAC'
 WHERE id=173123148

