
--Total 3000
   --row number: 12001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3133560 , [Content] ='60/40'
 WHERE id=196659173


   --row number: 12002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133560 , [Content] ='Yes'
 WHERE id=196659174


   --row number: 12003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133560 , [Content] ='EXEMPT'
 WHERE id=196659175


   --row number: 12004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133560 , [Content] ='7/20/18'
 WHERE id=196659180


   --row number: 12005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133571 , [Content] ='Yes'
 WHERE id=196659951


   --row number: 12006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133571 , [Content] ='4 - Sales Workers'
 WHERE id=196659952


   --row number: 12007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133571 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196659953


   --row number: 12008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133571 , [Content] ='Technical'
 WHERE id=196659954


   --row number: 12009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133571 , [Content] ='7/20/18'
 WHERE id=196659955


   --row number: 12010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133571 , [Content] ='S665 CAN'
 WHERE id=196659937


   --row number: 12011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133571 , [Content] ='CAN'
 WHERE id=196659938


   --row number: 12012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133571 , [Content] ='AMS'
 WHERE id=196659939


   --row number: 12013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133571 , [Content] ='CANADA'
 WHERE id=196659940


   --row number: 12014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133571 , [Content] ='Sales'
 WHERE id=196659941


   --row number: 12015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133571 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=196659942


   --row number: 12016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133571 , [Content] ='Product Line Sales'
 WHERE id=196659943


   --row number: 12017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133571 , [Content] ='IC5'
 WHERE id=196659944


   --row number: 12018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133571 , [Content] ='CAD'
 WHERE id=196659946


   --row number: 12019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133571 , [Content] ='151,215 / 164,558 / 177,900 / 191,243 / 204,585'
 WHERE id=196659947


   --row number: 12020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133571 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=196659948


   --row number: 12021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3133571 , [Content] ='252,025 / 274,263 / 296,500 / 318,738 / 340,975'
 WHERE id=196659949


   --row number: 12022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3133571 , [Content] ='60/40'
 WHERE id=196659950


   --row number: 12023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133616 , [Content] ='NO'
 WHERE id=196664800


   --row number: 12024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133616 , [Content] ='2 - Professionals'
 WHERE id=196664801


   --row number: 12025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133616 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196664802


   --row number: 12026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133616 , [Content] ='Technical'
 WHERE id=196664803


   --row number: 12027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133616 , [Content] ='7/20/18'
 WHERE id=196664804


   --row number: 12028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133616 , [Content] ='4684 US - MRKT 1'
 WHERE id=196664785


   --row number: 12029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133616 , [Content] ='US - MRKT 1'
 WHERE id=196664786


   --row number: 12030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133616 , [Content] ='AMS'
 WHERE id=196664787


   --row number: 12031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133616 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196664788


   --row number: 12032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133616 , [Content] ='Business Strategy'
 WHERE id=196664789


   --row number: 12033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133616 , [Content] ='4684 - Business Process Analyst IC4'
 WHERE id=196664790


   --row number: 12034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133616 , [Content] ='Business Process'
 WHERE id=196664791


   --row number: 12035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133616 , [Content] ='IC4'
 WHERE id=196664792


   --row number: 12036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133616 , [Content] ='USD'
 WHERE id=196664794


   --row number: 12037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133616 , [Content] ='106,000 / 125,100 / 144,200 / 163,250 / 182,300'
 WHERE id=196664795


   --row number: 12038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133616 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=196664796


   --row number: 12039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133616 , [Content] ='15%'
 WHERE id=196664797


   --row number: 12040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133616 , [Content] ='Yes'
 WHERE id=196664798


   --row number: 12041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133616 , [Content] ='EXEMPT'
 WHERE id=196664799


   --row number: 12042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133655 , [Content] ='2 - Professionals'
 WHERE id=196669483


   --row number: 12043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133655 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196669484


   --row number: 12044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133655 , [Content] ='Technical'
 WHERE id=196669485


   --row number: 12045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133655 , [Content] ='7/20/18'
 WHERE id=196669486


   --row number: 12046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133655 , [Content] ='5142 US - MRKT 2'
 WHERE id=196669467


   --row number: 12047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133655 , [Content] ='US - MRKT 2'
 WHERE id=196669468


   --row number: 12048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133655 , [Content] ='AMS'
 WHERE id=196669469


   --row number: 12049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133655 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196669470


   --row number: 12050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133655 , [Content] ='Engineering'
 WHERE id=196669471


   --row number: 12051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133655 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=196669472


   --row number: 12052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133655 , [Content] ='Software'
 WHERE id=196669473


   --row number: 12053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133655 , [Content] ='IC2'
 WHERE id=196669474


   --row number: 12054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133655 , [Content] ='USD'
 WHERE id=196669476


   --row number: 12055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133655 , [Content] ='76,700 / 89,350 / 102,000 / 114,650 / 127,300'
 WHERE id=196669477


   --row number: 12056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133655 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=196669478


   --row number: 12057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133655 , [Content] ='10%'
 WHERE id=196669479


   --row number: 12058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133655 , [Content] ='Yes'
 WHERE id=196669480


   --row number: 12059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133655 , [Content] ='EXEMPT'
 WHERE id=196669481


   --row number: 12060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133655 , [Content] ='NO'
 WHERE id=196669482


   --row number: 12061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133657 , [Content] ='2 - Professionals'
 WHERE id=196669668


   --row number: 12062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133657 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196669669


   --row number: 12063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133657 , [Content] ='Technical'
 WHERE id=196669670


   --row number: 12064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133657 , [Content] ='7/20/18'
 WHERE id=196669671


   --row number: 12065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133657 , [Content] ='5141 US - MRKT 2'
 WHERE id=196669652


   --row number: 12066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133657 , [Content] ='US - MRKT 2'
 WHERE id=196669653


   --row number: 12067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133657 , [Content] ='AMS'
 WHERE id=196669654


   --row number: 12068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133657 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196669655


   --row number: 12069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133657 , [Content] ='Engineering'
 WHERE id=196669656


   --row number: 12070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133657 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=196669657


   --row number: 12071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133657 , [Content] ='Software'
 WHERE id=196669658


   --row number: 12072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133657 , [Content] ='IC1'
 WHERE id=196669659


   --row number: 12073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133657 , [Content] ='USD'
 WHERE id=196669661


   --row number: 12074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3133657 , [Content] ='62,300 / 71,150 / 80,000 / 88,900 / 97,800'
 WHERE id=196669662


   --row number: 12075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133657 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=196669663


   --row number: 12076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133657 , [Content] ='10%'
 WHERE id=196669664


   --row number: 12077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133657 , [Content] ='Yes'
 WHERE id=196669665


   --row number: 12078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3133657 , [Content] ='EXEMPT'
 WHERE id=196669666


   --row number: 12079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3133657 , [Content] ='NO'
 WHERE id=196669667


   --row number: 12080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133856 , [Content] ='6223 JPN'
 WHERE id=196714773


   --row number: 12081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133856 , [Content] ='JPN'
 WHERE id=196714774


   --row number: 12082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133856 , [Content] ='APAC'
 WHERE id=196714775


   --row number: 12083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133856 , [Content] ='JAPAN'
 WHERE id=196714776


   --row number: 12084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133856 , [Content] ='Human Resources'
 WHERE id=196714777


   --row number: 12085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133856 , [Content] ='6223 - Recruiter/Staffing Representative IC3'
 WHERE id=196714778


   --row number: 12086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133856 , [Content] ='Staffing'
 WHERE id=196714779


   --row number: 12087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133856 , [Content] ='IC3'
 WHERE id=196714780


   --row number: 12088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133856 , [Content] ='JPY'
 WHERE id=196714782


   --row number: 12089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3133856 , [Content] ='27,000 / 37,500 / 48,000 / 58,800 / 69,600'
 WHERE id=196714783


   --row number: 12090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133856 , [Content] ='10%'
 WHERE id=196714784


   --row number: 12091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133856 , [Content] ='Yes'
 WHERE id=196714785


   --row number: 12092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133856 , [Content] ='2 - Professionals'
 WHERE id=196714786


   --row number: 12093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133856 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196714787


   --row number: 12094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133856 , [Content] ='Non Technical'
 WHERE id=196714788


   --row number: 12095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133856 , [Content] ='10/24/2018'
 WHERE id=196714789


   --row number: 12096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133904 , [Content] ='S1832 IND'
 WHERE id=196732864


   --row number: 12097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133904 , [Content] ='IND'
 WHERE id=196732865


   --row number: 12098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133904 , [Content] ='APAC'
 WHERE id=196732866


   --row number: 12099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133904 , [Content] ='INDIA'
 WHERE id=196732867


   --row number: 12100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133904 , [Content] ='Sales Operations'
 WHERE id=196732868


   --row number: 12101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133904 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=196732869


   --row number: 12102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133904 , [Content] ='Sales Operations'
 WHERE id=196732870


   --row number: 12103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133904 , [Content] ='IC2'
 WHERE id=196732871


   --row number: 12104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133904 , [Content] ='INR'
 WHERE id=196732873


   --row number: 12105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133904 , [Content] ='10%'
 WHERE id=196732874


   --row number: 12106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133904 , [Content] ='No'
 WHERE id=196732875


   --row number: 12107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133904 , [Content] ='2 - Professionals'
 WHERE id=196732876


   --row number: 12108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133904 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196732877


   --row number: 12109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133904 , [Content] ='Technical'
 WHERE id=196732878


   --row number: 12110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133904 , [Content] ='7/20/18'
 WHERE id=196732879


   --row number: 12111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3133906 , [Content] ='S1832 IND'
 WHERE id=196733216


   --row number: 12112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3133906 , [Content] ='IND'
 WHERE id=196733217


   --row number: 12113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3133906 , [Content] ='APAC'
 WHERE id=196733218


   --row number: 12114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3133906 , [Content] ='INDIA'
 WHERE id=196733219


   --row number: 12115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3133906 , [Content] ='Sales Operations'
 WHERE id=196733220


   --row number: 12116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3133906 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=196733221


   --row number: 12117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3133906 , [Content] ='Sales Operations'
 WHERE id=196733222


   --row number: 12118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3133906 , [Content] ='IC2'
 WHERE id=196733223


   --row number: 12119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3133906 , [Content] ='INR'
 WHERE id=196733225


   --row number: 12120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3133906 , [Content] ='10%'
 WHERE id=196733226


   --row number: 12121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3133906 , [Content] ='No'
 WHERE id=196733227


   --row number: 12122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3133906 , [Content] ='2 - Professionals'
 WHERE id=196733228


   --row number: 12123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3133906 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196733229


   --row number: 12124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3133906 , [Content] ='Technical'
 WHERE id=196733230


   --row number: 12125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3133906 , [Content] ='7/20/18'
 WHERE id=196733231


   --row number: 12126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134012 , [Content] ='Technical'
 WHERE id=196742594


   --row number: 12127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134012 , [Content] ='7/20/18'
 WHERE id=196742595


   --row number: 12128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134012 , [Content] ='5143 IND'
 WHERE id=196742578


   --row number: 12129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134012 , [Content] ='IND'
 WHERE id=196742579


   --row number: 12130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134012 , [Content] ='APAC'
 WHERE id=196742580


   --row number: 12131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134012 , [Content] ='INDIA'
 WHERE id=196742581


   --row number: 12132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134012 , [Content] ='Engineering'
 WHERE id=196742582


   --row number: 12133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134012 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=196742583


   --row number: 12134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134012 , [Content] ='Software'
 WHERE id=196742584


   --row number: 12135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134012 , [Content] ='IC3'
 WHERE id=196742585


   --row number: 12136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134012 , [Content] ='INR'
 WHERE id=196742587


   --row number: 12137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134012 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=196742588


   --row number: 12138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3134012 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=196742589


   --row number: 12139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3134012 , [Content] ='15%'
 WHERE id=196742590


   --row number: 12140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134012 , [Content] ='Yes'
 WHERE id=196742591


   --row number: 12141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134012 , [Content] ='2 - Professionals'
 WHERE id=196742592


   --row number: 12142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134012 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196742593


   --row number: 12143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134072 , [Content] ='6093 IND'
 WHERE id=196748890


   --row number: 12144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134072 , [Content] ='IND'
 WHERE id=196748891


   --row number: 12145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134072 , [Content] ='APAC'
 WHERE id=196748892


   --row number: 12146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134072 , [Content] ='INDIA'
 WHERE id=196748893


   --row number: 12147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134072 , [Content] ='Finance'
 WHERE id=196748894


   --row number: 12148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134072 , [Content] ='6093 - Sr. Revenue Accountant IC3'
 WHERE id=196748895


   --row number: 12149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134072 , [Content] ='Revenue Accounting'
 WHERE id=196748896


   --row number: 12150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134072 , [Content] ='IC3'
 WHERE id=196748897


   --row number: 12151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134072 , [Content] ='INR'
 WHERE id=196748899


   --row number: 12152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134072 , [Content] ='827,600 / 1,013,800 / 1,200,000 / 1,386,200 / 1,572,400'
 WHERE id=196748900


   --row number: 12153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3134072 , [Content] ='10%'
 WHERE id=196748901


   --row number: 12154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134072 , [Content] ='No'
 WHERE id=196748902


   --row number: 12155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134072 , [Content] ='2 - Professionals'
 WHERE id=196748903


   --row number: 12156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134072 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196748904


   --row number: 12157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134072 , [Content] ='Non Technical'
 WHERE id=196748905


   --row number: 12158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134072 , [Content] ='7/20/18'
 WHERE id=196748906


   --row number: 12159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134075 , [Content] ='6093 IND'
 WHERE id=196749304


   --row number: 12160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134075 , [Content] ='IND'
 WHERE id=196749305


   --row number: 12161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134075 , [Content] ='APAC'
 WHERE id=196749306


   --row number: 12162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134075 , [Content] ='INDIA'
 WHERE id=196749307


   --row number: 12163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134075 , [Content] ='Finance'
 WHERE id=196749308


   --row number: 12164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134075 , [Content] ='6093 - Sr. Revenue Accountant IC3'
 WHERE id=196749309


   --row number: 12165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134075 , [Content] ='Revenue Accounting'
 WHERE id=196749310


   --row number: 12166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134075 , [Content] ='IC3'
 WHERE id=196749311


   --row number: 12167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134075 , [Content] ='INR'
 WHERE id=196749313


   --row number: 12168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134075 , [Content] ='827,600 / 1,013,800 / 1,200,000 / 1,386,200 / 1,572,400'
 WHERE id=196749314


   --row number: 12169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3134075 , [Content] ='10%'
 WHERE id=196749315


   --row number: 12170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134075 , [Content] ='No'
 WHERE id=196749316


   --row number: 12171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134075 , [Content] ='2 - Professionals'
 WHERE id=196749317


   --row number: 12172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134075 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196749318


   --row number: 12173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134075 , [Content] ='Non Technical'
 WHERE id=196749319


   --row number: 12174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134075 , [Content] ='7/20/18'
 WHERE id=196749320


   --row number: 12175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134077 , [Content] ='Technical'
 WHERE id=196750031


   --row number: 12176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134077 , [Content] ='7/20/18'
 WHERE id=196750032


   --row number: 12177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134077 , [Content] ='6464 IND'
 WHERE id=196750015


   --row number: 12178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134077 , [Content] ='IND'
 WHERE id=196750016


   --row number: 12179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134077 , [Content] ='APAC'
 WHERE id=196750017


   --row number: 12180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134077 , [Content] ='INDIA'
 WHERE id=196750018


   --row number: 12181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134077 , [Content] ='Info Systems/Technology'
 WHERE id=196750019


   --row number: 12182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134077 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=196750020


   --row number: 12183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134077 , [Content] ='Business Systems Analysis'
 WHERE id=196750021


   --row number: 12184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134077 , [Content] ='IC4'
 WHERE id=196750022


   --row number: 12185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134077 , [Content] ='INR'
 WHERE id=196750024


   --row number: 12186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134077 , [Content] ='1,724,100 / 2,112,050 / 2,500,000 / 2,887,900 / 3,275,800'
 WHERE id=196750025


   --row number: 12187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3134077 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=196750026


   --row number: 12188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3134077 , [Content] ='15%'
 WHERE id=196750027


   --row number: 12189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134077 , [Content] ='Yes'
 WHERE id=196750028


   --row number: 12190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134077 , [Content] ='2 - Professionals'
 WHERE id=196750029


   --row number: 12191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134077 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196750030


   --row number: 12192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134278 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196769345


   --row number: 12193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134278 , [Content] ='Technical'
 WHERE id=196769346


   --row number: 12194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134278 , [Content] ='7/20/18'
 WHERE id=196769347


   --row number: 12195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134278 , [Content] ='S1416A NLD'
 WHERE id=196769329


   --row number: 12196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134278 , [Content] ='NLD'
 WHERE id=196769330


   --row number: 12197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134278 , [Content] ='EMEA'
 WHERE id=196769331


   --row number: 12198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134278 , [Content] ='NETHERLANDS'
 WHERE id=196769332


   --row number: 12199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134278 , [Content] ='Solution Consulting'
 WHERE id=196769333


   --row number: 12200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134278 , [Content] ='S1416A - Principal Solution Architect IC6'
 WHERE id=196769334


   --row number: 12201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134278 , [Content] ='Solution Consultant Architect'
 WHERE id=196769335


   --row number: 12202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134278 , [Content] ='IC6'
 WHERE id=196769336


   --row number: 12203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134278 , [Content] ='EUR'
 WHERE id=196769338


   --row number: 12204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134278 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=196769339


   --row number: 12205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3134278 , [Content] ='114,000 / 171,000 / 228,000 / 285,000 / 342,000'
 WHERE id=196769340


   --row number: 12206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3134278 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=196769341


   --row number: 12207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3134278 , [Content] ='75/25'
 WHERE id=196769342


   --row number: 12208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134278 , [Content] ='Yes'
 WHERE id=196769343


   --row number: 12209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134278 , [Content] ='4 - Sales Workers'
 WHERE id=196769344


   --row number: 12210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134683 , [Content] ='Technical'
 WHERE id=196805725


   --row number: 12211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134683 , [Content] ='7/20/18'
 WHERE id=196805726


   --row number: 12212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134683 , [Content] ='2565 UK'
 WHERE id=196805709


   --row number: 12213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134683 , [Content] ='UK'
 WHERE id=196805710


   --row number: 12214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134683 , [Content] ='EMEA'
 WHERE id=196805711


   --row number: 12215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134683 , [Content] ='UNITED KINGDOM'
 WHERE id=196805712


   --row number: 12216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134683 , [Content] ='Professional Services'
 WHERE id=196805713


   --row number: 12217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134683 , [Content] ='2565 - Dir, Technology Consulting Mgmt M5'
 WHERE id=196805714


   --row number: 12218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134683 , [Content] ='Technology Consultant'
 WHERE id=196805715


   --row number: 12219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134683 , [Content] ='M5'
 WHERE id=196805716


   --row number: 12220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134683 , [Content] ='GBP'
 WHERE id=196805718


   --row number: 12221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134683 , [Content] ='77,900 / 95,450 / 113,000 / 130,500 / 148,000'
 WHERE id=196805719


   --row number: 12222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3134683 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=196805720


   --row number: 12223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3134683 , [Content] ='25%'
 WHERE id=196805721


   --row number: 12224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134683 , [Content] ='Yes'
 WHERE id=196805722


   --row number: 12225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134683 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=196805723


   --row number: 12226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134683 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196805724


   --row number: 12227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3134832 , [Content] ='2 - Professionals'
 WHERE id=196817220


   --row number: 12228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3134832 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196817221


   --row number: 12229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3134832 , [Content] ='Technical'
 WHERE id=196817222


   --row number: 12230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3134832 , [Content] ='7/20/18'
 WHERE id=196817223


   --row number: 12231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3134832 , [Content] ='5141 US - MRKT 1'
 WHERE id=196817204


   --row number: 12232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3134832 , [Content] ='US - MRKT 1'
 WHERE id=196817205


   --row number: 12233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3134832 , [Content] ='AMS'
 WHERE id=196817206


   --row number: 12234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3134832 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196817207


   --row number: 12235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3134832 , [Content] ='Engineering'
 WHERE id=196817208


   --row number: 12236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3134832 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=196817209


   --row number: 12237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3134832 , [Content] ='Software'
 WHERE id=196817210


   --row number: 12238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3134832 , [Content] ='IC1'
 WHERE id=196817211


   --row number: 12239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3134832 , [Content] ='USD'
 WHERE id=196817213


   --row number: 12240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3134832 , [Content] ='84,700 / 96,750 / 108,800 / 120,900 / 133,000'
 WHERE id=196817214


   --row number: 12241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3134832 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=196817215


   --row number: 12242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3134832 , [Content] ='10%'
 WHERE id=196817216


   --row number: 12243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3134832 , [Content] ='Yes'
 WHERE id=196817217


   --row number: 12244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3134832 , [Content] ='EXEMPT'
 WHERE id=196817218


   --row number: 12245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3134832 , [Content] ='NO'
 WHERE id=196817219


   --row number: 12246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3135454 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=196867787


   --row number: 12247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3135454 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196867788


   --row number: 12248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3135454 , [Content] ='Technical'
 WHERE id=196867789


   --row number: 12249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3135454 , [Content] ='7/20/18'
 WHERE id=196867790


   --row number: 12250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3135454 , [Content] ='S316.1 US - MRKT 1'
 WHERE id=196867770


   --row number: 12251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3135454 , [Content] ='US - MRKT 1'
 WHERE id=196867771


   --row number: 12252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3135454 , [Content] ='AMS'
 WHERE id=196867772


   --row number: 12253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3135454 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196867773


   --row number: 12254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3135454 , [Content] ='Sales'
 WHERE id=196867774


   --row number: 12255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3135454 , [Content] ='S316.1 - Sr Dir, Sales M6'
 WHERE id=196867775


   --row number: 12256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3135454 , [Content] ='Sales Management'
 WHERE id=196867776


   --row number: 12257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3135454 , [Content] ='M6'
 WHERE id=196867777


   --row number: 12258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3135454 , [Content] ='USD'
 WHERE id=196867779


   --row number: 12259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3135454 , [Content] ='178,500 / 194,250 / 210,000 / 225,750 / 241,500'
 WHERE id=196867780


   --row number: 12260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3135454 , [Content] ='240,000 / 360,000 / 480,000 / 600,000 / 720,000'
 WHERE id=196867781


   --row number: 12261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3135454 , [Content] ='357,000 / 388,500 / 420,000 / 451,500 / 483,000'
 WHERE id=196867782


   --row number: 12262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3135454 , [Content] ='50/50'
 WHERE id=196867783


   --row number: 12263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3135454 , [Content] ='Yes'
 WHERE id=196867784


   --row number: 12264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3135454 , [Content] ='EXEMPT'
 WHERE id=196867785


   --row number: 12265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3135454 , [Content] ='NO'
 WHERE id=196867786


   --row number: 12266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3135563 , [Content] ='NO'
 WHERE id=196878664


   --row number: 12267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3135563 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=196878665


   --row number: 12268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3135563 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196878666


   --row number: 12269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3135563 , [Content] ='Technical'
 WHERE id=196878667


   --row number: 12270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3135563 , [Content] ='7/20/18'
 WHERE id=196878668


   --row number: 12271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3135563 , [Content] ='S1406 US - MRKT 1'
 WHERE id=196878648


   --row number: 12272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3135563 , [Content] ='US - MRKT 1'
 WHERE id=196878649


   --row number: 12273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3135563 , [Content] ='AMS'
 WHERE id=196878650


   --row number: 12274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3135563 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196878651


   --row number: 12275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3135563 , [Content] ='Solution Consulting'
 WHERE id=196878652


   --row number: 12276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3135563 , [Content] ='S1406 - Sr Dir, Solution Consulting M6'
 WHERE id=196878653


   --row number: 12277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3135563 , [Content] ='Solution Consultant Core'
 WHERE id=196878654


   --row number: 12278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3135563 , [Content] ='M6'
 WHERE id=196878655


   --row number: 12279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3135563 , [Content] ='USD'
 WHERE id=196878657


   --row number: 12280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3135563 , [Content] ='204,000 / 222,000 / 240,000 / 258,000 / 276,000'
 WHERE id=196878658


   --row number: 12281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3135563 , [Content] ='240,000 / 360,000 / 480,000 / 600,000 / 720,000'
 WHERE id=196878659


   --row number: 12282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3135563 , [Content] ='272,000 / 296,000 / 320,000 / 344,000 / 368,000'
 WHERE id=196878660


   --row number: 12283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3135563 , [Content] ='75/25'
 WHERE id=196878661


   --row number: 12284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3135563 , [Content] ='Yes'
 WHERE id=196878662


   --row number: 12285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3135563 , [Content] ='EXEMPT'
 WHERE id=196878663


   --row number: 12286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3135661 , [Content] ='2 - Professionals'
 WHERE id=196888455


   --row number: 12287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3135661 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196888456


   --row number: 12288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3135661 , [Content] ='Technical'
 WHERE id=196888457


   --row number: 12289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3135661 , [Content] ='7/20/18'
 WHERE id=196888458


   --row number: 12290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3135661 , [Content] ='5465 US - MRKT 1'
 WHERE id=196888439


   --row number: 12291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3135661 , [Content] ='US - MRKT 1'
 WHERE id=196888440


   --row number: 12292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3135661 , [Content] ='AMS'
 WHERE id=196888441


   --row number: 12293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3135661 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196888442


   --row number: 12294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3135661 , [Content] ='Marketing'
 WHERE id=196888443


   --row number: 12295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3135661 , [Content] ='5465 - Product Portfolio Mgr IC5'
 WHERE id=196888444


   --row number: 12296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3135661 , [Content] ='Product Mgrs'
 WHERE id=196888445


   --row number: 12297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3135661 , [Content] ='IC5'
 WHERE id=196888446


   --row number: 12298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3135661 , [Content] ='USD'
 WHERE id=196888448


   --row number: 12299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3135661 , [Content] ='130,700 / 160,100 / 189,500 / 218,900 / 248,300'
 WHERE id=196888449


   --row number: 12300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3135661 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=196888450


   --row number: 12301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3135661 , [Content] ='25%'
 WHERE id=196888451


   --row number: 12302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3135661 , [Content] ='Yes'
 WHERE id=196888452


   --row number: 12303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3135661 , [Content] ='EXEMPT'
 WHERE id=196888453


   --row number: 12304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3135661 , [Content] ='NO'
 WHERE id=196888454


   --row number: 12305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3135708 , [Content] ='8810-Clerical Office Employees'
 WHERE id=196893510


   --row number: 12306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3135708 , [Content] ='Technical'
 WHERE id=196893511


   --row number: 12307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3135708 , [Content] ='7/20/18'
 WHERE id=196893512


   --row number: 12308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3135708 , [Content] ='3593 US - MRKT 1'
 WHERE id=196893493


   --row number: 12309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3135708 , [Content] ='US - MRKT 1'
 WHERE id=196893494


   --row number: 12310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3135708 , [Content] ='AMS'
 WHERE id=196893495


   --row number: 12311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3135708 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196893496


   --row number: 12312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3135708 , [Content] ='Info Systems/Technology'
 WHERE id=196893497


   --row number: 12313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3135708 , [Content] ='3593 - Mgr, Data Informatics Mgmt M3'
 WHERE id=196893498


   --row number: 12314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3135708 , [Content] ='Data Informatics'
 WHERE id=196893499


   --row number: 12315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3135708 , [Content] ='M3'
 WHERE id=196893500


   --row number: 12316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3135708 , [Content] ='USD'
 WHERE id=196893502


   --row number: 12317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3135708 , [Content] ='110,300 / 133,400 / 156,500 / 179,600 / 202,700'
 WHERE id=196893503


   --row number: 12318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3135708 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=196893504


   --row number: 12319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3135708 , [Content] ='20%'
 WHERE id=196893505


   --row number: 12320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3135708 , [Content] ='Yes'
 WHERE id=196893506


   --row number: 12321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3135708 , [Content] ='EXEMPT'
 WHERE id=196893507


   --row number: 12322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3135708 , [Content] ='NO'
 WHERE id=196893508


   --row number: 12323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3135708 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=196893509


   --row number: 12324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3135744 , [Content] ='NO'
 WHERE id=196896582


   --row number: 12325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3135744 , [Content] ='2 - Professionals'
 WHERE id=196896583


   --row number: 12326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3135744 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=196896584


   --row number: 12327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3135744 , [Content] ='Technical'
 WHERE id=196896585


   --row number: 12328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3135744 , [Content] ='7/20/18'
 WHERE id=196896586


   --row number: 12329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3135744 , [Content] ='5144 US - MRKT 1'
 WHERE id=196896567


   --row number: 12330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3135744 , [Content] ='US - MRKT 1'
 WHERE id=196896568


   --row number: 12331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3135744 , [Content] ='AMS'
 WHERE id=196896569


   --row number: 12332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3135744 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=196896570


   --row number: 12333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3135744 , [Content] ='Engineering'
 WHERE id=196896571


   --row number: 12334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3135744 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=196896572


   --row number: 12335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3135744 , [Content] ='Software'
 WHERE id=196896573


   --row number: 12336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3135744 , [Content] ='IC4'
 WHERE id=196896574


   --row number: 12337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3135744 , [Content] ='USD'
 WHERE id=196896576


   --row number: 12338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3135744 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=196896577


   --row number: 12339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3135744 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=196896578


   --row number: 12340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3135744 , [Content] ='20%'
 WHERE id=196896579


   --row number: 12341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3135744 , [Content] ='Yes'
 WHERE id=196896580


   --row number: 12342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3135744 , [Content] ='EXEMPT'
 WHERE id=196896581


   --row number: 12343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136641 , [Content] ='S634 JPN'
 WHERE id=196936211


   --row number: 12344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136641 , [Content] ='JPN'
 WHERE id=196936212


   --row number: 12345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136641 , [Content] ='APAC'
 WHERE id=196936213


   --row number: 12346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136641 , [Content] ='JAPAN'
 WHERE id=196936214


   --row number: 12347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136641 , [Content] ='Sales'
 WHERE id=196936215


   --row number: 12348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136641 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=196936216


   --row number: 12349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136641 , [Content] ='Enterprise Accounts'
 WHERE id=196936217


   --row number: 12350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136641 , [Content] ='IC4'
 WHERE id=196936218


   --row number: 12351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136641 , [Content] ='JPY'
 WHERE id=196936220


   --row number: 12352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136641 , [Content] ='Technical'
 WHERE id=196936228


   --row number: 12353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136641 , [Content] ='04/05/18'
 WHERE id=196936229


   --row number: 12354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136641 , [Content] ='8,670,000 / 9,435,000 / 10,200,000 / 10,965,000 / 11,730,000'
 WHERE id=196936221


   --row number: 12355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136641 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=196936222


   --row number: 12356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136641 , [Content] ='14,450,000 / 15,725,000 / 17,000,000 / 18,275,000 / 19,550,000'
 WHERE id=196936223


   --row number: 12357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136641 , [Content] ='60/40'
 WHERE id=196936224


   --row number: 12358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136641 , [Content] ='Yes'
 WHERE id=196936225


   --row number: 12359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136641 , [Content] ='4 - Sales Workers'
 WHERE id=196936226


   --row number: 12360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136641 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196936227


   --row number: 12361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136644 , [Content] ='IC4'
 WHERE id=196936383


   --row number: 12362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136644 , [Content] ='Technical'
 WHERE id=196936393


   --row number: 12363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136644 , [Content] ='04/05/18'
 WHERE id=196936394


   --row number: 12364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136645 , [Content] ='S634 JPN'
 WHERE id=196936438


   --row number: 12365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136645 , [Content] ='JPN'
 WHERE id=196936439


   --row number: 12366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136645 , [Content] ='APAC'
 WHERE id=196936440


   --row number: 12367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136645 , [Content] ='JAPAN'
 WHERE id=196936441


   --row number: 12368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136645 , [Content] ='Sales'
 WHERE id=196936442


   --row number: 12369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136644 , [Content] ='JPY'
 WHERE id=196936385


   --row number: 12370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136644 , [Content] ='S634 JPN'
 WHERE id=196936376


   --row number: 12371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136644 , [Content] ='JPN'
 WHERE id=196936377


   --row number: 12372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136644 , [Content] ='APAC'
 WHERE id=196936378


   --row number: 12373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136644 , [Content] ='JAPAN'
 WHERE id=196936379


   --row number: 12374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136644 , [Content] ='Sales'
 WHERE id=196936380


   --row number: 12375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136644 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=196936381


   --row number: 12376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136644 , [Content] ='Enterprise Accounts'
 WHERE id=196936382


   --row number: 12377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136644 , [Content] ='8,670,000 / 9,435,000 / 10,200,000 / 10,965,000 / 11,730,000'
 WHERE id=196936386


   --row number: 12378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136644 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=196936387


   --row number: 12379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136644 , [Content] ='14,450,000 / 15,725,000 / 17,000,000 / 18,275,000 / 19,550,000'
 WHERE id=196936388


   --row number: 12380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136644 , [Content] ='60/40'
 WHERE id=196936389


   --row number: 12381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136644 , [Content] ='Yes'
 WHERE id=196936390


   --row number: 12382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136644 , [Content] ='4 - Sales Workers'
 WHERE id=196936391


   --row number: 12383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136644 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196936392


   --row number: 12384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136645 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=196936443


   --row number: 12385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136648 , [Content] ='JPN'
 WHERE id=196936909


   --row number: 12386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136648 , [Content] ='APAC'
 WHERE id=196936910


   --row number: 12387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136648 , [Content] ='JAPAN'
 WHERE id=196936911


   --row number: 12388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136648 , [Content] ='Solution Consulting'
 WHERE id=196936912


   --row number: 12389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136648 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=196936913


   --row number: 12390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136648 , [Content] ='Solution Consultant Core'
 WHERE id=196936914


   --row number: 12391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136648 , [Content] ='IC3'
 WHERE id=196936915


   --row number: 12392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136648 , [Content] ='JPY'
 WHERE id=196936917


   --row number: 12393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136648 , [Content] ='8,287,500 / 9,018,750 / 9,750,000 / 10,481,250 / 11,212,500'
 WHERE id=196936918


   --row number: 12394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136648 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=196936919


   --row number: 12395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136648 , [Content] ='11,050,000 / 12,025,000 / 13,000,000 / 13,975,000 / 14,950,000'
 WHERE id=196936920


   --row number: 12396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136648 , [Content] ='75/25'
 WHERE id=196936921


   --row number: 12397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136648 , [Content] ='Yes'
 WHERE id=196936922


   --row number: 12398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136648 , [Content] ='4 - Sales Workers'
 WHERE id=196936923


   --row number: 12399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136648 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196936924


   --row number: 12400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136648 , [Content] ='Technical'
 WHERE id=196936925


   --row number: 12401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136648 , [Content] ='7/20/18'
 WHERE id=196936926


   --row number: 12402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136649 , [Content] ='S1415 JPN'
 WHERE id=196936954


   --row number: 12403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136649 , [Content] ='JPN'
 WHERE id=196936955


   --row number: 12404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136649 , [Content] ='APAC'
 WHERE id=196936956


   --row number: 12405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136649 , [Content] ='JAPAN'
 WHERE id=196936957


   --row number: 12406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136645 , [Content] ='Enterprise Accounts'
 WHERE id=196936444


   --row number: 12407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136645 , [Content] ='IC4'
 WHERE id=196936445


   --row number: 12408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136645 , [Content] ='JPY'
 WHERE id=196936447


   --row number: 12409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136645 , [Content] ='8,670,000 / 9,435,000 / 10,200,000 / 10,965,000 / 11,730,000'
 WHERE id=196936448


   --row number: 12410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136645 , [Content] ='37,200 / 51,600 / 66,000 / 80,700 / 95,400'
 WHERE id=196936449


   --row number: 12411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136645 , [Content] ='14,450,000 / 15,725,000 / 17,000,000 / 18,275,000 / 19,550,000'
 WHERE id=196936450


   --row number: 12412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136645 , [Content] ='60/40'
 WHERE id=196936451


   --row number: 12413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136645 , [Content] ='Yes'
 WHERE id=196936452


   --row number: 12414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136645 , [Content] ='4 - Sales Workers'
 WHERE id=196936453


   --row number: 12415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136645 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196936454


   --row number: 12416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136645 , [Content] ='Technical'
 WHERE id=196936455


   --row number: 12417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136645 , [Content] ='04/05/18'
 WHERE id=196936456


   --row number: 12418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136648 , [Content] ='S1413 JPN'
 WHERE id=196936908


   --row number: 12419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136649 , [Content] ='Solution Consulting'
 WHERE id=196936958


   --row number: 12420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136649 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=196936959


   --row number: 12421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136649 , [Content] ='Solution Consultant Core'
 WHERE id=196936960


   --row number: 12422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136649 , [Content] ='IC5'
 WHERE id=196936961


   --row number: 12423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136649 , [Content] ='JPY'
 WHERE id=196936963


   --row number: 12424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136649 , [Content] ='11,475,000 / 12,487,500 / 13,500,000 / 14,512,500 / 15,525,000'
 WHERE id=196936964


   --row number: 12425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136649 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=196936965


   --row number: 12426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136649 , [Content] ='15,300,000 / 16,650,000 / 18,000,000 / 19,350,000 / 20,700,000'
 WHERE id=196936966


   --row number: 12427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136649 , [Content] ='75/25'
 WHERE id=196936967


   --row number: 12428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136649 , [Content] ='Yes'
 WHERE id=196936968


   --row number: 12429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136649 , [Content] ='4 - Sales Workers'
 WHERE id=196936969


   --row number: 12430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136649 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196936970


   --row number: 12431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136649 , [Content] ='Technical'
 WHERE id=196936971


   --row number: 12432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136649 , [Content] ='09/05/18'
 WHERE id=196936972


   --row number: 12433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136650 , [Content] ='S1413 JPN'
 WHERE id=196936998


   --row number: 12434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136650 , [Content] ='JPN'
 WHERE id=196936999


   --row number: 12435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136650 , [Content] ='APAC'
 WHERE id=196937000


   --row number: 12436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136650 , [Content] ='JAPAN'
 WHERE id=196937001


   --row number: 12437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136650 , [Content] ='Solution Consulting'
 WHERE id=196937002


   --row number: 12438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136650 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=196937003


   --row number: 12439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136650 , [Content] ='Solution Consultant Core'
 WHERE id=196937004


   --row number: 12440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136650 , [Content] ='IC3'
 WHERE id=196937005


   --row number: 12441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136650 , [Content] ='JPY'
 WHERE id=196937007


   --row number: 12442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136650 , [Content] ='8,287,500 / 9,018,750 / 9,750,000 / 10,481,250 / 11,212,500'
 WHERE id=196937008


   --row number: 12443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136650 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=196937009


   --row number: 12444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136650 , [Content] ='11,050,000 / 12,025,000 / 13,000,000 / 13,975,000 / 14,950,000'
 WHERE id=196937010


   --row number: 12445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136650 , [Content] ='75/25'
 WHERE id=196937011


   --row number: 12446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136650 , [Content] ='Yes'
 WHERE id=196937012


   --row number: 12447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136650 , [Content] ='4 - Sales Workers'
 WHERE id=196937013


   --row number: 12448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136650 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196937014


   --row number: 12449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136650 , [Content] ='Technical'
 WHERE id=196937015


   --row number: 12450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136650 , [Content] ='7/20/18'
 WHERE id=196937016


   --row number: 12451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3136651 , [Content] ='S1413 JPN'
 WHERE id=196937074


   --row number: 12452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3136651 , [Content] ='JPN'
 WHERE id=196937075


   --row number: 12453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3136651 , [Content] ='APAC'
 WHERE id=196937076


   --row number: 12454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3136651 , [Content] ='JAPAN'
 WHERE id=196937077


   --row number: 12455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3136651 , [Content] ='Solution Consulting'
 WHERE id=196937078


   --row number: 12456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3136651 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=196937079


   --row number: 12457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3136651 , [Content] ='Solution Consultant Core'
 WHERE id=196937080


   --row number: 12458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3136651 , [Content] ='IC3'
 WHERE id=196937081


   --row number: 12459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3136651 , [Content] ='JPY'
 WHERE id=196937083


   --row number: 12460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3136651 , [Content] ='8,287,500 / 9,018,750 / 9,750,000 / 10,481,250 / 11,212,500'
 WHERE id=196937084


   --row number: 12461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3136651 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=196937085


   --row number: 12462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3136651 , [Content] ='11,050,000 / 12,025,000 / 13,000,000 / 13,975,000 / 14,950,000'
 WHERE id=196937086


   --row number: 12463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3136651 , [Content] ='75/25'
 WHERE id=196937087


   --row number: 12464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3136651 , [Content] ='Yes'
 WHERE id=196937088


   --row number: 12465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3136651 , [Content] ='4 - Sales Workers'
 WHERE id=196937089


   --row number: 12466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3136651 , [Content] ='8742-Salespersons - Outside'
 WHERE id=196937090


   --row number: 12467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3136651 , [Content] ='Technical'
 WHERE id=196937091


   --row number: 12468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3136651 , [Content] ='10/26/2018'
 WHERE id=196937092


   --row number: 12469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3138110 , [Content] ='6225 US - MRKT 3'
 WHERE id=197024050


   --row number: 12470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3138110 , [Content] ='US - MRKT 3'
 WHERE id=197024051


   --row number: 12471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3138110 , [Content] ='AMS'
 WHERE id=197024052


   --row number: 12472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3138110 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197024053


   --row number: 12473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3138110 , [Content] ='Human Resources'
 WHERE id=197024054


   --row number: 12474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3138110 , [Content] ='6225 - Recruiter/Staffing Representative IC5'
 WHERE id=197024055


   --row number: 12475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3138110 , [Content] ='Staffing'
 WHERE id=197024056


   --row number: 12476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3138110 , [Content] ='IC5'
 WHERE id=197024057


   --row number: 12477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3138110 , [Content] ='USD'
 WHERE id=197024059


   --row number: 12478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3138110 , [Content] ='94,000 / 113,700 / 133,400 / 153,100 / 172,800'
 WHERE id=197024060


   --row number: 12479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3138110 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=197024061


   --row number: 12480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3138110 , [Content] ='20%'
 WHERE id=197024062


   --row number: 12481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3138110 , [Content] ='Yes'
 WHERE id=197024063


   --row number: 12482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3138110 , [Content] ='EXEMPT'
 WHERE id=197024064


   --row number: 12483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3138110 , [Content] ='2 - Professionals'
 WHERE id=197024065


   --row number: 12484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3138110 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197024066


   --row number: 12485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3138110 , [Content] ='Non Technical'
 WHERE id=197024067


   --row number: 12486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3138110 , [Content] ='7/20/18'
 WHERE id=197024068


   --row number: 12487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3138542 , [Content] ='9999 US - MRKT 1'
 WHERE id=197051324


   --row number: 12488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3138542 , [Content] ='US - MRKT 1'
 WHERE id=197051325


   --row number: 12489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3138542 , [Content] ='AMS'
 WHERE id=197051326


   --row number: 12490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3138542 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197051327


   --row number: 12491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3138542 , [Content] ='9999 - Intern'
 WHERE id=197051328


   --row number: 12492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3138542 , [Content] ='USD'
 WHERE id=197051329


   --row number: 12493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3138542 , [Content] ='No'
 WHERE id=197051330


   --row number: 12494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3138542 , [Content] ='NON-EXEMPT'
 WHERE id=197051331


   --row number: 12495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3138542 , [Content] ='7/20/18'
 WHERE id=197051332


   --row number: 12496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3138555 , [Content] ='5143 US - MRKT 1'
 WHERE id=197052137


   --row number: 12497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3138555 , [Content] ='US - MRKT 1'
 WHERE id=197052138


   --row number: 12498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3138555 , [Content] ='AMS'
 WHERE id=197052139


   --row number: 12499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3138555 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197052140


   --row number: 12500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3138555 , [Content] ='Engineering'
 WHERE id=197052141


   --row number: 12501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3138555 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=197052142


   --row number: 12502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3138555 , [Content] ='Software'
 WHERE id=197052143


   --row number: 12503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3138555 , [Content] ='IC3'
 WHERE id=197052144


   --row number: 12504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3138555 , [Content] ='USD'
 WHERE id=197052146


   --row number: 12505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3138555 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=197052147


   --row number: 12506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3138555 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=197052148


   --row number: 12507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3138555 , [Content] ='15%'
 WHERE id=197052149


   --row number: 12508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3138555 , [Content] ='Yes'
 WHERE id=197052150


   --row number: 12509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3138555 , [Content] ='EXEMPT'
 WHERE id=197052151


   --row number: 12510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3138555 , [Content] ='NO'
 WHERE id=197052152


   --row number: 12511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3138555 , [Content] ='2 - Professionals'
 WHERE id=197052153


   --row number: 12512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3138555 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197052154


   --row number: 12513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3138555 , [Content] ='Technical'
 WHERE id=197052155


   --row number: 12514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3138555 , [Content] ='7/20/18'
 WHERE id=197052156


   --row number: 12515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3138661 , [Content] ='5374 US - MRKT 2'
 WHERE id=197062594


   --row number: 12516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3138661 , [Content] ='US - MRKT 2'
 WHERE id=197062595


   --row number: 12517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3138661 , [Content] ='AMS'
 WHERE id=197062596


   --row number: 12518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3138661 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197062597


   --row number: 12519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3138661 , [Content] ='Engineering'
 WHERE id=197062598


   --row number: 12520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3138661 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=197062599


   --row number: 12521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3138661 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=197062600


   --row number: 12522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3138661 , [Content] ='IC4'
 WHERE id=197062601


   --row number: 12523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3138661 , [Content] ='USD'
 WHERE id=197062603


   --row number: 12524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3138661 , [Content] ='96,100 / 116,250 / 136,400 / 156,500 / 176,600'
 WHERE id=197062604


   --row number: 12525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3138661 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=197062605


   --row number: 12526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3138661 , [Content] ='20%'
 WHERE id=197062606


   --row number: 12527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3138661 , [Content] ='Yes'
 WHERE id=197062607


   --row number: 12528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3138661 , [Content] ='EXEMPT'
 WHERE id=197062608


   --row number: 12529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3138661 , [Content] ='NO'
 WHERE id=197062609


   --row number: 12530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3138661 , [Content] ='2 - Professionals'
 WHERE id=197062610


   --row number: 12531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3138661 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197062611


   --row number: 12532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3138661 , [Content] ='Technical'
 WHERE id=197062612


   --row number: 12533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3138661 , [Content] ='7/20/18'
 WHERE id=197062613


   --row number: 12534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3138950 , [Content] ='5884 US - MRKT 2'
 WHERE id=197096457


   --row number: 12535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3138950 , [Content] ='US - MRKT 2'
 WHERE id=197096458


   --row number: 12536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3138950 , [Content] ='AMS'
 WHERE id=197096459


   --row number: 12537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3138950 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197096460


   --row number: 12538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3138950 , [Content] ='Professional Services'
 WHERE id=197096461


   --row number: 12539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3138950 , [Content] ='5884 - Customer/Technical Trainer IC4'
 WHERE id=197096462


   --row number: 12540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3138950 , [Content] ='Customer/Tech Training'
 WHERE id=197096463


   --row number: 12541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3138950 , [Content] ='IC4'
 WHERE id=197096464


   --row number: 12542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3138950 , [Content] ='USD'
 WHERE id=197096466


   --row number: 12543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3138950 , [Content] ='81,000 / 95,550 / 110,100 / 124,700 / 139,300'
 WHERE id=197096467


   --row number: 12544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3138950 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=197096468


   --row number: 12545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3138950 , [Content] ='15%'
 WHERE id=197096469


   --row number: 12546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3138950 , [Content] ='Yes'
 WHERE id=197096470


   --row number: 12547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3138950 , [Content] ='EXEMPT'
 WHERE id=197096471


   --row number: 12548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3138950 , [Content] ='NO'
 WHERE id=197096472


   --row number: 12549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3138950 , [Content] ='2 - Professionals'
 WHERE id=197096473


   --row number: 12550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3138950 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197096474


   --row number: 12551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3138950 , [Content] ='Technical'
 WHERE id=197096475


   --row number: 12552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3138950 , [Content] ='7/20/18'
 WHERE id=197096476


   --row number: 12553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3138970 , [Content] ='4685 US - MRKT 2'
 WHERE id=197101492


   --row number: 12554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3138970 , [Content] ='US - MRKT 2'
 WHERE id=197101493


   --row number: 12555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3138970 , [Content] ='AMS'
 WHERE id=197101494


   --row number: 12556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3138970 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197101495


   --row number: 12557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3138970 , [Content] ='Business Strategy'
 WHERE id=197101496


   --row number: 12558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3138970 , [Content] ='4685 - Business Process Analyst IC5'
 WHERE id=197101497


   --row number: 12559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3138970 , [Content] ='Business Process'
 WHERE id=197101498


   --row number: 12560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3138970 , [Content] ='IC5'
 WHERE id=197101499


   --row number: 12561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3138970 , [Content] ='USD'
 WHERE id=197101501


   --row number: 12562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3138970 , [Content] ='104,700 / 126,650 / 148,600 / 170,500 / 192,400'
 WHERE id=197101502


   --row number: 12563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3138970 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=197101503


   --row number: 12564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3138970 , [Content] ='20%'
 WHERE id=197101504


   --row number: 12565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3138970 , [Content] ='Yes'
 WHERE id=197101505


   --row number: 12566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3138970 , [Content] ='EXEMPT'
 WHERE id=197101506


   --row number: 12567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3138970 , [Content] ='NO'
 WHERE id=197101507


   --row number: 12568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3138970 , [Content] ='2 - Professionals'
 WHERE id=197101508


   --row number: 12569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3138970 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197101509


   --row number: 12570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3138970 , [Content] ='Technical'
 WHERE id=197101510


   --row number: 12571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3138970 , [Content] ='7/20/18'
 WHERE id=197101511


   --row number: 12572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3139205 , [Content] ='5182 IND'
 WHERE id=197132639


   --row number: 12573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3139205 , [Content] ='IND'
 WHERE id=197132640


   --row number: 12574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3139205 , [Content] ='APAC'
 WHERE id=197132641


   --row number: 12575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3139205 , [Content] ='INDIA'
 WHERE id=197132642


   --row number: 12576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3139205 , [Content] ='Engineering'
 WHERE id=197132643


   --row number: 12577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3139205 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=197132644


   --row number: 12578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3139205 , [Content] ='Quality'
 WHERE id=197132645


   --row number: 12579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3139205 , [Content] ='IC2'
 WHERE id=197132646


   --row number: 12580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3139205 , [Content] ='INR'
 WHERE id=197132648


   --row number: 12581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3139205 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=197132649


   --row number: 12582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3139205 , [Content] ='10%'
 WHERE id=197132651


   --row number: 12583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3139205 , [Content] ='No'
 WHERE id=197132652


   --row number: 12584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3139205 , [Content] ='2 - Professionals'
 WHERE id=197132653


   --row number: 12585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3139205 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197132654


   --row number: 12586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3139205 , [Content] ='Technical'
 WHERE id=197132655


   --row number: 12587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3139205 , [Content] ='09/05/18'
 WHERE id=197132656


   --row number: 12588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3140281 , [Content] ='S634 UK'
 WHERE id=197183540


   --row number: 12589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3140281 , [Content] ='UK'
 WHERE id=197183541


   --row number: 12590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3140281 , [Content] ='EMEA'
 WHERE id=197183542


   --row number: 12591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3140281 , [Content] ='UNITED KINGDOM'
 WHERE id=197183543


   --row number: 12592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3140281 , [Content] ='Sales'
 WHERE id=197183544


   --row number: 12593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3140281 , [Content] ='S634 - Enterprise Account Exec IC4'
 WHERE id=197183545


   --row number: 12594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3140281 , [Content] ='Enterprise Accounts'
 WHERE id=197183546


   --row number: 12595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3140281 , [Content] ='IC4'
 WHERE id=197183547


   --row number: 12596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3140281 , [Content] ='GBP'
 WHERE id=197183549


   --row number: 12597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3140281 , [Content] ='72,463 / 78,856 / 85,250 / 91,644 / 98,038'
 WHERE id=197183550


   --row number: 12598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3140281 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=197183551


   --row number: 12599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3140281 , [Content] ='144,925 / 157,713 / 170,500 / 183,288 / 196,075'
 WHERE id=197183552


   --row number: 12600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3140281 , [Content] ='50/50'
 WHERE id=197183553


   --row number: 12601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3140281 , [Content] ='Yes'
 WHERE id=197183554


   --row number: 12602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3140281 , [Content] ='4 - Sales Workers'
 WHERE id=197183555


   --row number: 12603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3140281 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197183556


   --row number: 12604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3140281 , [Content] ='Technical'
 WHERE id=197183557


   --row number: 12605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3140281 , [Content] ='7/20/18'
 WHERE id=197183558


   --row number: 12606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3140760 , [Content] ='5375 US - MRKT 2'
 WHERE id=197221943


   --row number: 12607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3140760 , [Content] ='US - MRKT 2'
 WHERE id=197221944


   --row number: 12608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3140760 , [Content] ='AMS'
 WHERE id=197221945


   --row number: 12609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3140760 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197221946


   --row number: 12610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3140760 , [Content] ='Engineering'
 WHERE id=197221947


   --row number: 12611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3140760 , [Content] ='5375 - Project (Design) Manager IC5'
 WHERE id=197221948


   --row number: 12612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3140760 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=197221949


   --row number: 12613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3140760 , [Content] ='IC5'
 WHERE id=197221950


   --row number: 12614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3140760 , [Content] ='USD'
 WHERE id=197221952


   --row number: 12615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3140760 , [Content] ='115,600 / 141,600 / 167,600 / 193,600 / 219,600'
 WHERE id=197221953


   --row number: 12616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3140760 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=197221954


   --row number: 12617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3140760 , [Content] ='25%'
 WHERE id=197221955


   --row number: 12618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3140760 , [Content] ='Yes'
 WHERE id=197221956


   --row number: 12619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3140760 , [Content] ='EXEMPT'
 WHERE id=197221957


   --row number: 12620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3140760 , [Content] ='NO'
 WHERE id=197221958


   --row number: 12621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3140760 , [Content] ='2 - Professionals'
 WHERE id=197221959


   --row number: 12622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3140760 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197221960


   --row number: 12623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3140760 , [Content] ='Technical'
 WHERE id=197221961


   --row number: 12624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3140760 , [Content] ='7/20/18'
 WHERE id=197221962


   --row number: 12625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141146 , [Content] ='6396 US - MRKT 1'
 WHERE id=197251837


   --row number: 12626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141146 , [Content] ='US - MRKT 1'
 WHERE id=197251838


   --row number: 12627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141146 , [Content] ='AMS'
 WHERE id=197251839


   --row number: 12628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141146 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197251840


   --row number: 12629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3141146 , [Content] ='Legal'
 WHERE id=197251841


   --row number: 12630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141146 , [Content] ='6396 - Legal Counsel IC6'
 WHERE id=197251842


   --row number: 12631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3141146 , [Content] ='Legal Counsel'
 WHERE id=197251843


   --row number: 12632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3141146 , [Content] ='IC6'
 WHERE id=197251844


   --row number: 12633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141146 , [Content] ='USD'
 WHERE id=197251846


   --row number: 12634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3141146 , [Content] ='168,000 / 205,800 / 243,600 / 281,400 / 319,200'
 WHERE id=197251847


   --row number: 12635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3141146 , [Content] ='300,000 / 450,000 / 600,000 / 750,000 / 900,000'
 WHERE id=197251848


   --row number: 12636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3141146 , [Content] ='30%'
 WHERE id=197251849


   --row number: 12637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141146 , [Content] ='Yes'
 WHERE id=197251850


   --row number: 12638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3141146 , [Content] ='2 - Professionals'
 WHERE id=197251853


   --row number: 12639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3141146 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197251854


   --row number: 12640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3141146 , [Content] ='Non Technical'
 WHERE id=197251855


   --row number: 12641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141146 , [Content] ='10/05/18'
 WHERE id=197251856


   --row number: 12642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141233 , [Content] ='9999 US - MRKT 1'
 WHERE id=197257742


   --row number: 12643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141233 , [Content] ='US - MRKT 1'
 WHERE id=197257743


   --row number: 12644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141233 , [Content] ='AMS'
 WHERE id=197257744


   --row number: 12645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141233 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197257745


   --row number: 12646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141233 , [Content] ='9999 - Intern'
 WHERE id=197257746


   --row number: 12647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141233 , [Content] ='USD'
 WHERE id=197257747


   --row number: 12648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141233 , [Content] ='No'
 WHERE id=197257748


   --row number: 12649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3141233 , [Content] ='NON-EXEMPT'
 WHERE id=197257749


   --row number: 12650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141233 , [Content] ='7/20/18'
 WHERE id=197257750


   --row number: 12651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141378 , [Content] ='S635 US - MRKT 3'
 WHERE id=197270352


   --row number: 12652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141378 , [Content] ='US - MRKT 3'
 WHERE id=197270353


   --row number: 12653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141378 , [Content] ='AMS'
 WHERE id=197270354


   --row number: 12654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141378 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197270355


   --row number: 12655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3141378 , [Content] ='Sales'
 WHERE id=197270356


   --row number: 12656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141378 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=197270357


   --row number: 12657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3141378 , [Content] ='Enterprise Accounts'
 WHERE id=197270358


   --row number: 12658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3141378 , [Content] ='IC5'
 WHERE id=197270359


   --row number: 12659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141378 , [Content] ='USD'
 WHERE id=197270361


   --row number: 12660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3141378 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=197270362


   --row number: 12661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3141378 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=197270363


   --row number: 12662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3141378 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=197270364


   --row number: 12663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3141378 , [Content] ='50/50'
 WHERE id=197270365


   --row number: 12664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141378 , [Content] ='Yes'
 WHERE id=197270366


   --row number: 12665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3141378 , [Content] ='EXEMPT'
 WHERE id=197270367


   --row number: 12666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3141378 , [Content] ='4 - Sales Workers'
 WHERE id=197270368


   --row number: 12667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3141378 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197270369


   --row number: 12668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3141378 , [Content] ='Technical'
 WHERE id=197270370


   --row number: 12669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141378 , [Content] ='7/20/2018'
 WHERE id=197270371


   --row number: 12670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141381 , [Content] ='9999 US - MRKT 1'
 WHERE id=197270686


   --row number: 12671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141381 , [Content] ='US - MRKT 1'
 WHERE id=197270687


   --row number: 12672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141381 , [Content] ='AMS'
 WHERE id=197270688


   --row number: 12673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141381 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197270689


   --row number: 12674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141381 , [Content] ='9999 - Intern'
 WHERE id=197270690


   --row number: 12675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141381 , [Content] ='USD'
 WHERE id=197270691


   --row number: 12676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141381 , [Content] ='No'
 WHERE id=197270692


   --row number: 12677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3141381 , [Content] ='NON-EXEMPT'
 WHERE id=197270693


   --row number: 12678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141381 , [Content] ='7/20/18'
 WHERE id=197270694


   --row number: 12679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141455 , [Content] ='6075 AUS'
 WHERE id=197279105


   --row number: 12680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141455 , [Content] ='AUS'
 WHERE id=197279106


   --row number: 12681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141455 , [Content] ='APAC'
 WHERE id=197279107


   --row number: 12682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141455 , [Content] ='AUSTRALIA'
 WHERE id=197279108


   --row number: 12683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3141455 , [Content] ='Legal'
 WHERE id=197279109


   --row number: 12684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141455 , [Content] ='6075 - Contracts Manager IC5'
 WHERE id=197279110


   --row number: 12685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3141455 , [Content] ='Contracts Mgmt'
 WHERE id=197279111


   --row number: 12686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3141455 , [Content] ='IC5'
 WHERE id=197279112


   --row number: 12687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141455 , [Content] ='AUD'
 WHERE id=197279114


   --row number: 12688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3141455 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=197279115


   --row number: 12689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3141455 , [Content] ='20%'
 WHERE id=197279116


   --row number: 12690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141455 , [Content] ='Yes'
 WHERE id=197279117


   --row number: 12691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3141455 , [Content] ='2 - Professionals'
 WHERE id=197279118


   --row number: 12692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3141455 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197279119


   --row number: 12693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3141455 , [Content] ='Non Technical'
 WHERE id=197279120


   --row number: 12694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141455 , [Content] ='7/20/18'
 WHERE id=197279121


   --row number: 12695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141732 , [Content] ='S1832 JPN'
 WHERE id=197322399


   --row number: 12696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141732 , [Content] ='JPN'
 WHERE id=197322400


   --row number: 12697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141732 , [Content] ='APAC'
 WHERE id=197322401


   --row number: 12698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141732 , [Content] ='JAPAN'
 WHERE id=197322402


   --row number: 12699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3141732 , [Content] ='Sales Operations'
 WHERE id=197322403


   --row number: 12700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141732 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=197322404


   --row number: 12701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3141732 , [Content] ='Sales Operations'
 WHERE id=197322405


   --row number: 12702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3141732 , [Content] ='IC2'
 WHERE id=197322406


   --row number: 12703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141732 , [Content] ='JPY'
 WHERE id=197322408


   --row number: 12704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3141732 , [Content] ='6,381,300 / 7,290,650 / 8,200,000 / 9,109,300 / 10,018,600'
 WHERE id=197322409


   --row number: 12705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3141732 , [Content] ='16,800 / 23,400 / 30,000 / 36,600 / 43,200'
 WHERE id=197322410


   --row number: 12706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3141732 , [Content] ='10%'
 WHERE id=197322411


   --row number: 12707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141732 , [Content] ='Yes'
 WHERE id=197322412


   --row number: 12708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3141732 , [Content] ='2 - Professionals'
 WHERE id=197322413


   --row number: 12709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3141732 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197322414


   --row number: 12710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3141732 , [Content] ='Technical'
 WHERE id=197322415


   --row number: 12711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141732 , [Content] ='7/20/18'
 WHERE id=197322416


   --row number: 12712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141762 , [Content] ='6075 JPN'
 WHERE id=197326658


   --row number: 12713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141762 , [Content] ='JPN'
 WHERE id=197326659


   --row number: 12714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141762 , [Content] ='APAC'
 WHERE id=197326660


   --row number: 12715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141762 , [Content] ='JAPAN'
 WHERE id=197326661


   --row number: 12716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3141762 , [Content] ='Legal'
 WHERE id=197326662


   --row number: 12717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141762 , [Content] ='6075 - Contracts Manager IC5'
 WHERE id=197326663


   --row number: 12718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3141762 , [Content] ='Contracts Mgmt'
 WHERE id=197326664


   --row number: 12719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3141762 , [Content] ='IC5'
 WHERE id=197326665


   --row number: 12720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141762 , [Content] ='JPY'
 WHERE id=197326667


   --row number: 12721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3141762 , [Content] ='48,000 / 66,000 / 84,000 / 102,000 / 120,000'
 WHERE id=197326668


   --row number: 12722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3141762 , [Content] ='20%'
 WHERE id=197326669


   --row number: 12723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141762 , [Content] ='Yes'
 WHERE id=197326670


   --row number: 12724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3141762 , [Content] ='2 - Professionals'
 WHERE id=197326671


   --row number: 12725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3141762 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197326672


   --row number: 12726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3141762 , [Content] ='Non Technical'
 WHERE id=197326673


   --row number: 12727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141762 , [Content] ='7/20/18'
 WHERE id=197326674


   --row number: 12728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3141974 , [Content] ='2565 UK'
 WHERE id=197342166


   --row number: 12729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3141974 , [Content] ='UK'
 WHERE id=197342167


   --row number: 12730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3141974 , [Content] ='EMEA'
 WHERE id=197342168


   --row number: 12731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3141974 , [Content] ='UNITED KINGDOM'
 WHERE id=197342169


   --row number: 12732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3141974 , [Content] ='Professional Services'
 WHERE id=197342170


   --row number: 12733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3141974 , [Content] ='2565 - Dir, Technology Consulting Mgmt M5'
 WHERE id=197342171


   --row number: 12734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3141974 , [Content] ='Technology Consultant'
 WHERE id=197342172


   --row number: 12735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3141974 , [Content] ='M5'
 WHERE id=197342173


   --row number: 12736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3141974 , [Content] ='GBP'
 WHERE id=197342175


   --row number: 12737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3141974 , [Content] ='77,900 / 95,450 / 113,000 / 130,500 / 148,000'
 WHERE id=197342176


   --row number: 12738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3141974 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=197342177


   --row number: 12739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3141974 , [Content] ='25%'
 WHERE id=197342178


   --row number: 12740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3141974 , [Content] ='Yes'
 WHERE id=197342179


   --row number: 12741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3141974 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=197342180


   --row number: 12742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3141974 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197342181


   --row number: 12743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3141974 , [Content] ='Technical'
 WHERE id=197342182


   --row number: 12744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3141974 , [Content] ='7/20/18'
 WHERE id=197342183


   --row number: 12745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142316 , [Content] ='5374 US - MRKT 2'
 WHERE id=197365345


   --row number: 12746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142316 , [Content] ='US - MRKT 2'
 WHERE id=197365346


   --row number: 12747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142316 , [Content] ='AMS'
 WHERE id=197365347


   --row number: 12748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142316 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197365348


   --row number: 12749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142316 , [Content] ='Engineering'
 WHERE id=197365349


   --row number: 12750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142316 , [Content] ='5374 - Project (Design) Manager IC4'
 WHERE id=197365350


   --row number: 12751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142316 , [Content] ='Engrg Project/Program Mgrs'
 WHERE id=197365351


   --row number: 12752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142316 , [Content] ='IC4'
 WHERE id=197365352


   --row number: 12753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142316 , [Content] ='USD'
 WHERE id=197365354


   --row number: 12754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142343 , [Content] ='AMS'
 WHERE id=197367183


   --row number: 12755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142343 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197367184


   --row number: 12756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142343 , [Content] ='Engineering'
 WHERE id=197367185


   --row number: 12757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142343 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=197367186


   --row number: 12758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142343 , [Content] ='Software'
 WHERE id=197367187


   --row number: 12759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142343 , [Content] ='IC4'
 WHERE id=197367188


   --row number: 12760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142343 , [Content] ='USD'
 WHERE id=197367190


   --row number: 12761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142343 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=197367191


   --row number: 12762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142343 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=197367192


   --row number: 12763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142343 , [Content] ='20%'
 WHERE id=197367193


   --row number: 12764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142343 , [Content] ='Yes'
 WHERE id=197367194


   --row number: 12765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142343 , [Content] ='EXEMPT'
 WHERE id=197367195


   --row number: 12766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142343 , [Content] ='NO'
 WHERE id=197367196


   --row number: 12767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142343 , [Content] ='2 - Professionals'
 WHERE id=197367197


   --row number: 12768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142343 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197367198


   --row number: 12769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142343 , [Content] ='Technical'
 WHERE id=197367199


   --row number: 12770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142343 , [Content] ='7/20/18'
 WHERE id=197367200


   --row number: 12771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142343 , [Content] ='US - MRKT 1'
 WHERE id=197367182


   --row number: 12772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142343 , [Content] ='5144 US - MRKT 1'
 WHERE id=197367181


   --row number: 12773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142316 , [Content] ='7/20/18'
 WHERE id=197365364


   --row number: 12774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142316 , [Content] ='Technical'
 WHERE id=197365363


   --row number: 12775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142316 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197365362


   --row number: 12776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142316 , [Content] ='2 - Professionals'
 WHERE id=197365361


   --row number: 12777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142316 , [Content] ='NO'
 WHERE id=197365360


   --row number: 12778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142316 , [Content] ='EXEMPT'
 WHERE id=197365359


   --row number: 12779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142316 , [Content] ='Yes'
 WHERE id=197365358


   --row number: 12780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142316 , [Content] ='20%'
 WHERE id=197365357


   --row number: 12781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142316 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=197365356


   --row number: 12782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142316 , [Content] ='96,100 / 116,250 / 136,400 / 156,500 / 176,600'
 WHERE id=197365355


   --row number: 12783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142358 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197368130


   --row number: 12784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142358 , [Content] ='Technical'
 WHERE id=197368131


   --row number: 12785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142358 , [Content] ='7/20/18'
 WHERE id=197368132


   --row number: 12786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142358 , [Content] ='5184 US - MRKT 1'
 WHERE id=197368113


   --row number: 12787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142358 , [Content] ='US - MRKT 1'
 WHERE id=197368114


   --row number: 12788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142358 , [Content] ='AMS'
 WHERE id=197368115


   --row number: 12789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142358 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197368116


   --row number: 12790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142358 , [Content] ='Engineering'
 WHERE id=197368117


   --row number: 12791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142358 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=197368118


   --row number: 12792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142358 , [Content] ='Quality'
 WHERE id=197368119


   --row number: 12793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142358 , [Content] ='IC4'
 WHERE id=197368120


   --row number: 12794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142358 , [Content] ='USD'
 WHERE id=197368122


   --row number: 12795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142358 , [Content] ='103,300 / 124,950 / 146,600 / 168,250 / 189,900'
 WHERE id=197368123


   --row number: 12796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142358 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=197368124


   --row number: 12797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142358 , [Content] ='20%'
 WHERE id=197368125


   --row number: 12798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142358 , [Content] ='Yes'
 WHERE id=197368126


   --row number: 12799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142358 , [Content] ='EXEMPT'
 WHERE id=197368127


   --row number: 12800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142358 , [Content] ='NO'
 WHERE id=197368128


   --row number: 12801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142358 , [Content] ='2 - Professionals'
 WHERE id=197368129


   --row number: 12802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142382 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=197370038


   --row number: 12803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142382 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197370039


   --row number: 12804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142382 , [Content] ='Technical'
 WHERE id=197370040


   --row number: 12805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142382 , [Content] ='7/20/18'
 WHERE id=197370041


   --row number: 12806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142382 , [Content] ='2255 US - MRKT 1'
 WHERE id=197370022


   --row number: 12807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142382 , [Content] ='US - MRKT 1'
 WHERE id=197370023


   --row number: 12808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142382 , [Content] ='AMS'
 WHERE id=197370024


   --row number: 12809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142382 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197370025


   --row number: 12810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142382 , [Content] ='Engineering'
 WHERE id=197370026


   --row number: 12811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142382 , [Content] ='2255 - Dir, UI Engineering Mgmt M5'
 WHERE id=197370027


   --row number: 12812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142382 , [Content] ='UI'
 WHERE id=197370028


   --row number: 12813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142382 , [Content] ='M5'
 WHERE id=197370029


   --row number: 12814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142382 , [Content] ='USD'
 WHERE id=197370031


   --row number: 12815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142382 , [Content] ='151,900 / 186,100 / 220,300 / 254,450 / 288,600'
 WHERE id=197370032


   --row number: 12816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142382 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=197370033


   --row number: 12817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142382 , [Content] ='25%'
 WHERE id=197370034


   --row number: 12818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142382 , [Content] ='Yes'
 WHERE id=197370035


   --row number: 12819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142382 , [Content] ='EXEMPT'
 WHERE id=197370036


   --row number: 12820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142382 , [Content] ='NO'
 WHERE id=197370037


   --row number: 12821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142394 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=197371248


   --row number: 12822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142394 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197371249


   --row number: 12823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142394 , [Content] ='Technical'
 WHERE id=197371250


   --row number: 12824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142394 , [Content] ='7/20/18'
 WHERE id=197371251


   --row number: 12825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142394 , [Content] ='2244 US - MRKT 1'
 WHERE id=197371232


   --row number: 12826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142394 , [Content] ='US - MRKT 1'
 WHERE id=197371233


   --row number: 12827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142394 , [Content] ='AMS'
 WHERE id=197371234


   --row number: 12828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142394 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197371235


   --row number: 12829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142394 , [Content] ='Engineering'
 WHERE id=197371236


   --row number: 12830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142394 , [Content] ='2244 - Sr Mgr, Product Mgmt M4'
 WHERE id=197371237


   --row number: 12831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142394 , [Content] ='Product Mgmt Mgr'
 WHERE id=197371238


   --row number: 12832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142394 , [Content] ='M4'
 WHERE id=197371239


   --row number: 12833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142394 , [Content] ='USD'
 WHERE id=197371241


   --row number: 12834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142394 , [Content] ='133,300 / 163,300 / 193,300 / 223,300 / 253,300'
 WHERE id=197371242


   --row number: 12835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142394 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=197371243


   --row number: 12836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142394 , [Content] ='25%'
 WHERE id=197371244


   --row number: 12837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142394 , [Content] ='Yes'
 WHERE id=197371245


   --row number: 12838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142394 , [Content] ='EXEMPT'
 WHERE id=197371246


   --row number: 12839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142394 , [Content] ='NO'
 WHERE id=197371247


   --row number: 12840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142409 , [Content] ='EXEMPT'
 WHERE id=197372141


   --row number: 12841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142409 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=197372143


   --row number: 12842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142409 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197372144


   --row number: 12843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142409 , [Content] ='Technical'
 WHERE id=197372145


   --row number: 12844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142409 , [Content] ='09/05/18'
 WHERE id=197372146


   --row number: 12845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142409 , [Content] ='NO'
 WHERE id=197372142


   --row number: 12846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142409 , [Content] ='2244 US - MRKT 1'
 WHERE id=197372127


   --row number: 12847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142409 , [Content] ='US - MRKT 1'
 WHERE id=197372128


   --row number: 12848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142409 , [Content] ='AMS'
 WHERE id=197372129


   --row number: 12849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142409 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197372130


   --row number: 12850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142409 , [Content] ='Engineering'
 WHERE id=197372131


   --row number: 12851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142409 , [Content] ='2244 - Sr Mgr, Product Mgmt M4'
 WHERE id=197372132


   --row number: 12852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142409 , [Content] ='Product Mgmt Mgr'
 WHERE id=197372133


   --row number: 12853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142409 , [Content] ='M4'
 WHERE id=197372134


   --row number: 12854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142409 , [Content] ='USD'
 WHERE id=197372136


   --row number: 12855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142409 , [Content] ='133,300 / 163,300 / 193,300 / 223,300 / 253,300'
 WHERE id=197372137


   --row number: 12856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142409 , [Content] ='240,000 / 330,000 / 420,000 / 510,000 / 600,000'
 WHERE id=197372138


   --row number: 12857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142409 , [Content] ='25%'
 WHERE id=197372139


   --row number: 12858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142409 , [Content] ='Yes'
 WHERE id=197372140


   --row number: 12859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3142431 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=197373907


   --row number: 12860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3142431 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197373908


   --row number: 12861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3142431 , [Content] ='Technical'
 WHERE id=197373909


   --row number: 12862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142431 , [Content] ='7/20/18'
 WHERE id=197373910


   --row number: 12863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142431 , [Content] ='2243 US - MRKT 2'
 WHERE id=197373891


   --row number: 12864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142431 , [Content] ='US - MRKT 2'
 WHERE id=197373892


   --row number: 12865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142431 , [Content] ='AMS'
 WHERE id=197373893


   --row number: 12866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142431 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197373894


   --row number: 12867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3142431 , [Content] ='Engineering'
 WHERE id=197373895


   --row number: 12868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142431 , [Content] ='2243 - Mgr, Product Mgmt M3'
 WHERE id=197373896


   --row number: 12869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3142431 , [Content] ='Product Mgmt Mgr'
 WHERE id=197373897


   --row number: 12870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3142431 , [Content] ='M3'
 WHERE id=197373898


   --row number: 12871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142431 , [Content] ='USD'
 WHERE id=197373900


   --row number: 12872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3142431 , [Content] ='100,100 / 121,050 / 142,000 / 163,000 / 184,000'
 WHERE id=197373901


   --row number: 12873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3142431 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=197373902


   --row number: 12874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3142431 , [Content] ='20%'
 WHERE id=197373903


   --row number: 12875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142431 , [Content] ='Yes'
 WHERE id=197373904


   --row number: 12876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142431 , [Content] ='EXEMPT'
 WHERE id=197373905


   --row number: 12877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3142431 , [Content] ='NO'
 WHERE id=197373906


   --row number: 12878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3142807 , [Content] ='9999 US - MRKT 1'
 WHERE id=197402451


   --row number: 12879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3142807 , [Content] ='US - MRKT 1'
 WHERE id=197402452


   --row number: 12880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3142807 , [Content] ='AMS'
 WHERE id=197402453


   --row number: 12881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3142807 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197402454


   --row number: 12882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3142807 , [Content] ='9999 - Intern'
 WHERE id=197402455


   --row number: 12883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3142807 , [Content] ='USD'
 WHERE id=197402456


   --row number: 12884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3142807 , [Content] ='No'
 WHERE id=197402457


   --row number: 12885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3142807 , [Content] ='NON-EXEMPT'
 WHERE id=197402458


   --row number: 12886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3142807 , [Content] ='7/20/18'
 WHERE id=197402459


   --row number: 12887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3143078 , [Content] ='EXEMPT'
 WHERE id=197424299


   --row number: 12888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3143078 , [Content] ='4 - Sales Workers'
 WHERE id=197424300


   --row number: 12889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3143078 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197424301


   --row number: 12890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3143078 , [Content] ='Technical'
 WHERE id=197424302


   --row number: 12891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3143078 , [Content] ='7/20/18'
 WHERE id=197424303


   --row number: 12892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3143078 , [Content] ='R3612C US - MRKT 3'
 WHERE id=197424284


   --row number: 12893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3143078 , [Content] ='US - MRKT 3'
 WHERE id=197424285


   --row number: 12894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3143078 , [Content] ='AMS'
 WHERE id=197424286


   --row number: 12895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3143078 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197424287


   --row number: 12896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3143078 , [Content] ='Sales'
 WHERE id=197424288


   --row number: 12897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3143078 , [Content] ='R3612C - Commercial Account Exec - Govt Emerging Mkts IC2'
 WHERE id=197424289


   --row number: 12898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3143078 , [Content] ='Commercial Accounts'
 WHERE id=197424290


   --row number: 12899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3143078 , [Content] ='IC2'
 WHERE id=197424291


   --row number: 12900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3143078 , [Content] ='USD'
 WHERE id=197424293


   --row number: 12901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3143078 , [Content] ='92,225 / 100,363 / 108,500 / 116,638 / 124,775'
 WHERE id=197424294


   --row number: 12902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3143078 , [Content] ='45,000 / 53,700 / 62,400 / 71,400 / 80,400'
 WHERE id=197424295


   --row number: 12903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3143078 , [Content] ='131,750 / 143,375 / 155,000 / 166,625 / 178,250'
 WHERE id=197424296


   --row number: 12904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3143078 , [Content] ='70/30'
 WHERE id=197424297


   --row number: 12905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3143078 , [Content] ='Yes'
 WHERE id=197424298


   --row number: 12906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3143257 , [Content] ='Technical'
 WHERE id=197450936


   --row number: 12907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3143257 , [Content] ='7/20/18'
 WHERE id=197450937


   --row number: 12908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3143257 , [Content] ='5142 IND'
 WHERE id=197450921


   --row number: 12909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3143257 , [Content] ='IND'
 WHERE id=197450922


   --row number: 12910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3143257 , [Content] ='APAC'
 WHERE id=197450923


   --row number: 12911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3143257 , [Content] ='INDIA'
 WHERE id=197450924


   --row number: 12912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3143257 , [Content] ='Engineering'
 WHERE id=197450925


   --row number: 12913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3143257 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=197450926


   --row number: 12914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3143257 , [Content] ='Software'
 WHERE id=197450927


   --row number: 12915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3143257 , [Content] ='IC2'
 WHERE id=197450928


   --row number: 12916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3143257 , [Content] ='INR'
 WHERE id=197450930


   --row number: 12917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3143257 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=197450931


   --row number: 12918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3143257 , [Content] ='10%'
 WHERE id=197450932


   --row number: 12919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3143257 , [Content] ='No'
 WHERE id=197450933


   --row number: 12920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3143257 , [Content] ='2 - Professionals'
 WHERE id=197450934


   --row number: 12921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3143257 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197450935


   --row number: 12922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3143769 , [Content] ='4 - Sales Workers'
 WHERE id=197617582


   --row number: 12923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3143769 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197617583


   --row number: 12924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3143769 , [Content] ='Technical'
 WHERE id=197617584


   --row number: 12925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3143769 , [Content] ='10/05/18'
 WHERE id=197617585


   --row number: 12926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3143769 , [Content] ='S1413 SWE'
 WHERE id=197617567


   --row number: 12927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3143769 , [Content] ='SWE'
 WHERE id=197617568


   --row number: 12928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3143769 , [Content] ='EMEA'
 WHERE id=197617569


   --row number: 12929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3143769 , [Content] ='SWEDEN'
 WHERE id=197617570


   --row number: 12930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3143769 , [Content] ='Solution Consulting'
 WHERE id=197617571


   --row number: 12931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3143769 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=197617572


   --row number: 12932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3143769 , [Content] ='Solution Consultant Core'
 WHERE id=197617573


   --row number: 12933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3143769 , [Content] ='IC3'
 WHERE id=197617574


   --row number: 12934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3143769 , [Content] ='SEK'
 WHERE id=197617576


   --row number: 12935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3143769 , [Content] ='561,000 / 610,500 / 660,000 / 709,500 / 759,000'
 WHERE id=197617577


   --row number: 12936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3143769 , [Content] ='30,000 / 42,000 / 54,000 / 66,000 / 78,000'
 WHERE id=197617578


   --row number: 12937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3143769 , [Content] ='748,000 / 814,000 / 880,000 / 946,000 / 1,012,000'
 WHERE id=197617579


   --row number: 12938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3143769 , [Content] ='75/25'
 WHERE id=197617580


   --row number: 12939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3143769 , [Content] ='Yes'
 WHERE id=197617581


   --row number: 12940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3144049 , [Content] ='10/05/18'
 WHERE id=197727379


   --row number: 12941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3144049 , [Content] ='5141 IND'
 WHERE id=197727363


   --row number: 12942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3144049 , [Content] ='IND'
 WHERE id=197727364


   --row number: 12943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3144049 , [Content] ='APAC'
 WHERE id=197727365


   --row number: 12944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3144049 , [Content] ='INDIA'
 WHERE id=197727366


   --row number: 12945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3144049 , [Content] ='Engineering'
 WHERE id=197727367


   --row number: 12946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3144049 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=197727368


   --row number: 12947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3144049 , [Content] ='Software'
 WHERE id=197727369


   --row number: 12948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3144049 , [Content] ='IC1'
 WHERE id=197727370


   --row number: 12949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3144049 , [Content] ='INR'
 WHERE id=197727372


   --row number: 12950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3144049 , [Content] ='703,500 / 861,800 / 1,020,100 / 1,178,400 / 1,336,700'
 WHERE id=197727373


   --row number: 12951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3144049 , [Content] ='10%'
 WHERE id=197727374


   --row number: 12952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3144049 , [Content] ='No'
 WHERE id=197727375


   --row number: 12953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3144049 , [Content] ='2 - Professionals'
 WHERE id=197727376


   --row number: 12954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3144049 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197727377


   --row number: 12955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3144049 , [Content] ='Technical'
 WHERE id=197727378


   --row number: 12956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3144083 , [Content] ='60/40'
 WHERE id=197733093


   --row number: 12957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3144083 , [Content] ='Yes'
 WHERE id=197733094


   --row number: 12958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3144083 , [Content] ='S1616 UK'
 WHERE id=197733080


   --row number: 12959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3144083 , [Content] ='UK'
 WHERE id=197733081


   --row number: 12960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3144083 , [Content] ='EMEA'
 WHERE id=197733082


   --row number: 12961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3144083 , [Content] ='UNITED KINGDOM'
 WHERE id=197733083


   --row number: 12962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3144083 , [Content] ='Sales'
 WHERE id=197733084


   --row number: 12963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3144083 , [Content] ='S1616 - Regional Partner Mgr IC6'
 WHERE id=197733085


   --row number: 12964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3144083 , [Content] ='Partner Sales'
 WHERE id=197733086


   --row number: 12965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3144083 , [Content] ='IC6'
 WHERE id=197733087


   --row number: 12966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3144083 , [Content] ='GBP'
 WHERE id=197733089


   --row number: 12967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3144083 , [Content] ='99,705 / 108,503 / 117,300 / 126,098 / 134,895'
 WHERE id=197733090


   --row number: 12968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3144083 , [Content] ='114,000 / 171,000 / 228,000 / 285,000 / 342,000'
 WHERE id=197733091


   --row number: 12969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3144083 , [Content] ='166,175 / 180,838 / 195,500 / 210,163 / 224,825'
 WHERE id=197733092


   --row number: 12970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3144083 , [Content] ='4 - Sales Workers'
 WHERE id=197733095


   --row number: 12971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3144083 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197733096


   --row number: 12972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3144083 , [Content] ='Technical'
 WHERE id=197733097


   --row number: 12973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3144083 , [Content] ='7/20/18'
 WHERE id=197733098


   --row number: 12974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3145094 , [Content] ='US - MRKT 1'
 WHERE id=197831028


   --row number: 12975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3145094 , [Content] ='USD'
 WHERE id=197831036


   --row number: 12976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3145094 , [Content] ='100,300 / 121,300 / 142,300 / 163,350 / 184,400'
 WHERE id=197831037


   --row number: 12977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3145094 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=197831038


   --row number: 12978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3145094 , [Content] ='20%'
 WHERE id=197831039


   --row number: 12979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3145094 , [Content] ='Yes'
 WHERE id=197831040


   --row number: 12980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3145094 , [Content] ='EXEMPT'
 WHERE id=197831041


   --row number: 12981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3145094 , [Content] ='NO'
 WHERE id=197831042


   --row number: 12982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3145094 , [Content] ='2 - Professionals'
 WHERE id=197831043


   --row number: 12983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3145094 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197831044


   --row number: 12984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3145094 , [Content] ='Technical'
 WHERE id=197831045


   --row number: 12985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3145094 , [Content] ='7/20/18'
 WHERE id=197831046


   --row number: 12986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3145094 , [Content] ='AMS'
 WHERE id=197831029


   --row number: 12987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3145094 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197831030


   --row number: 12988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3145094 , [Content] ='Info Systems/Technology'
 WHERE id=197831031


   --row number: 12989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3145094 , [Content] ='6534 - Web Developer IC4'
 WHERE id=197831032


   --row number: 12990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3145094 , [Content] ='Web Development'
 WHERE id=197831033


   --row number: 12991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3145094 , [Content] ='IC4'
 WHERE id=197831034


   --row number: 12992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3145094 , [Content] ='6534 US - MRKT 1'
 WHERE id=197831027


   --row number: 12993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3146012 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=197937891


   --row number: 12994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3146012 , [Content] ='INR'
 WHERE id=197937895


   --row number: 12995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3146012 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=197937896


   --row number: 12996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3146012 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=197937897


   --row number: 12997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3146012 , [Content] ='20%'
 WHERE id=197937898


   --row number: 12998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3146012 , [Content] ='Yes'
 WHERE id=197937899


   --row number: 12999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3146012 , [Content] ='2 - Professionals'
 WHERE id=197937900


   --row number: 13000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3146012 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=197937901


   --row number: 13001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3146012 , [Content] ='Technical'
 WHERE id=197937902


   --row number: 13002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3146012 , [Content] ='7/20/18'
 WHERE id=197937903


   --row number: 13003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3146012 , [Content] ='Software'
 WHERE id=197937892


   --row number: 13004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3146012 , [Content] ='IC4'
 WHERE id=197937893


   --row number: 13005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3146012 , [Content] ='5144 IND'
 WHERE id=197937886


   --row number: 13006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3146012 , [Content] ='IND'
 WHERE id=197937887


   --row number: 13007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3146012 , [Content] ='APAC'
 WHERE id=197937888


   --row number: 13008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3146012 , [Content] ='INDIA'
 WHERE id=197937889


   --row number: 13009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3146012 , [Content] ='Engineering'
 WHERE id=197937890


   --row number: 13010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3146147 , [Content] ='7/20/18'
 WHERE id=197951074


   --row number: 13011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3146147 , [Content] ='S1832 SGP'
 WHERE id=197951057


   --row number: 13012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3146147 , [Content] ='SGP'
 WHERE id=197951058


   --row number: 13013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3146147 , [Content] ='APAC'
 WHERE id=197951059


   --row number: 13014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3146147 , [Content] ='SINGAPORE'
 WHERE id=197951060


   --row number: 13015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3146147 , [Content] ='Sales Operations'
 WHERE id=197951061


   --row number: 13016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3146147 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=197951062


   --row number: 13017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3146147 , [Content] ='Sales Operations'
 WHERE id=197951063


   --row number: 13018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3146147 , [Content] ='IC2'
 WHERE id=197951064


   --row number: 13019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3146147 , [Content] ='SGD'
 WHERE id=197951066


   --row number: 13020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3146147 , [Content] ='47,400 / 54,150 / 60,900 / 67,650 / 74,400'
 WHERE id=197951067


   --row number: 13021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3146147 , [Content] ='19,200 / 26,400 / 33,600 / 40,800 / 48,000'
 WHERE id=197951068


   --row number: 13022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3146147 , [Content] ='10%'
 WHERE id=197951069


   --row number: 13023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3146147 , [Content] ='Yes'
 WHERE id=197951070


   --row number: 13024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3146147 , [Content] ='2 - Professionals'
 WHERE id=197951071


   --row number: 13025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3146147 , [Content] ='8810-Clerical Office Employees'
 WHERE id=197951072


   --row number: 13026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3146147 , [Content] ='Technical'
 WHERE id=197951073


   --row number: 13027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3146283 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=197963204


   --row number: 13028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3146283 , [Content] ='Yes'
 WHERE id=197963207


   --row number: 13029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3146283 , [Content] ='4 - Sales Workers'
 WHERE id=197963208


   --row number: 13030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3146283 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197963209


   --row number: 13031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3146283 , [Content] ='Technical'
 WHERE id=197963210


   --row number: 13032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3146283 , [Content] ='7/20/18'
 WHERE id=197963211


   --row number: 13033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3146283 , [Content] ='93,500 / 101,750 / 110,000 / 118,250 / 126,500'
 WHERE id=197963205


   --row number: 13034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3146283 , [Content] ='75/25'
 WHERE id=197963206


   --row number: 13035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3146283 , [Content] ='S1414A UK'
 WHERE id=197963193


   --row number: 13036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3146283 , [Content] ='UK'
 WHERE id=197963194


   --row number: 13037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3146283 , [Content] ='EMEA'
 WHERE id=197963195


   --row number: 13038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3146283 , [Content] ='UNITED KINGDOM'
 WHERE id=197963196


   --row number: 13039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3146283 , [Content] ='Solution Consulting'
 WHERE id=197963197


   --row number: 13040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3146283 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=197963198


   --row number: 13041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3146283 , [Content] ='Solution Consultant Architect'
 WHERE id=197963199


   --row number: 13042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3146283 , [Content] ='IC4'
 WHERE id=197963200


   --row number: 13043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3146283 , [Content] ='GBP'
 WHERE id=197963202


   --row number: 13044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3146283 , [Content] ='70,125 / 76,313 / 82,500 / 88,688 / 94,875'
 WHERE id=197963203


   --row number: 13045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3146286 , [Content] ='8742-Salespersons - Outside'
 WHERE id=197963410


   --row number: 13046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3146286 , [Content] ='Technical'
 WHERE id=197963411


   --row number: 13047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3146286 , [Content] ='7/20/18'
 WHERE id=197963412


   --row number: 13048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3146286 , [Content] ='S1414A NLD'
 WHERE id=197963394


   --row number: 13049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3146286 , [Content] ='NLD'
 WHERE id=197963395


   --row number: 13050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3146286 , [Content] ='EMEA'
 WHERE id=197963396


   --row number: 13051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3146286 , [Content] ='NETHERLANDS'
 WHERE id=197963397


   --row number: 13052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3146286 , [Content] ='Solution Consulting'
 WHERE id=197963398


   --row number: 13053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3146286 , [Content] ='S1414A - Advisory Solution Architect IC4'
 WHERE id=197963399


   --row number: 13054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3146286 , [Content] ='Solution Consultant Architect'
 WHERE id=197963400


   --row number: 13055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3146286 , [Content] ='IC4'
 WHERE id=197963401


   --row number: 13056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3146286 , [Content] ='EUR'
 WHERE id=197963403


   --row number: 13057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3146286 , [Content] ='75,544 / 82,209 / 88,875 / 95,541 / 102,206'
 WHERE id=197963404


   --row number: 13058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3146286 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=197963405


   --row number: 13059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3146286 , [Content] ='100,725 / 109,613 / 118,500 / 127,388 / 136,275'
 WHERE id=197963406


   --row number: 13060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3146286 , [Content] ='75/25'
 WHERE id=197963407


   --row number: 13061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3146286 , [Content] ='Yes'
 WHERE id=197963408


   --row number: 13062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3146286 , [Content] ='4 - Sales Workers'
 WHERE id=197963409


   --row number: 13063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3146656 , [Content] ='9999 US - MRKT 1'
 WHERE id=197988529


   --row number: 13064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3146656 , [Content] ='US - MRKT 1'
 WHERE id=197988530


   --row number: 13065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3146656 , [Content] ='AMS'
 WHERE id=197988531


   --row number: 13066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3146656 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=197988532


   --row number: 13067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3146656 , [Content] ='9999 - Intern'
 WHERE id=197988533


   --row number: 13068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3146656 , [Content] ='USD'
 WHERE id=197988534


   --row number: 13069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3146656 , [Content] ='No'
 WHERE id=197988535


   --row number: 13070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3146656 , [Content] ='NON-EXEMPT'
 WHERE id=197988536


   --row number: 13071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3146656 , [Content] ='04/05/18'
 WHERE id=197988537


   --row number: 13072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3147462 , [Content] ='9999 US - MRKT 1'
 WHERE id=198053907


   --row number: 13073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3147462 , [Content] ='US - MRKT 1'
 WHERE id=198053908


   --row number: 13074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3147462 , [Content] ='AMS'
 WHERE id=198053909


   --row number: 13075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3147462 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198053910


   --row number: 13076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3147462 , [Content] ='9999 - Intern'
 WHERE id=198053911


   --row number: 13077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3147462 , [Content] ='USD'
 WHERE id=198053912


   --row number: 13078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3147462 , [Content] ='No'
 WHERE id=198053913


   --row number: 13079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3147462 , [Content] ='NON-EXEMPT'
 WHERE id=198053914


   --row number: 13080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3147462 , [Content] ='7/20/18'
 WHERE id=198053915


   --row number: 13081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3147495 , [Content] ='9999 US - MRKT 1'
 WHERE id=198055763


   --row number: 13082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3147495 , [Content] ='US - MRKT 1'
 WHERE id=198055764


   --row number: 13083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3147495 , [Content] ='AMS'
 WHERE id=198055765


   --row number: 13084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3147495 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198055766


   --row number: 13085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3147495 , [Content] ='9999 - Intern'
 WHERE id=198055767


   --row number: 13086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3147495 , [Content] ='USD'
 WHERE id=198055768


   --row number: 13087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3147495 , [Content] ='No'
 WHERE id=198055769


   --row number: 13088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3147495 , [Content] ='NON-EXEMPT'
 WHERE id=198055770


   --row number: 13089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3147495 , [Content] ='7/20/18'
 WHERE id=198055771


   --row number: 13090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3147514 , [Content] ='9999 US - MRKT 1'
 WHERE id=198056859


   --row number: 13091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3147514 , [Content] ='US - MRKT 1'
 WHERE id=198056860


   --row number: 13092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3147514 , [Content] ='AMS'
 WHERE id=198056861


   --row number: 13093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3147514 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198056862


   --row number: 13094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3147514 , [Content] ='9999 - Intern'
 WHERE id=198056863


   --row number: 13095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3147514 , [Content] ='USD'
 WHERE id=198056864


   --row number: 13096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3147514 , [Content] ='No'
 WHERE id=198056865


   --row number: 13097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3147514 , [Content] ='NON-EXEMPT'
 WHERE id=198056866


   --row number: 13098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3147514 , [Content] ='7/20/18'
 WHERE id=198056867


   --row number: 13099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148235 , [Content] ='INR'
 WHERE id=198152029


   --row number: 13100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148235 , [Content] ='Yes'
 WHERE id=198152033


   --row number: 13101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3148235 , [Content] ='2 - Professionals'
 WHERE id=198152034


   --row number: 13102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3148235 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198152035


   --row number: 13103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3148235 , [Content] ='Technical'
 WHERE id=198152036


   --row number: 13104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148235 , [Content] ='7/20/18'
 WHERE id=198152037


   --row number: 13105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3148235 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=198152030


   --row number: 13106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148235 , [Content] ='5144 IND'
 WHERE id=198152020


   --row number: 13107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148235 , [Content] ='IND'
 WHERE id=198152021


   --row number: 13108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148235 , [Content] ='APAC'
 WHERE id=198152022


   --row number: 13109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148235 , [Content] ='INDIA'
 WHERE id=198152023


   --row number: 13110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3148235 , [Content] ='Engineering'
 WHERE id=198152024


   --row number: 13111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148235 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=198152025


   --row number: 13112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3148235 , [Content] ='Software'
 WHERE id=198152026


   --row number: 13113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3148235 , [Content] ='IC4'
 WHERE id=198152027


   --row number: 13114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3148235 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=198152031


   --row number: 13115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3148235 , [Content] ='20%'
 WHERE id=198152032


   --row number: 13116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3148242 , [Content] ='Technical'
 WHERE id=198153245


   --row number: 13117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148242 , [Content] ='7/20/2018'
 WHERE id=198153246


   --row number: 13118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148242 , [Content] ='6493 IND'
 WHERE id=198153229


   --row number: 13119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148242 , [Content] ='IND'
 WHERE id=198153230


   --row number: 13120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148242 , [Content] ='APAC'
 WHERE id=198153231


   --row number: 13121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148242 , [Content] ='INDIA'
 WHERE id=198153232


   --row number: 13122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3148242 , [Content] ='Info Systems/Technology'
 WHERE id=198153233


   --row number: 13123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148242 , [Content] ='6493 - Data Informatics Analyst IC3'
 WHERE id=198153234


   --row number: 13124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3148242 , [Content] ='Data Informatics'
 WHERE id=198153235


   --row number: 13125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3148242 , [Content] ='IC3'
 WHERE id=198153236


   --row number: 13126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148242 , [Content] ='INR'
 WHERE id=198153238


   --row number: 13127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3148242 , [Content] ='1,337,900 / 1,638,950 / 1,940,000 / 2,241,000 / 2,542,000'
 WHERE id=198153239


   --row number: 13128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3148242 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=198153240


   --row number: 13129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3148242 , [Content] ='15%'
 WHERE id=198153241


   --row number: 13130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148242 , [Content] ='Yes'
 WHERE id=198153242


   --row number: 13131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3148242 , [Content] ='2 - Professionals'
 WHERE id=198153243


   --row number: 13132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3148242 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198153244


   --row number: 13133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148244 , [Content] ='5182 IND'
 WHERE id=198154063


   --row number: 13134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148244 , [Content] ='IND'
 WHERE id=198154064


   --row number: 13135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148244 , [Content] ='APAC'
 WHERE id=198154065


   --row number: 13136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148244 , [Content] ='INDIA'
 WHERE id=198154066


   --row number: 13137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3148244 , [Content] ='Engineering'
 WHERE id=198154067


   --row number: 13138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148244 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=198154068


   --row number: 13139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3148244 , [Content] ='Quality'
 WHERE id=198154069


   --row number: 13140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3148244 , [Content] ='IC2'
 WHERE id=198154070


   --row number: 13141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3148244 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198154077


   --row number: 13142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3148244 , [Content] ='Technical'
 WHERE id=198154078


   --row number: 13143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148244 , [Content] ='7/20/18'
 WHERE id=198154079


   --row number: 13144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148244 , [Content] ='INR'
 WHERE id=198154072


   --row number: 13145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3148244 , [Content] ='978,600 / 1,198,800 / 1,419,000 / 1,639,150 / 1,859,300'
 WHERE id=198154073


   --row number: 13146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3148244 , [Content] ='10%'
 WHERE id=198154074


   --row number: 13147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148244 , [Content] ='No'
 WHERE id=198154075


   --row number: 13148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3148244 , [Content] ='2 - Professionals'
 WHERE id=198154076


   --row number: 13149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148247 , [Content] ='INDIA'
 WHERE id=198154953


   --row number: 13150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3148247 , [Content] ='2 - Professionals'
 WHERE id=198154964


   --row number: 13151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3148247 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198154965


   --row number: 13152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3148247 , [Content] ='Technical'
 WHERE id=198154966


   --row number: 13153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148247 , [Content] ='7/20/18'
 WHERE id=198154967


   --row number: 13154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3148247 , [Content] ='Info Systems/Technology'
 WHERE id=198154954


   --row number: 13155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148247 , [Content] ='6553 - Enterprisewide Apps/Sys Developer IC3'
 WHERE id=198154955


   --row number: 13156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3148247 , [Content] ='Enterprise Apps/Systems'
 WHERE id=198154956


   --row number: 13157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3148247 , [Content] ='IC3'
 WHERE id=198154957


   --row number: 13158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148247 , [Content] ='6553 IND'
 WHERE id=198154950


   --row number: 13159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148247 , [Content] ='IND'
 WHERE id=198154951


   --row number: 13160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148247 , [Content] ='APAC'
 WHERE id=198154952


   --row number: 13161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148247 , [Content] ='INR'
 WHERE id=198154959


   --row number: 13162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3148247 , [Content] ='1,034,500 / 1,267,250 / 1,500,000 / 1,732,800 / 1,965,600'
 WHERE id=198154960


   --row number: 13163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3148247 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=198154961


   --row number: 13164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3148247 , [Content] ='15%'
 WHERE id=198154962


   --row number: 13165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148247 , [Content] ='Yes'
 WHERE id=198154963


   --row number: 13166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148325 , [Content] ='04/05/18'
 WHERE id=198163852


   --row number: 13167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148325 , [Content] ='5143 IND'
 WHERE id=198163835


   --row number: 13168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148325 , [Content] ='IND'
 WHERE id=198163836


   --row number: 13169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148325 , [Content] ='APAC'
 WHERE id=198163837


   --row number: 13170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148325 , [Content] ='INDIA'
 WHERE id=198163838


   --row number: 13171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3148325 , [Content] ='Engineering'
 WHERE id=198163839


   --row number: 13172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148325 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=198163840


   --row number: 13173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3148325 , [Content] ='Software'
 WHERE id=198163841


   --row number: 13174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3148325 , [Content] ='IC3'
 WHERE id=198163842


   --row number: 13175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148325 , [Content] ='INR'
 WHERE id=198163844


   --row number: 13176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3148325 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=198163845


   --row number: 13177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3148325 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=198163846


   --row number: 13178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3148325 , [Content] ='15%'
 WHERE id=198163847


   --row number: 13179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148325 , [Content] ='Yes'
 WHERE id=198163848


   --row number: 13180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3148325 , [Content] ='2 - Professionals'
 WHERE id=198163849


   --row number: 13181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3148325 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198163850


   --row number: 13182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3148325 , [Content] ='Technical'
 WHERE id=198163851


   --row number: 13183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148713 , [Content] ='9999 US - MRKT 1'
 WHERE id=198205275


   --row number: 13184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148713 , [Content] ='US - MRKT 1'
 WHERE id=198205276


   --row number: 13185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148713 , [Content] ='AMS'
 WHERE id=198205277


   --row number: 13186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148713 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198205278


   --row number: 13187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148713 , [Content] ='9999 - Intern'
 WHERE id=198205279


   --row number: 13188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148713 , [Content] ='USD'
 WHERE id=198205280


   --row number: 13189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148713 , [Content] ='No'
 WHERE id=198205281


   --row number: 13190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3148713 , [Content] ='NON-EXEMPT'
 WHERE id=198205282


   --row number: 13191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148713 , [Content] ='7/20/18'
 WHERE id=198205283


   --row number: 13192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3148845 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=198216682


   --row number: 13193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3148845 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198216683


   --row number: 13194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3148845 , [Content] ='Technical'
 WHERE id=198216684


   --row number: 13195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3148845 , [Content] ='7/20/18'
 WHERE id=198216685


   --row number: 13196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3148845 , [Content] ='EXEMPT'
 WHERE id=198216680


   --row number: 13197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3148845 , [Content] ='NO'
 WHERE id=198216681


   --row number: 13198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3148845 , [Content] ='2184 US - MRKT 2'
 WHERE id=198216666


   --row number: 13199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3148845 , [Content] ='US - MRKT 2'
 WHERE id=198216667


   --row number: 13200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3148845 , [Content] ='AMS'
 WHERE id=198216668


   --row number: 13201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3148845 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198216669


   --row number: 13202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3148845 , [Content] ='Engineering'
 WHERE id=198216670


   --row number: 13203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3148845 , [Content] ='2184 - Sr Mgr,  Software QA Engineering Mgmt M4'
 WHERE id=198216671


   --row number: 13204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3148845 , [Content] ='Quality'
 WHERE id=198216672


   --row number: 13205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3148845 , [Content] ='M4'
 WHERE id=198216673


   --row number: 13206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3148845 , [Content] ='USD'
 WHERE id=198216675


   --row number: 13207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3148845 , [Content] ='110,500 / 135,350 / 160,200 / 185,100 / 210,000'
 WHERE id=198216676


   --row number: 13208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3148845 , [Content] ='138,000 / 189,000 / 240,000 / 291,000 / 342,000'
 WHERE id=198216677


   --row number: 13209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3148845 , [Content] ='25%'
 WHERE id=198216678


   --row number: 13210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3148845 , [Content] ='Yes'
 WHERE id=198216679


   --row number: 13211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3149667 , [Content] ='S1373 US - MRKT 2'
 WHERE id=198284517


   --row number: 13212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3149667 , [Content] ='US - MRKT 2'
 WHERE id=198284518


   --row number: 13213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3149667 , [Content] ='AMS'
 WHERE id=198284519


   --row number: 13214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3149667 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198284520


   --row number: 13215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3149667 , [Content] ='Sales'
 WHERE id=198284521


   --row number: 13216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3149667 , [Content] ='S1373 - Inside/Contract Renewal Sales Rep A3'
 WHERE id=198284522


   --row number: 13217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3149667 , [Content] ='Inside/Contract Renewal'
 WHERE id=198284523


   --row number: 13218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3149667 , [Content] ='A3'
 WHERE id=198284524


   --row number: 13219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3149667 , [Content] ='USD'
 WHERE id=198284526


   --row number: 13220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3149667 , [Content] ='53,600 / 58,300 / 63,000 / 67,750 / 72,500'
 WHERE id=198284527


   --row number: 13221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3149667 , [Content] ='24,600 / 29,100 / 33,600 / 38,400 / 43,200'
 WHERE id=198284528


   --row number: 13222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3149667 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=198284529


   --row number: 13223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3149667 , [Content] ='70/30'
 WHERE id=198284530


   --row number: 13224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3149667 , [Content] ='Yes'
 WHERE id=198284531


   --row number: 13225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3149667 , [Content] ='NON-EXEMPT'
 WHERE id=198284532


   --row number: 13226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3149667 , [Content] ='NO'
 WHERE id=198284533


   --row number: 13227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3149667 , [Content] ='4 - Sales Workers'
 WHERE id=198284534


   --row number: 13228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3149667 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198284535


   --row number: 13229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3149667 , [Content] ='Non Technical'
 WHERE id=198284536


   --row number: 13230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3149667 , [Content] ='09/05/18'
 WHERE id=198284537


   --row number: 13231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3149559 , [Content] ='9999 US - MRKT 1'
 WHERE id=198276919


   --row number: 13232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3149559 , [Content] ='US - MRKT 1'
 WHERE id=198276920


   --row number: 13233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3149559 , [Content] ='AMS'
 WHERE id=198276921


   --row number: 13234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3149559 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198276922


   --row number: 13235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3149559 , [Content] ='9999 - Intern'
 WHERE id=198276923


   --row number: 13236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3149559 , [Content] ='Intern'
 WHERE id=198276924


   --row number: 13237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3149559 , [Content] ='No'
 WHERE id=198276925


   --row number: 13238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3149559 , [Content] ='NON-EXEMPT'
 WHERE id=198276926


   --row number: 13239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3149759 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198290170


   --row number: 13240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3149759 , [Content] ='Non Technical'
 WHERE id=198290171


   --row number: 13241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3149759 , [Content] ='10/05/18'
 WHERE id=198290172


   --row number: 13242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3149759 , [Content] ='S1374 US - MRKT 2'
 WHERE id=198290152


   --row number: 13243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3149759 , [Content] ='US - MRKT 2'
 WHERE id=198290153


   --row number: 13244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3149759 , [Content] ='AMS'
 WHERE id=198290154


   --row number: 13245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3149759 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198290155


   --row number: 13246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3149759 , [Content] ='Sales'
 WHERE id=198290156


   --row number: 13247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3149759 , [Content] ='S1374 - Inside/Contract Renewal Sales Rep A4'
 WHERE id=198290157


   --row number: 13248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3149759 , [Content] ='Inside/Contract Renewal'
 WHERE id=198290158


   --row number: 13249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3149759 , [Content] ='A4'
 WHERE id=198290159


   --row number: 13250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3149759 , [Content] ='USD'
 WHERE id=198290161


   --row number: 13251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3149759 , [Content] ='63,700 / 69,300 / 74,900 / 80,550 / 86,200'
 WHERE id=198290162


   --row number: 13252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3149759 , [Content] ='45,000 / 53,700 / 62,400 / 71,400 / 80,400'
 WHERE id=198290163


   --row number: 13253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3149759 , [Content] ='91,000 / 99,000 / 107,000 / 115,050 / 123,100'
 WHERE id=198290164


   --row number: 13254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3149759 , [Content] ='70/30'
 WHERE id=198290165


   --row number: 13255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3149759 , [Content] ='Yes'
 WHERE id=198290166


   --row number: 13256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3149759 , [Content] ='EXEMPT'
 WHERE id=198290167


   --row number: 13257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3149759 , [Content] ='4 - Sales Workers'
 WHERE id=198290169


   --row number: 13258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3149763 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198290531


   --row number: 13259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3149763 , [Content] ='Non Technical'
 WHERE id=198290532


   --row number: 13260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3149763 , [Content] ='10/24/2018'
 WHERE id=198290533


   --row number: 13261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3149763 , [Content] ='S1375 US - MRKT 1'
 WHERE id=198290513


   --row number: 13262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3149763 , [Content] ='US - MRKT 1'
 WHERE id=198290514


   --row number: 13263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3149763 , [Content] ='AMS'
 WHERE id=198290515


   --row number: 13264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3149763 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198290516


   --row number: 13265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3149763 , [Content] ='Sales'
 WHERE id=198290517


   --row number: 13266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3149763 , [Content] ='S1375 - Inside/Contract Renewal Sales Rep IC5'
 WHERE id=198290518


   --row number: 13267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3149763 , [Content] ='Inside/Contract Renewal'
 WHERE id=198290519


   --row number: 13268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3149763 , [Content] ='IC5'
 WHERE id=198290520


   --row number: 13269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3149763 , [Content] ='USD'
 WHERE id=198290522


   --row number: 13270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3149763 , [Content] ='82,100 / 89,350 / 96,600 / 103,850 / 111,100'
 WHERE id=198290523


   --row number: 13271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3149763 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=198290524


   --row number: 13272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3149763 , [Content] ='117,300 / 127,650 / 138,000 / 148,350 / 158,700'
 WHERE id=198290525


   --row number: 13273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3149763 , [Content] ='70/30'
 WHERE id=198290526


   --row number: 13274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3149763 , [Content] ='Yes'
 WHERE id=198290527


   --row number: 13275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3149763 , [Content] ='EXEMPT'
 WHERE id=198290528


   --row number: 13276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3149763 , [Content] ='4 - Sales Workers'
 WHERE id=198290530


   --row number: 13277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150092 , [Content] ='INR'
 WHERE id=198344668


   --row number: 13278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150092 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=198344669


   --row number: 13279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150092 , [Content] ='5142 IND'
 WHERE id=198344659


   --row number: 13280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150092 , [Content] ='IND'
 WHERE id=198344660


   --row number: 13281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150092 , [Content] ='APAC'
 WHERE id=198344661


   --row number: 13282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150092 , [Content] ='INDIA'
 WHERE id=198344662


   --row number: 13283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150092 , [Content] ='Engineering'
 WHERE id=198344663


   --row number: 13284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150092 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=198344664


   --row number: 13285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150092 , [Content] ='Software'
 WHERE id=198344665


   --row number: 13286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150092 , [Content] ='IC2'
 WHERE id=198344666


   --row number: 13287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150092 , [Content] ='10%'
 WHERE id=198344671


   --row number: 13288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150092 , [Content] ='No'
 WHERE id=198344672


   --row number: 13289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150092 , [Content] ='2 - Professionals'
 WHERE id=198344673


   --row number: 13290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3150092 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=198344670


   --row number: 13291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150092 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198344674


   --row number: 13292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150092 , [Content] ='Technical'
 WHERE id=198344675


   --row number: 13293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150092 , [Content] ='09/05/18'
 WHERE id=198344676


   --row number: 13294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150369 , [Content] ='Engineering'
 WHERE id=198381160


   --row number: 13295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150369 , [Content] ='Technical'
 WHERE id=198381173


   --row number: 13296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150369 , [Content] ='09/05/18'
 WHERE id=198381174


   --row number: 13297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150369 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=198381161


   --row number: 13298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150369 , [Content] ='Quality'
 WHERE id=198381162


   --row number: 13299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150369 , [Content] ='IC3'
 WHERE id=198381163


   --row number: 13300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150369 , [Content] ='APAC'
 WHERE id=198381158


   --row number: 13301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150369 , [Content] ='INDIA'
 WHERE id=198381159


   --row number: 13302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150369 , [Content] ='INR'
 WHERE id=198381165


   --row number: 13303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150369 , [Content] ='1,344,800 / 1,647,400 / 1,950,000 / 2,252,550 / 2,555,100'
 WHERE id=198381166


   --row number: 13304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150369 , [Content] ='28,800 / 39,900 / 51,000 / 62,700 / 74,400'
 WHERE id=198381167


   --row number: 13305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3150369 , [Content] ='1,546,500 / 1,894,500 / 2,242,500 / 2,590,450 / 2,938,400'
 WHERE id=198381168


   --row number: 13306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150369 , [Content] ='15%'
 WHERE id=198381169


   --row number: 13307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150369 , [Content] ='Yes'
 WHERE id=198381170


   --row number: 13308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150369 , [Content] ='2 - Professionals'
 WHERE id=198381171


   --row number: 13309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150369 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198381172


   --row number: 13310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150369 , [Content] ='5183 IND'
 WHERE id=198381156


   --row number: 13311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150369 , [Content] ='IND'
 WHERE id=198381157


   --row number: 13312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150389 , [Content] ='20%'
 WHERE id=198382153


   --row number: 13313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150389 , [Content] ='Yes'
 WHERE id=198382154


   --row number: 13314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150389 , [Content] ='2 - Professionals'
 WHERE id=198382155


   --row number: 13315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150389 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198382156


   --row number: 13316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150389 , [Content] ='Technical'
 WHERE id=198382157


   --row number: 13317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150389 , [Content] ='09/05/18'
 WHERE id=198382158


   --row number: 13318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150389 , [Content] ='5144 IND'
 WHERE id=198382140


   --row number: 13319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150389 , [Content] ='IND'
 WHERE id=198382141


   --row number: 13320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150389 , [Content] ='APAC'
 WHERE id=198382142


   --row number: 13321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150389 , [Content] ='INDIA'
 WHERE id=198382143


   --row number: 13322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150389 , [Content] ='Engineering'
 WHERE id=198382144


   --row number: 13323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150389 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=198382145


   --row number: 13324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150389 , [Content] ='Software'
 WHERE id=198382146


   --row number: 13325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150389 , [Content] ='IC4'
 WHERE id=198382147


   --row number: 13326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150389 , [Content] ='INR'
 WHERE id=198382149


   --row number: 13327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150389 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=198382150


   --row number: 13328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150389 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=198382151


   --row number: 13329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3150389 , [Content] ='2,813,800 / 3,446,900 / 4,080,000 / 4,713,050 / 5,346,100'
 WHERE id=198382152


   --row number: 13330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150472 , [Content] ='6464 IND'
 WHERE id=198393265


   --row number: 13331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150472 , [Content] ='IND'
 WHERE id=198393266


   --row number: 13332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150472 , [Content] ='APAC'
 WHERE id=198393267


   --row number: 13333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150472 , [Content] ='India'
 WHERE id=198393268


   --row number: 13334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150472 , [Content] ='Info Systems/Technology'
 WHERE id=198393269


   --row number: 13335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150472 , [Content] ='6464 - Business Systems Analyst IC4'
 WHERE id=198393270


   --row number: 13336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150472 , [Content] ='Business Systems Analysis'
 WHERE id=198393271


   --row number: 13337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150472 , [Content] ='IC4'
 WHERE id=198393272


   --row number: 13338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150472 , [Content] ='1,448,300 / 2,100,000 / 2,751,800'
 WHERE id=198393274


   --row number: 13339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150472 , [Content] ='310 / 625 / 940'
 WHERE id=198393275


   --row number: 13340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150472 , [Content] ='15%'
 WHERE id=198393276


   --row number: 13341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150472 , [Content] ='Yes'
 WHERE id=198393277


   --row number: 13342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150472 , [Content] ='2 - Professionals'
 WHERE id=198393278


   --row number: 13343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150472 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198393279


   --row number: 13344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150472 , [Content] ='Non Technical'
 WHERE id=198393280


   --row number: 13345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150569 , [Content] ='09/05/18'
 WHERE id=198404947


   --row number: 13346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150569 , [Content] ='6102 IND'
 WHERE id=198404930


   --row number: 13347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150569 , [Content] ='IND'
 WHERE id=198404931


   --row number: 13348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150569 , [Content] ='APAC'
 WHERE id=198404932


   --row number: 13349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150569 , [Content] ='INDIA'
 WHERE id=198404933


   --row number: 13350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150569 , [Content] ='Finance'
 WHERE id=198404934


   --row number: 13351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150569 , [Content] ='6102 - Accountant IC2'
 WHERE id=198404935


   --row number: 13352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150569 , [Content] ='Accounting'
 WHERE id=198404936


   --row number: 13353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150569 , [Content] ='IC2'
 WHERE id=198404937


   --row number: 13354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150569 , [Content] ='INR'
 WHERE id=198404939


   --row number: 13355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150569 , [Content] ='620,700 / 760,350 / 900,000 / 1,039,650 / 1,179,300'
 WHERE id=198404940


   --row number: 13356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3150569 , [Content] ='682,800 / 836,400 / 990,000 / 1,143,600 / 1,297,200'
 WHERE id=198404941


   --row number: 13357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150569 , [Content] ='10%'
 WHERE id=198404942


   --row number: 13358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150569 , [Content] ='No'
 WHERE id=198404943


   --row number: 13359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150569 , [Content] ='2 - Professionals'
 WHERE id=198404944


   --row number: 13360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150569 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198404945


   --row number: 13361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150569 , [Content] ='Non Technical'
 WHERE id=198404946


   --row number: 13362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150649 , [Content] ='2525 NLD'
 WHERE id=198416772


   --row number: 13363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150649 , [Content] ='NLD'
 WHERE id=198416773


   --row number: 13364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150649 , [Content] ='EMEA'
 WHERE id=198416774


   --row number: 13365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150649 , [Content] ='NETHERLANDS'
 WHERE id=198416775


   --row number: 13366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150649 , [Content] ='Marketing'
 WHERE id=198416776


   --row number: 13367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150649 , [Content] ='2525 - Dir, Marketing Communications Mgmt M5'
 WHERE id=198416777


   --row number: 13368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150649 , [Content] ='Marcom'
 WHERE id=198416778


   --row number: 13369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150649 , [Content] ='M5'
 WHERE id=198416779


   --row number: 13370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150649 , [Content] ='EUR'
 WHERE id=198416781


   --row number: 13371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150649 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=198416782


   --row number: 13372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150649 , [Content] ='25%'
 WHERE id=198416783


   --row number: 13373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150649 , [Content] ='Yes'
 WHERE id=198416784


   --row number: 13374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150649 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=198416785


   --row number: 13375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150649 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198416786


   --row number: 13376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150649 , [Content] ='Non Technical'
 WHERE id=198416787


   --row number: 13377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150649 , [Content] ='09/05/18'
 WHERE id=198416788


   --row number: 13378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150722 , [Content] ='S665 DEU'
 WHERE id=198428698


   --row number: 13379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150722 , [Content] ='DEU'
 WHERE id=198428699


   --row number: 13380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150722 , [Content] ='EMEA'
 WHERE id=198428700


   --row number: 13381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150722 , [Content] ='GERMANY'
 WHERE id=198428701


   --row number: 13382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150722 , [Content] ='Sales'
 WHERE id=198428702


   --row number: 13383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150722 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=198428703


   --row number: 13384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150722 , [Content] ='Product Line Sales'
 WHERE id=198428704


   --row number: 13385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150722 , [Content] ='IC5'
 WHERE id=198428705


   --row number: 13386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150722 , [Content] ='87,000 / 121,500 / 156,000 / 190,800 / 225,600'
 WHERE id=198428707


   --row number: 13387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3150722 , [Content] ='60/40'
 WHERE id=198428708


   --row number: 13388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150722 , [Content] ='Yes'
 WHERE id=198428709


   --row number: 13389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150722 , [Content] ='4 - Sales Workers'
 WHERE id=198428710


   --row number: 13390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150722 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198428711


   --row number: 13391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150722 , [Content] ='Technical'
 WHERE id=198428712


   --row number: 13392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150729 , [Content] ='5143 IND'
 WHERE id=198429707


   --row number: 13393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150729 , [Content] ='IND'
 WHERE id=198429708


   --row number: 13394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150729 , [Content] ='APAC'
 WHERE id=198429709


   --row number: 13395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150729 , [Content] ='INDIA'
 WHERE id=198429710


   --row number: 13396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150729 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198429723


   --row number: 13397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150729 , [Content] ='Technical'
 WHERE id=198429724


   --row number: 13398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150729 , [Content] ='09/05/18'
 WHERE id=198429725


   --row number: 13399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150729 , [Content] ='Engineering'
 WHERE id=198429711


   --row number: 13400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150729 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=198429712


   --row number: 13401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150729 , [Content] ='Software'
 WHERE id=198429713


   --row number: 13402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150729 , [Content] ='IC3'
 WHERE id=198429714


   --row number: 13403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150729 , [Content] ='INR'
 WHERE id=198429716


   --row number: 13404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150729 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=198429717


   --row number: 13405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150729 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=198429718


   --row number: 13406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3150729 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=198429719


   --row number: 13407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3150742 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=198430559


   --row number: 13408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150742 , [Content] ='15%'
 WHERE id=198430560


   --row number: 13409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150742 , [Content] ='Yes'
 WHERE id=198430561


   --row number: 13410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150742 , [Content] ='2 - Professionals'
 WHERE id=198430562


   --row number: 13411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3150742 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198430563


   --row number: 13412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3150742 , [Content] ='Technical'
 WHERE id=198430564


   --row number: 13413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3150742 , [Content] ='09/05/18'
 WHERE id=198430565


   --row number: 13414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3150729 , [Content] ='15%'
 WHERE id=198429720


   --row number: 13415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3150729 , [Content] ='Yes'
 WHERE id=198429721


   --row number: 13416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3150729 , [Content] ='2 - Professionals'
 WHERE id=198429722


   --row number: 13417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3150742 , [Content] ='5143 IND'
 WHERE id=198430547


   --row number: 13418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3150742 , [Content] ='IND'
 WHERE id=198430548


   --row number: 13419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3150742 , [Content] ='APAC'
 WHERE id=198430549


   --row number: 13420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3150742 , [Content] ='INDIA'
 WHERE id=198430550


   --row number: 13421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3150742 , [Content] ='Engineering'
 WHERE id=198430551


   --row number: 13422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3150742 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=198430552


   --row number: 13423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3150742 , [Content] ='Software'
 WHERE id=198430553


   --row number: 13424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3150742 , [Content] ='IC3'
 WHERE id=198430554


   --row number: 13425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3150742 , [Content] ='INR'
 WHERE id=198430556


   --row number: 13426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3150742 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=198430557


   --row number: 13427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3150742 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=198430558


   --row number: 13428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151250 , [Content] ='Yes'
 WHERE id=198479283


   --row number: 13429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151250 , [Content] ='EXEMPT'
 WHERE id=198479284


   --row number: 13430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151250 , [Content] ='NO'
 WHERE id=198479285


   --row number: 13431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151250 , [Content] ='2 - Professionals'
 WHERE id=198479286


   --row number: 13432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151250 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198479287


   --row number: 13433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151250 , [Content] ='Technical'
 WHERE id=198479288


   --row number: 13434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151250 , [Content] ='09/05/18'
 WHERE id=198479289


   --row number: 13435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151250 , [Content] ='5774 US - MRKT 1'
 WHERE id=198479269


   --row number: 13436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151250 , [Content] ='US - MRKT 1'
 WHERE id=198479270


   --row number: 13437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151250 , [Content] ='AMS'
 WHERE id=198479271


   --row number: 13438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151250 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198479272


   --row number: 13439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151250 , [Content] ='Professional Services'
 WHERE id=198479273


   --row number: 13440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151250 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=198479274


   --row number: 13441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151250 , [Content] ='Business Process Consulting'
 WHERE id=198479275


   --row number: 13442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151250 , [Content] ='IC4'
 WHERE id=198479276


   --row number: 13443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151250 , [Content] ='USD'
 WHERE id=198479278


   --row number: 13444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151250 , [Content] ='94,600 / 111,650 / 128,700 / 145,700 / 162,700'
 WHERE id=198479279


   --row number: 13445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151250 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=198479280


   --row number: 13446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151250 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=198479281


   --row number: 13447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151250 , [Content] ='15%'
 WHERE id=198479282


   --row number: 13448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151257 , [Content] ='NO'
 WHERE id=198479848


   --row number: 13449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151257 , [Content] ='2 - Professionals'
 WHERE id=198479849


   --row number: 13450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151257 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198479850


   --row number: 13451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151257 , [Content] ='Technical'
 WHERE id=198479851


   --row number: 13452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151257 , [Content] ='09/05/18'
 WHERE id=198479852


   --row number: 13453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151257 , [Content] ='5774 US - MRKT 1'
 WHERE id=198479832


   --row number: 13454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151257 , [Content] ='US - MRKT 1'
 WHERE id=198479833


   --row number: 13455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151257 , [Content] ='AMS'
 WHERE id=198479834


   --row number: 13456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151257 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198479835


   --row number: 13457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151257 , [Content] ='Professional Services'
 WHERE id=198479836


   --row number: 13458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151257 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=198479837


   --row number: 13459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151257 , [Content] ='Business Process Consulting'
 WHERE id=198479838


   --row number: 13460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151257 , [Content] ='IC4'
 WHERE id=198479839


   --row number: 13461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151257 , [Content] ='USD'
 WHERE id=198479841


   --row number: 13462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151257 , [Content] ='94,600 / 111,650 / 128,700 / 145,700 / 162,700'
 WHERE id=198479842


   --row number: 13463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151257 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=198479843


   --row number: 13464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151257 , [Content] ='Yes'
 WHERE id=198479846


   --row number: 13465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151257 , [Content] ='EXEMPT'
 WHERE id=198479847


   --row number: 13466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151257 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=198479844


   --row number: 13467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151257 , [Content] ='15%'
 WHERE id=198479845


   --row number: 13468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151281 , [Content] ='NO'
 WHERE id=198480959


   --row number: 13469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151281 , [Content] ='2 - Professionals'
 WHERE id=198480960


   --row number: 13470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151281 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198480961


   --row number: 13471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151281 , [Content] ='Technical'
 WHERE id=198480962


   --row number: 13472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151281 , [Content] ='09/05/18'
 WHERE id=198480963


   --row number: 13473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151281 , [Content] ='5764 US - MRKT 1'
 WHERE id=198480943


   --row number: 13474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151281 , [Content] ='US - MRKT 1'
 WHERE id=198480944


   --row number: 13475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151281 , [Content] ='AMS'
 WHERE id=198480945


   --row number: 13476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151281 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198480946


   --row number: 13477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151281 , [Content] ='Professional Services'
 WHERE id=198480947


   --row number: 13478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151281 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=198480948


   --row number: 13479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151281 , [Content] ='Technology Consultant'
 WHERE id=198480949


   --row number: 13480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151281 , [Content] ='IC4'
 WHERE id=198480950


   --row number: 13481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151281 , [Content] ='USD'
 WHERE id=198480952


   --row number: 13482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151281 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=198480953


   --row number: 13483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151281 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198480954


   --row number: 13484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151281 , [Content] ='120,000 / 145,150 / 170,300 / 195,450 / 220,600'
 WHERE id=198480955


   --row number: 13485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151281 , [Content] ='20%'
 WHERE id=198480956


   --row number: 13486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151281 , [Content] ='Yes'
 WHERE id=198480957


   --row number: 13487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151281 , [Content] ='EXEMPT'
 WHERE id=198480958


   --row number: 13488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151283 , [Content] ='NO'
 WHERE id=198481119


   --row number: 13489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151283 , [Content] ='2 - Professionals'
 WHERE id=198481120


   --row number: 13490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151283 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198481121


   --row number: 13491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151283 , [Content] ='Technical'
 WHERE id=198481122


   --row number: 13492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151283 , [Content] ='09/05/18'
 WHERE id=198481123


   --row number: 13493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151283 , [Content] ='5764 US - MRKT 1'
 WHERE id=198481103


   --row number: 13494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151283 , [Content] ='US - MRKT 1'
 WHERE id=198481104


   --row number: 13495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151283 , [Content] ='AMS'
 WHERE id=198481105


   --row number: 13496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151283 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198481106


   --row number: 13497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151283 , [Content] ='Professional Services'
 WHERE id=198481107


   --row number: 13498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151283 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=198481108


   --row number: 13499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151283 , [Content] ='Technology Consultant'
 WHERE id=198481109


   --row number: 13500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151283 , [Content] ='IC4'
 WHERE id=198481110


   --row number: 13501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151283 , [Content] ='USD'
 WHERE id=198481112


   --row number: 13502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151283 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=198481113


   --row number: 13503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151283 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198481114


   --row number: 13504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151283 , [Content] ='120,000 / 145,150 / 170,300 / 195,450 / 220,600'
 WHERE id=198481115


   --row number: 13505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151283 , [Content] ='20%'
 WHERE id=198481116


   --row number: 13506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151283 , [Content] ='Yes'
 WHERE id=198481117


   --row number: 13507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151283 , [Content] ='EXEMPT'
 WHERE id=198481118


   --row number: 13508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151309 , [Content] ='NO'
 WHERE id=198482385


   --row number: 13509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151309 , [Content] ='2 - Professionals'
 WHERE id=198482386


   --row number: 13510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151309 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198482387


   --row number: 13511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151309 , [Content] ='Technical'
 WHERE id=198482388


   --row number: 13512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151309 , [Content] ='09/05/18'
 WHERE id=198482389


   --row number: 13513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151309 , [Content] ='5774 US - MRKT 1'
 WHERE id=198482369


   --row number: 13514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151309 , [Content] ='US - MRKT 1'
 WHERE id=198482370


   --row number: 13515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151309 , [Content] ='AMS'
 WHERE id=198482371


   --row number: 13516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151309 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198482372


   --row number: 13517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151309 , [Content] ='Professional Services'
 WHERE id=198482373


   --row number: 13518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151309 , [Content] ='5774 - Business Process Consultant IC4'
 WHERE id=198482374


   --row number: 13519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151309 , [Content] ='Business Process Consulting'
 WHERE id=198482375


   --row number: 13520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151309 , [Content] ='IC4'
 WHERE id=198482376


   --row number: 13521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151309 , [Content] ='USD'
 WHERE id=198482378


   --row number: 13522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151309 , [Content] ='94,600 / 111,650 / 128,700 / 145,700 / 162,700'
 WHERE id=198482379


   --row number: 13523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151309 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=198482380


   --row number: 13524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151309 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=198482381


   --row number: 13525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151309 , [Content] ='15%'
 WHERE id=198482382


   --row number: 13526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151309 , [Content] ='Yes'
 WHERE id=198482383


   --row number: 13527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151309 , [Content] ='EXEMPT'
 WHERE id=198482384


   --row number: 13528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151312 , [Content] ='NO'
 WHERE id=198482503


   --row number: 13529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151312 , [Content] ='2 - Professionals'
 WHERE id=198482504


   --row number: 13530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151312 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198482505


   --row number: 13531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151312 , [Content] ='Technical'
 WHERE id=198482506


   --row number: 13532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151312 , [Content] ='09/05/18'
 WHERE id=198482507


   --row number: 13533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151312 , [Content] ='5764 US - MRKT 1'
 WHERE id=198482487


   --row number: 13534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151312 , [Content] ='US - MRKT 1'
 WHERE id=198482488


   --row number: 13535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151312 , [Content] ='AMS'
 WHERE id=198482489


   --row number: 13536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151312 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198482490


   --row number: 13537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151312 , [Content] ='Professional Services'
 WHERE id=198482491


   --row number: 13538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151312 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=198482492


   --row number: 13539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151312 , [Content] ='Technology Consultant'
 WHERE id=198482493


   --row number: 13540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151312 , [Content] ='IC4'
 WHERE id=198482494


   --row number: 13541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151312 , [Content] ='USD'
 WHERE id=198482496


   --row number: 13542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151312 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=198482497


   --row number: 13543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151312 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198482498


   --row number: 13544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151312 , [Content] ='120,000 / 145,150 / 170,300 / 195,450 / 220,600'
 WHERE id=198482499


   --row number: 13545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151312 , [Content] ='20%'
 WHERE id=198482500


   --row number: 13546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151312 , [Content] ='Yes'
 WHERE id=198482501


   --row number: 13547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151312 , [Content] ='EXEMPT'
 WHERE id=198482502


   --row number: 13548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151319 , [Content] ='EXEMPT'
 WHERE id=198483070


   --row number: 13549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151319 , [Content] ='2 - Professionals'
 WHERE id=198483072


   --row number: 13550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151319 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198483073


   --row number: 13551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151319 , [Content] ='Technical'
 WHERE id=198483074


   --row number: 13552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151319 , [Content] ='09/05/18'
 WHERE id=198483075


   --row number: 13553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151319 , [Content] ='NO'
 WHERE id=198483071


   --row number: 13554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151319 , [Content] ='5764 US - MRKT 1'
 WHERE id=198483055


   --row number: 13555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151319 , [Content] ='US - MRKT 1'
 WHERE id=198483056


   --row number: 13556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151319 , [Content] ='AMS'
 WHERE id=198483057


   --row number: 13557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151319 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198483058


   --row number: 13558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151319 , [Content] ='Professional Services'
 WHERE id=198483059


   --row number: 13559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151319 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=198483060


   --row number: 13560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151319 , [Content] ='Technology Consultant'
 WHERE id=198483061


   --row number: 13561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151319 , [Content] ='IC4'
 WHERE id=198483062


   --row number: 13562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151319 , [Content] ='USD'
 WHERE id=198483064


   --row number: 13563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151319 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=198483065


   --row number: 13564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151319 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198483066


   --row number: 13565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151319 , [Content] ='120,000 / 145,150 / 170,300 / 195,450 / 220,600'
 WHERE id=198483067


   --row number: 13566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151319 , [Content] ='20%'
 WHERE id=198483068


   --row number: 13567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151319 , [Content] ='Yes'
 WHERE id=198483069


   --row number: 13568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151323 , [Content] ='EXEMPT'
 WHERE id=198483359


   --row number: 13569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151323 , [Content] ='NO'
 WHERE id=198483360


   --row number: 13570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151323 , [Content] ='2 - Professionals'
 WHERE id=198483361


   --row number: 13571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151323 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198483362


   --row number: 13572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151323 , [Content] ='Technical'
 WHERE id=198483363


   --row number: 13573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151323 , [Content] ='09/05/18'
 WHERE id=198483364


   --row number: 13574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151323 , [Content] ='5764 US - MRKT 1'
 WHERE id=198483344


   --row number: 13575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151323 , [Content] ='US - MRKT 1'
 WHERE id=198483345


   --row number: 13576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151323 , [Content] ='AMS'
 WHERE id=198483346


   --row number: 13577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151323 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198483347


   --row number: 13578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151323 , [Content] ='Professional Services'
 WHERE id=198483348


   --row number: 13579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151323 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=198483349


   --row number: 13580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151323 , [Content] ='Technology Consultant'
 WHERE id=198483350


   --row number: 13581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151323 , [Content] ='IC4'
 WHERE id=198483351


   --row number: 13582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151323 , [Content] ='USD'
 WHERE id=198483353


   --row number: 13583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151323 , [Content] ='100,000 / 120,950 / 141,900 / 162,850 / 183,800'
 WHERE id=198483354


   --row number: 13584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151323 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198483355


   --row number: 13585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151323 , [Content] ='120,000 / 145,150 / 170,300 / 195,450 / 220,600'
 WHERE id=198483356


   --row number: 13586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3151323 , [Content] ='20%'
 WHERE id=198483357


   --row number: 13587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151323 , [Content] ='Yes'
 WHERE id=198483358


   --row number: 13588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3123368 , [Content] ='84,400 / 98,300 / 112,200 / 126,100 / 140,000'
 WHERE id=198497767


   --row number: 13589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151860 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=198523668


   --row number: 13590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151860 , [Content] ='EXEMPT'
 WHERE id=198523673


   --row number: 13591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151860 , [Content] ='NO'
 WHERE id=198523674


   --row number: 13592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151860 , [Content] ='4 - Sales Workers'
 WHERE id=198523675


   --row number: 13593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151860 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198523676


   --row number: 13594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151860 , [Content] ='Technical'
 WHERE id=198523677


   --row number: 13595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151860 , [Content] ='09/05/18'
 WHERE id=198523678


   --row number: 13596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151860 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=198523669


   --row number: 13597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151860 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=198523670


   --row number: 13598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3151860 , [Content] ='50/50'
 WHERE id=198523671


   --row number: 13599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151860 , [Content] ='Yes'
 WHERE id=198523672


   --row number: 13600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151860 , [Content] ='S635 US - MRKT 2'
 WHERE id=198523658


   --row number: 13601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151860 , [Content] ='US - MRKT 2'
 WHERE id=198523659


   --row number: 13602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151860 , [Content] ='AMS'
 WHERE id=198523660


   --row number: 13603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151860 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198523661


   --row number: 13604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151860 , [Content] ='Sales'
 WHERE id=198523662


   --row number: 13605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151860 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=198523663


   --row number: 13606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151860 , [Content] ='Enterprise Accounts'
 WHERE id=198523664


   --row number: 13607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151860 , [Content] ='IC5'
 WHERE id=198523665


   --row number: 13608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151860 , [Content] ='USD'
 WHERE id=198523667


   --row number: 13609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151872 , [Content] ='S1414 US - MRKT 2'
 WHERE id=198525082


   --row number: 13610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151872 , [Content] ='US - MRKT 2'
 WHERE id=198525083


   --row number: 13611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151872 , [Content] ='AMS'
 WHERE id=198525084


   --row number: 13612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151872 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198525085


   --row number: 13613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151872 , [Content] ='Solution Consulting'
 WHERE id=198525086


   --row number: 13614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151872 , [Content] ='S1414 - Advisory Solution Consultant IC4'
 WHERE id=198525087


   --row number: 13615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151872 , [Content] ='Solution Consultant Core'
 WHERE id=198525088


   --row number: 13616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3151872 , [Content] ='NO'
 WHERE id=198525098


   --row number: 13617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151872 , [Content] ='4 - Sales Workers'
 WHERE id=198525099


   --row number: 13618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151872 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198525100


   --row number: 13619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151872 , [Content] ='Technical'
 WHERE id=198525101


   --row number: 13620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151872 , [Content] ='09/05/18'
 WHERE id=198525102


   --row number: 13621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151872 , [Content] ='USD'
 WHERE id=198525091


   --row number: 13622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151872 , [Content] ='124,313 / 135,281 / 146,250 / 157,219 / 168,188'
 WHERE id=198525092


   --row number: 13623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151872 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=198525093


   --row number: 13624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151872 , [Content] ='165,750 / 180,375 / 195,000 / 209,625 / 224,250'
 WHERE id=198525094


   --row number: 13625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3151872 , [Content] ='75/25'
 WHERE id=198525095


   --row number: 13626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151872 , [Content] ='Yes'
 WHERE id=198525096


   --row number: 13627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151872 , [Content] ='EXEMPT'
 WHERE id=198525097


   --row number: 13628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151872 , [Content] ='IC4'
 WHERE id=198525089


   --row number: 13629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3151873 , [Content] ='4 - Sales Workers'
 WHERE id=198525421


   --row number: 13630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3151873 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198525422


   --row number: 13631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3151873 , [Content] ='Technical'
 WHERE id=198525423


   --row number: 13632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3151873 , [Content] ='09/05/18'
 WHERE id=198525424


   --row number: 13633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3151873 , [Content] ='S1413 US - MRKT 3'
 WHERE id=198525405


   --row number: 13634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3151873 , [Content] ='US - MRKT 3'
 WHERE id=198525406


   --row number: 13635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3151873 , [Content] ='AMS'
 WHERE id=198525407


   --row number: 13636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3151873 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198525408


   --row number: 13637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3151873 , [Content] ='Solution Consulting'
 WHERE id=198525409


   --row number: 13638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3151873 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=198525410


   --row number: 13639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3151873 , [Content] ='Solution Consultant Core'
 WHERE id=198525411


   --row number: 13640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3151873 , [Content] ='IC3'
 WHERE id=198525412


   --row number: 13641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3151873 , [Content] ='USD'
 WHERE id=198525414


   --row number: 13642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3151873 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=198525415


   --row number: 13643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3151873 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=198525416


   --row number: 13644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3151873 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=198525417


   --row number: 13645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3151873 , [Content] ='75/25'
 WHERE id=198525418


   --row number: 13646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3151873 , [Content] ='Yes'
 WHERE id=198525419


   --row number: 13647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3151873 , [Content] ='EXEMPT'
 WHERE id=198525420


   --row number: 13648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3152329 , [Content] ='62,300 / 71,150 / 80,000 / 88,900 / 97,800'
 WHERE id=198731556


   --row number: 13649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3152329 , [Content] ='EXEMPT'
 WHERE id=198731560


   --row number: 13650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3152329 , [Content] ='NO'
 WHERE id=198731561


   --row number: 13651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3152329 , [Content] ='2 - Professionals'
 WHERE id=198731562


   --row number: 13652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3152329 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198731563


   --row number: 13653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3152329 , [Content] ='Technical'
 WHERE id=198731564


   --row number: 13654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3152329 , [Content] ='09/05/18'
 WHERE id=198731565


   --row number: 13655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3152329 , [Content] ='39,640 / 52,820 / 66,000 / 79,180 / 92,360'
 WHERE id=198731557


   --row number: 13656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3152329 , [Content] ='10%'
 WHERE id=198731558


   --row number: 13657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3152329 , [Content] ='Yes'
 WHERE id=198731559


   --row number: 13658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3152329 , [Content] ='5141 US - MRKT 2'
 WHERE id=198731546


   --row number: 13659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3152329 , [Content] ='US - MRKT 2'
 WHERE id=198731547


   --row number: 13660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3152329 , [Content] ='AMS'
 WHERE id=198731548


   --row number: 13661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3152329 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198731549


   --row number: 13662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3152329 , [Content] ='Engineering'
 WHERE id=198731550


   --row number: 13663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3152329 , [Content] ='5141 - Assoc Software Engineer IC1'
 WHERE id=198731551


   --row number: 13664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3152329 , [Content] ='Software'
 WHERE id=198731552


   --row number: 13665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3152329 , [Content] ='IC1'
 WHERE id=198731553


   --row number: 13666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3152329 , [Content] ='USD'
 WHERE id=198731555


   --row number: 13667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153167 , [Content] ='EXEMPT'
 WHERE id=198814271


   --row number: 13668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153167 , [Content] ='2 - Professionals'
 WHERE id=198814273


   --row number: 13669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153167 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198814274


   --row number: 13670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153167 , [Content] ='Non Technical'
 WHERE id=198814275


   --row number: 13671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153167 , [Content] ='09/05/18'
 WHERE id=198814276


   --row number: 13672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153167 , [Content] ='NO'
 WHERE id=198814272


   --row number: 13673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153167 , [Content] ='6223 US - MRKT 1'
 WHERE id=198814256


   --row number: 13674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153167 , [Content] ='US - MRKT 1'
 WHERE id=198814257


   --row number: 13675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153167 , [Content] ='AMS'
 WHERE id=198814258


   --row number: 13676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153167 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198814259


   --row number: 13677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153167 , [Content] ='Human Resources'
 WHERE id=198814260


   --row number: 13678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153167 , [Content] ='6223 - Recruiter/Staffing Representative IC3'
 WHERE id=198814261


   --row number: 13679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153167 , [Content] ='Staffing'
 WHERE id=198814262


   --row number: 13680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153167 , [Content] ='IC3'
 WHERE id=198814263


   --row number: 13681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153167 , [Content] ='USD'
 WHERE id=198814265


   --row number: 13682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153167 , [Content] ='83,200 / 96,950 / 110,700 / 124,400 / 138,100'
 WHERE id=198814266


   --row number: 13683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153167 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=198814267


   --row number: 13684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153167 , [Content] ='91,500 / 106,650 / 121,800 / 136,850 / 151,900'
 WHERE id=198814268


   --row number: 13685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153167 , [Content] ='10%'
 WHERE id=198814269


   --row number: 13686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153167 , [Content] ='Yes'
 WHERE id=198814270


   --row number: 13687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153361 , [Content] ='Yes'
 WHERE id=198833683


   --row number: 13688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153361 , [Content] ='2 - Professionals'
 WHERE id=198833686


   --row number: 13689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153361 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198833687


   --row number: 13690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153361 , [Content] ='Technical'
 WHERE id=198833688


   --row number: 13691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153361 , [Content] ='09/05/18'
 WHERE id=198833689


   --row number: 13692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153361 , [Content] ='EXEMPT'
 WHERE id=198833684


   --row number: 13693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153361 , [Content] ='NO'
 WHERE id=198833685


   --row number: 13694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153361 , [Content] ='5144 US - MRKT 1'
 WHERE id=198833669


   --row number: 13695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153361 , [Content] ='US - MRKT 1'
 WHERE id=198833670


   --row number: 13696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153361 , [Content] ='AMS'
 WHERE id=198833671


   --row number: 13697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153361 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198833672


   --row number: 13698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153361 , [Content] ='Engineering'
 WHERE id=198833673


   --row number: 13699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153361 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=198833674


   --row number: 13700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153361 , [Content] ='Software'
 WHERE id=198833675


   --row number: 13701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153361 , [Content] ='IC4'
 WHERE id=198833676


   --row number: 13702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153361 , [Content] ='USD'
 WHERE id=198833678


   --row number: 13703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153361 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=198833679


   --row number: 13704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153361 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=198833680


   --row number: 13705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153361 , [Content] ='148,200 / 179,200 / 210,200 / 241,300 / 272,400'
 WHERE id=198833681


   --row number: 13706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153361 , [Content] ='20%'
 WHERE id=198833682


   --row number: 13707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3152329 , [Content] ='68,500 / 78,250 / 88,000 / 97,800 / 107,600'
 WHERE id=198842779


   --row number: 13708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153820 , [Content] ='USD'
 WHERE id=198879302


   --row number: 13709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153820 , [Content] ='94,300 / 109,850 / 125,400 / 140,950 / 156,500'
 WHERE id=198879306


   --row number: 13710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153820 , [Content] ='10%'
 WHERE id=198879307


   --row number: 13711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153820 , [Content] ='Yes'
 WHERE id=198879310


   --row number: 13712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153820 , [Content] ='EXEMPT'
 WHERE id=198879311


   --row number: 13713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153820 , [Content] ='NO'
 WHERE id=198879313


   --row number: 13714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153820 , [Content] ='2 - Professionals'
 WHERE id=198879315


   --row number: 13715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153820 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198879316


   --row number: 13716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153820 , [Content] ='Technical'
 WHERE id=198879317


   --row number: 13717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153820 , [Content] ='09/05/18'
 WHERE id=198879318


   --row number: 13718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153820 , [Content] ='85,700 / 99,850 / 114,000 / 128,150 / 142,300'
 WHERE id=198879303


   --row number: 13719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153820 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=198879305


   --row number: 13720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153820 , [Content] ='6802 US - MRKT 1'
 WHERE id=198879293


   --row number: 13721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153820 , [Content] ='US - MRKT 1'
 WHERE id=198879294


   --row number: 13722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153820 , [Content] ='AMS'
 WHERE id=198879295


   --row number: 13723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153820 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198879296


   --row number: 13724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153820 , [Content] ='Info Systems/Technology'
 WHERE id=198879297


   --row number: 13725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153820 , [Content] ='6802 - UI/ UX Designer IC2'
 WHERE id=198879298


   --row number: 13726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153820 , [Content] ='UI/UX Designer'
 WHERE id=198879299


   --row number: 13727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153820 , [Content] ='IC2'
 WHERE id=198879300


   --row number: 13728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153824 , [Content] ='NO'
 WHERE id=198879879


   --row number: 13729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153824 , [Content] ='2 - Professionals'
 WHERE id=198879880


   --row number: 13730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153824 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198879881


   --row number: 13731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153824 , [Content] ='Technical'
 WHERE id=198879882


   --row number: 13732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153824 , [Content] ='10/05/18'
 WHERE id=198879883


   --row number: 13733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153824 , [Content] ='Yes'
 WHERE id=198879877


   --row number: 13734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153824 , [Content] ='EXEMPT'
 WHERE id=198879878


   --row number: 13735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153824 , [Content] ='5183 US - MRKT 1'
 WHERE id=198879863


   --row number: 13736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153824 , [Content] ='US - MRKT 1'
 WHERE id=198879864


   --row number: 13737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153824 , [Content] ='AMS'
 WHERE id=198879865


   --row number: 13738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153824 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198879866


   --row number: 13739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153824 , [Content] ='Engineering'
 WHERE id=198879867


   --row number: 13740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153824 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=198879868


   --row number: 13741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153824 , [Content] ='Quality'
 WHERE id=198879869


   --row number: 13742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153824 , [Content] ='IC3'
 WHERE id=198879870


   --row number: 13743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153824 , [Content] ='USD'
 WHERE id=198879872


   --row number: 13744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153824 , [Content] ='95,500 / 112,700 / 129,900 / 147,100 / 164,300'
 WHERE id=198879873


   --row number: 13745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153824 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=198879874


   --row number: 13746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153824 , [Content] ='109,800 / 129,600 / 149,400 / 169,150 / 188,900'
 WHERE id=198879875


   --row number: 13747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153824 , [Content] ='15%'
 WHERE id=198879876


   --row number: 13748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153844 , [Content] ='2 - Professionals'
 WHERE id=198882446


   --row number: 13749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153844 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198882447


   --row number: 13750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153844 , [Content] ='Technical'
 WHERE id=198882448


   --row number: 13751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153844 , [Content] ='09/05/18'
 WHERE id=198882449


   --row number: 13752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153844 , [Content] ='6804 US - MRKT 1'
 WHERE id=198882429


   --row number: 13753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153844 , [Content] ='US - MRKT 1'
 WHERE id=198882430


   --row number: 13754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153844 , [Content] ='AMS'
 WHERE id=198882431


   --row number: 13755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153844 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198882432


   --row number: 13756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153844 , [Content] ='Info Systems/Technology'
 WHERE id=198882433


   --row number: 13757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153844 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=198882434


   --row number: 13758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153844 , [Content] ='UI/UX Designer'
 WHERE id=198882435


   --row number: 13759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153844 , [Content] ='IC4'
 WHERE id=198882436


   --row number: 13760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153844 , [Content] ='USD'
 WHERE id=198882438


   --row number: 13761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153844 , [Content] ='110,800 / 134,000 / 157,200 / 180,450 / 203,700'
 WHERE id=198882439


   --row number: 13762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153844 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198882440


   --row number: 13763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153844 , [Content] ='133,000 / 160,800 / 188,600 / 216,500 / 244,400'
 WHERE id=198882441


   --row number: 13764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153844 , [Content] ='20%'
 WHERE id=198882442


   --row number: 13765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153844 , [Content] ='Yes'
 WHERE id=198882443


   --row number: 13766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153844 , [Content] ='EXEMPT'
 WHERE id=198882444


   --row number: 13767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153844 , [Content] ='NO'
 WHERE id=198882445


   --row number: 13768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153854 , [Content] ='NO'
 WHERE id=198883537


   --row number: 13769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153854 , [Content] ='2 - Professionals'
 WHERE id=198883538


   --row number: 13770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153854 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198883539


   --row number: 13771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153854 , [Content] ='Technical'
 WHERE id=198883540


   --row number: 13772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153854 , [Content] ='09/05/18'
 WHERE id=198883541


   --row number: 13773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153854 , [Content] ='5143 US - MRKT 1'
 WHERE id=198883521


   --row number: 13774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153854 , [Content] ='US - MRKT 1'
 WHERE id=198883522


   --row number: 13775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153854 , [Content] ='AMS'
 WHERE id=198883523


   --row number: 13776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153854 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198883524


   --row number: 13777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153854 , [Content] ='Engineering'
 WHERE id=198883525


   --row number: 13778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153854 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=198883526


   --row number: 13779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153854 , [Content] ='Software'
 WHERE id=198883527


   --row number: 13780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153854 , [Content] ='IC3'
 WHERE id=198883528


   --row number: 13781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153854 , [Content] ='USD'
 WHERE id=198883530


   --row number: 13782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153854 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=198883531


   --row number: 13783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153854 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=198883532


   --row number: 13784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153854 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=198883533


   --row number: 13785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153854 , [Content] ='15%'
 WHERE id=198883534


   --row number: 13786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153854 , [Content] ='Yes'
 WHERE id=198883535


   --row number: 13787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153854 , [Content] ='EXEMPT'
 WHERE id=198883536


   --row number: 13788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3153856 , [Content] ='EXEMPT'
 WHERE id=198883750


   --row number: 13789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3153856 , [Content] ='NO'
 WHERE id=198883751


   --row number: 13790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3153856 , [Content] ='2 - Professionals'
 WHERE id=198883752


   --row number: 13791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3153856 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198883753


   --row number: 13792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3153856 , [Content] ='Technical'
 WHERE id=198883754


   --row number: 13793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3153856 , [Content] ='09/05/18'
 WHERE id=198883755


   --row number: 13794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3153856 , [Content] ='5143 US - MRKT 1'
 WHERE id=198883735


   --row number: 13795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3153856 , [Content] ='US - MRKT 1'
 WHERE id=198883736


   --row number: 13796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3153856 , [Content] ='AMS'
 WHERE id=198883737


   --row number: 13797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3153856 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198883738


   --row number: 13798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3153856 , [Content] ='Engineering'
 WHERE id=198883739


   --row number: 13799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3153856 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=198883740


   --row number: 13800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3153856 , [Content] ='Software'
 WHERE id=198883741


   --row number: 13801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3153856 , [Content] ='IC3'
 WHERE id=198883742


   --row number: 13802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3153856 , [Content] ='USD'
 WHERE id=198883744


   --row number: 13803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3153856 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=198883745


   --row number: 13804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3153856 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=198883746


   --row number: 13805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3153856 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=198883747


   --row number: 13806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3153856 , [Content] ='15%'
 WHERE id=198883748


   --row number: 13807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3153856 , [Content] ='Yes'
 WHERE id=198883749


   --row number: 13808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154020 , [Content] ='EXEMPT'
 WHERE id=198903829


   --row number: 13809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154020 , [Content] ='NO'
 WHERE id=198903830


   --row number: 13810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154020 , [Content] ='2 - Professionals'
 WHERE id=198903831


   --row number: 13811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154020 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198903832


   --row number: 13812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154020 , [Content] ='Technical'
 WHERE id=198903833


   --row number: 13813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154020 , [Content] ='09/05/18'
 WHERE id=198903834


   --row number: 13814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154020 , [Content] ='4685 US - MRKT 1'
 WHERE id=198903814


   --row number: 13815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154020 , [Content] ='US - MRKT 1'
 WHERE id=198903815


   --row number: 13816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154020 , [Content] ='AMS'
 WHERE id=198903816


   --row number: 13817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154020 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198903817


   --row number: 13818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154020 , [Content] ='Business Strategy'
 WHERE id=198903818


   --row number: 13819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154020 , [Content] ='4685 - Business Process Analyst IC5'
 WHERE id=198903819


   --row number: 13820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154020 , [Content] ='Business Process'
 WHERE id=198903820


   --row number: 13821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154020 , [Content] ='IC5'
 WHERE id=198903821


   --row number: 13822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154020 , [Content] ='USD'
 WHERE id=198903823


   --row number: 13823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154020 , [Content] ='121,900 / 147,450 / 173,000 / 198,550 / 224,100'
 WHERE id=198903824


   --row number: 13824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154020 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198903825


   --row number: 13825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154020 , [Content] ='146,300 / 176,950 / 207,600 / 238,250 / 268,900'
 WHERE id=198903826


   --row number: 13826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154020 , [Content] ='20%'
 WHERE id=198903827


   --row number: 13827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154020 , [Content] ='Yes'
 WHERE id=198903828


   --row number: 13828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154024 , [Content] ='NO'
 WHERE id=198904689


   --row number: 13829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154024 , [Content] ='2 - Professionals'
 WHERE id=198904690


   --row number: 13830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154024 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198904691


   --row number: 13831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154024 , [Content] ='Technical'
 WHERE id=198904692


   --row number: 13832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154024 , [Content] ='09/05/18'
 WHERE id=198904693


   --row number: 13833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154024 , [Content] ='4685 US - MRKT 1'
 WHERE id=198904673


   --row number: 13834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154024 , [Content] ='US - MRKT 1'
 WHERE id=198904674


   --row number: 13835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154024 , [Content] ='AMS'
 WHERE id=198904675


   --row number: 13836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154024 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198904676


   --row number: 13837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154024 , [Content] ='Business Strategy'
 WHERE id=198904677


   --row number: 13838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154024 , [Content] ='4685 - Business Process Analyst IC5'
 WHERE id=198904678


   --row number: 13839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154024 , [Content] ='Business Process'
 WHERE id=198904679


   --row number: 13840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154024 , [Content] ='IC5'
 WHERE id=198904680


   --row number: 13841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154024 , [Content] ='USD'
 WHERE id=198904682


   --row number: 13842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154024 , [Content] ='121,900 / 147,450 / 173,000 / 198,550 / 224,100'
 WHERE id=198904683


   --row number: 13843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154024 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198904684


   --row number: 13844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154024 , [Content] ='146,300 / 176,950 / 207,600 / 238,250 / 268,900'
 WHERE id=198904685


   --row number: 13845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154024 , [Content] ='20%'
 WHERE id=198904686


   --row number: 13846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154024 , [Content] ='Yes'
 WHERE id=198904687


   --row number: 13847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154024 , [Content] ='EXEMPT'
 WHERE id=198904688


   --row number: 13848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154031 , [Content] ='NO'
 WHERE id=198905933


   --row number: 13849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154031 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=198905934


   --row number: 13850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154031 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198905935


   --row number: 13851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154031 , [Content] ='Technical'
 WHERE id=198905936


   --row number: 13852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154031 , [Content] ='09/05/18'
 WHERE id=198905937


   --row number: 13853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154031 , [Content] ='2143 US - MRKT 2'
 WHERE id=198905917


   --row number: 13854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154031 , [Content] ='US - MRKT 2'
 WHERE id=198905918


   --row number: 13855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154031 , [Content] ='AMS'
 WHERE id=198905919


   --row number: 13856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154031 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198905920


   --row number: 13857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154031 , [Content] ='Engineering'
 WHERE id=198905921


   --row number: 13858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154031 , [Content] ='2143 - Mgr, Software Engrg Mgmt M3'
 WHERE id=198905922


   --row number: 13859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154031 , [Content] ='Software'
 WHERE id=198905923


   --row number: 13860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154031 , [Content] ='M3'
 WHERE id=198905924


   --row number: 13861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154031 , [Content] ='USD'
 WHERE id=198905926


   --row number: 13862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154031 , [Content] ='111,000 / 134,250 / 157,500 / 180,750 / 204,000'
 WHERE id=198905927


   --row number: 13863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154031 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=198905928


   --row number: 13864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154031 , [Content] ='133,200 / 161,100 / 189,000 / 216,900 / 244,800'
 WHERE id=198905929


   --row number: 13865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154031 , [Content] ='20%'
 WHERE id=198905930


   --row number: 13866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154031 , [Content] ='Yes'
 WHERE id=198905931


   --row number: 13867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154031 , [Content] ='EXEMPT'
 WHERE id=198905932


   --row number: 13868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154038 , [Content] ='EXEMPT'
 WHERE id=198906406


   --row number: 13869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154038 , [Content] ='NO'
 WHERE id=198906407


   --row number: 13870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154038 , [Content] ='2 - Professionals'
 WHERE id=198906408


   --row number: 13871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154038 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198906409


   --row number: 13872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154038 , [Content] ='Technical'
 WHERE id=198906410


   --row number: 13873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154038 , [Content] ='09/05/18'
 WHERE id=198906411


   --row number: 13874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154038 , [Content] ='5184 US - MRKT 2'
 WHERE id=198906391


   --row number: 13875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154038 , [Content] ='US - MRKT 2'
 WHERE id=198906392


   --row number: 13876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154038 , [Content] ='AMS'
 WHERE id=198906393


   --row number: 13877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154038 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198906394


   --row number: 13878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154038 , [Content] ='Engineering'
 WHERE id=198906395


   --row number: 13879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154038 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=198906396


   --row number: 13880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154038 , [Content] ='Quality'
 WHERE id=198906397


   --row number: 13881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154038 , [Content] ='IC4'
 WHERE id=198906398


   --row number: 13882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154038 , [Content] ='USD'
 WHERE id=198906400


   --row number: 13883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154038 , [Content] ='91,600 / 110,800 / 130,000 / 149,200 / 168,400'
 WHERE id=198906401


   --row number: 13884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154038 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198906402


   --row number: 13885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154038 , [Content] ='109,900 / 132,950 / 156,000 / 179,050 / 202,100'
 WHERE id=198906403


   --row number: 13886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154038 , [Content] ='20%'
 WHERE id=198906404


   --row number: 13887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154038 , [Content] ='Yes'
 WHERE id=198906405


   --row number: 13888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154042 , [Content] ='EXEMPT'
 WHERE id=198907395


   --row number: 13889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154042 , [Content] ='NO'
 WHERE id=198907396


   --row number: 13890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154042 , [Content] ='2 - Professionals'
 WHERE id=198907397


   --row number: 13891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154042 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198907398


   --row number: 13892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154042 , [Content] ='Technical'
 WHERE id=198907399


   --row number: 13893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154042 , [Content] ='09/05/18'
 WHERE id=198907400


   --row number: 13894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154042 , [Content] ='5144 US - MRKT 1'
 WHERE id=198907380


   --row number: 13895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154042 , [Content] ='US - MRKT 1'
 WHERE id=198907381


   --row number: 13896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154042 , [Content] ='AMS'
 WHERE id=198907382


   --row number: 13897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154042 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198907383


   --row number: 13898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154042 , [Content] ='Engineering'
 WHERE id=198907384


   --row number: 13899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154042 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=198907385


   --row number: 13900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154042 , [Content] ='Software'
 WHERE id=198907386


   --row number: 13901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154042 , [Content] ='IC4'
 WHERE id=198907387


   --row number: 13902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154042 , [Content] ='USD'
 WHERE id=198907389


   --row number: 13903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154042 , [Content] ='123,500 / 149,350 / 175,200 / 201,100 / 227,000'
 WHERE id=198907390


   --row number: 13904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154042 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=198907391


   --row number: 13905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154042 , [Content] ='148,200 / 179,200 / 210,200 / 241,300 / 272,400'
 WHERE id=198907392


   --row number: 13906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154042 , [Content] ='20%'
 WHERE id=198907393


   --row number: 13907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154042 , [Content] ='Yes'
 WHERE id=198907394


   --row number: 13908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154135 , [Content] ='NO'
 WHERE id=198924125


   --row number: 13909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154135 , [Content] ='4 - Sales Workers'
 WHERE id=198924126


   --row number: 13910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154135 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198924127


   --row number: 13911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154135 , [Content] ='Technical'
 WHERE id=198924128


   --row number: 13912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154135 , [Content] ='09/05/18'
 WHERE id=198924129


   --row number: 13913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154135 , [Content] ='S635 US - MRKT 1'
 WHERE id=198924109


   --row number: 13914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154135 , [Content] ='US - MRKT 1'
 WHERE id=198924110


   --row number: 13915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154135 , [Content] ='AMS'
 WHERE id=198924111


   --row number: 13916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154135 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198924112


   --row number: 13917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154135 , [Content] ='Sales'
 WHERE id=198924113


   --row number: 13918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154135 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=198924114


   --row number: 13919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154135 , [Content] ='Enterprise Accounts'
 WHERE id=198924115


   --row number: 13920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154135 , [Content] ='IC5'
 WHERE id=198924116


   --row number: 13921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154135 , [Content] ='USD'
 WHERE id=198924118


   --row number: 13922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154135 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=198924119


   --row number: 13923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154135 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=198924120


   --row number: 13924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154135 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=198924121


   --row number: 13925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3154135 , [Content] ='50/50'
 WHERE id=198924122


   --row number: 13926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154135 , [Content] ='Yes'
 WHERE id=198924123


   --row number: 13927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154135 , [Content] ='EXEMPT'
 WHERE id=198924124


   --row number: 13928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154140 , [Content] ='NO'
 WHERE id=198924726


   --row number: 13929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154140 , [Content] ='4 - Sales Workers'
 WHERE id=198924727


   --row number: 13930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154140 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198924728


   --row number: 13931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154140 , [Content] ='Technical'
 WHERE id=198924729


   --row number: 13932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154140 , [Content] ='09/05/18'
 WHERE id=198924730


   --row number: 13933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154140 , [Content] ='S635 US - MRKT 1'
 WHERE id=198924710


   --row number: 13934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154140 , [Content] ='US - MRKT 1'
 WHERE id=198924711


   --row number: 13935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154140 , [Content] ='AMS'
 WHERE id=198924712


   --row number: 13936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154140 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198924713


   --row number: 13937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154140 , [Content] ='Sales'
 WHERE id=198924714


   --row number: 13938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154140 , [Content] ='S635 - Enterprise Account Exec IC5'
 WHERE id=198924715


   --row number: 13939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154140 , [Content] ='Enterprise Accounts'
 WHERE id=198924716


   --row number: 13940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154140 , [Content] ='IC5'
 WHERE id=198924717


   --row number: 13941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154140 , [Content] ='USD'
 WHERE id=198924719


   --row number: 13942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154140 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=198924720


   --row number: 13943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154140 , [Content] ='109,800 / 150,900 / 192,000 / 233,400 / 274,800'
 WHERE id=198924721


   --row number: 13944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154140 , [Content] ='255,000 / 277,500 / 300,000 / 322,500 / 345,000'
 WHERE id=198924722


   --row number: 13945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3154140 , [Content] ='50/50'
 WHERE id=198924723


   --row number: 13946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154140 , [Content] ='Yes'
 WHERE id=198924724


   --row number: 13947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154140 , [Content] ='EXEMPT'
 WHERE id=198924725


   --row number: 13948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154154 , [Content] ='NO'
 WHERE id=198925862


   --row number: 13949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154154 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=198925863


   --row number: 13950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154154 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198925864


   --row number: 13951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154154 , [Content] ='Technical'
 WHERE id=198925865


   --row number: 13952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154154 , [Content] ='09/05/18'
 WHERE id=198925866


   --row number: 13953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154154 , [Content] ='S1801 US - MRKT 2'
 WHERE id=198925846


   --row number: 13954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154154 , [Content] ='US - MRKT 2'
 WHERE id=198925847


   --row number: 13955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154154 , [Content] ='AMS'
 WHERE id=198925848


   --row number: 13956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154154 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198925849


   --row number: 13957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154154 , [Content] ='Sales Operations'
 WHERE id=198925850


   --row number: 13958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154154 , [Content] ='S1801 - Sup, Sales Operations Mgmt M1'
 WHERE id=198925851


   --row number: 13959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154154 , [Content] ='Sales Operations'
 WHERE id=198925852


   --row number: 13960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154154 , [Content] ='M1'
 WHERE id=198925853


   --row number: 13961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154154 , [Content] ='USD'
 WHERE id=198925855


   --row number: 13962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154154 , [Content] ='57,100 / 66,550 / 76,000 / 85,400 / 94,800'
 WHERE id=198925856


   --row number: 13963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154154 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=198925857


   --row number: 13964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154154 , [Content] ='62,800 / 73,200 / 83,600 / 93,950 / 104,300'
 WHERE id=198925858


   --row number: 13965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154154 , [Content] ='10%'
 WHERE id=198925859


   --row number: 13966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154154 , [Content] ='Yes'
 WHERE id=198925860


   --row number: 13967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154154 , [Content] ='EXEMPT'
 WHERE id=198925861


   --row number: 13968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154160 , [Content] ='Yes'
 WHERE id=198926933


   --row number: 13969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154160 , [Content] ='EXEMPT'
 WHERE id=198926934


   --row number: 13970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154160 , [Content] ='NO'
 WHERE id=198926935


   --row number: 13971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154160 , [Content] ='4 - Sales Workers'
 WHERE id=198926936


   --row number: 13972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154160 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198926937


   --row number: 13973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154160 , [Content] ='Technical'
 WHERE id=198926938


   --row number: 13974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154160 , [Content] ='10/05/18'
 WHERE id=198926939


   --row number: 13975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154160 , [Content] ='S1452 US - MRKT 2'
 WHERE id=198926919


   --row number: 13976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154160 , [Content] ='US - MRKT 2'
 WHERE id=198926920


   --row number: 13977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154160 , [Content] ='AMS'
 WHERE id=198926921


   --row number: 13978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154160 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198926922


   --row number: 13979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154160 , [Content] ='Solution Consulting'
 WHERE id=198926923


   --row number: 13980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154160 , [Content] ='S1452 - Solution Consultant Demo Center IC2'
 WHERE id=198926924


   --row number: 13981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154160 , [Content] ='Solution Consultant Demo Center'
 WHERE id=198926925


   --row number: 13982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154160 , [Content] ='IC2'
 WHERE id=198926926


   --row number: 13983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154160 , [Content] ='USD'
 WHERE id=198926928


   --row number: 13984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154160 , [Content] ='76,500 / 83,250 / 90,000 / 96,750 / 103,500'
 WHERE id=198926929


   --row number: 13985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154160 , [Content] ='45,000 / 53,700 / 62,400 / 71,400 / 80,400'
 WHERE id=198926930


   --row number: 13986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154160 , [Content] ='102,000 / 111,000 / 120,000 / 129,000 / 138,000'
 WHERE id=198926931


   --row number: 13987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3154160 , [Content] ='75/25'
 WHERE id=198926932


   --row number: 13988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154162 , [Content] ='5694 US - MRKT 2'
 WHERE id=198927184


   --row number: 13989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154162 , [Content] ='US - MRKT 2'
 WHERE id=198927185


   --row number: 13990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154162 , [Content] ='NO'
 WHERE id=198927200


   --row number: 13991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154162 , [Content] ='2 - Professionals'
 WHERE id=198927201


   --row number: 13992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154162 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198927202


   --row number: 13993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154162 , [Content] ='Technical'
 WHERE id=198927203


   --row number: 13994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154162 , [Content] ='09/05/18'
 WHERE id=198927204


   --row number: 13995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154162 , [Content] ='AMS'
 WHERE id=198927186


   --row number: 13996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154162 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198927187


   --row number: 13997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154162 , [Content] ='Customer Support'
 WHERE id=198927188


   --row number: 13998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154162 , [Content] ='5694 - Support Account Services Mgr IC4'
 WHERE id=198927189


   --row number: 13999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154162 , [Content] ='SAM Services'
 WHERE id=198927190


   --row number: 14000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154162 , [Content] ='IC4'
 WHERE id=198927191


   --row number: 14001

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154162 , [Content] ='USD'
 WHERE id=198927193


   --row number: 14002

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154162 , [Content] ='87,000 / 102,650 / 118,300 / 133,950 / 149,600'
 WHERE id=198927194


   --row number: 14003

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154162 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=198927195


   --row number: 14004

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154162 , [Content] ='100,100 / 118,050 / 136,000 / 154,000 / 172,000'
 WHERE id=198927196


   --row number: 14005

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154162 , [Content] ='15%'
 WHERE id=198927197


   --row number: 14006

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154162 , [Content] ='Yes'
 WHERE id=198927198


   --row number: 14007

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154162 , [Content] ='EXEMPT'
 WHERE id=198927199


   --row number: 14008

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154163 , [Content] ='2 - Professionals'
 WHERE id=198927337


   --row number: 14009

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154163 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198927338


   --row number: 14010

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154163 , [Content] ='Technical'
 WHERE id=198927339


   --row number: 14011

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154163 , [Content] ='09/05/18'
 WHERE id=198927340


   --row number: 14012

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154163 , [Content] ='S1833 US - MRKT 2'
 WHERE id=198927320


   --row number: 14013

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154163 , [Content] ='US - MRKT 2'
 WHERE id=198927321


   --row number: 14014

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154163 , [Content] ='AMS'
 WHERE id=198927322


   --row number: 14015

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154163 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198927323


   --row number: 14016

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154163 , [Content] ='Sales Operations'
 WHERE id=198927324


   --row number: 14017

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154163 , [Content] ='S1833 - Sales Operations Analyst IC3'
 WHERE id=198927325


   --row number: 14018

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154163 , [Content] ='Sales Operations'
 WHERE id=198927326


   --row number: 14019

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154163 , [Content] ='IC3'
 WHERE id=198927327


   --row number: 14020

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154163 , [Content] ='USD'
 WHERE id=198927329


   --row number: 14021

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154163 , [Content] ='60,200 / 70,100 / 80,000 / 89,950 / 99,900'
 WHERE id=198927330


   --row number: 14022

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154163 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=198927331


   --row number: 14023

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154163 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=198927332


   --row number: 14024

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154163 , [Content] ='10%'
 WHERE id=198927333


   --row number: 14025

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154163 , [Content] ='Yes'
 WHERE id=198927334


   --row number: 14026

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154163 , [Content] ='EXEMPT'
 WHERE id=198927335


   --row number: 14027

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154163 , [Content] ='NO'
 WHERE id=198927336


   --row number: 14028

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154168 , [Content] ='NO'
 WHERE id=198928800


   --row number: 14029

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154168 , [Content] ='2 - Professionals'
 WHERE id=198928801


   --row number: 14030

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154168 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198928802


   --row number: 14031

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154168 , [Content] ='Technical'
 WHERE id=198928803


   --row number: 14032

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154168 , [Content] ='09/05/18'
 WHERE id=198928804


   --row number: 14033

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154168 , [Content] ='S1833 US - MRKT 2'
 WHERE id=198928784


   --row number: 14034

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154168 , [Content] ='US - MRKT 2'
 WHERE id=198928785


   --row number: 14035

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154168 , [Content] ='AMS'
 WHERE id=198928786


   --row number: 14036

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154168 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198928787


   --row number: 14037

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154168 , [Content] ='Sales Operations'
 WHERE id=198928788


   --row number: 14038

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154168 , [Content] ='S1833 - Sales Operations Analyst IC3'
 WHERE id=198928789


   --row number: 14039

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154168 , [Content] ='Sales Operations'
 WHERE id=198928790


   --row number: 14040

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154168 , [Content] ='IC3'
 WHERE id=198928791


   --row number: 14041

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154168 , [Content] ='USD'
 WHERE id=198928793


   --row number: 14042

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154168 , [Content] ='60,200 / 70,100 / 80,000 / 89,950 / 99,900'
 WHERE id=198928794


   --row number: 14043

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154168 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=198928795


   --row number: 14044

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154168 , [Content] ='66,200 / 77,100 / 88,000 / 98,950 / 109,900'
 WHERE id=198928796


   --row number: 14045

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154168 , [Content] ='10%'
 WHERE id=198928797


   --row number: 14046

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154168 , [Content] ='Yes'
 WHERE id=198928798


   --row number: 14047

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154168 , [Content] ='EXEMPT'
 WHERE id=198928799


   --row number: 14048

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154171 , [Content] ='NON-EXEMPT'
 WHERE id=198929283


   --row number: 14049

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154171 , [Content] ='NO'
 WHERE id=198929284


   --row number: 14050

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154171 , [Content] ='2 - Professionals'
 WHERE id=198929285


   --row number: 14051

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154171 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198929286


   --row number: 14052

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154171 , [Content] ='Technical'
 WHERE id=198929287


   --row number: 14053

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154171 , [Content] ='09/05/18'
 WHERE id=198929288


   --row number: 14054

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154171 , [Content] ='5822 US - MRKT 1'
 WHERE id=198929268


   --row number: 14055

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154171 , [Content] ='US - MRKT 1'
 WHERE id=198929269


   --row number: 14056

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154171 , [Content] ='AMS'
 WHERE id=198929270


   --row number: 14057

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154171 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198929271


   --row number: 14058

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154171 , [Content] ='Customer Support'
 WHERE id=198929272


   --row number: 14059

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154171 , [Content] ='5822 - Tech Support Engineer IC2'
 WHERE id=198929273


   --row number: 14060

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154171 , [Content] ='Technical Support'
 WHERE id=198929274


   --row number: 14061

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154171 , [Content] ='IC2'
 WHERE id=198929275


   --row number: 14062

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154171 , [Content] ='USD'
 WHERE id=198929277


   --row number: 14063

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154171 , [Content] ='63,700 / 74,200 / 84,700 / 95,200 / 105,700'
 WHERE id=198929278


   --row number: 14064

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154171 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=198929279


   --row number: 14065

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154171 , [Content] ='70,100 / 81,650 / 93,200 / 104,750 / 116,300'
 WHERE id=198929280


   --row number: 14066

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154171 , [Content] ='10%'
 WHERE id=198929281


   --row number: 14067

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154171 , [Content] ='Yes'
 WHERE id=198929282


   --row number: 14068

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154187 , [Content] ='5764 US - MRKT 3'
 WHERE id=198931915


   --row number: 14069

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154187 , [Content] ='US - MRKT 3'
 WHERE id=198931916


   --row number: 14070

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154187 , [Content] ='AMS'
 WHERE id=198931917


   --row number: 14071

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154187 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198931918


   --row number: 14072

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154187 , [Content] ='Professional Services'
 WHERE id=198931919


   --row number: 14073

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154187 , [Content] ='5764 - Technology Consultant IC4'
 WHERE id=198931920


   --row number: 14074

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154187 , [Content] ='Technology Consultant'
 WHERE id=198931921


   --row number: 14075

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154187 , [Content] ='2 - Professionals'
 WHERE id=198931931


   --row number: 14076

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154187 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198931932


   --row number: 14077

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154187 , [Content] ='Technical'
 WHERE id=198931933


   --row number: 14078

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154187 , [Content] ='09/05/18'
 WHERE id=198931934


   --row number: 14079

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154187 , [Content] ='IC4'
 WHERE id=198931922


   --row number: 14080

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154187 , [Content] ='USD'
 WHERE id=198931924


   --row number: 14081

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154187 , [Content] ='88,100 / 106,550 / 125,000 / 143,450 / 161,900'
 WHERE id=198931925


   --row number: 14082

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154187 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198931926


   --row number: 14083

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154187 , [Content] ='105,700 / 127,850 / 150,000 / 172,150 / 194,300'
 WHERE id=198931927


   --row number: 14084

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154187 , [Content] ='20%'
 WHERE id=198931928


   --row number: 14085

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154187 , [Content] ='Yes'
 WHERE id=198931929


   --row number: 14086

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154187 , [Content] ='EXEMPT'
 WHERE id=198931930


   --row number: 14087

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154195 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198934698


   --row number: 14088

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154195 , [Content] ='Technical'
 WHERE id=198934699


   --row number: 14089

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154195 , [Content] ='09/05/18'
 WHERE id=198934700


   --row number: 14090

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154195 , [Content] ='5144 IND'
 WHERE id=198934682


   --row number: 14091

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154195 , [Content] ='IND'
 WHERE id=198934683


   --row number: 14092

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154195 , [Content] ='APAC'
 WHERE id=198934684


   --row number: 14093

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154195 , [Content] ='INDIA'
 WHERE id=198934685


   --row number: 14094

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154195 , [Content] ='Engineering'
 WHERE id=198934686


   --row number: 14095

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154195 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=198934687


   --row number: 14096

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154195 , [Content] ='Software'
 WHERE id=198934688


   --row number: 14097

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154195 , [Content] ='IC4'
 WHERE id=198934689


   --row number: 14098

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154195 , [Content] ='INR'
 WHERE id=198934691


   --row number: 14099

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154195 , [Content] ='2,344,800 / 2,872,400 / 3,400,000 / 3,927,550 / 4,455,100'
 WHERE id=198934692


   --row number: 14100

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154195 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=198934693


   --row number: 14101

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154195 , [Content] ='2,813,800 / 3,446,900 / 4,080,000 / 4,713,050 / 5,346,100'
 WHERE id=198934694


   --row number: 14102

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154195 , [Content] ='20%'
 WHERE id=198934695


   --row number: 14103

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154195 , [Content] ='Yes'
 WHERE id=198934696


   --row number: 14104

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154195 , [Content] ='2 - Professionals'
 WHERE id=198934697


   --row number: 14105

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154199 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198936648


   --row number: 14106

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154199 , [Content] ='Technical'
 WHERE id=198936649


   --row number: 14107

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154199 , [Content] ='09/05/18'
 WHERE id=198936650


   --row number: 14108

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154199 , [Content] ='5224 IND'
 WHERE id=198936632


   --row number: 14109

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154199 , [Content] ='IND'
 WHERE id=198936633


   --row number: 14110

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154199 , [Content] ='APAC'
 WHERE id=198936634


   --row number: 14111

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154199 , [Content] ='INDIA'
 WHERE id=198936635


   --row number: 14112

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154199 , [Content] ='Engineering'
 WHERE id=198936636


   --row number: 14113

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154199 , [Content] ='5224 - Staff Product Mgmt Mgr IC4'
 WHERE id=198936637


   --row number: 14114

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154199 , [Content] ='Product Mgmt Mgr'
 WHERE id=198936638


   --row number: 14115

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154199 , [Content] ='IC4'
 WHERE id=198936639


   --row number: 14116

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154199 , [Content] ='INR'
 WHERE id=198936641


   --row number: 14117

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154199 , [Content] ='2,310,300 / 2,830,150 / 3,350,000 / 3,869,800 / 4,389,600'
 WHERE id=198936642


   --row number: 14118

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154199 , [Content] ='84,000 / 117,000 / 150,000 / 183,600 / 217,200'
 WHERE id=198936643


   --row number: 14119

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154199 , [Content] ='2,772,400 / 3,396,200 / 4,020,000 / 4,643,750 / 5,267,500'
 WHERE id=198936644


   --row number: 14120

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154199 , [Content] ='20%'
 WHERE id=198936645


   --row number: 14121

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154199 , [Content] ='Yes'
 WHERE id=198936646


   --row number: 14122

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154199 , [Content] ='2 - Professionals'
 WHERE id=198936647


   --row number: 14123

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154244 , [Content] ='Technical'
 WHERE id=198944538


   --row number: 14124

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154244 , [Content] ='09/05/18'
 WHERE id=198944539


   --row number: 14125

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154244 , [Content] ='5142 IND'
 WHERE id=198944522


   --row number: 14126

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154244 , [Content] ='IND'
 WHERE id=198944523


   --row number: 14127

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154244 , [Content] ='APAC'
 WHERE id=198944524


   --row number: 14128

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154244 , [Content] ='INDIA'
 WHERE id=198944525


   --row number: 14129

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154244 , [Content] ='Engineering'
 WHERE id=198944526


   --row number: 14130

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154244 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=198944527


   --row number: 14131

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154244 , [Content] ='Software'
 WHERE id=198944528


   --row number: 14132

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154244 , [Content] ='IC2'
 WHERE id=198944529


   --row number: 14133

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154244 , [Content] ='INR'
 WHERE id=198944531


   --row number: 14134

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154244 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=198944532


   --row number: 14135

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154244 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=198944533


   --row number: 14136

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154244 , [Content] ='10%'
 WHERE id=198944534


   --row number: 14137

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154244 , [Content] ='No'
 WHERE id=198944535


   --row number: 14138

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154244 , [Content] ='2 - Professionals'
 WHERE id=198944536


   --row number: 14139

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154244 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198944537


   --row number: 14140

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154277 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=198951001


   --row number: 14141

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154277 , [Content] ='Technical'
 WHERE id=198951002


   --row number: 14142

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154277 , [Content] ='09/05/18'
 WHERE id=198951003


   --row number: 14143

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154277 , [Content] ='5143 IND'
 WHERE id=198950985


   --row number: 14144

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154277 , [Content] ='IND'
 WHERE id=198950986


   --row number: 14145

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154277 , [Content] ='APAC'
 WHERE id=198950987


   --row number: 14146

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154277 , [Content] ='INDIA'
 WHERE id=198950988


   --row number: 14147

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154277 , [Content] ='Engineering'
 WHERE id=198950989


   --row number: 14148

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154277 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=198950990


   --row number: 14149

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154277 , [Content] ='Software'
 WHERE id=198950991


   --row number: 14150

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154277 , [Content] ='IC3'
 WHERE id=198950992


   --row number: 14151

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154277 , [Content] ='INR'
 WHERE id=198950994


   --row number: 14152

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154277 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=198950995


   --row number: 14153

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154277 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=198950996


   --row number: 14154

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154277 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=198950997


   --row number: 14155

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154277 , [Content] ='15%'
 WHERE id=198950998


   --row number: 14156

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154277 , [Content] ='Yes'
 WHERE id=198950999


   --row number: 14157

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154277 , [Content] ='2 - Professionals'
 WHERE id=198951000


   --row number: 14158

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154319 , [Content] ='2 - Professionals'
 WHERE id=198954625


   --row number: 14159

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154319 , [Content] ='09/05/18'
 WHERE id=198954628


   --row number: 14160

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154319 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198954626


   --row number: 14161

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154319 , [Content] ='Technical'
 WHERE id=198954627


   --row number: 14162

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154319 , [Content] ='6582 UK'
 WHERE id=198954611


   --row number: 14163

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154319 , [Content] ='UK'
 WHERE id=198954612


   --row number: 14164

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154319 , [Content] ='EMEA'
 WHERE id=198954613


   --row number: 14165

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154319 , [Content] ='UNITED KINGDOM'
 WHERE id=198954614


   --row number: 14166

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154319 , [Content] ='Info Systems/Technology'
 WHERE id=198954615


   --row number: 14167

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154319 , [Content] ='6582 - Information Security Engineer IC2'
 WHERE id=198954616


   --row number: 14168

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154319 , [Content] ='Security'
 WHERE id=198954617


   --row number: 14169

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154319 , [Content] ='IC2'
 WHERE id=198954618


   --row number: 14170

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154319 , [Content] ='GBP'
 WHERE id=198954620


   --row number: 14171

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154319 , [Content] ='33,800 / 39,400 / 45,000 / 50,550 / 56,100'
 WHERE id=198954621


   --row number: 14172

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154319 , [Content] ='37,200 / 43,350 / 49,500 / 55,600 / 61,700'
 WHERE id=198954622


   --row number: 14173

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154319 , [Content] ='10%'
 WHERE id=198954623


   --row number: 14174

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154319 , [Content] ='No'
 WHERE id=198954624


   --row number: 14175

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154324 , [Content] ='8742-Salespersons - Outside'
 WHERE id=198955330


   --row number: 14176

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154324 , [Content] ='Technical'
 WHERE id=198955331


   --row number: 14177

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154324 , [Content] ='09/05/18'
 WHERE id=198955332


   --row number: 14178

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154324 , [Content] ='S1415 ITA'
 WHERE id=198955314


   --row number: 14179

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154324 , [Content] ='ITA'
 WHERE id=198955315


   --row number: 14180

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154324 , [Content] ='EMEA'
 WHERE id=198955316


   --row number: 14181

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154324 , [Content] ='ITALY'
 WHERE id=198955317


   --row number: 14182

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154324 , [Content] ='Solution Consulting'
 WHERE id=198955318


   --row number: 14183

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154324 , [Content] ='S1415 - Sr Advisory Solution Consultant IC5'
 WHERE id=198955319


   --row number: 14184

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154324 , [Content] ='Solution Consultant Core'
 WHERE id=198955320


   --row number: 14185

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154324 , [Content] ='IC5'
 WHERE id=198955321


   --row number: 14186

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154324 , [Content] ='EUR'
 WHERE id=198955323


   --row number: 14187

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154324 , [Content] ='68,213 / 74,231 / 80,250 / 86,269 / 92,288'
 WHERE id=198955324


   --row number: 14188

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154324 , [Content] ='53,400 / 74,700 / 96,000 / 117,300 / 138,600'
 WHERE id=198955325


   --row number: 14189

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154324 , [Content] ='90,950 / 98,975 / 107,000 / 115,025 / 123,050'
 WHERE id=198955326


   --row number: 14190

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3154324 , [Content] ='75/25'
 WHERE id=198955327


   --row number: 14191

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154324 , [Content] ='Yes'
 WHERE id=198955328


   --row number: 14192

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154324 , [Content] ='4 - Sales Workers'
 WHERE id=198955329


   --row number: 14193

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154477 , [Content] ='5883 FRA'
 WHERE id=198975628


   --row number: 14194

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154477 , [Content] ='FRA'
 WHERE id=198975629


   --row number: 14195

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154477 , [Content] ='Technical'
 WHERE id=198975644


   --row number: 14196

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154477 , [Content] ='10/05/18'
 WHERE id=198975645


   --row number: 14197

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154477 , [Content] ='EMEA'
 WHERE id=198975630


   --row number: 14198

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154477 , [Content] ='FRANCE'
 WHERE id=198975631


   --row number: 14199

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154477 , [Content] ='Professional Services'
 WHERE id=198975632


   --row number: 14200

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154477 , [Content] ='5883 - Customer/Technical Trainer IC3'
 WHERE id=198975633


   --row number: 14201

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154477 , [Content] ='Customer/Tech Training'
 WHERE id=198975634


   --row number: 14202

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154477 , [Content] ='IC3'
 WHERE id=198975635


   --row number: 14203

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154477 , [Content] ='EUR'
 WHERE id=198975637


   --row number: 14204

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154477 , [Content] ='42,200 / 49,150 / 56,100 / 63,100 / 70,100'
 WHERE id=198975638


   --row number: 14205

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154477 , [Content] ='10%'
 WHERE id=198975640


   --row number: 14206

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154477 , [Content] ='No'
 WHERE id=198975641


   --row number: 14207

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154477 , [Content] ='2 - Professionals'
 WHERE id=198975642


   --row number: 14208

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154477 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198975643


   --row number: 14209

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154537 , [Content] ='EMEA'
 WHERE id=198981456


   --row number: 14210

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154537 , [Content] ='France'
 WHERE id=198981457


   --row number: 14211

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154537 , [Content] ='9999 - Intern'
 WHERE id=198981458


   --row number: 14212

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154537 , [Content] ='EUR'
 WHERE id=198981459


   --row number: 14213

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154537 , [Content] ='No'
 WHERE id=198981460


   --row number: 14214

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154706 , [Content] ='6804 - UI/ UX Designer IC4'
 WHERE id=198994764


   --row number: 14215

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154706 , [Content] ='UI/UX Designer'
 WHERE id=198994765


   --row number: 14216

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154706 , [Content] ='IC4'
 WHERE id=198994766


   --row number: 14217

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154706 , [Content] ='USD'
 WHERE id=198994768


   --row number: 14218

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154706 , [Content] ='97,200 / 117,550 / 137,900 / 158,300 / 178,700'
 WHERE id=198994769


   --row number: 14219

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154706 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=198994770


   --row number: 14220

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154706 , [Content] ='116,600 / 141,050 / 165,500 / 189,950 / 214,400'
 WHERE id=198994771


   --row number: 14221

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154706 , [Content] ='20%'
 WHERE id=198994772


   --row number: 14222

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154706 , [Content] ='Yes'
 WHERE id=198994773


   --row number: 14223

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154706 , [Content] ='EXEMPT'
 WHERE id=198994774


   --row number: 14224

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154706 , [Content] ='NO'
 WHERE id=198994775


   --row number: 14225

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154706 , [Content] ='2 - Professionals'
 WHERE id=198994776


   --row number: 14226

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154706 , [Content] ='8810-Clerical Office Employees'
 WHERE id=198994777


   --row number: 14227

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154706 , [Content] ='Technical'
 WHERE id=198994778


   --row number: 14228

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154706 , [Content] ='09/05/18'
 WHERE id=198994779


   --row number: 14229

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154537 , [Content] ='9999 FRA'
 WHERE id=198981454


   --row number: 14230

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154537 , [Content] ='FRA'
 WHERE id=198981455


   --row number: 14231

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154537 , [Content] ='09/05/18'
 WHERE id=198981461


   --row number: 14232

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154706 , [Content] ='6804 US - MRKT 2'
 WHERE id=198994759


   --row number: 14233

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154706 , [Content] ='US - MRKT 2'
 WHERE id=198994760


   --row number: 14234

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154706 , [Content] ='AMS'
 WHERE id=198994761


   --row number: 14235

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154706 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=198994762


   --row number: 14236

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154706 , [Content] ='Info Systems/Technology'
 WHERE id=198994763


   --row number: 14237

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3154897 , [Content] ='USD'
 WHERE id=199010633


   --row number: 14238

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3154897 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=199010634


   --row number: 14239

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3154897 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=199010635


   --row number: 14240

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3154897 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=199010636


   --row number: 14241

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3154897 , [Content] ='15%'
 WHERE id=199010637


   --row number: 14242

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3154897 , [Content] ='Yes'
 WHERE id=199010638


   --row number: 14243

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3154897 , [Content] ='EXEMPT'
 WHERE id=199010639


   --row number: 14244

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3154897 , [Content] ='NO'
 WHERE id=199010640


   --row number: 14245

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3154897 , [Content] ='2 - Professionals'
 WHERE id=199010641


   --row number: 14246

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3154897 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199010642


   --row number: 14247

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3154897 , [Content] ='Technical'
 WHERE id=199010643


   --row number: 14248

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3154897 , [Content] ='10/05/18'
 WHERE id=199010644


   --row number: 14249

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3154897 , [Content] ='5183 US - MRKT 2'
 WHERE id=199010624


   --row number: 14250

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3154897 , [Content] ='US - MRKT 2'
 WHERE id=199010625


   --row number: 14251

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3154897 , [Content] ='AMS'
 WHERE id=199010626


   --row number: 14252

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3154897 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199010627


   --row number: 14253

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3154897 , [Content] ='Engineering'
 WHERE id=199010628


   --row number: 14254

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3154897 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=199010629


   --row number: 14255

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3154897 , [Content] ='Quality'
 WHERE id=199010630


   --row number: 14256

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3154897 , [Content] ='IC3'
 WHERE id=199010631


   --row number: 14257

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3155071 , [Content] ='15%'
 WHERE id=199026134


   --row number: 14258

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3155071 , [Content] ='Yes'
 WHERE id=199026135


   --row number: 14259

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3155071 , [Content] ='EXEMPT'
 WHERE id=199026136


   --row number: 14260

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3155071 , [Content] ='NO'
 WHERE id=199026137


   --row number: 14261

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3155071 , [Content] ='2 - Professionals'
 WHERE id=199026138


   --row number: 14262

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3155071 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199026139


   --row number: 14263

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3155071 , [Content] ='Non Technical'
 WHERE id=199026140


   --row number: 14264

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3155071 , [Content] ='09/05/18'
 WHERE id=199026141


   --row number: 14265

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3155071 , [Content] ='5614 US - MRKT 1'
 WHERE id=199026121


   --row number: 14266

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3155071 , [Content] ='US - MRKT 1'
 WHERE id=199026122


   --row number: 14267

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3155071 , [Content] ='AMS'
 WHERE id=199026123


   --row number: 14268

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3155071 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199026124


   --row number: 14269

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3155071 , [Content] ='Marketing'
 WHERE id=199026125


   --row number: 14270

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3155071 , [Content] ='5614 - Marketing Mgr IC4'
 WHERE id=199026126


   --row number: 14271

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3155071 , [Content] ='Marketing'
 WHERE id=199026127


   --row number: 14272

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3155071 , [Content] ='IC4'
 WHERE id=199026128


   --row number: 14273

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3155071 , [Content] ='USD'
 WHERE id=199026130


   --row number: 14274

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3155071 , [Content] ='107,200 / 126,500 / 145,800 / 165,100 / 184,400'
 WHERE id=199026131


   --row number: 14275

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3155071 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=199026132


   --row number: 14276

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3155071 , [Content] ='123,300 / 145,500 / 167,700 / 189,900 / 212,100'
 WHERE id=199026133


   --row number: 14277

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3155334 , [Content] ='159,375 / 173,438 / 187,500 / 201,563 / 215,625'
 WHERE id=199051348


   --row number: 14278

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3155334 , [Content] ='EXEMPT'
 WHERE id=199051353


   --row number: 14279

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3155334 , [Content] ='NO'
 WHERE id=199051354


   --row number: 14280

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3155334 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=199051355


   --row number: 14281

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3155334 , [Content] ='8742-Salespersons - Outside'
 WHERE id=199051356


   --row number: 14282

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3155334 , [Content] ='Technical'
 WHERE id=199051357


   --row number: 14283

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3155334 , [Content] ='09/05/18'
 WHERE id=199051358


   --row number: 14284

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3155334 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=199051349


   --row number: 14285

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3155334 , [Content] ='318,750 / 346,875 / 375,000 / 403,125 / 431,250'
 WHERE id=199051350


   --row number: 14286

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3155334 , [Content] ='50/50'
 WHERE id=199051351


   --row number: 14287

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3155334 , [Content] ='Yes'
 WHERE id=199051352


   --row number: 14288

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3155334 , [Content] ='M5'
 WHERE id=199051345


   --row number: 14289

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3155334 , [Content] ='USD'
 WHERE id=199051347


   --row number: 14290

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3155334 , [Content] ='S315 US - MRKT 1'
 WHERE id=199051338


   --row number: 14291

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3155334 , [Content] ='US - MRKT 1'
 WHERE id=199051339


   --row number: 14292

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3155334 , [Content] ='AMS'
 WHERE id=199051340


   --row number: 14293

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3155334 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199051341


   --row number: 14294

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3155334 , [Content] ='Sales'
 WHERE id=199051342


   --row number: 14295

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3155334 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=199051343


   --row number: 14296

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3155334 , [Content] ='Sales Management'
 WHERE id=199051344


   --row number: 14297

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3155352 , [Content] ='EXEMPT'
 WHERE id=199052710


   --row number: 14298

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3155352 , [Content] ='NO'
 WHERE id=199052711


   --row number: 14299

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3155352 , [Content] ='4 - Sales Workers'
 WHERE id=199052712


   --row number: 14300

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3155352 , [Content] ='8742-Salespersons - Outside'
 WHERE id=199052713


   --row number: 14301

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3155352 , [Content] ='Technical'
 WHERE id=199052714


   --row number: 14302

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3155352 , [Content] ='09/05/18'
 WHERE id=199052715


   --row number: 14303

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3155352 , [Content] ='R3614B US - MRKT 2'
 WHERE id=199052695


   --row number: 14304

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3155352 , [Content] ='US - MRKT 2'
 WHERE id=199052696


   --row number: 14305

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3155352 , [Content] ='AMS'
 WHERE id=199052697


   --row number: 14306

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3155352 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199052698


   --row number: 14307

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3155352 , [Content] ='Sales'
 WHERE id=199052699


   --row number: 14308

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3155352 , [Content] ='R3614B - Commercial Account Exec IC4'
 WHERE id=199052700


   --row number: 14309

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3155352 , [Content] ='Commercial Accounts'
 WHERE id=199052701


   --row number: 14310

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3155352 , [Content] ='IC4'
 WHERE id=199052702


   --row number: 14311

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3155352 , [Content] ='USD'
 WHERE id=199052704


   --row number: 14312

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3155352 , [Content] ='114,750 / 124,875 / 135,000 / 145,125 / 155,250'
 WHERE id=199052705


   --row number: 14313

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3155352 , [Content] ='72,000 / 88,800 / 105,600 / 122,700 / 139,800'
 WHERE id=199052706


   --row number: 14314

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3155352 , [Content] ='229,500 / 249,750 / 270,000 / 290,250 / 310,500'
 WHERE id=199052707


   --row number: 14315

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3155352 , [Content] ='50/50'
 WHERE id=199052708


   --row number: 14316

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3155352 , [Content] ='Yes'
 WHERE id=199052709


   --row number: 14317

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156236 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=199083816


   --row number: 14318

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156236 , [Content] ='3115 US - MRKT 1'
 WHERE id=199083799


   --row number: 14319

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156236 , [Content] ='US - MRKT 1'
 WHERE id=199083800


   --row number: 14320

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156236 , [Content] ='AMS'
 WHERE id=199083801


   --row number: 14321

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156236 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199083802


   --row number: 14322

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156236 , [Content] ='Finance'
 WHERE id=199083803


   --row number: 14323

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156236 , [Content] ='3115 - Dir, FP&A Mgmt M5'
 WHERE id=199083804


   --row number: 14324

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156236 , [Content] ='FP&A'
 WHERE id=199083805


   --row number: 14325

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156236 , [Content] ='M5'
 WHERE id=199083806


   --row number: 14326

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156236 , [Content] ='USD'
 WHERE id=199083808


   --row number: 14327

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156236 , [Content] ='148,200 / 181,550 / 214,900 / 248,250 / 281,600'
 WHERE id=199083809


   --row number: 14328

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3156236 , [Content] ='180,000 / 270,000 / 360,000 / 450,000 / 540,000'
 WHERE id=199083810


   --row number: 14329

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3156236 , [Content] ='185,300 / 226,950 / 268,600 / 310,300 / 352,000'
 WHERE id=199083811


   --row number: 14330

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3156236 , [Content] ='25%'
 WHERE id=199083812


   --row number: 14331

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156236 , [Content] ='Yes'
 WHERE id=199083813


   --row number: 14332

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3156236 , [Content] ='EXEMPT'
 WHERE id=199083814


   --row number: 14333

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3156236 , [Content] ='NO'
 WHERE id=199083815


   --row number: 14334

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156236 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199083817


   --row number: 14335

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156236 , [Content] ='Non Technical'
 WHERE id=199083818


   --row number: 14336

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156236 , [Content] ='09/05/18'
 WHERE id=199083819


   --row number: 14337

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156275 , [Content] ='USD'
 WHERE id=199086641


   --row number: 14338

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3156275 , [Content] ='EXEMPT'
 WHERE id=199086647


   --row number: 14339

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3156275 , [Content] ='NO'
 WHERE id=199086648


   --row number: 14340

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156275 , [Content] ='2 - Professionals'
 WHERE id=199086649


   --row number: 14341

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156275 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199086650


   --row number: 14342

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156275 , [Content] ='Technical'
 WHERE id=199086651


   --row number: 14343

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156275 , [Content] ='09/05/18'
 WHERE id=199086652


   --row number: 14344

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156275 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=199086642


   --row number: 14345

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3156275 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=199086643


   --row number: 14346

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3156275 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=199086644


   --row number: 14347

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3156275 , [Content] ='15%'
 WHERE id=199086645


   --row number: 14348

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156275 , [Content] ='Yes'
 WHERE id=199086646


   --row number: 14349

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156275 , [Content] ='5143 US - MRKT 1'
 WHERE id=199086632


   --row number: 14350

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156275 , [Content] ='US - MRKT 1'
 WHERE id=199086633


   --row number: 14351

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156275 , [Content] ='AMS'
 WHERE id=199086634


   --row number: 14352

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156275 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199086635


   --row number: 14353

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156275 , [Content] ='Engineering'
 WHERE id=199086636


   --row number: 14354

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156275 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=199086637


   --row number: 14355

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156275 , [Content] ='Software'
 WHERE id=199086638


   --row number: 14356

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156275 , [Content] ='IC3'
 WHERE id=199086639


   --row number: 14357

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156387 , [Content] ='2 - Professionals'
 WHERE id=199098057


   --row number: 14358

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156387 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199098058


   --row number: 14359

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156387 , [Content] ='Non Technical'
 WHERE id=199098059


   --row number: 14360

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156387 , [Content] ='09/05/18'
 WHERE id=199098060


   --row number: 14361

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156387 , [Content] ='6124 US - MRKT 1'
 WHERE id=199098040


   --row number: 14362

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156387 , [Content] ='US - MRKT 1'
 WHERE id=199098041


   --row number: 14363

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156387 , [Content] ='AMS'
 WHERE id=199098042


   --row number: 14364

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156387 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199098043


   --row number: 14365

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156387 , [Content] ='Finance'
 WHERE id=199098044


   --row number: 14366

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156387 , [Content] ='6124 - Sr. Tax Accountant IC4'
 WHERE id=199098045


   --row number: 14367

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156387 , [Content] ='Tax'
 WHERE id=199098046


   --row number: 14368

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156387 , [Content] ='IC4'
 WHERE id=199098047


   --row number: 14369

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156387 , [Content] ='USD'
 WHERE id=199098049


   --row number: 14370

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156387 , [Content] ='103,300 / 121,900 / 140,500 / 159,100 / 177,700'
 WHERE id=199098050


   --row number: 14371

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3156387 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=199098051


   --row number: 14372

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3156387 , [Content] ='118,800 / 140,200 / 161,600 / 183,000 / 204,400'
 WHERE id=199098052


   --row number: 14373

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3156387 , [Content] ='15%'
 WHERE id=199098053


   --row number: 14374

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156387 , [Content] ='Yes'
 WHERE id=199098054


   --row number: 14375

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3156387 , [Content] ='EXEMPT'
 WHERE id=199098055


   --row number: 14376

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3156387 , [Content] ='NO'
 WHERE id=199098056


   --row number: 14377

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156564 , [Content] ='8742-Salespersons - Outside'
 WHERE id=199130189


   --row number: 14378

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156564 , [Content] ='Technical'
 WHERE id=199130190


   --row number: 14379

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156564 , [Content] ='09/05/18'
 WHERE id=199130191


   --row number: 14380

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156564 , [Content] ='S665 AUS'
 WHERE id=199130173


   --row number: 14381

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156564 , [Content] ='AUS'
 WHERE id=199130174


   --row number: 14382

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156564 , [Content] ='APAC'
 WHERE id=199130175


   --row number: 14383

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156564 , [Content] ='AUSTRALIA'
 WHERE id=199130176


   --row number: 14384

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156564 , [Content] ='Sales'
 WHERE id=199130177


   --row number: 14385

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156564 , [Content] ='S665 - Product Line Sales Mgr IC5'
 WHERE id=199130178


   --row number: 14386

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156564 , [Content] ='Product Line Sales'
 WHERE id=199130179


   --row number: 14387

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156564 , [Content] ='IC5'
 WHERE id=199130180


   --row number: 14388

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156564 , [Content] ='AUD'
 WHERE id=199130182


   --row number: 14389

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156564 , [Content] ='188,700 / 205,350 / 222,000 / 238,650 / 255,300'
 WHERE id=199130183


   --row number: 14390

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3156564 , [Content] ='70,200 / 98,100 / 126,000 / 154,200 / 182,400'
 WHERE id=199130184


   --row number: 14391

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3156564 , [Content] ='314,500 / 342,250 / 370,000 / 397,750 / 425,500'
 WHERE id=199130185


   --row number: 14392

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3156564 , [Content] ='60/40'
 WHERE id=199130186


   --row number: 14393

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156564 , [Content] ='Yes'
 WHERE id=199130187


   --row number: 14394

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156564 , [Content] ='4 - Sales Workers'
 WHERE id=199130188


   --row number: 14395

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156642 , [Content] ='5142 IND'
 WHERE id=199145915


   --row number: 14396

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156642 , [Content] ='IND'
 WHERE id=199145916


   --row number: 14397

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156642 , [Content] ='APAC'
 WHERE id=199145917


   --row number: 14398

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156642 , [Content] ='INDIA'
 WHERE id=199145918


   --row number: 14399

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156642 , [Content] ='Engineering'
 WHERE id=199145919


   --row number: 14400

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156642 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=199145920


   --row number: 14401

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156642 , [Content] ='Software'
 WHERE id=199145921


   --row number: 14402

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156642 , [Content] ='IC2'
 WHERE id=199145922


   --row number: 14403

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156642 , [Content] ='INR'
 WHERE id=199145924


   --row number: 14404

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156642 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=199145925


   --row number: 14405

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3156642 , [Content] ='10%'
 WHERE id=199145926


   --row number: 14406

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156642 , [Content] ='No'
 WHERE id=199145927


   --row number: 14407

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156642 , [Content] ='2 - Professionals'
 WHERE id=199145928


   --row number: 14408

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156642 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199145929


   --row number: 14409

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156642 , [Content] ='Technical'
 WHERE id=199145930


   --row number: 14410

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156642 , [Content] ='5/16/2018'
 WHERE id=199145931


   --row number: 14411

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156816 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199166994


   --row number: 14412

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156816 , [Content] ='09/05/18'
 WHERE id=199166996


   --row number: 14413

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156816 , [Content] ='Technical'
 WHERE id=199166995


   --row number: 14414

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156816 , [Content] ='5143 IND'
 WHERE id=199166978


   --row number: 14415

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156816 , [Content] ='IND'
 WHERE id=199166979


   --row number: 14416

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156816 , [Content] ='APAC'
 WHERE id=199166980


   --row number: 14417

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156816 , [Content] ='INDIA'
 WHERE id=199166981


   --row number: 14418

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156816 , [Content] ='Engineering'
 WHERE id=199166982


   --row number: 14419

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156816 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=199166983


   --row number: 14420

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156816 , [Content] ='Software'
 WHERE id=199166984


   --row number: 14421

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156816 , [Content] ='IC3'
 WHERE id=199166985


   --row number: 14422

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156816 , [Content] ='INR'
 WHERE id=199166987


   --row number: 14423

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156816 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=199166988


   --row number: 14424

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3156816 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=199166989


   --row number: 14425

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3156816 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=199166990


   --row number: 14426

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3156816 , [Content] ='15%'
 WHERE id=199166991


   --row number: 14427

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156816 , [Content] ='Yes'
 WHERE id=199166992


   --row number: 14428

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156816 , [Content] ='2 - Professionals'
 WHERE id=199166993


   --row number: 14429

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3156822 , [Content] ='Technical'
 WHERE id=199167979


   --row number: 14430

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3156822 , [Content] ='09/05/18'
 WHERE id=199167980


   --row number: 14431

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3156822 , [Content] ='5142 IND'
 WHERE id=199167963


   --row number: 14432

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3156822 , [Content] ='IND'
 WHERE id=199167964


   --row number: 14433

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3156822 , [Content] ='APAC'
 WHERE id=199167965


   --row number: 14434

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3156822 , [Content] ='INDIA'
 WHERE id=199167966


   --row number: 14435

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3156822 , [Content] ='Engineering'
 WHERE id=199167967


   --row number: 14436

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3156822 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=199167968


   --row number: 14437

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3156822 , [Content] ='Software'
 WHERE id=199167969


   --row number: 14438

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3156822 , [Content] ='IC2'
 WHERE id=199167970


   --row number: 14439

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3156822 , [Content] ='INR'
 WHERE id=199167972


   --row number: 14440

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3156822 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=199167973


   --row number: 14441

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3156822 , [Content] ='1,100,000 / 1,347,500 / 1,595,000 / 1,842,500 / 2,090,000'
 WHERE id=199167974


   --row number: 14442

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3156822 , [Content] ='10%'
 WHERE id=199167975


   --row number: 14443

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3156822 , [Content] ='No'
 WHERE id=199167976


   --row number: 14444

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3156822 , [Content] ='2 - Professionals'
 WHERE id=199167977


   --row number: 14445

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3156822 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199167978


   --row number: 14446

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3160994 , [Content] ='132,000 / 186,000 / 240,000 / 294,000 / 348,000'
 WHERE id=199176518


   --row number: 14447

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3160994 , [Content] ='2 - Professionals'
 WHERE id=199176522


   --row number: 14448

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3160994 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199176523


   --row number: 14449

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3160994 , [Content] ='Technical'
 WHERE id=199176524


   --row number: 14450

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3160994 , [Content] ='09/05/18'
 WHERE id=199176525


   --row number: 14451

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3160994 , [Content] ='363,700 / 439,900 / 516,100 / 592,300 / 668,500'
 WHERE id=199176519


   --row number: 14452

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3160994 , [Content] ='20%'
 WHERE id=199176520


   --row number: 14453

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3160994 , [Content] ='Yes'
 WHERE id=199176521


   --row number: 14454

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3160994 , [Content] ='5144 ISR'
 WHERE id=199176507


   --row number: 14455

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3160994 , [Content] ='ISR'
 WHERE id=199176508


   --row number: 14456

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3160994 , [Content] ='EMEA'
 WHERE id=199176509


   --row number: 14457

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3160994 , [Content] ='ISRAEL'
 WHERE id=199176510


   --row number: 14458

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3160994 , [Content] ='Engineering'
 WHERE id=199176511


   --row number: 14459

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3160994 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=199176512


   --row number: 14460

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3160994 , [Content] ='Software'
 WHERE id=199176513


   --row number: 14461

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3160994 , [Content] ='IC4'
 WHERE id=199176514


   --row number: 14462

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3160994 , [Content] ='ILS'
 WHERE id=199176516


   --row number: 14463

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3160994 , [Content] ='303,100 / 366,600 / 430,100 / 493,600 / 557,100'
 WHERE id=199176517


   --row number: 14464

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3161087 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199189192


   --row number: 14465

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3161087 , [Content] ='Technical'
 WHERE id=199189193


   --row number: 14466

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3161087 , [Content] ='09/05/18'
 WHERE id=199189194


   --row number: 14467

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3161087 , [Content] ='5693 NLD'
 WHERE id=199189177


   --row number: 14468

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3161087 , [Content] ='NLD'
 WHERE id=199189178


   --row number: 14469

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3161087 , [Content] ='EMEA'
 WHERE id=199189179


   --row number: 14470

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3161087 , [Content] ='NETHERLANDS'
 WHERE id=199189180


   --row number: 14471

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3161087 , [Content] ='Customer Support'
 WHERE id=199189181


   --row number: 14472

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3161087 , [Content] ='5693 - Support Account Services Mgr IC3'
 WHERE id=199189182


   --row number: 14473

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3161087 , [Content] ='SAM Services'
 WHERE id=199189183


   --row number: 14474

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3161087 , [Content] ='IC3'
 WHERE id=199189184


   --row number: 14475

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3161087 , [Content] ='EUR'
 WHERE id=199189186


   --row number: 14476

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3161087 , [Content] ='47,400 / 55,250 / 63,100 / 70,900 / 78,700'
 WHERE id=199189187


   --row number: 14477

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3161087 , [Content] ='52,100 / 60,750 / 69,400 / 78,000 / 86,600'
 WHERE id=199189188


   --row number: 14478

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3161087 , [Content] ='10%'
 WHERE id=199189189


   --row number: 14479

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3161087 , [Content] ='No'
 WHERE id=199189190


   --row number: 14480

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3161087 , [Content] ='2 - Professionals'
 WHERE id=199189191


   --row number: 14481

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3161101 , [Content] ='5812 NLD'
 WHERE id=199191030


   --row number: 14482

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3161101 , [Content] ='NLD'
 WHERE id=199191031


   --row number: 14483

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3161101 , [Content] ='EMEA'
 WHERE id=199191032


   --row number: 14484

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3161101 , [Content] ='NETHERLANDS'
 WHERE id=199191033


   --row number: 14485

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3161101 , [Content] ='Customer Support'
 WHERE id=199191034


   --row number: 14486

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3161101 , [Content] ='5812 - Customer Support Rep IC2'
 WHERE id=199191035


   --row number: 14487

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3161101 , [Content] ='Customer Support'
 WHERE id=199191036


   --row number: 14488

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3161101 , [Content] ='IC2'
 WHERE id=199191037


   --row number: 14489

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3161101 , [Content] ='EUR'
 WHERE id=199191039


   --row number: 14490

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3161101 , [Content] ='36,700 / 41,700 / 46,700 / 51,650 / 56,600'
 WHERE id=199191040


   --row number: 14491

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3161101 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199191045


   --row number: 14492

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3161101 , [Content] ='Technical'
 WHERE id=199191046


   --row number: 14493

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3161101 , [Content] ='09/05/18'
 WHERE id=199191047


   --row number: 14494

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3161101 , [Content] ='40,400 / 45,900 / 51,400 / 56,850 / 62,300'
 WHERE id=199191041


   --row number: 14495

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3161101 , [Content] ='10%'
 WHERE id=199191042


   --row number: 14496

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3161101 , [Content] ='No'
 WHERE id=199191043


   --row number: 14497

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3161101 , [Content] ='2 - Professionals'
 WHERE id=199191044


   --row number: 14498

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3161717 , [Content] ='AMS'
 WHERE id=199244180


   --row number: 14499

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3161717 , [Content] ='58,200 / 66,500 / 74,800 / 83,100 / 91,400'
 WHERE id=199244190


   --row number: 14500

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3161717 , [Content] ='10%'
 WHERE id=199244191


   --row number: 14501

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3161717 , [Content] ='Yes'
 WHERE id=199244192


   --row number: 14502

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3161717 , [Content] ='EXEMPT'
 WHERE id=199244193


   --row number: 14503

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3161717 , [Content] ='NO'
 WHERE id=199244194


   --row number: 14504

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3161717 , [Content] ='2 - Professionals'
 WHERE id=199244195


   --row number: 14505

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3161717 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199244196


   --row number: 14506

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3161717 , [Content] ='Technical'
 WHERE id=199244197


   --row number: 14507

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3161717 , [Content] ='10/05/18'
 WHERE id=199244198


   --row number: 14508

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3161717 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199244181


   --row number: 14509

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3161717 , [Content] ='Sales Operations'
 WHERE id=199244182


   --row number: 14510

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3161717 , [Content] ='S1832 - Sales Operations Analyst IC2'
 WHERE id=199244183


   --row number: 14511

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3161717 , [Content] ='Sales Operations'
 WHERE id=199244184


   --row number: 14512

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3161717 , [Content] ='IC2'
 WHERE id=199244185


   --row number: 14513

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3161717 , [Content] ='S1832 US - MRKT 2'
 WHERE id=199244178


   --row number: 14514

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3161717 , [Content] ='US - MRKT 2'
 WHERE id=199244179


   --row number: 14515

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3161717 , [Content] ='USD'
 WHERE id=199244187


   --row number: 14516

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3161717 , [Content] ='52,900 / 60,450 / 68,000 / 75,550 / 83,100'
 WHERE id=199244188


   --row number: 14517

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3161717 , [Content] ='26,400 / 34,200 / 42,000 / 49,800 / 57,600'
 WHERE id=199244189


   --row number: 14518

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162113 , [Content] ='9999 US - MRKT 1'
 WHERE id=199275455


   --row number: 14519

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162113 , [Content] ='US - MRKT 1'
 WHERE id=199275456


   --row number: 14520

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162113 , [Content] ='AMS'
 WHERE id=199275457


   --row number: 14521

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162113 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199275458


   --row number: 14522

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162113 , [Content] ='9999 - Intern'
 WHERE id=199275459


   --row number: 14523

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162113 , [Content] ='USD'
 WHERE id=199275460


   --row number: 14524

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162113 , [Content] ='No'
 WHERE id=199275461


   --row number: 14525

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162113 , [Content] ='NON-EXEMPT'
 WHERE id=199275462


   --row number: 14526

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162113 , [Content] ='04/05/18'
 WHERE id=199275463


   --row number: 14527

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3162548 , [Content] ='15%'
 WHERE id=199312242


   --row number: 14528

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162548 , [Content] ='Yes'
 WHERE id=199312243


   --row number: 14529

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162548 , [Content] ='EXEMPT'
 WHERE id=199312244


   --row number: 14530

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3162548 , [Content] ='NO'
 WHERE id=199312245


   --row number: 14531

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3162548 , [Content] ='2 - Professionals'
 WHERE id=199312246


   --row number: 14532

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3162548 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199312247


   --row number: 14533

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3162548 , [Content] ='Technical'
 WHERE id=199312248


   --row number: 14534

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162548 , [Content] ='09/05/18'
 WHERE id=199312249


   --row number: 14535

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162548 , [Content] ='5183 US - MRKT 2'
 WHERE id=199312229


   --row number: 14536

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162548 , [Content] ='US - MRKT 2'
 WHERE id=199312230


   --row number: 14537

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162548 , [Content] ='AMS'
 WHERE id=199312231


   --row number: 14538

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162548 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199312232


   --row number: 14539

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3162548 , [Content] ='Engineering'
 WHERE id=199312233


   --row number: 14540

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162548 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=199312234


   --row number: 14541

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3162548 , [Content] ='Quality'
 WHERE id=199312235


   --row number: 14542

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3162548 , [Content] ='IC3'
 WHERE id=199312236


   --row number: 14543

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162548 , [Content] ='USD'
 WHERE id=199312238


   --row number: 14544

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3162548 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=199312239


   --row number: 14545

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3162548 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=199312240


   --row number: 14546

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3162548 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=199312241


   --row number: 14547

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162552 , [Content] ='EXEMPT'
 WHERE id=199312715


   --row number: 14548

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3162552 , [Content] ='NO'
 WHERE id=199312716


   --row number: 14549

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3162552 , [Content] ='2 - Professionals'
 WHERE id=199312717


   --row number: 14550

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3162552 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199312718


   --row number: 14551

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3162552 , [Content] ='Technical'
 WHERE id=199312719


   --row number: 14552

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162552 , [Content] ='09/05/18'
 WHERE id=199312720


   --row number: 14553

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3162552 , [Content] ='20%'
 WHERE id=199312713


   --row number: 14554

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162552 , [Content] ='Yes'
 WHERE id=199312714


   --row number: 14555

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162552 , [Content] ='5184 US - MRKT 2'
 WHERE id=199312700


   --row number: 14556

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162552 , [Content] ='US - MRKT 2'
 WHERE id=199312701


   --row number: 14557

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162552 , [Content] ='AMS'
 WHERE id=199312702


   --row number: 14558

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162552 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199312703


   --row number: 14559

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3162552 , [Content] ='Engineering'
 WHERE id=199312704


   --row number: 14560

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162552 , [Content] ='5184 - Staff Software QA Engineer IC4'
 WHERE id=199312705


   --row number: 14561

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3162552 , [Content] ='Quality'
 WHERE id=199312706


   --row number: 14562

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3162552 , [Content] ='IC4'
 WHERE id=199312707


   --row number: 14563

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162552 , [Content] ='USD'
 WHERE id=199312709


   --row number: 14564

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3162552 , [Content] ='91,600 / 110,800 / 130,000 / 149,200 / 168,400'
 WHERE id=199312710


   --row number: 14565

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3162552 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=199312711


   --row number: 14566

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3162552 , [Content] ='109,900 / 132,950 / 156,000 / 179,050 / 202,100'
 WHERE id=199312712


   --row number: 14567

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162819 , [Content] ='9999 US - MRKT 2'
 WHERE id=199359865


   --row number: 14568

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162819 , [Content] ='US - MRKT 2'
 WHERE id=199359866


   --row number: 14569

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162819 , [Content] ='AMS'
 WHERE id=199359867


   --row number: 14570

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162819 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199359868


   --row number: 14571

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162819 , [Content] ='9999 - Intern'
 WHERE id=199359869


   --row number: 14572

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162819 , [Content] ='USD'
 WHERE id=199359870


   --row number: 14573

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162819 , [Content] ='No'
 WHERE id=199359871


   --row number: 14574

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162819 , [Content] ='NON-EXEMPT'
 WHERE id=199359872


   --row number: 14575

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162819 , [Content] ='09/05/18'
 WHERE id=199359873


   --row number: 14576

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162817 , [Content] ='9999 US - MRKT 1'
 WHERE id=199359670


   --row number: 14577

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162817 , [Content] ='US - MRKT 1'
 WHERE id=199359671


   --row number: 14578

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162817 , [Content] ='AMS'
 WHERE id=199359672


   --row number: 14579

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162817 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199359673


   --row number: 14580

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162817 , [Content] ='9999 - Intern'
 WHERE id=199359674


   --row number: 14581

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162817 , [Content] ='USD'
 WHERE id=199359675


   --row number: 14582

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162817 , [Content] ='No'
 WHERE id=199359676


   --row number: 14583

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162817 , [Content] ='NON-EXEMPT'
 WHERE id=199359677


   --row number: 14584

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162817 , [Content] ='04/05/18'
 WHERE id=199359678


   --row number: 14585

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3162819 , [Content] ='NO'
 WHERE id=199360068


   --row number: 14586

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162820 , [Content] ='9999 US - MRKT 2'
 WHERE id=199360205


   --row number: 14587

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162820 , [Content] ='US - MRKT 2'
 WHERE id=199360206


   --row number: 14588

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162820 , [Content] ='AMS'
 WHERE id=199360207


   --row number: 14589

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162820 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199360208


   --row number: 14590

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162820 , [Content] ='9999 - Intern'
 WHERE id=199360209


   --row number: 14591

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162820 , [Content] ='USD'
 WHERE id=199360210


   --row number: 14592

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162820 , [Content] ='No'
 WHERE id=199360211


   --row number: 14593

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162820 , [Content] ='NON-EXEMPT'
 WHERE id=199360212


   --row number: 14594

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3162820 , [Content] ='NO'
 WHERE id=199360213


   --row number: 14595

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162820 , [Content] ='09/05/18'
 WHERE id=199360214


   --row number: 14596

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162821 , [Content] ='9999 US - MRKT 2'
 WHERE id=199360372


   --row number: 14597

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162821 , [Content] ='US - MRKT 2'
 WHERE id=199360373


   --row number: 14598

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162821 , [Content] ='AMS'
 WHERE id=199360374


   --row number: 14599

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162821 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199360375


   --row number: 14600

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162821 , [Content] ='9999 - Intern'
 WHERE id=199360376


   --row number: 14601

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3162821 , [Content] ='USD'
 WHERE id=199360377


   --row number: 14602

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162821 , [Content] ='No'
 WHERE id=199360378


   --row number: 14603

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3162821 , [Content] ='NON-EXEMPT'
 WHERE id=199360379


   --row number: 14604

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3162821 , [Content] ='NO'
 WHERE id=199360380


   --row number: 14605

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3162821 , [Content] ='09/05/18'
 WHERE id=199360381


   --row number: 14606

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3162889 , [Content] ='5694 JPN'
 WHERE id=199368843


   --row number: 14607

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3162889 , [Content] ='JPN'
 WHERE id=199368844


   --row number: 14608

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3162889 , [Content] ='APAC'
 WHERE id=199368845


   --row number: 14609

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3162889 , [Content] ='Japan'
 WHERE id=199368846


   --row number: 14610

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3162889 , [Content] ='Customer Support'
 WHERE id=199368847


   --row number: 14611

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3162889 , [Content] ='5694 - Support Account Services Mgr IC4'
 WHERE id=199368848


   --row number: 14612

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3162889 , [Content] ='SAM Services'
 WHERE id=199368849


   --row number: 14613

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3162889 , [Content] ='IC4'
 WHERE id=199368850


   --row number: 14614

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3162889 , [Content] ='7,638,500 / 10,388,300 / 13,138,200'
 WHERE id=199368852


   --row number: 14615

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3162889 , [Content] ='400 / 800 / 1,200'
 WHERE id=199368853


   --row number: 14616

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3162889 , [Content] ='15%'
 WHERE id=199368854


   --row number: 14617

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3162889 , [Content] ='Yes'
 WHERE id=199368855


   --row number: 14618

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3162889 , [Content] ='2 - Professionals'
 WHERE id=199368856


   --row number: 14619

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3162889 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199368857


   --row number: 14620

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3162889 , [Content] ='Technical'
 WHERE id=199368858


   --row number: 14621

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3163563 , [Content] ='318,750 / 346,875 / 375,000 / 403,125 / 431,250'
 WHERE id=199439881


   --row number: 14622

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3163563 , [Content] ='50/50'
 WHERE id=199439882


   --row number: 14623

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3163563 , [Content] ='Yes'
 WHERE id=199439883


   --row number: 14624

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3163563 , [Content] ='EXEMPT'
 WHERE id=199439884


   --row number: 14625

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3163563 , [Content] ='NO'
 WHERE id=199439885


   --row number: 14626

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3163563 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=199439886


   --row number: 14627

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3163563 , [Content] ='8742-Salespersons - Outside'
 WHERE id=199439887


   --row number: 14628

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3163563 , [Content] ='Technical'
 WHERE id=199439888


   --row number: 14629

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3163563 , [Content] ='09/05/18'
 WHERE id=199439889


   --row number: 14630

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3163563 , [Content] ='S315 US - MRKT 2'
 WHERE id=199439869


   --row number: 14631

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3163563 , [Content] ='US - MRKT 2'
 WHERE id=199439870


   --row number: 14632

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3163563 , [Content] ='AMS'
 WHERE id=199439871


   --row number: 14633

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3163563 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199439872


   --row number: 14634

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3163563 , [Content] ='Sales'
 WHERE id=199439873


   --row number: 14635

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3163563 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=199439874


   --row number: 14636

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3163563 , [Content] ='Sales Management'
 WHERE id=199439875


   --row number: 14637

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3163563 , [Content] ='M5'
 WHERE id=199439876


   --row number: 14638

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3163563 , [Content] ='USD'
 WHERE id=199439878


   --row number: 14639

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3163563 , [Content] ='159,375 / 173,438 / 187,500 / 201,563 / 215,625'
 WHERE id=199439879


   --row number: 14640

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3163563 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=199439880


   --row number: 14641

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3164937 , [Content] ='IC3'
 WHERE id=199579039


   --row number: 14642

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3164937 , [Content] ='GBP'
 WHERE id=199579041


   --row number: 14643

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3164937 , [Content] ='35,100 / 41,400 / 47,700 / 54,050 / 60,400'
 WHERE id=199579042


   --row number: 14644

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3164937 , [Content] ='45,600 / 63,600 / 81,600 / 99,600 / 117,600'
 WHERE id=199579043


   --row number: 14645

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3164937 , [Content] ='15%'
 WHERE id=199579044


   --row number: 14646

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3164937 , [Content] ='Yes'
 WHERE id=199579045


   --row number: 14647

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3164937 , [Content] ='2 - Professionals'
 WHERE id=199579046


   --row number: 14648

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3164937 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199579047


   --row number: 14649

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3164937 , [Content] ='Technical'
 WHERE id=199579048


   --row number: 14650

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3164937 , [Content] ='09/05/18'
 WHERE id=199579049


   --row number: 14651

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3164937 , [Content] ='5823 UK'
 WHERE id=199579032


   --row number: 14652

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3164937 , [Content] ='UK'
 WHERE id=199579033


   --row number: 14653

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3164937 , [Content] ='EMEA'
 WHERE id=199579034


   --row number: 14654

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3164937 , [Content] ='UNITED KINGDOM'
 WHERE id=199579035


   --row number: 14655

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3164937 , [Content] ='Customer Support'
 WHERE id=199579036


   --row number: 14656

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3164937 , [Content] ='5823 - Sr Tech Support Engineer IC3'
 WHERE id=199579037


   --row number: 14657

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3164937 , [Content] ='Technical Support'
 WHERE id=199579038


   --row number: 14658

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3165048 , [Content] ='Yes'
 WHERE id=199590117


   --row number: 14659

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3165048 , [Content] ='2 - Professionals'
 WHERE id=199590118


   --row number: 14660

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3165048 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199590119


   --row number: 14661

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3165048 , [Content] ='Technical'
 WHERE id=199590120


   --row number: 14662

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3165048 , [Content] ='09/05/18'
 WHERE id=199590121


   --row number: 14663

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3165048 , [Content] ='5143 IND'
 WHERE id=199590103


   --row number: 14664

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3165048 , [Content] ='IND'
 WHERE id=199590104


   --row number: 14665

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3165048 , [Content] ='APAC'
 WHERE id=199590105


   --row number: 14666

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3165048 , [Content] ='INDIA'
 WHERE id=199590106


   --row number: 14667

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3165048 , [Content] ='Engineering'
 WHERE id=199590107


   --row number: 14668

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3165048 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=199590108


   --row number: 14669

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3165048 , [Content] ='Software'
 WHERE id=199590109


   --row number: 14670

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3165048 , [Content] ='IC3'
 WHERE id=199590110


   --row number: 14671

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3165048 , [Content] ='INR'
 WHERE id=199590112


   --row number: 14672

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3165048 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=199590113


   --row number: 14673

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3165048 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=199590114


   --row number: 14674

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3165048 , [Content] ='1,760,700 / 2,156,850 / 2,553,000 / 2,949,100 / 3,345,200'
 WHERE id=199590115


   --row number: 14675

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3165048 , [Content] ='15%'
 WHERE id=199590116


   --row number: 14676

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3165452 , [Content] ='2 - Professionals'
 WHERE id=199620294


   --row number: 14677

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3165452 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199620295


   --row number: 14678

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3165452 , [Content] ='Technical'
 WHERE id=199620296


   --row number: 14679

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3165452 , [Content] ='7/20/18'
 WHERE id=199620297


   --row number: 14680

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3165452 , [Content] ='5144 US - MRKT 2'
 WHERE id=199620278


   --row number: 14681

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3165452 , [Content] ='US - MRKT 2'
 WHERE id=199620279


   --row number: 14682

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3165452 , [Content] ='AMS'
 WHERE id=199620280


   --row number: 14683

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3165452 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199620281


   --row number: 14684

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3165452 , [Content] ='Engineering'
 WHERE id=199620282


   --row number: 14685

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3165452 , [Content] ='5144 - Staff Software Engineer IC4'
 WHERE id=199620283


   --row number: 14686

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3165452 , [Content] ='Software'
 WHERE id=199620284


   --row number: 14687

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3165452 , [Content] ='IC4'
 WHERE id=199620285


   --row number: 14688

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3165452 , [Content] ='USD'
 WHERE id=199620287


   --row number: 14689

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3165452 , [Content] ='107,100 / 129,550 / 152,000 / 174,450 / 196,900'
 WHERE id=199620288


   --row number: 14690

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3165452 , [Content] ='171,600 / 235,800 / 300,000 / 364,500 / 429,000'
 WHERE id=199620289


   --row number: 14691

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3165452 , [Content] ='20%'
 WHERE id=199620290


   --row number: 14692

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3165452 , [Content] ='Yes'
 WHERE id=199620291


   --row number: 14693

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3165452 , [Content] ='EXEMPT'
 WHERE id=199620292


   --row number: 14694

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3165452 , [Content] ='NO'
 WHERE id=199620293


   --row number: 14695

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3166307 , [Content] ='5183 US - MRKT 2'
 WHERE id=199680267


   --row number: 14696

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3166307 , [Content] ='US - MRKT 2'
 WHERE id=199680268


   --row number: 14697

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3166307 , [Content] ='AMS'
 WHERE id=199680269


   --row number: 14698

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3166307 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199680270


   --row number: 14699

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3166307 , [Content] ='Engineering'
 WHERE id=199680271


   --row number: 14700

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3166307 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=199680272


   --row number: 14701

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3166307 , [Content] ='Quality'
 WHERE id=199680273


   --row number: 14702

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3166307 , [Content] ='IC3'
 WHERE id=199680274


   --row number: 14703

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3166307 , [Content] ='USD'
 WHERE id=199680276


   --row number: 14704

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3166307 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=199680277


   --row number: 14705

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3166307 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=199680278


   --row number: 14706

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3166307 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=199680279


   --row number: 14707

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3166307 , [Content] ='15%'
 WHERE id=199680280


   --row number: 14708

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3166307 , [Content] ='Yes'
 WHERE id=199680281


   --row number: 14709

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3166307 , [Content] ='EXEMPT'
 WHERE id=199680282


   --row number: 14710

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3166307 , [Content] ='NO'
 WHERE id=199680283


   --row number: 14711

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3166307 , [Content] ='2 - Professionals'
 WHERE id=199680284


   --row number: 14712

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3166307 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199680285


   --row number: 14713

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3166307 , [Content] ='Technical'
 WHERE id=199680286


   --row number: 14714

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3166307 , [Content] ='09/05/18'
 WHERE id=199680287


   --row number: 14715

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3166377 , [Content] ='NO'
 WHERE id=199686811


   --row number: 14716

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3166377 , [Content] ='2 - Professionals'
 WHERE id=199686812


   --row number: 14717

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3166377 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199686813


   --row number: 14718

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3166377 , [Content] ='Non Technical'
 WHERE id=199686814


   --row number: 14719

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3166377 , [Content] ='09/05/18'
 WHERE id=199686815


   --row number: 14720

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3166377 , [Content] ='6225 US - MRKT 1'
 WHERE id=199686795


   --row number: 14721

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3166377 , [Content] ='US - MRKT 1'
 WHERE id=199686796


   --row number: 14722

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3166377 , [Content] ='AMS'
 WHERE id=199686797


   --row number: 14723

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3166377 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=199686798


   --row number: 14724

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3166377 , [Content] ='Human Resources'
 WHERE id=199686799


   --row number: 14725

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3166377 , [Content] ='6225 - Recruiter/Staffing Representative IC5'
 WHERE id=199686800


   --row number: 14726

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3166377 , [Content] ='Staffing'
 WHERE id=199686801


   --row number: 14727

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3166377 , [Content] ='IC5'
 WHERE id=199686802


   --row number: 14728

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3166377 , [Content] ='USD'
 WHERE id=199686804


   --row number: 14729

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3166377 , [Content] ='119,600 / 144,650 / 169,700 / 194,750 / 219,800'
 WHERE id=199686805


   --row number: 14730

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3166377 , [Content] ='84,000 / 108,000 / 132,000 / 156,000 / 180,000'
 WHERE id=199686806


   --row number: 14731

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3166377 , [Content] ='143,500 / 173,550 / 203,600 / 233,700 / 263,800'
 WHERE id=199686807


   --row number: 14732

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3166377 , [Content] ='20%'
 WHERE id=199686808


   --row number: 14733

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3166377 , [Content] ='Yes'
 WHERE id=199686809


   --row number: 14734

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3166377 , [Content] ='EXEMPT'
 WHERE id=199686810


   --row number: 14735

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3166978 , [Content] ='Technical'
 WHERE id=199902562


   --row number: 14736

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3166978 , [Content] ='04/05/18'
 WHERE id=199902563


   --row number: 14737

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3166978 , [Content] ='5143 IND'
 WHERE id=199902546


   --row number: 14738

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3166978 , [Content] ='IND'
 WHERE id=199902547


   --row number: 14739

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3166978 , [Content] ='APAC'
 WHERE id=199902548


   --row number: 14740

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3166978 , [Content] ='INDIA'
 WHERE id=199902549


   --row number: 14741

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3166978 , [Content] ='Engineering'
 WHERE id=199902550


   --row number: 14742

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3166978 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=199902551


   --row number: 14743

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3166978 , [Content] ='Software'
 WHERE id=199902552


   --row number: 14744

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3166978 , [Content] ='IC3'
 WHERE id=199902553


   --row number: 14745

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3166978 , [Content] ='INR'
 WHERE id=199902555


   --row number: 14746

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3166978 , [Content] ='1,531,000 / 1,875,500 / 2,220,000 / 2,564,450 / 2,908,900'
 WHERE id=199902556


   --row number: 14747

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3166978 , [Content] ='50,400 / 70,200 / 90,000 / 110,100 / 130,200'
 WHERE id=199902557


   --row number: 14748

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3166978 , [Content] ='15%'
 WHERE id=199902558


   --row number: 14749

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3166978 , [Content] ='Yes'
 WHERE id=199902559


   --row number: 14750

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3166978 , [Content] ='2 - Professionals'
 WHERE id=199902560


   --row number: 14751

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3166978 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199902561


   --row number: 14752

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3166979 , [Content] ='10/05/18'
 WHERE id=199902624


   --row number: 14753

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3166980 , [Content] ='5142 IND'
 WHERE id=199902666


   --row number: 14754

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3166980 , [Content] ='IND'
 WHERE id=199902667


   --row number: 14755

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3166980 , [Content] ='APAC'
 WHERE id=199902668


   --row number: 14756

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3166980 , [Content] ='INDIA'
 WHERE id=199902669


   --row number: 14757

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3166980 , [Content] ='Engineering'
 WHERE id=199902670


   --row number: 14758

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3166980 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=199902671


   --row number: 14759

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3166980 , [Content] ='Software'
 WHERE id=199902672


   --row number: 14760

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3166980 , [Content] ='IC2'
 WHERE id=199902673


   --row number: 14761

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3166980 , [Content] ='INR'
 WHERE id=199902675


   --row number: 14762

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3166980 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=199902676


   --row number: 14763

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3166980 , [Content] ='10%'
 WHERE id=199902678


   --row number: 14764

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3166980 , [Content] ='No'
 WHERE id=199902679


   --row number: 14765

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3166980 , [Content] ='2 - Professionals'
 WHERE id=199902680


   --row number: 14766

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3166980 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199902681


   --row number: 14767

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3166980 , [Content] ='Technical'
 WHERE id=199902682


   --row number: 14768

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3166980 , [Content] ='09/05/18'
 WHERE id=199902683


   --row number: 14769

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3166979 , [Content] ='5142 IND'
 WHERE id=199902607


   --row number: 14770

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3166979 , [Content] ='IND'
 WHERE id=199902608


   --row number: 14771

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3166979 , [Content] ='APAC'
 WHERE id=199902609


   --row number: 14772

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3166979 , [Content] ='INDIA'
 WHERE id=199902610


   --row number: 14773

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3166979 , [Content] ='Engineering'
 WHERE id=199902611


   --row number: 14774

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3166979 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=199902612


   --row number: 14775

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3166979 , [Content] ='Software'
 WHERE id=199902613


   --row number: 14776

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3166979 , [Content] ='IC2'
 WHERE id=199902614


   --row number: 14777

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3166979 , [Content] ='INR'
 WHERE id=199902616


   --row number: 14778

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3166979 , [Content] ='1,000,000 / 1,225,000 / 1,450,000 / 1,675,000 / 1,900,000'
 WHERE id=199902617


   --row number: 14779

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3166979 , [Content] ='10%'
 WHERE id=199902619


   --row number: 14780

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3166979 , [Content] ='No'
 WHERE id=199902620


   --row number: 14781

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3166979 , [Content] ='2 - Professionals'
 WHERE id=199902621


   --row number: 14782

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3166979 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=199902622


   --row number: 14783

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3166979 , [Content] ='Technical'
 WHERE id=199902623


   --row number: 14784

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3167197 , [Content] ='Yes'
 WHERE id=199934361


   --row number: 14785

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3167197 , [Content] ='Technical'
 WHERE id=199934364


   --row number: 14786

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3167197 , [Content] ='09/05/18'
 WHERE id=199934365


   --row number: 14787

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3167197 , [Content] ='4 - Sales Workers'
 WHERE id=199934362


   --row number: 14788

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3167197 , [Content] ='8742-Salespersons - Outside'
 WHERE id=199934363


   --row number: 14789

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3167197 , [Content] ='R3614B DEU'
 WHERE id=199934347


   --row number: 14790

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3167197 , [Content] ='DEU'
 WHERE id=199934348


   --row number: 14791

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3167197 , [Content] ='EMEA'
 WHERE id=199934349


   --row number: 14792

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3167197 , [Content] ='GERMANY'
 WHERE id=199934350


   --row number: 14793

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3167197 , [Content] ='Sales'
 WHERE id=199934351


   --row number: 14794

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3167197 , [Content] ='R3614B - Commercial Account Exec IC4'
 WHERE id=199934352


   --row number: 14795

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3167197 , [Content] ='Commercial Accounts'
 WHERE id=199934353


   --row number: 14796

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3167197 , [Content] ='IC4'
 WHERE id=199934354


   --row number: 14797

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3167197 , [Content] ='EUR'
 WHERE id=199934356


   --row number: 14798

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3167197 , [Content] ='70,125 / 76,313 / 82,500 / 88,688 / 94,875'
 WHERE id=199934357


   --row number: 14799

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3167197 , [Content] ='46,800 / 65,400 / 84,000 / 102,000 / 120,000'
 WHERE id=199934358


   --row number: 14800

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3167197 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=199934359


   --row number: 14801

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3167197 , [Content] ='50/50'
 WHERE id=199934360


   --row number: 14802

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3167214 , [Content] ='5693 UK'
 WHERE id=199935346


   --row number: 14803

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3167214 , [Content] ='UK'
 WHERE id=199935347


   --row number: 14804

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3167214 , [Content] ='EMEA'
 WHERE id=199935348


   --row number: 14805

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3167214 , [Content] ='UNITED KINGDOM'
 WHERE id=199935349


   --row number: 14806

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3167214 , [Content] ='No'
 WHERE id=199935359


   --row number: 14807

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3167214 , [Content] ='2 - Professionals'
 WHERE id=199935360


   --row number: 14808

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3167214 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199935361


   --row number: 14809

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3167214 , [Content] ='Technical'
 WHERE id=199935362


   --row number: 14810

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3167214 , [Content] ='09/05/18'
 WHERE id=199935363


   --row number: 14811

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3167214 , [Content] ='Customer Support'
 WHERE id=199935350


   --row number: 14812

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3167214 , [Content] ='5693 - Support Account Services Mgr IC3'
 WHERE id=199935351


   --row number: 14813

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3167214 , [Content] ='SAM Services'
 WHERE id=199935352


   --row number: 14814

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3167214 , [Content] ='IC3'
 WHERE id=199935353


   --row number: 14815

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3167214 , [Content] ='GBP'
 WHERE id=199935355


   --row number: 14816

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3167214 , [Content] ='39,900 / 46,500 / 53,100 / 59,650 / 66,200'
 WHERE id=199935356


   --row number: 14817

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3167214 , [Content] ='43,900 / 51,150 / 58,400 / 65,600 / 72,800'
 WHERE id=199935357


   --row number: 14818

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3167214 , [Content] ='10%'
 WHERE id=199935358


   --row number: 14819

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3167298 , [Content] ='5874 UK'
 WHERE id=199942003


   --row number: 14820

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3167298 , [Content] ='UK'
 WHERE id=199942004


   --row number: 14821

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3167298 , [Content] ='EMEA'
 WHERE id=199942005


   --row number: 14822

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3167298 , [Content] ='UNITED KINGDOM'
 WHERE id=199942006


   --row number: 14823

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3167298 , [Content] ='Professional Services'
 WHERE id=199942007


   --row number: 14824

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3167298 , [Content] ='5874 - Engagement Mgr IC4'
 WHERE id=199942008


   --row number: 14825

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3167298 , [Content] ='Engagement Mgrs'
 WHERE id=199942009


   --row number: 14826

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3167298 , [Content] ='IC4'
 WHERE id=199942010


   --row number: 14827

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3167298 , [Content] ='GBP'
 WHERE id=199942012


   --row number: 14828

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3167298 , [Content] ='49,800 / 60,200 / 70,600 / 81,050 / 91,500'
 WHERE id=199942013


   --row number: 14829

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3167298 , [Content] ='60,000 / 82,800 / 105,600 / 129,000 / 152,400'
 WHERE id=199942014


   --row number: 14830

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3167298 , [Content] ='59,800 / 72,250 / 84,700 / 97,250 / 109,800'
 WHERE id=199942015


   --row number: 14831

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3167298 , [Content] ='20%'
 WHERE id=199942016


   --row number: 14832

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3167298 , [Content] ='Yes'
 WHERE id=199942017


   --row number: 14833

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3167298 , [Content] ='2 - Professionals'
 WHERE id=199942018


   --row number: 14834

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3167298 , [Content] ='8810-Clerical Office Employees'
 WHERE id=199942019


   --row number: 14835

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3167298 , [Content] ='Technical'
 WHERE id=199942020


   --row number: 14836

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3167298 , [Content] ='09/05/18'
 WHERE id=199942021


   --row number: 14837

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168224 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=200018138


   --row number: 14838

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168224 , [Content] ='140,250 / 152,625 / 165,000 / 177,375 / 189,750'
 WHERE id=200018139


   --row number: 14839

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3168224 , [Content] ='75/25'
 WHERE id=200018140


   --row number: 14840

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168224 , [Content] ='Yes'
 WHERE id=200018141


   --row number: 14841

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168224 , [Content] ='EXEMPT'
 WHERE id=200018142


   --row number: 14842

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168224 , [Content] ='4 - Sales Workers'
 WHERE id=200018143


   --row number: 14843

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168224 , [Content] ='S1413 US - MRKT 3'
 WHERE id=200018127


   --row number: 14844

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168224 , [Content] ='US - MRKT 3'
 WHERE id=200018128


   --row number: 14845

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168224 , [Content] ='AMS'
 WHERE id=200018129


   --row number: 14846

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168224 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200018130


   --row number: 14847

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168224 , [Content] ='Solution Consulting'
 WHERE id=200018131


   --row number: 14848

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168224 , [Content] ='S1413 - Sr Solution Consultant IC3'
 WHERE id=200018132


   --row number: 14849

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168224 , [Content] ='Solution Consultant Core'
 WHERE id=200018133


   --row number: 14850

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168224 , [Content] ='IC3'
 WHERE id=200018134


   --row number: 14851

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168224 , [Content] ='USD'
 WHERE id=200018136


   --row number: 14852

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168224 , [Content] ='105,188 / 114,469 / 123,750 / 133,031 / 142,313'
 WHERE id=200018137


   --row number: 14853

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168224 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200018144


   --row number: 14854

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168224 , [Content] ='Technical'
 WHERE id=200018145


   --row number: 14855

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168224 , [Content] ='09/05/18'
 WHERE id=200018146


   --row number: 14856

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168721 , [Content] ='Yes'
 WHERE id=200062668


   --row number: 14857

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168721 , [Content] ='EXEMPT'
 WHERE id=200062669


   --row number: 14858

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168721 , [Content] ='NO'
 WHERE id=200062670


   --row number: 14859

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168721 , [Content] ='4 - Sales Workers'
 WHERE id=200062671


   --row number: 14860

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168721 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200062672


   --row number: 14861

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168721 , [Content] ='Technical'
 WHERE id=200062673


   --row number: 14862

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168721 , [Content] ='09/05/18'
 WHERE id=200062674


   --row number: 14863

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168721 , [Content] ='USD'
 WHERE id=200062663


   --row number: 14864

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168721 , [Content] ='127,500 / 138,750 / 150,000 / 161,250 / 172,500'
 WHERE id=200062664


   --row number: 14865

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168721 , [Content] ='60,000 / 70,800 / 81,600 / 93,000 / 104,400'
 WHERE id=200062665


   --row number: 14866

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168721 , [Content] ='212,500 / 231,250 / 250,000 / 268,750 / 287,500'
 WHERE id=200062666


   --row number: 14867

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3168721 , [Content] ='60/40'
 WHERE id=200062667


   --row number: 14868

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168721 , [Content] ='S713 US - MRKT 1'
 WHERE id=200062654


   --row number: 14869

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168721 , [Content] ='US - MRKT 1'
 WHERE id=200062655


   --row number: 14870

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168721 , [Content] ='AMS'
 WHERE id=200062656


   --row number: 14871

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168721 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200062657


   --row number: 14872

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168721 , [Content] ='Sales - MSP'
 WHERE id=200062658


   --row number: 14873

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168721 , [Content] ='Enterprise Accounts - MSP'
 WHERE id=200062660


   --row number: 14874

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168721 , [Content] ='IC3'
 WHERE id=200062661


   --row number: 14875

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168721 , [Content] ='S713 - Enterprise Account Exec - MSP IC3'
 WHERE id=200062659


   --row number: 14876

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3168724 , [Content] ='50/50'
 WHERE id=200063073


   --row number: 14877

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168724 , [Content] ='Yes'
 WHERE id=200063074


   --row number: 14878

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168724 , [Content] ='EXEMPT'
 WHERE id=200063075


   --row number: 14879

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168724 , [Content] ='NO'
 WHERE id=200063076


   --row number: 14880

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168724 , [Content] ='1.2 - First/Mid-Level Officials and Managers'
 WHERE id=200063077


   --row number: 14881

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168724 , [Content] ='8742-Salespersons - Outside'
 WHERE id=200063078


   --row number: 14882

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168724 , [Content] ='Technical'
 WHERE id=200063079


   --row number: 14883

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168724 , [Content] ='09/05/18'
 WHERE id=200063080


   --row number: 14884

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168724 , [Content] ='S315 US - MRKT 1'
 WHERE id=200063060


   --row number: 14885

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168724 , [Content] ='US - MRKT 1'
 WHERE id=200063061


   --row number: 14886

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168724 , [Content] ='AMS'
 WHERE id=200063062


   --row number: 14887

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168724 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200063063


   --row number: 14888

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168724 , [Content] ='Sales'
 WHERE id=200063064


   --row number: 14889

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168724 , [Content] ='S315 - Dir, Sales M5'
 WHERE id=200063065


   --row number: 14890

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168724 , [Content] ='Sales Management'
 WHERE id=200063066


   --row number: 14891

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168724 , [Content] ='M5'
 WHERE id=200063067


   --row number: 14892

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168724 , [Content] ='USD'
 WHERE id=200063069


   --row number: 14893

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168724 , [Content] ='159,375 / 173,438 / 187,500 / 201,563 / 215,625'
 WHERE id=200063070


   --row number: 14894

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168724 , [Content] ='144,000 / 216,000 / 288,000 / 360,000 / 432,000'
 WHERE id=200063071


   --row number: 14895

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168724 , [Content] ='318,750 / 346,875 / 375,000 / 403,125 / 431,250'
 WHERE id=200063072


   --row number: 14896

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168781 , [Content] ='Yes'
 WHERE id=200068843


   --row number: 14897

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168781 , [Content] ='EXEMPT'
 WHERE id=200068844


   --row number: 14898

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168781 , [Content] ='NO'
 WHERE id=200068845


   --row number: 14899

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168781 , [Content] ='2 - Professionals'
 WHERE id=200068846


   --row number: 14900

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168781 , [Content] ='8810-Clerical Office Employees'
 WHERE id=200068847


   --row number: 14901

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168781 , [Content] ='Non Technical'
 WHERE id=200068848


   --row number: 14902

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168781 , [Content] ='09/05/18'
 WHERE id=200068849


   --row number: 14903

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168781 , [Content] ='6633 US - MRKT 2'
 WHERE id=200068829


   --row number: 14904

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168781 , [Content] ='US - MRKT 2'
 WHERE id=200068830


   --row number: 14905

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168781 , [Content] ='AMS'
 WHERE id=200068831


   --row number: 14906

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168781 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200068832


   --row number: 14907

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168781 , [Content] ='Administration'
 WHERE id=200068833


   --row number: 14908

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168781 , [Content] ='6633 - Project/Program Manager IC3'
 WHERE id=200068834


   --row number: 14909

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168781 , [Content] ='Project/Program Mgrs'
 WHERE id=200068835


   --row number: 14910

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168781 , [Content] ='IC3'
 WHERE id=200068836


   --row number: 14911

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168781 , [Content] ='USD'
 WHERE id=200068838


   --row number: 14912

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168781 , [Content] ='73,800 / 85,950 / 98,100 / 110,300 / 122,500'
 WHERE id=200068839


   --row number: 14913

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168781 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200068840


   --row number: 14914

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168781 , [Content] ='81,200 / 94,550 / 107,900 / 121,350 / 134,800'
 WHERE id=200068841


   --row number: 14915

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3168781 , [Content] ='10%'
 WHERE id=200068842


   --row number: 14916

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168806 , [Content] ='5182 US - MRKT 1'
 WHERE id=200070027


   --row number: 14917

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168806 , [Content] ='US - MRKT 1'
 WHERE id=200070028


   --row number: 14918

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168806 , [Content] ='Yes'
 WHERE id=200070041


   --row number: 14919

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168806 , [Content] ='EXEMPT'
 WHERE id=200070042


   --row number: 14920

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168806 , [Content] ='NO'
 WHERE id=200070043


   --row number: 14921

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168806 , [Content] ='2 - Professionals'
 WHERE id=200070044


   --row number: 14922

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168806 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200070045


   --row number: 14923

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168806 , [Content] ='Technical'
 WHERE id=200070046


   --row number: 14924

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168806 , [Content] ='09/05/18'
 WHERE id=200070047


   --row number: 14925

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168806 , [Content] ='AMS'
 WHERE id=200070029


   --row number: 14926

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168806 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200070030


   --row number: 14927

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168806 , [Content] ='Engineering'
 WHERE id=200070031


   --row number: 14928

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168806 , [Content] ='5182 - Software QA Engineer IC2'
 WHERE id=200070032


   --row number: 14929

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168806 , [Content] ='Quality'
 WHERE id=200070033


   --row number: 14930

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168806 , [Content] ='IC2'
 WHERE id=200070034


   --row number: 14931

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168806 , [Content] ='USD'
 WHERE id=200070036


   --row number: 14932

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168806 , [Content] ='87,700 / 102,150 / 116,600 / 131,100 / 145,600'
 WHERE id=200070037


   --row number: 14933

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168806 , [Content] ='51,000 / 64,500 / 78,000 / 91,500 / 105,000'
 WHERE id=200070038


   --row number: 14934

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168806 , [Content] ='96,500 / 112,400 / 128,300 / 144,250 / 160,200'
 WHERE id=200070039


   --row number: 14935

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3168806 , [Content] ='10%'
 WHERE id=200070040


   --row number: 14936

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3168893 , [Content] ='15%'
 WHERE id=200082479


   --row number: 14937

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168893 , [Content] ='Yes'
 WHERE id=200082480


   --row number: 14938

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168893 , [Content] ='EXEMPT'
 WHERE id=200082481


   --row number: 14939

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168893 , [Content] ='NO'
 WHERE id=200082482


   --row number: 14940

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168893 , [Content] ='2 - Professionals'
 WHERE id=200082483


   --row number: 14941

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168893 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200082484


   --row number: 14942

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168893 , [Content] ='Technical'
 WHERE id=200082485


   --row number: 14943

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168893 , [Content] ='09/05/18'
 WHERE id=200082486


   --row number: 14944

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168893 , [Content] ='5143 US - MRKT 1'
 WHERE id=200082457


   --row number: 14945

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168893 , [Content] ='US - MRKT 1'
 WHERE id=200082458


   --row number: 14946

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168893 , [Content] ='AMS'
 WHERE id=200082459


   --row number: 14947

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168893 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200082460


   --row number: 14948

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168893 , [Content] ='Engineering'
 WHERE id=200082461


   --row number: 14949

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168893 , [Content] ='5143 - Sr Software Engineer IC3'
 WHERE id=200082466


   --row number: 14950

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168893 , [Content] ='Software'
 WHERE id=200082467


   --row number: 14951

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168893 , [Content] ='IC3'
 WHERE id=200082469


   --row number: 14952

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168893 , [Content] ='USD'
 WHERE id=200082472


   --row number: 14953

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168893 , [Content] ='108,800 / 128,400 / 148,000 / 167,550 / 187,100'
 WHERE id=200082476


   --row number: 14954

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168893 , [Content] ='108,000 / 144,000 / 180,000 / 216,000 / 252,000'
 WHERE id=200082477


   --row number: 14955

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168893 , [Content] ='125,100 / 147,650 / 170,200 / 192,700 / 215,200'
 WHERE id=200082478


   --row number: 14956

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168922 , [Content] ='Yes'
 WHERE id=200085289


   --row number: 14957

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168922 , [Content] ='EXEMPT'
 WHERE id=200085290


   --row number: 14958

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168922 , [Content] ='NO'
 WHERE id=200085291


   --row number: 14959

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168922 , [Content] ='2 - Professionals'
 WHERE id=200085292


   --row number: 14960

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168922 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200085293


   --row number: 14961

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168922 , [Content] ='Technical'
 WHERE id=200085294


   --row number: 14962

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168922 , [Content] ='09/05/18'
 WHERE id=200085295


   --row number: 14963

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168922 , [Content] ='5142 US - MRKT 1'
 WHERE id=200085275


   --row number: 14964

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168922 , [Content] ='US - MRKT 1'
 WHERE id=200085276


   --row number: 14965

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168922 , [Content] ='AMS'
 WHERE id=200085277


   --row number: 14966

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168922 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200085278


   --row number: 14967

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168922 , [Content] ='Engineering'
 WHERE id=200085279


   --row number: 14968

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168922 , [Content] ='5142 - Software Engineer IC2'
 WHERE id=200085280


   --row number: 14969

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168922 , [Content] ='Software'
 WHERE id=200085281


   --row number: 14970

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168922 , [Content] ='IC2'
 WHERE id=200085282


   --row number: 14971

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168922 , [Content] ='USD'
 WHERE id=200085284


   --row number: 14972

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168922 , [Content] ='91,700 / 106,850 / 122,000 / 137,100 / 152,200'
 WHERE id=200085285


   --row number: 14973

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168922 , [Content] ='86,400 / 115,200 / 144,000 / 172,800 / 201,600'
 WHERE id=200085286


   --row number: 14974

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168922 , [Content] ='100,900 / 117,550 / 134,200 / 150,800 / 167,400'
 WHERE id=200085287


   --row number: 14975

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3168922 , [Content] ='10%'
 WHERE id=200085288


   --row number: 14976

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3168924 , [Content] ='Yes'
 WHERE id=200085640


   --row number: 14977

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3168924 , [Content] ='EXEMPT'
 WHERE id=200085641


   --row number: 14978

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3168924 , [Content] ='NO'
 WHERE id=200085642


   --row number: 14979

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87516 , itemid=3168924 , [Content] ='2 - Professionals'
 WHERE id=200085643


   --row number: 14980

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87517 , itemid=3168924 , [Content] ='8859-Computer Programming or Software Development'
 WHERE id=200085644


   --row number: 14981

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=87518 , itemid=3168924 , [Content] ='Technical'
 WHERE id=200085645


   --row number: 14982

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=134049 , itemid=3168924 , [Content] ='09/05/18'
 WHERE id=200085646


   --row number: 14983

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69938 , itemid=3168924 , [Content] ='5183 US - MRKT 2'
 WHERE id=200085626


   --row number: 14984

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58882 , itemid=3168924 , [Content] ='US - MRKT 2'
 WHERE id=200085627


   --row number: 14985

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=39373 , itemid=3168924 , [Content] ='AMS'
 WHERE id=200085628


   --row number: 14986

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=70430 , itemid=3168924 , [Content] ='UNITED STATES OF AMERICA'
 WHERE id=200085629


   --row number: 14987

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40093 , itemid=3168924 , [Content] ='Engineering'
 WHERE id=200085630


   --row number: 14988

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40094 , itemid=3168924 , [Content] ='5183 - Sr Software QA Engineer IC3'
 WHERE id=200085631


   --row number: 14989

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58880 , itemid=3168924 , [Content] ='Quality'
 WHERE id=200085632


   --row number: 14990

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40095 , itemid=3168924 , [Content] ='IC3'
 WHERE id=200085633


   --row number: 14991

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=133434 , itemid=3168924 , [Content] ='USD'
 WHERE id=200085635


   --row number: 14992

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69931 , itemid=3168924 , [Content] ='80,900 / 95,450 / 110,000 / 124,550 / 139,100'
 WHERE id=200085636


   --row number: 14993

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=40104 , itemid=3168924 , [Content] ='72,000 / 87,000 / 102,000 / 117,000 / 132,000'
 WHERE id=200085637


   --row number: 14994

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3168924 , [Content] ='93,000 / 109,750 / 126,500 / 143,250 / 160,000'
 WHERE id=200085638


   --row number: 14995

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69933 , itemid=3168924 , [Content] ='15%'
 WHERE id=200085639


   --row number: 14996

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=137510 , itemid=3169016 , [Content] ='318,750 / 346,875 / 375,000 / 403,125 / 431,250'
 WHERE id=200109549


   --row number: 14997

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=69930 , itemid=3169016 , [Content] ='50/50'
 WHERE id=200109550


   --row number: 14998

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=107219 , itemid=3169016 , [Content] ='Yes'
 WHERE id=200109551


   --row number: 14999

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58885 , itemid=3169016 , [Content] ='EXEMPT'
 WHERE id=200109552


   --row number: 15000

   UPDATE [T_CustomFieldContent]
   SET companyid=1159 , fieldid=58886 , itemid=3169016 , [Content] ='NO'
 WHERE id=200109553

